#!/usr/bin/env python3
"""
Name:          cli_brain_manager.py
Description:   Thin command-line wrapper over the Brain library family. Every call prints exactly one JSON object {ok, command, code, message, data}. Exit codes: 0 success, 20 environment problem (not initialised, path guard, lock timeout), 30 data/validation/schema problem.
Version:       1.0.0
Date Created:  2026-10-24
Author:        Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID: 462612db-8ccd-446f-bf8b-937b31009870
"""

import argparse
import json
import logging
import sys
from pathlib import Path

VERSION = "1.0.0"
RELATIONAL_ID = "462612db-8ccd-446f-bf8b-937b31009870"
SCRIPT_PATH = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_PATH.parent.parent            # CLI_AI project root (CLI/brain_cli/ -> root)
LIB_AI_DIR = PROJECT_ROOT / "lib" / "AI"
sys.path.insert(0, str(LIB_AI_DIR))

import lib_bejson_AI_brain_core_bridge  # noqa: E402,F401
from lib_bejson_AI_ai_console_log import setup_logging  # noqa: E402  (AI family logger: rotating file in dev/logs + WARNING+ console)
from lib_bejson_AI_brain_errors import BRAIN_ENVIRONMENT_CODES, BrainError  # noqa: E402
from lib_bejson_AI_brain_store import BrainStore  # noqa: E402
from lib_bejson_AI_brain_config import brain_config_load, brain_config_set  # noqa: E402
import lib_bejson_AI_brain_snapshots as snapshots  # noqa: E402
import lib_bejson_AI_brain_audit as audit  # noqa: E402

EXIT_OK, EXIT_ENVIRONMENT, EXIT_DATA = 0, 20, 30
ABOUT = {
    "name": "Brain", "description": "Persistent, versioned, snapshot-protected memory store for the AI chat client.",
    "version": VERSION, "date": "2026-10-24",
    "author": "Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton",
}


class JsonArgumentParser(argparse.ArgumentParser):
    # Argument errors become the same JSON envelope instead of a usage dump.
    def error(self, message):
        _emit(False, "arguments", 0, message, None)
        sys.exit(EXIT_DATA)


# Writes the single JSON result object.
def _emit(ok: bool, command: str, code: int, message: str, data) -> None:
    sys.stdout.write(json.dumps({"ok": ok, "command": command, "code": code, "message": message, "data": data}, indent=2, ensure_ascii=False) + "\n")


def _build_parser() -> argparse.ArgumentParser:
    parser = JsonArgumentParser(prog="cli_brain_manager.py", description="Brain memory manager (prints one JSON object).")
    parser.add_argument("--version", action="store_true", help="print the version and exit")
    parser.add_argument("--root", default=str(PROJECT_ROOT / "data" / "brain"), help="folder holding brain_mfdb/, brain_state/, snapshots/")
    parser.add_argument("--config-dir", default=str(LIB_AI_DIR / "config"), help="folder holding brain_limits.104a.bejson")
    parser.add_argument("--actor", choices=("user", "ai"), default="user")
    sub = parser.add_subparsers(dest="command")
    for name in ("about", "init", "status", "verify", "proposals", "snapshots", "config-show"):
        sub.add_parser(name)
    cats = sub.add_parser("categories"); cats.add_argument("--all", action="store_true")
    add = sub.add_parser("category-add"); add.add_argument("name"); add.add_argument("--description", default=""); add.add_argument("--keywords", default="")
    arch = sub.add_parser("category-archive"); arch.add_argument("category")
    mems = sub.add_parser("memories"); mems.add_argument("--category"); mems.add_argument("--status"); mems.add_argument("--text"); mems.add_argument("--all", action="store_true")
    get = sub.add_parser("memory-get"); get.add_argument("id")
    madd = sub.add_parser("memory-add")
    madd.add_argument("--category", default="General"); madd.add_argument("--title", required=True); madd.add_argument("--content", required=True)
    madd.add_argument("--keywords", default=""); madd.add_argument("--priority", type=int); madd.add_argument("--confidence", type=float); madd.add_argument("--pinned", action="store_true")
    mup = sub.add_parser("memory-update"); mup.add_argument("id")
    for flag in ("title", "content", "keywords", "category"):
        mup.add_argument(f"--{flag}")
    mup.add_argument("--priority", type=int); mup.add_argument("--confidence", type=float)
    mar = sub.add_parser("memory-archive"); mar.add_argument("id")
    pin = sub.add_parser("memory-pin"); pin.add_argument("id"); pin.add_argument("--off", action="store_true")
    for name in ("approve", "reject"):
        p = sub.add_parser(name); p.add_argument("id")
    snap = sub.add_parser("snapshot"); snap.add_argument("--tier", default="default", choices=snapshots.TIERS); snap.add_argument("--reason", default="manual")
    roll = sub.add_parser("rollback"); roll.add_argument("snapshot", help="<tier>/<filename> or a filename")
    aud = sub.add_parser("audit"); aud.add_argument("--count", type=int, default=20)
    cset = sub.add_parser("config-set"); cset.add_argument("name"); cset.add_argument("value")
    return parser


# Parses a config value typed on the command line: integers become int, everything else stays text.
def _parse_value(text: str):
    return int(text) if text.lstrip("-").isdigit() else text


def _run(args) -> tuple[str, object]:
    store = BrainStore(args.root, config_dir=args.config_dir)
    cmd = args.command
    if cmd == "about":
        return "About Brain", ABOUT
    if cmd == "init":
        created = store.init()
        return ("Database created." if created else "Database already exists."), {"created": created}
    if cmd == "config-show":
        return "Settings", store.limits
    if cmd == "config-set":
        return "Setting changed.", brain_config_set(args.config_dir, args.name, _parse_value(args.value))
    if cmd == "status":
        return "Status", store.status()
    if cmd == "verify":
        findings = store.verify()
        return ("Database verified." if not [f for f in findings if "error" in f] else "Problems found."), findings
    if cmd == "categories":
        return "Categories", store.categories(include_archived=args.all)
    if cmd == "category-add":
        return "Category created.", store.apply({"op": "category_create", "name": args.name, "description": args.description or args.name, "keywords": args.keywords}, args.actor)
    if cmd == "category-archive":
        return "Category archived.", store.apply({"op": "category_archive", "category": args.category}, args.actor)
    if cmd == "memories":
        return "Memories", store.memories(category=args.category, status=args.status, text=args.text, include_archived=args.all)
    if cmd == "memory-get":
        return "Memory", store.get_memory(args.id)
    if cmd == "memory-add":
        op = {"op": "memory_add", "category": args.category, "title": args.title, "content": args.content, "keywords": args.keywords, "pinned": args.pinned}
        for key in ("priority", "confidence"):
            if getattr(args, key) is not None:
                op[key] = getattr(args, key)
        return "Memory saved.", store.apply(op, args.actor)
    if cmd == "memory-update":
        fields = {k: getattr(args, k) for k in ("title", "content", "keywords", "category", "priority", "confidence") if getattr(args, k) is not None}
        return "Memory updated.", store.apply({"op": "memory_update", "id": args.id, "fields": fields}, args.actor)
    if cmd == "memory-archive":
        return "Memory archived.", store.apply({"op": "memory_archive", "id": args.id}, args.actor)
    if cmd == "memory-pin":
        return "Memory pin changed.", store.apply({"op": "memory_pin", "id": args.id, "pinned": not args.off}, args.actor)
    if cmd == "proposals":
        return "Proposals", store.proposals()
    if cmd in ("approve", "reject"):
        return f"Proposal {cmd}d.", store.apply({"op": f"proposal_{cmd}", "id": args.id}, args.actor)
    if cmd == "snapshots":
        return "Snapshots", snapshots.snapshots_list(store)
    if cmd == "snapshot":
        return "Snapshot saved.", snapshots.snapshots_create(store, args.tier, args.reason)
    if cmd == "rollback":
        return "Rolled back.", snapshots.snapshots_rollback(store, args.snapshot)
    if cmd == "audit":
        return "Audit trail", audit.brain_audit_tail(store.state_dir, args.count)
    raise BrainError(0, f"Unknown command {cmd}")


def main(argv=None) -> int:
    setup_logging(PROJECT_ROOT)
    parser = _build_parser()
    args = parser.parse_args(argv)
    if args.version:
        _emit(True, "version", 0, VERSION, ABOUT)
        return EXIT_OK
    if not args.command:
        _emit(False, "arguments", 0, "A command is required (try about, init, status).", None)
        return EXIT_DATA
    try:
        message, data = _run(args)
    except BrainError as exc:
        _emit(False, args.command, exc.code, exc.message, exc.to_dict())
        return EXIT_ENVIRONMENT if exc.code in BRAIN_ENVIRONMENT_CODES else EXIT_DATA
    except Exception as exc:  # noqa: BLE001 - the CLI must always answer with its JSON envelope
        logging.getLogger("brain.cli").exception("Unexpected failure")
        _emit(False, args.command, 0, f"Unexpected failure: {exc}", None)
        return EXIT_DATA
    _emit(True, args.command, 0, message, data)
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
