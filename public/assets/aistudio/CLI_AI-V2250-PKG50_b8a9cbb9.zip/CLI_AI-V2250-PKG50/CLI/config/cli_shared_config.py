"""
File:         cli_shared_config.py
Description:  Shared bootstrap for every *_cli tool in CLI_AI/CLI/. Reads
              cli_shared_config.104a.bejson (same folder) once and returns
              the resolved lib/Core, lib/AI, and lib/ paths, instead of
              each tool computing them independently via hardcoded
              relative Path math. Enforces portable_mode (prints a
              warning and exits if true -- portable mode is not
              implemented yet, matching client/app.py's guard) and
              exposes model_registry_source so each tool knows whether to
              list models from the unified registry (lib/ai_model_registry
              .bejson, default) or its own legacy per-provider registry.

              Import and call bootstrap() at the very top of a prompt_*.py,
              before importing any lib_bejson_* module -- bootstrap() is
              what puts lib/Core and lib/AI on sys.path in the first place.
Version:      1.1.0
Date Created: 2026-09-16
Author:       Elton Boehnen · boehnenelton2024@gmail.com
              boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID: 7c2e4f81-9b3d-4a6e-8f1c-5d0a2b8e6c93

Changelog:
  1.1.0 (2026-09-16) -- Fixed schema: was using a generic
        (setting_name, setting_value: "any", description) key/value table.
        "any" is not a valid BEJSON field type under any format (confirmed
        against CRASH_COURSE_23_OFFICIAL.md -- valid types are exactly
        string/integer/number/boolean/array/object, nothing else, ever).
        Rewritten to one field per setting with its own real type
        (portable_mode: boolean, library_path: string,
        model_registry_source: string) and a single Values row, matching
        every other real *_cli_config.104a.bejson in this project (e.g.
        groq_cli_config.104a.bejson). _load_or_init()'s field-name-driven
        matching required no logic changes -- only _SCHEMA needed fixing.
"""

import json
import os
import sys
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parent          # CLI/config/
CLI_ROOT = CONFIG_DIR.parent                           # CLI/
SHARED_CONFIG_PATH = CONFIG_DIR / "cli_shared_config.104a.bejson"

DEFAULT_VALUES = {
    "portable_mode": False,
    "library_path": "../../lib/",
    "model_registry_source": "unified",
}

_SCHEMA = {
    "Format": "BEJSON",
    "Format_Version": "104a",
    "Format_Creator": "Elton Boehnen",
    "Schema_Name": "CLISharedConfig",
    "Records_Type": ["CLIConfig"],
    "Fields": [
        {"name": "portable_mode", "type": "boolean"},
        {"name": "library_path", "type": "string"},
        {"name": "model_registry_source", "type": "string"},
    ],
    "Values": [
        [False, "../../lib/", "unified"],
    ],
}


def _load_or_init() -> dict:
    """Load cli_shared_config.104a.bejson, creating it with defaults if missing."""
    if not SHARED_CONFIG_PATH.exists():
        os.makedirs(SHARED_CONFIG_PATH.parent, exist_ok=True)
        with open(SHARED_CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(_SCHEMA, f, indent=2)
        return dict(DEFAULT_VALUES)

    try:
        with open(SHARED_CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        fields = [fld.get("name") for fld in data.get("Fields", [])]
        values = data.get("Values", [])
        if not values:
            return dict(DEFAULT_VALUES)
        row = values[0]
        cfg = dict(DEFAULT_VALUES)
        for i, name in enumerate(fields):
            if name in cfg and i < len(row):
                cfg[name] = row[i]
        return cfg
    except Exception:
        # Malformed file -- fall back to built-in defaults rather than crash
        # every CLI tool at import time.
        return dict(DEFAULT_VALUES)


def bootstrap(cli_dir: Path) -> dict:
    """
    Resolve CORE_DIR/AI_DIR/LIB_DIR from the shared config, insert them
    into sys.path, enforce the portable_mode guard, and return a dict of
    resolved values for the calling tool to use.

    cli_dir: the calling tool's own CLI_DIR (Path(__file__).resolve().parent),
    kept as a parameter (rather than inferred) so this stays correct no
    matter how deep a given tool's own folder nesting is.
    """
    cfg = _load_or_init()

    if cfg.get("portable_mode") is True:
        print(
            "WARNING: portable_mode is set to true in "
            f"{SHARED_CONFIG_PATH}, but portable mode is not yet "
            "implemented for CLI tools. Set it back to false and use "
            "library_path to point at the shared lib/ directory. Exiting.",
            file=sys.stderr,
        )
        sys.exit(1)

    lib_path_setting = cfg.get("library_path") or DEFAULT_VALUES["library_path"]
    lib_path = Path(lib_path_setting)
    if not lib_path.is_absolute():
        lib_path = (CONFIG_DIR / lib_path).resolve()

    core_dir = lib_path / "Core"
    ai_dir = lib_path / "AI"
    ai_model_registry_path = lib_path / "ai_model_registry.bejson"

    for p in (str(lib_path), str(core_dir), str(ai_dir)):
        if p not in sys.path:
            sys.path.insert(0, p)

    return {
        "PROJECT_ROOT": lib_path.parent,
        "LIB_DIR": lib_path,
        "CORE_DIR": core_dir,
        "AI_DIR": ai_dir,
        "PORTABLE_MODE": cfg.get("portable_mode", False),
        "MODEL_REGISTRY_SOURCE": cfg.get("model_registry_source", "unified"),
        "AI_MODEL_REGISTRY_PATH": ai_model_registry_path,
    }
