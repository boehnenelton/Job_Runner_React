"""
Tool:           prompt_gemini.py
Family:         CLI
Description:    Interactive, stateful command-line chat client for Gemini's
                 Interactions API -- mirrors the groq_cli / openrouter_cli /
                 provocative_cli tooling pattern (BEJSON 104a config preset,
                 secure-env key sourcing, credited About/Info) but built on
                 lib_bejson_AI_bejson_interactions.py instead of a one-shot
                 prompt(): multi-turn via previous_interaction_id, plus
                 Gemini function/tool calling wired to the tools/ directory
                 (20 tools ported from the Flask_Gemini_Interactions project
                 -- tool_def.json + system_instruction.md per tool).

                 Tool execution mirrors that project's /api/tool_exec route:
                 each tool call is a sub-interaction (GeminiInteractionsAPI.
                 tool_direct()) using the tool's own system_instruction.md,
                 not local Python execution -- these are generation/analysis
                 tools (BEJSON validator, decomposer, component generator,
                 etc.), not side-effecting functions.
Version:        1.5.0
Date:           2026-09-16
Author:         Elton Boehnen
Contact:        eltonboehnen@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  c42bf816-f8c7-4db1-b64c-51694c11ef8f

Changelog:
  1.5.0 (2026-09-16) -- Path resolution now goes through the shared
        CLI/config/cli_shared_config.py bootstrap (portable_mode guard +
        library_path) instead of hardcoded relative Path math. No model
        listing feature exists in this tool yet, so MODEL_REGISTRY_SOURCE/
        AI_MODEL_REGISTRY_PATH are resolved for consistency with the other
        CLI tools but not yet acted on here.
  1.4.0 (2026-09-09) -- Wired BEJSON 104db structured output detection into
        run_turn(). When the bejson_104db_generator profile (or any AI
        response) returns a valid 104db document, auto_parse_bejson_104db()
        detects, validates, and unpacks the file hierarchy to
        data/structured_output/<project_name>/. User sees a notification
        with project name, version, file count, and output path.
  1.3.0 (2026-09-04) -- Profile injection wired into standalone main().
        Imports lib_bejson_AI_gemini_standard_profiles from the shared AI
        lib dir. If Profiles_Enabled is true, the active profile's
        System_Instruction overrides the config/--system default (explicit
        --system flag still takes priority). Profile name shown in the
        session header. Falls back silently on any load error.
  1.2.0 (2026-08-19) -- Wired into the shared lib_bejson_AI_ai_console_log
        root-logger setup (file log at dev/logs/cli_ai.log) and gained a
        broad except + KeyboardInterrupt guard around the standalone entry
        point (run_gemini_chat() in prompt_menu.py already had its own
        guard as of that file's 1.2.0 — this covers direct invocation of
        this script too). Also fixes a pre-existing header/VERSION-const
        mismatch (header said 1.0.0, VERSION said "1.1.0" -- both now say
        1.2.0, consistent with Sec 9's single-VERSION-var rule).
"""

import logging
import sys
import os
import json
import argparse
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Setup paths to ensure lib/Core and lib/AI are importable, via the shared
# CLI config instead of hardcoded relative path math.
CLI_DIR = Path(__file__).resolve().parent
CLI_ROOT = CLI_DIR.parent  # CLI_AI/CLI/ -- all *_cli tool folders live here

_CONFIG_DIR = CLI_ROOT / "config"
if str(_CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(_CONFIG_DIR))
from cli_shared_config import bootstrap as _cli_bootstrap

_SHARED = _cli_bootstrap(CLI_DIR)
PROJECT_ROOT = _SHARED["PROJECT_ROOT"]  # CLI_AI/ -- lib/, reports/, tests/, etc.
CORE_DIR = _SHARED["CORE_DIR"]
AI_DIR = _SHARED["AI_DIR"]
MODEL_REGISTRY_SOURCE = _SHARED["MODEL_REGISTRY_SOURCE"]
AI_MODEL_REGISTRY_PATH = _SHARED["AI_MODEL_REGISTRY_PATH"]

# Mandatory Environment & BEJSON Imports
from lib_bejson_Core_bejson_env import source_env, resolve_path
from lib_bejson_Core_bejson_core import bejson_core_load_file, bejson_core_atomic_write, bejson_core_get_field_map
from lib_bejson_AI_bejson_interactions import get_standard_interactions_api, GeminiInteractionsAPI
from lib_bejson_AI_ai_call_log import log_ai_call
import lib_bejson_AI_ai_console_log as console_log

console_log.setup_logging(PROJECT_ROOT)
_logger = logging.getLogger("cli_ai.gemini")

# Profile injection support
try:
    from lib_bejson_AI_gemini_standard_profiles import (
        gemini_profiles_is_enabled,
        gemini_profiles_get_selected,
    )
    import lib_bejson_Core_bejson_core as _bejson_core_pg
    _PROFILES_CONFIG = str(PROJECT_ROOT / "profiles" / "config" / "profile_config.104a.bejson")
    _PROFILES_STORE  = str(PROJECT_ROOT / "profiles" / "profiles")
    _PROFILES_AVAILABLE = True
except ImportError:
    _PROFILES_AVAILABLE = False
    _PROFILES_CONFIG = ""
    _PROFILES_STORE  = ""

VERSION = "1.5.0"

DEFAULT_SECURE_ENV = "/storage/emulated/0/.env/secure/secureenv_file.py"
CONFIG_FILE_PATH = CLI_DIR / "gemini_cli_config.104a.bejson"
TOOLS_DIR = CLI_DIR / "tools"

# BEJSON 104a Schema for CLI Configuration Preset
SCHEMA_CLI_CONFIG = {
    "Format": "BEJSON",
    "Format_Version": "104a",
    "Format_Creator": "Elton Boehnen",
    "Schema_Name": "GeminiInteractiveCLIConfig",
    "Records_Type": ["CLIConfig"],
    "Fields": [
        {"name": "env_file_path", "type": "string"},
        {"name": "default_model_id", "type": "string"},
        {"name": "default_system_instruction", "type": "string"},
        {"name": "tools_enabled_by_default", "type": "boolean"},
        {"name": "max_function_call_rounds", "type": "integer"},
        {"name": "show_thought_by_default", "type": "boolean"}
    ],
    "Values": [
        [
            DEFAULT_SECURE_ENV,
            "gemini-3.6-flash",
            "You are a helpful assistant. Provide clear, accurate, and concise information.",
            True,
            5,
            False
        ]
    ]
}


def ensure_config_preset() -> dict:
    """Ensures the BEJSON 104a config file exists on first run with default presets."""
    if not CONFIG_FILE_PATH.exists():
        os.makedirs(CONFIG_FILE_PATH.parent, exist_ok=True)
        bejson_core_atomic_write(str(CONFIG_FILE_PATH), SCHEMA_CLI_CONFIG)
        print(f"[+] Initialized BEJSON 104a config file at: {CONFIG_FILE_PATH}")

    try:
        data = bejson_core_load_file(str(CONFIG_FILE_PATH))
        fmap = bejson_core_get_field_map(data)
        values = data.get("Values", [])[0]
        return {
            "env_file_path": values[fmap.get("env_file_path", 0)],
            "default_model_id": values[fmap.get("default_model_id", 1)],
            "default_system_instruction": values[fmap.get("default_system_instruction", 2)],
            "tools_enabled_by_default": values[fmap.get("tools_enabled_by_default", 3)],
            "max_function_call_rounds": values[fmap.get("max_function_call_rounds", 4)],
            "show_thought_by_default": values[fmap.get("show_thought_by_default", 5)]
        }
    except Exception as e:
        print(f"[!] Warning: Failed to parse {CONFIG_FILE_PATH}, using built-in defaults: {e}")
        return {
            "env_file_path": DEFAULT_SECURE_ENV,
            "default_model_id": "gemini-3.6-flash",
            "default_system_instruction": "You are a helpful assistant. Provide clear, accurate, and concise information.",
            "tools_enabled_by_default": True,
            "max_function_call_rounds": 5,
            "show_thought_by_default": False
        }


# --- Tool loading (mirrors Flask_Gemini_Service.py's api_tools() scan) -----

def load_tools(tools_dir: Path) -> Tuple[List[Dict[str, Any]], Dict[str, str]]:
    """
    Scans tools_dir for <tool_name>/tool_def.json (+ optional
    system_instruction.md). Returns:
      - interactions_tools: flat Interactions-API tool declarations
        ({"type":"function","name",...} -- the tool_def.json content as-is;
        these files are already flat per the API's format, NOT the
        generateContent-style {"function_declarations":[...]} wrapper).
      - si_map: tool_name -> system_instruction.md text, used by the tool
        executor to run the tool as its own sub-interaction.
    """
    interactions_tools: List[Dict[str, Any]] = []
    si_map: Dict[str, str] = {}
    if not tools_dir.exists():
        return interactions_tools, si_map

    for folder in sorted(tools_dir.iterdir()):
        if not folder.is_dir():
            continue
        def_file = folder / "tool_def.json"
        if not def_file.exists():
            continue
        try:
            with open(def_file, "r", encoding="utf-8") as f:
                tool_def = json.load(f)
        except Exception as e:
            print(f"[!] Warning: failed to load {def_file}: {e}")
            continue

        name = tool_def.get("name", folder.name)
        # Interactions API tool declarations are flat {"type":"function",...} --
        # ensure "type" is present even if a tool_def.json omits it.
        decl = dict(tool_def)
        decl.setdefault("type", "function")
        interactions_tools.append(decl)

        si_file = folder / "system_instruction.md"
        if si_file.exists():
            try:
                si_map[name] = si_file.read_text(encoding="utf-8")
            except Exception as e:
                print(f"[!] Warning: failed to read {si_file}: {e}")

    return interactions_tools, si_map


def extract_text(interaction: Dict[str, Any]) -> str:
    """
    Concatenates all text content from a finished interaction.

    CORRECTED 2026-08-15 against ai.google.dev/api/interactions-api
    (fetched live). The Interaction resource has NO "outputs" field --
    that was wrong in the first cut of this file. The real shape is
    "steps" (array of Step); a text reply arrives as a step of type
    "model_output" wrapping a nested "content" array of Content blocks,
    e.g. {"type":"model_output","content":[{"type":"text","text":"..."}]}.
    Confirmed against every example response in the official reference.
    """
    text = ""
    for step in interaction.get("steps", []):
        if step.get("type") == "model_output":
            for block in step.get("content", []):
                if block.get("type") == "text":
                    text += block.get("text", "")
    return text


def extract_thought(interaction: Dict[str, Any]) -> str:
    """
    Best-effort extraction of thought/reasoning summaries, if present.

    NOTE: the official reference's non-streaming Step type list was too
    long to fetch in full and got cut off before confirming an exact
    "ThoughtStep" shape (the streaming SSE side documents
    ThoughtSummaryDelta with a nested "content" Content block, which
    suggests the non-streaming equivalent is a step carrying a similar
    "content" or "summary" field, but this is not independently
    confirmed against a live call). Checks a couple of plausible shapes
    defensively rather than asserting one field name with confidence.
    """
    thought = ""
    for step in interaction.get("steps", []):
        if step.get("type") in ("thought", "thought_summary"):
            if "summary" in step:
                thought += step.get("summary", "") or ""
            for block in step.get("content", []) or []:
                if isinstance(block, dict) and block.get("type") == "text":
                    thought += block.get("text", "")
    return thought


def make_tool_executor(api: GeminiInteractionsAPI, model_id: str, si_map: Dict[str, str]):
    """
    Builds the tool_executor callback passed to GeminiInteractionsAPI.chat().
    Mirrors Flask_Gemini_Service.py's /api/tool_exec: each tool call becomes
    its own sub-interaction via tool_direct() with the tool's
    system_instruction.md, and the extracted text is returned as the
    function_result content -- these tools are generation/analysis prompts,
    not locally-executed side-effecting functions.
    """
    def _executor(name: str, args: Dict[str, Any]) -> str:
        si = si_map.get(name, "")
        prompt = f"Execute the {name} tool with these parameters:\n{json.dumps(args, indent=2)}"
        try:
            result_interaction = api.tool_direct(si, prompt, model_id=model_id)
        except Exception as e:
            return f"ERROR executing tool '{name}': {e}"
        text = extract_text(result_interaction)
        return text or f"[No text output from {name}]"
    return _executor


def print_tool_list(tools: List[Dict[str, Any]]) -> None:
    print("\n--- Available Gemini Tools ---")
    for idx, t in enumerate(tools, 1):
        print(f"{idx:2d}. {t.get('name')} -- {t.get('description', '')[:90]}")


def run_turn(
    api: GeminiInteractionsAPI,
    user_input: str,
    *,
    model_id: str,
    system_instruction: Optional[str],
    tools: Optional[List[Dict[str, Any]]],
    tool_executor,
    previous_interaction_id: Optional[str],
    max_rounds: int,
    show_thought: bool,
) -> Optional[str]:
    """Runs one turn of the chat loop and prints the result. Returns the new
    previous_interaction_id (or the old one, unchanged, on failure).

    After printing the response text, automatically detects BEJSON 104db
    structured output and unpacks it to data/structured_output/<project_name>/.
    """
    try:
        interaction = api.chat(
            user_input,
            tools=tools,
            tool_executor=tool_executor,
            model_id=model_id,
            system_instruction=system_instruction,
            previous_interaction_id=previous_interaction_id,
            max_rounds=max_rounds,
        )
    except Exception as e:
        print(f"\n[!] Turn failed: {e}")
        log_ai_call("gemini", user_input, f"ERROR: {e}")
        return previous_interaction_id

    text = extract_text(interaction)
    print(f"\nGemini: {text}")
    if show_thought:
        thought = extract_thought(interaction)
        if thought:
            print(f"\n--- Reasoning / Thought Summary ---\n{thought}")

    # ── Structured Output Detection (BEJSON 104db) ────────────────────────
    # Detects if the AI response contains a valid BEJSON 104db document
    # (e.g., from the bejson_104db_generator profile) and auto-unpacks the
    # file hierarchy to data/structured_output/<project_name>/.
    try:
        from lib_bejson_AI_ai_response import auto_parse_bejson_104db
        output_base = str(PROJECT_ROOT / "data" / "structured_output")
        meta, count, out_dir = auto_parse_bejson_104db(text, output_base)
        if meta and count > 0:
            proj = meta.get("project_name", "unknown")
            ver = meta.get("version", "?")
            print(f"\n[+] BEJSON 104db structured output detected!")
            print(f"    Project : {proj} v{ver}")
            print(f"    Files   : {count} written")
            print(f"    Output  : {out_dir}")
            _logger.info("Structured output unpacked: %s v%s -> %s (%d files)",
                         proj, ver, out_dir, count)
    except Exception as so_err:
        _logger.warning("Structured output detection error: %s", so_err)
    # ─────────────────────────────────────────────────────────────────────

    log_ai_call("gemini", user_input, text)
    return interaction.get("id") or previous_interaction_id


def main():
    config = ensure_config_preset()

    env_path = resolve_path(config["env_file_path"])
    if not source_env(env_path):
        source_env(DEFAULT_SECURE_ENV)

    parser = argparse.ArgumentParser(
        description="Interactive CLI chat client for Gemini's Interactions API, with function/tool calling."
    )
    parser.add_argument(
        "prompt",
        nargs="?",
        help="Optional first message. If given without --once, the session continues interactively after the reply."
    )
    parser.add_argument("-m", "--model", type=str, default=None,
                         help=f"Model ID to use (default from preset: {config['default_model_id']}).")
    parser.add_argument("-s", "--system", type=str, default=None,
                         help="System instruction override.")
    parser.add_argument("--no-tools", action="store_true",
                         help="Disable function/tool calling for this session.")
    parser.add_argument("-l", "--list-tools", action="store_true",
                         help="List available tools and exit.")
    parser.add_argument("-i", "--info", action="store_true",
                         help="Display loaded API keys, model, and tool registry info.")
    parser.add_argument("--show-thought", action="store_true",
                         default=config["show_thought_by_default"],
                         help="Display reasoning/thought summaries if available.")
    parser.add_argument("--once", action="store_true",
                         help="Send the positional prompt as a single turn and exit (no REPL).")

    args = parser.parse_args()

    api = get_standard_interactions_api()
    selected_model = args.model or config.get("default_model_id") or api.models.active_model_id
    system_instruction = args.system or config.get("default_system_instruction")
    # --- Profile injection ---------------------------------------------------
    # Explicit --system flag always wins. Otherwise try active profile if
    # Profiles_Enabled is true; fall back to config default last.
    profile_label = None
    if not args.system and _PROFILES_AVAILABLE:
        try:
            if gemini_profiles_is_enabled(_PROFILES_CONFIG):
                selected = gemini_profiles_get_selected(_PROFILES_CONFIG)
                if selected:
                    import json
                    from pathlib import Path as _Path
                    prof_file = _Path(_PROFILES_STORE) / f"{selected}.bejson"
                    if prof_file.exists():
                        doc = json.loads(prof_file.read_text(encoding="utf-8"))
                        fm = _bejson_core_pg.bejson_core_get_field_map(doc)
                        si_idx = fm.get("System_Instruction", -1)
                        if si_idx != -1 and doc.get("Values"):
                            instr = doc["Values"][0][si_idx]
                            if instr:
                                system_instruction = instr
                                profile_label = selected
                                _logger.info("Profile injection: '%s' -> %d chars",
                                             selected, len(instr))
        except Exception as _pe:
            _logger.error("profile injection error in prompt_gemini: %s", _pe)
    # -------------------------------------------------------------------------

    tools_enabled = config.get("tools_enabled_by_default", True) and not args.no_tools
    max_rounds = config.get("max_function_call_rounds", 5)

    interactions_tools, si_map = load_tools(TOOLS_DIR) if tools_enabled else ([], {})
    tool_executor = make_tool_executor(api, selected_model, si_map) if interactions_tools else None

    if args.info:
        print("--- Gemini Interactions CLI Info ---")
        print("Author / Creator : Elton Boehnen (boehnenelton2024@gmail.com)")
        print(f"Config File      : {CONFIG_FILE_PATH}")
        print(f"Env File Sourced : {env_path}")
        print(f"API Keys Loaded  : {len(api.keys.keys)}")
        print(f"Active Model     : {selected_model}")
        print(f"Total Models     : {len(api.models.models)}")
        print(f"Tools Enabled    : {tools_enabled}")
        print(f"Tools Loaded     : {len(interactions_tools)}")
        print(f"Max Call Rounds  : {max_rounds}")
        print(f"Profile Inject   : {profile_label or 'disabled'}")
        if not args.prompt and not args.list_tools:
            return

    if args.list_tools:
        print_tool_list(interactions_tools)
        if not args.prompt:
            return

    if not interactions_tools and tools_enabled:
        print(f"[!] Tools were enabled but none were found under {TOOLS_DIR}.")

    previous_id: Optional[str] = None

    if args.prompt:
        previous_id = run_turn(
            api, args.prompt,
            model_id=selected_model, system_instruction=system_instruction,
            tools=interactions_tools or None, tool_executor=tool_executor,
            previous_interaction_id=previous_id, max_rounds=max_rounds,
            show_thought=args.show_thought,
        )
        if args.once:
            return

    print(f"\n[*] Interactive session started -- model: {selected_model} | "
          f"tools: {'on' if tools_enabled else 'off'}"
          f"{' | profile: ' + profile_label if profile_label else ''} | "
          f"Commands: /exit  /reset  /tools  /model <id>  /help\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not user_input:
            continue
        if user_input in ("/exit", "/quit"):
            break
        if user_input == "/reset":
            previous_id = None
            print("[*] Conversation reset.")
            continue
        if user_input == "/tools":
            print_tool_list(interactions_tools)
            continue
        if user_input.startswith("/model "):
            selected_model = user_input.split(" ", 1)[1].strip() or selected_model
            print(f"[*] Model switched to: {selected_model}")
            continue
        if user_input == "/help":
            print("[*] Commands: /exit  /reset  /tools  /model <id>  /help")
            continue

        previous_id = run_turn(
            api, user_input,
            model_id=selected_model, system_instruction=system_instruction,
            tools=interactions_tools or None, tool_executor=tool_executor,
            previous_interaction_id=previous_id, max_rounds=max_rounds,
            show_thought=args.show_thought,
        )


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
    except Exception as fatal_error:  # noqa: BLE001 -- last-resort guard so a
        # bug surfaces as a clean colored line + a logged traceback instead
        # of a raw stack trace on the user's terminal.
        _logger.error("fatal error in prompt_gemini main()", exc_info=True)
        console_log.error(f"fatal error: {fatal_error}")
        sys.exit(1)
