"""
Tool:           prompt_huggingface.py
Family:         CLI
Description:    Command-line interface tool to test and prompt Hugging Face
                 Inference Providers (OpenAI-compatible router at
                 router.huggingface.co) using credentials sourced from
                 secure environment files and BEJSON 104a configuration
                 presets. Mirrors prompt_provocative.py / prompt_groq.py /
                 prompt_openrouter.py.
Version:        1.2.0
Date:           2026-09-16
Author:         Elton Boehnen
Contact:        eltonboehnen@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  0f5d8b3a-2e9c-4a1d-9f6e-7b4c3a8d2e91

Changelog:
  1.2.0 (2026-09-16) -- Path resolution now goes through the shared
        CLI/config/cli_shared_config.py bootstrap (portable_mode guard +
        library_path) instead of hardcoded relative Path math. Added a
        model_registry_source switch: --list-models reads from the
        unified lib/ai_model_registry.bejson (service key "HuggingFace")
        by default, falling back to prompter.model_reg.models (legacy)
        if set to "legacy" or the unified registry has no entries yet.
  1.1.0 (2026-08-19) -- Colored output pass (matches prompt_menu.py's
        DE2626 theme via the new shared lib_bejson_AI_ai_console_log.py),
        plus a broad except + KeyboardInterrupt guard around main().
  1.0.0 (2026-08-16) -- Initial creation.
"""

import logging
import sys
import os
import argparse
from pathlib import Path

CLI_DIR = Path(__file__).resolve().parent
CLI_ROOT = CLI_DIR.parent  # CLI_AI/CLI/ -- all *_cli tool folders live here

_CONFIG_DIR = CLI_ROOT / "config"
if str(_CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(_CONFIG_DIR))
from cli_shared_config import bootstrap as _cli_bootstrap

_SHARED = _cli_bootstrap(CLI_DIR)
PROJECT_ROOT = _SHARED["PROJECT_ROOT"]  # CLI_AI/ -- lib/, reports/, tests/, etc.
CORE_DIR = _SHARED["CORE_DIR"]
AI_DIR = _SHARED["AI_DIR"]
MODEL_REGISTRY_SOURCE = _SHARED["MODEL_REGISTRY_SOURCE"]
AI_MODEL_REGISTRY_PATH = _SHARED["AI_MODEL_REGISTRY_PATH"]

from lib_bejson_Core_bejson_env import source_env, resolve_path
from lib_bejson_Core_bejson_core import bejson_core_load_file, bejson_core_atomic_write, bejson_core_get_field_map
from lib_bejson_AI_ai_dispatch import ai_dispatch_call
from lib_bejson_AI_bejson_huggingface import get_standard_prompter
from lib_bejson_AI_ai_call_log import log_ai_call
import lib_bejson_AI_ai_console_log as console_log

console_log.setup_logging(PROJECT_ROOT)
_logger = logging.getLogger("cli_ai.huggingface")

VERSION = "1.2.0"

DEFAULT_SECURE_ENV = "/storage/emulated/0/.env/secure/secureenv_file.py"
CONFIG_FILE_PATH = CLI_DIR / "huggingface_cli_config.104a.bejson"

SCHEMA_CLI_CONFIG = {
    "Format": "BEJSON",
    "Format_Version": "104a",
    "Format_Creator": "Elton Boehnen",
    "Schema_Name": "HuggingFaceCLIConfig",
    "Records_Type": ["CLIConfig"],
    "Fields": [
        {"name": "env_file_path", "type": "string"},
        {"name": "default_model_id", "type": "string"},
        {"name": "default_system_instruction", "type": "string"},
        {"name": "show_thought_by_default", "type": "boolean"}
    ],
    "Values": [
        [
            DEFAULT_SECURE_ENV,
            "openai/gpt-oss-120b",
            "You are a helpful assistant. Provide clear, accurate, and concise information.",
            False
        ]
    ]
}


def ensure_config_preset() -> dict:
    if not CONFIG_FILE_PATH.exists():
        os.makedirs(CONFIG_FILE_PATH.parent, exist_ok=True)
        bejson_core_atomic_write(str(CONFIG_FILE_PATH), SCHEMA_CLI_CONFIG)
        console_log.ok(f"Initialized BEJSON 104a config file at: {CONFIG_FILE_PATH}")

    try:
        data = bejson_core_load_file(str(CONFIG_FILE_PATH))
        fmap = bejson_core_get_field_map(data)
        values = data.get("Values", [])[0]
        return {
            "env_file_path": values[fmap.get("env_file_path", 0)],
            "default_model_id": values[fmap.get("default_model_id", 1)],
            "default_system_instruction": values[fmap.get("default_system_instruction", 2)],
            "show_thought_by_default": values[fmap.get("show_thought_by_default", 3)]
        }
    except Exception as e:
        _logger.warning("failed to parse %s, using built-in defaults: %s", CONFIG_FILE_PATH, e)
        console_log.warn(f"Failed to parse {CONFIG_FILE_PATH}, using built-in defaults: {e}")
        return {
            "env_file_path": DEFAULT_SECURE_ENV,
            "default_model_id": "openai/gpt-oss-120b",
            "default_system_instruction": "You are a helpful assistant. Provide clear, accurate, and concise information.",
            "show_thought_by_default": False
        }


def main():
    config = ensure_config_preset()

    env_path = resolve_path(config["env_file_path"])
    if not source_env(env_path):
        source_env(DEFAULT_SECURE_ENV)

    parser = argparse.ArgumentParser(
        description="CLI tool to test prompts against Hugging Face Inference Providers using BEJSON presets."
    )
    parser.add_argument("prompt", nargs="?", help="Prompt text to send to Hugging Face.")
    parser.add_argument("-m", "--model", type=str, default=None,
                         help=f"Model ID to use, as '<repo>' or '<repo>:<provider>' "
                              f"(default from preset: {config['default_model_id']}).")
    parser.add_argument("-s", "--system", type=str, default=None, help="System instruction override.")
    parser.add_argument("-l", "--list-models", action="store_true", help="List available Hugging Face models.")
    parser.add_argument("-i", "--info", action="store_true", help="Display loaded API keys and registry info.")
    parser.add_argument("--show-thought", action="store_true", default=config["show_thought_by_default"],
                         help="Display reasoning/thought process if available.")

    args = parser.parse_args()

    prompter = get_standard_prompter()

    if args.info:
        console_log.heading("--- Hugging Face Configuration Info ---")
        print("Author / Creator : Elton Boehnen (boehnenelton2024@gmail.com)")
        print(f"Config File      : {CONFIG_FILE_PATH}")
        print(f"Env File Sourced : {env_path}")
        print(f"API Keys Loaded  : {len(prompter.key_reg.keys)}")
        print(f"Active Model     : {prompter.model_reg.active_model_id}")
        print(f"Preset Model     : {config['default_model_id']}")
        print(f"Total Models     : {len(prompter.model_reg.models)}")
        if not args.prompt and not args.list_models:
            return

    if args.list_models:
        console_log.heading("--- Available Hugging Face Models ---")
        if MODEL_REGISTRY_SOURCE == "unified":
            from lib_ai_model_registry import AIModelRegistry
            unified_models = AIModelRegistry(str(AI_MODEL_REGISTRY_PATH), {}).load().get_models("HuggingFace")
            if unified_models:
                for idx, m in enumerate(unified_models, 1):
                    is_active = " (active)" if m["id"] == prompter.model_reg.active_model_id else ""
                    print(f"{idx:2d}. {m['id']}{is_active}")
            else:
                console_log.warn("No HuggingFace entries in the unified registry yet -- falling back to legacy.")
                for idx, m in enumerate(prompter.model_reg.models, 1):
                    is_active = " (active)" if m["id"] == prompter.model_reg.active_model_id else ""
                    print(f"{idx:2d}. {m['id']}{is_active}")
        else:
            for idx, m in enumerate(prompter.model_reg.models, 1):
                is_active = " (active)" if m["id"] == prompter.model_reg.active_model_id else ""
                print(f"{idx:2d}. {m['id']}{is_active}")
        if not args.prompt:
            return

    if not args.prompt:
        if not args.info and not args.list_models:
            parser.print_help()
        return

    selected_model = args.model or config.get("default_model_id") or prompter.model_reg.active_model_id
    system_instruction = args.system or config.get("default_system_instruction")

    console_log.ok(f"Prompting model: {selected_model}...")

    response = ai_dispatch_call(
        provider="huggingface",
        user_input=args.prompt,
        model_id=selected_model,
        system_instruction=system_instruction
    )

    if response.get("success"):
        console_log.heading("=== Response ===")
        print(response.get("content", ""))
        if args.show_thought and response.get("thought"):
            console_log.heading("=== Reasoning / Thought Process ===")
            print(response.get("thought"))
        log_ai_call("huggingface", args.prompt, response.get("content", ""))
    else:
        console_log.error(f"Prompt failed: {response.get('error')}")
        log_ai_call("huggingface", args.prompt, f"ERROR: {response.get('error')}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
    except Exception as fatal_error:  # noqa: BLE001 -- last-resort guard
        _logger.error("fatal error in prompt_huggingface main()", exc_info=True)
        console_log.error(f"fatal error: {fatal_error}")
        sys.exit(1)
