"""
Tool:           prompt_menu.py
Family:         CLI
Description:    DE2626-themed terminal menu wrapper over the four cli_test
                 AI CLI tools (groq_cli, openrouter_cli, grok_cli,
                 gemini_cli). Lets the user pick which service to chat
                 with from a menu, then runs a real interactive
                 back-and-forth chat session using that service's own
                 library underneath -- not a subprocess wrapper, so every
                 turn logs to the same shared BEJSON 104a call-log feed
                 (lib_bejson_AI_ai_call_log.py) as the individual CLIs do.

                 Groq/OpenRouter/Grok have no native multi-turn
                 state on the underlying API (each call is a fresh
                 single-turn chat completion), so this wrapper carries
                 conversation history itself and folds it into each
                 call's user_input as a rendered transcript. Gemini
                 (Interactions API, via gemini_cli.prompt_gemini) already
                 has native multi-turn state via previous_interaction_id
                 and its own tool-calling loop, so the menu just drives
                 gemini_cli's existing run_turn() directly.
Version:        1.10.0
Date:           2026-09-16
Author:         Elton Boehnen
Contact:        eltonboehnen@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  4a8d2e6f-9c1b-4a3d-8e7f-2b5c0a9d3f62

Changelog:
  1.10.0 (2026-09-16) -- NOTE: header Version was at 1.7.0 while the
        VERSION constant further down was already at 1.9.0 -- pre-existing
        drift, not something introduced by this change. Bumped both to
        1.10.0, above the higher of the two, per Elton's version-mismatch
        policy (flag, then adopt the higher as canonical baseline).
        Path resolution now goes through the shared
        CLI/config/cli_shared_config.py bootstrap (portable_mode guard +
        library_path) instead of hardcoded relative Path math -- only the
        two lib/Core+lib/AI entries were removed from the manual sys.path
        loop; GEMINI_CLI_DIR/TRANSCRIBE_CLI_DIR insertion is unchanged.
        run_model_config() ("m. Model config") now reads from the unified
        lib/ai_model_registry.bejson by default (model_registry_source
        switch), falling back to each service's own
        lib/AI/config/<service>_model_registry.104a.bejson if set to
        "legacy" or the unified registry has no entries yet for that
        service. Added CLI/config/cli_shared_config.104a.bejson and
        lib/ai_model_registry.bejson to CONFIG_FILES_TO_VALIDATE.
  1.7.0 (2026-09-04) -- Profile injection wired into all chat loops.
        load_active_profile_instruction() reads Profiles_Enabled and
        System_Instruction from the active profile via Field Map Cache;
        returns None silently on any failure so callers degrade gracefully.
        run_gemini_chat() and run_simple_chat() both call it and pass the
        result as system_instruction to their respective dispatch layers.
        Gemini/GenAI/Grok/HuggingFace honor it natively; Groq/OpenRouter
        report it in unsupported_params (dispatch contract unchanged).
  1.6.0 (2026-09-04) -- Added a "p" menu entry for AI Profile Config: lets the
        user enable/disable profile injection and select the active profile
        directly from the terminal (no Flask app required). Reads/writes
        profiles/config/profile_config.104a.bejson via the shared
        lib_bejson_AI_gemini_standard_profiles library. Purely additive;
        all existing entries, sessions, and helpers are unchanged.
  1.5.0 (2026-09-03) -- Added a "t" menu entry (alongside the existing "v"
        validate-configs entry) that runs the new transcribe_cli tool
        (CLI/transcribe_cli/prompt_transcribe.py) for a single file: prompts
        for a path and mode, then delegates to
        lib_bejson_AI_ai_transcribe_dispatch.ai_transcribe_dispatch()
        directly (not a subprocess), same "no subprocess wrapper" design as
        the existing service entries, so it logs to the same shared
        cli_ai.log call-log feed. Purely additive: SERVICES,
        CONFIG_FILES_TO_VALIDATE, print_menu()'s 1-N branch,
        run_validate_configs(), run_simple_chat(), and run_gemini_chat()
        are all unchanged.
  1.4.0 (2026-08-22) -- Fixed "Validate config files" (the "v" menu
        option): CONFIG_FILES_TO_VALIDATE only ever checked
        "lib/AI/gemini_model_registry.104a.bejson", the pre-registry-
        overhaul path -- Gemini's own library has read from
        lib/AI/config/gemini_model_registry.104a.bejson since the
        2026-08-22 self-contained-storage overhaul, so this validator was
        checking a dead, orphaned file and never validating any actual
        provider's live model registry (groq/openrouter/grok/huggingface
        were never checked at all). Updated to validate every current
        provider's real registry under lib/AI/config/, matching SERVICES.
        Deleted the orphaned lib/AI/gemini_model_registry.104a.bejson
        (verified nothing else in the project reads that path -- see
        docs/dead_code.md).
  1.3.0 (2026-08-21) -- Removed "provocative" from SERVICES/
        CONFIG_FILES_TO_VALIDATE (Provocative AI removed from the project
        entirely at Elton's request). Added "grok" (xAI) in its place.
        Docstring/comment mentions of "provocative" updated to "grok"
        throughout.
  1.2.0 (2026-08-19) -- Logging + hardening pass. main()'s per-service
        dispatch loop is now wrapped in a broad except so an unexpected
        error in one chat session (bad key, provider outage, a bug) logs
        a full traceback via the new lib_bejson_AI_ai_console_log root-
        logger setup and drops back to the service menu instead of
        killing the whole process. run_simple_chat()/run_gemini_chat()'s
        per-turn error path now also logs (previously print-only, no
        trace left behind). lib_bejson_Core_bejson_validator.py updated
        to 2.1.1 (rejects unrecognized Field "type" values -- see its own
        changelog).
  1.1.0 (2026-08-16) -- Added Hugging Face to the SERVICES menu (routes
        through the existing manual-transcript run_simple_chat(), same
        as groq/openrouter/grok).
  1.0.0 (2026-08-15) -- Initial creation.
"""

import logging
import sys
import os
from pathlib import Path
from typing import List, Tuple, Optional

CLI_DIR = Path(__file__).resolve().parent
CLI_ROOT = CLI_DIR.parent  # CLI_AI/CLI/ -- all *_cli tool folders live here

_CONFIG_DIR = CLI_ROOT / "config"
if str(_CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(_CONFIG_DIR))
from cli_shared_config import bootstrap as _cli_bootstrap

_SHARED = _cli_bootstrap(CLI_DIR)
PROJECT_ROOT = _SHARED["PROJECT_ROOT"]  # CLI_AI/ -- lib/, reports/, tests/, etc.
CORE_DIR = _SHARED["CORE_DIR"]
AI_DIR = _SHARED["AI_DIR"]
MODEL_REGISTRY_SOURCE = _SHARED["MODEL_REGISTRY_SOURCE"]
AI_MODEL_REGISTRY_PATH = _SHARED["AI_MODEL_REGISTRY_PATH"]
GEMINI_CLI_DIR = CLI_ROOT / "gemini_cli"
TRANSCRIBE_CLI_DIR = CLI_ROOT / "transcribe_cli"
PROFILES_DIR = PROJECT_ROOT / "profiles"
PROFILES_CONFIG_FILE = str(PROFILES_DIR / "config" / "profile_config.104a.bejson")
PROFILES_STORE = str(PROFILES_DIR / "profiles")

for p in (GEMINI_CLI_DIR, TRANSCRIBE_CLI_DIR):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from lib_bejson_Core_bejson_env import source_env
from lib_bejson_AI_ai_dispatch import ai_dispatch_call
from lib_bejson_AI_ai_transcribe_dispatch import ai_transcribe_dispatch
from lib_bejson_AI_ai_call_log import log_ai_call
import lib_bejson_AI_ai_console_log as console_log
from lib_bejson_AI_gemini_standard_profiles import (
    gemini_profiles_load_config,
    gemini_profiles_get_config_value,
    gemini_profiles_is_enabled,
    gemini_profiles_get_selected,
)
import lib_bejson_Core_bejson_core as _bejson_core

console_log.setup_logging(PROJECT_ROOT)
_logger = logging.getLogger("cli_ai.menu")

# NOTE (2026-09-03): this const said "1.0.0" while the header above said
# "1.4.0" -- the same header/VERSION-const mismatch prompt_gemini.py fixed
# in its own 1.2.0 (see that file's changelog). Corrected here to match the
# header while making this change, since this file is already being edited.
VERSION = "1.10.0"

DEFAULT_SECURE_ENV = "/storage/emulated/0/.env/secure/secureenv_file.py"
MAX_HISTORY_TURNS = 6  # per service, to bound prompt growth in the manual-transcript services

# --- DE2626 terminal theme -------------------------------------------------
RED = "\033[38;2;222;38;38m"
DIM_RED = "\033[38;2;140;24;24m"
WHITE = "\033[97m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"

BANNER = f"""{RED}{BOLD}
   ______ __    ____   __  ___
  / ____// /   /  _/  / |/  /___  ____  __  __
 / /    / /    / /   /    /|_  /|_  / / / / / /
/ /___ / /____/ /   / /|  / /_/ / / /_/ /_/ /_/
\\____//_____/___/  /_/ |_/____/ /____(_)__/__/
{RESET}{WHITE}{DIM}  Elton Boehnen  ·  boehnenelton2024.pages.dev  ·  github.com/boehnenelton{RESET}
"""

SERVICES = [
    ("groq", "Groq"),
    ("openrouter", "OpenRouter"),
    ("grok", "Grok (xAI)"),
    ("huggingface", "Hugging Face (Inference Providers)"),
    ("openai", "OpenAI (GPT-4o, GPT-4o-mini, etc.)"),
    ("tokenrouter", "TokenRouter (z-ai/glm-5.3-free, etc.)"),
    ("ollama", "Ollama Cloud API"),
    ("gemini", "Gemini (Interactions API + tool calling)"),
]

CONFIG_FILES_TO_VALIDATE = [
    "CLI/config/cli_shared_config.104a.bejson",
    "CLI/groq_cli/groq_cli_config.104a.bejson",
    "CLI/openrouter_cli/openrouter_cli_config.104a.bejson",
    "CLI/grok_cli/grok_cli_config.104a.bejson",
    "CLI/huggingface_cli/huggingface_cli_config.104a.bejson",
    "CLI/openai_cli/openai_cli_config.104a.bejson",
    "CLI/tokenrouter_cli/tokenrouter_cli_config.104a.bejson",
    "CLI/ollama_cli/ollama_cli_config.104a.bejson",
    "CLI/gemini_cli/gemini_cli_config.104a.bejson",
    "lib/ai_model_registry.bejson",
    "lib/AI/config/groq_model_registry.104a.bejson",
    "lib/AI/config/openrouter_model_registry.104a.bejson",
    "lib/AI/config/grok_model_registry.104a.bejson",
    "lib/AI/config/huggingface_model_registry.104a.bejson",
    "lib/AI/config/openai_model_registry.104a.bejson",
    "lib/AI/config/tokenrouter_model_registry.104a.bejson",
    "lib/AI/config/ollama_keys.104a.bejson",
    "lib/AI/config/ollama_model_registry.104a.bejson",
    "lib/AI/config/gemini_model_registry.104a.bejson",
]

TRANSCRIBE_MODES = ["verbatim", "diarization"]


def source_default_env():
    if not source_env(DEFAULT_SECURE_ENV):
        # Individual CLI tools re-source from their own BEJSON config on
        # top of this if needed; this covers the menu's own dispatch calls.
        pass


def _profile_status_line() -> str:
    """Returns a one-line status string showing current profile config."""
    try:
        enabled = gemini_profiles_is_enabled(PROFILES_CONFIG_FILE)
        selected = gemini_profiles_get_selected(PROFILES_CONFIG_FILE)
        flag = f"{RED}ON{RESET}" if enabled else f"{DIM}OFF{RESET}"
        return f"  {DIM}Profile injection: {flag}  active: {WHITE}{selected}{RESET}"
    except Exception:
        return f"  {DIM}Profile injection: unavailable{RESET}"


def print_menu() -> Optional[str]:
    print(BANNER)
    print(_profile_status_line())
    print()
    print(f"{RED}{BOLD}Pick a service:{RESET}")
    for idx, (key, label) in enumerate(SERVICES, 1):
        print(f"  {WHITE}{idx}{RESET}. {label}")
    print(f"  {WHITE}v{RESET}. Validate config files (BEJSON structural check)")
    print(f"  {WHITE}t{RESET}. Transcribe an audio/video file (Gemini)")
    print(f"  {WHITE}p{RESET}. Profile config (enable/disable · select profile)")
    print(f"  {WHITE}m{RESET}. Model config (select default model for a service)")
    print(f"  {DIM}0. Exit{RESET}\n")

    choice = input(f"{RED}>{RESET} ").strip()
    if choice in ("0", "q", "quit", "exit"):
        return None
    if choice.lower() == "v":
        return "__validate__"
    if choice.lower() == "t":
        return "__transcribe__"
    if choice.lower() == "p":
        return "__profiles__"
    if choice.lower() == "m":
        return "__models__"
    try:
        idx = int(choice)
        if 1 <= idx <= len(SERVICES):
            return SERVICES[idx - 1][0]
    except ValueError:
        pass
    print(f"{DIM_RED}[!] Invalid choice.{RESET}\n")
    return print_menu()


def run_validate_configs():
    """Structurally validates every service's BEJSON 104a config/registry
    file with the Core validator (2.1.1) -- catches things like a corrupt
    config.json, a bad hand-edit, or (as of 2.1.1) a Field declared with
    an unrecognized "type" that previously passed silently."""
    try:
        import lib_bejson_Core_bejson_validator as validator
    except ImportError as import_error:
        print(f"{DIM_RED}[!] validator library unavailable: {import_error}{RESET}")
        _logger.error("validator import failed: %s", import_error)
        return

    print(f"\n{RED}{BOLD}-- Validating config files --{RESET}\n")
    failure_count = 0
    checked_count = 0
    for rel_path in CONFIG_FILES_TO_VALIDATE:
        file_path = PROJECT_ROOT / rel_path
        if not file_path.exists():
            print(f"  {DIM}(skip, not found) {rel_path}{RESET}")
            continue
        checked_count += 1
        result = validator.validate_bejson(str(file_path), is_file=True)
        if result.valid:
            print(f"  {WHITE}[ok]{RESET}   {rel_path}")
        else:
            failure_count += 1
            print(f"  {DIM_RED}[FAIL]{RESET} {rel_path} — {'; '.join(result.errors)}")
            _logger.error("config validation failed for %s: %s", rel_path, result.errors)
    print()
    if failure_count:
        print(f"{DIM_RED}{failure_count}/{checked_count} file(s) failed validation.{RESET}\n")
    else:
        print(f"{WHITE}all {checked_count} file(s) passed validation.{RESET}\n")


# --- Manual-transcript chat loop (groq / openrouter / grok) --------------

def render_history(history: List[Tuple[str, str]]) -> str:
    lines = []
    for role, text in history[-(MAX_HISTORY_TURNS * 2):]:
        speaker = "User" if role == "user" else "Assistant"
        lines.append(f"{speaker}: {text}")
    return "\n".join(lines)


def run_simple_chat(service: str, label: str):
    """
    Drives groq/openrouter/grok/genai/grok/huggingface through ai_dispatch_call,
    one single-turn call per exchange, with locally-carried history folded
    into user_input as a rendered transcript. Profile injection is honored
    for providers that support per-call system_instruction (gemini/genai/grok/
    huggingface); Groq and OpenRouter report it in unsupported_params.
    """
    # Profile injection — read once per session.
    profile_instruction = load_active_profile_instruction()
    profile_tag = ""
    if profile_instruction:
        selected = gemini_profiles_get_selected(PROFILES_CONFIG_FILE)
        profile_tag = f" | profile: {RED}{selected}{RESET}{DIM}"

    print(f"\n{RED}{BOLD}-- {label} --{RESET}  "
          f"{DIM}(/exit to return to menu, /reset to clear history{profile_tag}){RESET}\n")
    history: List[Tuple[str, str]] = []

    while True:
        try:
            user_input = input(f"{WHITE}You:{RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not user_input:
            continue
        if user_input in ("/exit", "/quit"):
            break
        if user_input == "/reset":
            history = []
            print(f"{DIM}[*] Conversation reset.{RESET}")
            continue

        context = render_history(history)
        full_input = f"{context}\nUser: {user_input}\nAssistant:" if context else user_input

        try:
            response = ai_dispatch_call(
                provider=service,
                user_input=full_input,
                model_id=None,
                system_instruction=profile_instruction,
            )
        except Exception as dispatch_error:  # noqa: BLE001 -- ai_dispatch_call's own
            # contract says it never raises for provider-side failures, only
            # programmer error (unknown provider). This guard exists for that
            # remaining case plus any future adapter that breaks the contract,
            # so one bad turn doesn't kill the whole chat session.
            _logger.error("%s dispatch raised unexpectedly", service, exc_info=True)
            print(f"\n{DIM_RED}[!] internal error: {dispatch_error}{RESET}\n")
            log_ai_call(service, user_input, f"ERROR: {dispatch_error}")
            continue

        if response.get("success"):
            text = response.get("content", "").strip()
            # Some models echo a leading "Assistant:" from the transcript framing.
            if text.startswith("Assistant:"):
                text = text[len("Assistant:"):].strip()
            print(f"\n{RED}{label}:{RESET} {text}\n")

            if response.get("unpacked_files_written", 0) > 0:
                out_dir = response.get("unpacked_output_dir")
                count = response.get("unpacked_files_written")
                print(f"{RED}[*] 104db Project Extracted:{RESET} Restored {count} file(s) -> {WHITE}{out_dir}{RESET}\n")

            log_ai_call(service, user_input, text)
            history.append(("user", user_input))
            history.append(("assistant", text))
        else:
            err = response.get("error", "unknown error")
            print(f"\n{DIM_RED}[!] {err}{RESET}\n")
            _logger.error("%s call failed: %s", service, err)
            log_ai_call(service, user_input, f"ERROR: {err}")


# --- Transcribe session (delegates to ai_transcribe_dispatch directly) ---

def run_transcribe_session():
    """
    Prompts for a media file path + mode, then calls
    ai_transcribe_dispatch() directly (not a subprocess) -- same "drive the
    library, not a subprocess wrapper" design as run_simple_chat()/
    run_gemini_chat(), so every request logs to the same shared
    cli_ai.log call-log feed via lib_bejson_AI_ai_call_log.
    """
    print(f"\n{RED}{BOLD}-- Transcribe (Gemini) --{RESET}  {DIM}(blank path to return to menu){RESET}\n")

    while True:
        try:
            raw_path = input(f"{WHITE}File path:{RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        if not raw_path:
            return

        file_path = Path(raw_path).expanduser().absolute()
        if not file_path.exists():
            print(f"{DIM_RED}[!] File not found: {file_path}{RESET}\n")
            continue

        mode_input = input(f"{WHITE}Mode{RESET} [{'/'.join(TRANSCRIBE_MODES)}] (default verbatim): ").strip().lower()
        mode = mode_input if mode_input in TRANSCRIBE_MODES else "verbatim"

        print(f"{DIM}[*] Transcribing {file_path.name} ({mode})...{RESET}")
        response = ai_transcribe_dispatch("gemini", file_path, mode=mode)

        log_label = f"transcribe:{file_path.name}"
        if response.get("success"):
            transcript = response.get("content", "")
            print(f"\n{RED}Transcript:{RESET}\n{transcript}\n")
            log_ai_call("gemini", log_label, transcript)
        else:
            err = response.get("error", "unknown error")
            print(f"\n{DIM_RED}[!] {err}{RESET}\n")
            _logger.error("transcribe failed for %s: %s", file_path, err)
            log_ai_call("gemini", log_label, f"ERROR: {err}")


# --- Profile Config submenu -----------------------------------------------

def run_profile_config():
    """
    Terminal submenu for AI profile persistent configuration.
    Reads and writes profiles/config/profile_config.104a.bejson via
    lib_bejson_AI_gemini_standard_profiles (Field Map Cache; no hardcoded
    positional indices). Changes take effect immediately for the next CLI
    call that checks is_enabled / get_selected.
    """
    import json
    from pathlib import Path

    cfg_path = Path(PROFILES_CONFIG_FILE)
    prof_store = Path(PROFILES_STORE)

    def _load():
        """Load config doc with field map attached."""
        try:
            with open(cfg_path, "r", encoding="utf-8") as fh:
                doc = json.load(fh)
            doc["_field_map"] = _bejson_core.bejson_core_get_field_map(doc)
            return doc
        except Exception as exc:
            _logger.error("profile_config load failed: %s", exc)
            return None

    def _save(doc):
        """Atomically write doc (strip _field_map)."""
        out = {k: v for k, v in doc.items() if k != "_field_map"}
        if not _bejson_core.bejson_core_atomic_write(str(cfg_path), out):
            print(f"{DIM_RED}[!] Atomic write failed for profile config.{RESET}")
            return False
        return True

    def _cfg_set(doc, key, value):
        """Set Config_Value for a Config_Key via Field Map Cache."""
        fm = doc["_field_map"]
        k_idx = fm.get("Config_Key", -1)
        v_idx = fm.get("Config_Value", -1)
        if k_idx == -1 or v_idx == -1:
            return False
        for row in doc.get("Values", []):
            if len(row) > max(k_idx, v_idx) and row[k_idx] == key:
                row[v_idx] = value
                return True
        return False

    def _list_profiles():
        try:
            return sorted(
                [f.stem for f in prof_store.glob("*.bejson")],
                key=lambda n: (n != "default", n)
            )
        except Exception:
            return []

    print(f"\n{RED}{BOLD}-- Profile Config --{RESET}  {DIM}(blank to return to menu){RESET}\n")

    while True:
        doc = _load()
        if doc is None:
            print(f"{DIM_RED}[!] Could not load profile config. Is the profiles/ directory initialised?{RESET}\n")
            return

        enabled = gemini_profiles_is_enabled(PROFILES_CONFIG_FILE)
        selected = gemini_profiles_get_selected(PROFILES_CONFIG_FILE)
        profiles = _list_profiles()

        flag = f"{RED}ON{RESET}" if enabled else f"{DIM}OFF{RESET}"
        print(f"  Injection: {flag}   Active profile: {WHITE}{selected}{RESET}")
        print()
        print(f"  {WHITE}1{RESET}. Toggle profile injection ({flag})")
        print(f"  {WHITE}2{RESET}. Select active profile  (current: {WHITE}{selected}{RESET})")
        print(f"  {DIM}blank / 0 — return to menu{RESET}\n")

        try:
            choice = input(f"{RED}>{RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        if not choice or choice in ("0", "q", "quit"):
            return

        if choice == "1":
            new_val = "false" if enabled else "true"
            doc = _load()
            if doc and _cfg_set(doc, "Profiles_Enabled", new_val) and _save(doc):
                state = "enabled" if new_val == "true" else "disabled"
                print(f"{WHITE}[ok]{RESET} Profile injection {state}.\n")
                _logger.info("Profile injection set to %s", new_val)
            else:
                print(f"{DIM_RED}[!] Could not update Profiles_Enabled.{RESET}\n")

        elif choice == "2":
            if not profiles:
                print(f"{DIM_RED}[!] No profiles found in {prof_store}{RESET}\n")
                continue
            print(f"\n  Available profiles:")
            for i, name in enumerate(profiles, 1):
                marker = f" {RED}←{RESET}" if name == selected else ""
                print(f"  {WHITE}{i}{RESET}. {name}{marker}")
            print()
            try:
                sel_input = input(f"{RED}>{RESET} Profile name or number: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if not sel_input:
                continue
            # Accept number or name
            new_profile = sel_input
            try:
                idx = int(sel_input)
                if 1 <= idx <= len(profiles):
                    new_profile = profiles[idx - 1]
                else:
                    print(f"{DIM_RED}[!] Index out of range.{RESET}\n")
                    continue
            except ValueError:
                pass  # treat as literal name
            if new_profile not in profiles:
                print(f"{DIM_RED}[!] Profile '{new_profile}' not found.{RESET}\n")
                continue
            doc = _load()
            if doc and _cfg_set(doc, "Selected_Profile", new_profile) and _save(doc):
                print(f"{WHITE}[ok]{RESET} Active profile set to '{new_profile}'.\n")
                _logger.info("Selected_Profile set to %s", new_profile)
            else:
                print(f"{DIM_RED}[!] Could not update Selected_Profile.{RESET}\n")

        else:
            print(f"{DIM_RED}[!] Invalid choice.{RESET}\n")


# --- Model Config submenu -------------------------------------------------

def run_model_config():
    """
    Terminal submenu for selecting the default active model for any service.
    Reads the service's model registry for available models and updates
    the default_model_id in its CLI config.
    """
    print(f"\n{RED}{BOLD}-- Model Config --{RESET}  {DIM}(blank to return to menu){RESET}\n")
    
    print("Select a service to configure:")
    for idx, (key, label) in enumerate(SERVICES, 1):
        print(f"  {WHITE}{idx}{RESET}. {label}")
    
    try:
        choice = input(f"\n{RED}>{RESET} ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
        
    if not choice:
        return
    
    try:
        idx = int(choice)
        if not (1 <= idx <= len(SERVICES)):
            print(f"{DIM_RED}[!] Invalid choice.{RESET}\n")
            return
        service_key = SERVICES[idx - 1][0]
    except ValueError:
        print(f"{DIM_RED}[!] Invalid choice.{RESET}\n")
        return

    # Load the registry to get models. model_registry_source == "unified"
    # (default) reads from the shared lib/ai_model_registry.bejson -- the
    # same source the chat client uses -- falling back to each service's
    # own dedicated legacy registry file if the switch is "legacy" or the
    # unified registry has no entries yet for this service.
    _UNIFIED_SERVICE_NAMES = {
        "groq": "Groq", "openrouter": "OpenRouter", "grok": "Grok",
        "huggingface": "HuggingFace", "openai": "OpenAI",
        "tokenrouter": "TokenRoute", "ollama": "Ollama", "gemini": "Gemini",
    }
    models = []
    if MODEL_REGISTRY_SOURCE == "unified":
        try:
            from lib_ai_model_registry import AIModelRegistry
            unified_reg = AIModelRegistry(str(AI_MODEL_REGISTRY_PATH), {}).load()
            models = [m["id"] for m in unified_reg.get_models(_UNIFIED_SERVICE_NAMES.get(service_key, ""))]
        except Exception as e:
            print(f"{DIM_RED}[!] Failed to read unified registry: {e}{RESET}\n")
        if not models:
            print(f"{DIM_RED}[!] No {service_key} entries in the unified registry yet -- falling back to legacy.{RESET}")

    if not models:
        reg_path = PROJECT_ROOT / "lib" / "AI" / "config" / f"{service_key}_model_registry.104a.bejson"
        if not reg_path.exists():
            print(f"{DIM_RED}[!] Registry not found: {reg_path.name}{RESET}\n")
            return

        try:
            reg_data = _bejson_core.bejson_core_load_file(str(reg_path))
            reg_fmap = _bejson_core.bejson_core_get_field_map(reg_data)
            models = [row[reg_fmap["model_id"]] for row in reg_data.get("Values", [])]
        except Exception as e:
            print(f"{DIM_RED}[!] Failed to read registry: {e}{RESET}\n")
            return

    if not models:
        print(f"{DIM_RED}[!] No models found in registry.{RESET}\n")
        return
        
    # Read current CLI config to find the current default
    cli_config_path = PROJECT_ROOT / "CLI" / f"{service_key}_cli" / f"{service_key}_cli_config.104a.bejson"
    current_model = None
    cli_data = None
    cli_fmap = None
    
    if cli_config_path.exists():
        try:
            cli_data = _bejson_core.bejson_core_load_file(str(cli_config_path))
            cli_fmap = _bejson_core.bejson_core_get_field_map(cli_data)
            if cli_data.get("Values"):
                current_model = cli_data["Values"][0][cli_fmap["default_model_id"]]
        except Exception:
            pass

    print(f"\nAvailable models for {service_key}:")
    for i, mid in enumerate(models, 1):
        marker = f" {RED}←{RESET} (current)" if mid == current_model else ""
        print(f"  {WHITE}{i}{RESET}. {mid}{marker}")
        
    try:
        choice = input(f"\n{RED}>{RESET} Model number or ID: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
        
    if not choice:
        return
        
    new_model = choice
    try:
        midx = int(choice)
        if 1 <= midx <= len(models):
            new_model = models[midx - 1]
    except ValueError:
        pass
        
    if new_model not in models:
        print(f"{DIM_RED}[!] Model '{new_model}' not found in registry.{RESET}\n")
        return
        
    if not cli_data or not cli_fmap or "default_model_id" not in cli_fmap:
        print(f"{DIM_RED}[!] CLI config not found or invalid: {cli_config_path.name}{RESET}\n")
        return
        
    try:
        cli_data["Values"][0][cli_fmap["default_model_id"]] = new_model
        if _bejson_core.bejson_core_atomic_write(str(cli_config_path), cli_data):
            print(f"{WHITE}[ok]{RESET} Active model for {service_key} set to '{new_model}'.\n")
            _logger.info("default_model_id for %s set to %s", service_key, new_model)
        else:
            print(f"{DIM_RED}[!] Atomic write failed for CLI config.{RESET}\n")
    except Exception as e:
        print(f"{DIM_RED}[!] Failed to update CLI config: {e}{RESET}\n")


# --- Profile injection helper ---------------------------------------------

def load_active_profile_instruction() -> Optional[str]:
    """
    Returns the System_Instruction string from the active BEJSON 104 profile
    if Profiles_Enabled is true, otherwise None. All BEJSON reads go through
    Field Map Cache -- no positional hardcoding. Returns None silently on
    any error so callers degrade to their default system instruction.
    """
    import json
    try:
        if not gemini_profiles_is_enabled(PROFILES_CONFIG_FILE):
            return None
        selected = gemini_profiles_get_selected(PROFILES_CONFIG_FILE)
        if not selected:
            return None
        prof_file = Path(PROFILES_STORE) / f"{selected}.bejson"
        if not prof_file.exists():
            _logger.warning("active profile file not found: %s", prof_file)
            return None
        with open(prof_file, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
        fm = _bejson_core.bejson_core_get_field_map(doc)
        si_idx = fm.get("System_Instruction", -1)
        if si_idx == -1 or not doc.get("Values"):
            _logger.warning("System_Instruction field missing in profile %s", selected)
            return None
        instruction = doc["Values"][0][si_idx]
        if not instruction:
            return None
        _logger.info("Profile injection: '%s' -> %d chars", selected, len(instruction))
        return instruction
    except Exception as exc:
        _logger.error("load_active_profile_instruction failed: %s", exc)
        return None


# --- Gemini chat loop (delegates to gemini_cli's own stateful loop) -------

def run_gemini_chat():
    import prompt_gemini as pg

    config = pg.ensure_config_preset()
    api = pg.get_standard_interactions_api()
    model_id = config.get("default_model_id") or api.models.active_model_id

    # Profile injection: if enabled, active profile's System_Instruction
    # overrides the config-file default. Falls back to config default if
    # profiles are disabled or any load error occurs.
    profile_instruction = load_active_profile_instruction()
    system_instruction = profile_instruction or config.get("default_system_instruction")

    tools_enabled = config.get("tools_enabled_by_default", True)
    max_rounds = config.get("max_function_call_rounds", 5)

    tools, si_map = pg.load_tools(pg.TOOLS_DIR) if tools_enabled else ([], {})
    tool_executor = pg.make_tool_executor(api, model_id, si_map) if tools else None

    profile_tag = ""
    if profile_instruction:
        selected = gemini_profiles_get_selected(PROFILES_CONFIG_FILE)
        profile_tag = f" | profile: {RED}{selected}{RESET}{DIM}"

    print(f"\n{RED}{BOLD}-- Gemini (Interactions API) --{RESET}  "
          f"{DIM}model: {model_id} | tools: {'on' if tools else 'off'}{profile_tag} | "
          f"/exit to return to menu, /reset to clear session{RESET}\n")

    previous_id: Optional[str] = None
    while True:
        try:
            user_input = input(f"{WHITE}You:{RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not user_input:
            continue
        if user_input in ("/exit", "/quit"):
            break
        if user_input == "/reset":
            previous_id = None
            print(f"{DIM}[*] Conversation reset.{RESET}")
            continue

        previous_id = pg.run_turn(
            api, user_input,
            model_id=model_id, system_instruction=system_instruction,
            tools=tools or None, tool_executor=tool_executor,
            previous_interaction_id=previous_id, max_rounds=max_rounds,
            show_thought=False,
        )
        print()


def main():
    source_default_env()

    while True:
        service = print_menu()
        if service is None:
            print(f"{DIM}Goodbye.{RESET}")
            break

        if service == "__validate__":
            run_validate_configs()
            print()
            continue

        if service == "__transcribe__":
            try:
                run_transcribe_session()
            except (EOFError, KeyboardInterrupt):
                print()
            except Exception as session_error:  # noqa: BLE001 -- same last-resort
                # guard as the service dispatch below, so a bug in one
                # transcription (bad ffmpeg exit, SDK issue) drops back to
                # the menu instead of crashing the whole process.
                _logger.error("transcribe session raised unexpectedly", exc_info=True)
                print(f"{DIM_RED}[!] internal error: {session_error}{RESET}\n")
            continue

        if service == "__profiles__":
            try:
                run_profile_config()
            except (EOFError, KeyboardInterrupt):
                print()
            except Exception as prof_error:  # noqa: BLE001
                _logger.error("profile config session raised unexpectedly", exc_info=True)
                print(f"{DIM_RED}[!] internal error: {prof_error}{RESET}\n")
            continue

        if service == "__models__":
            try:
                run_model_config()
            except (EOFError, KeyboardInterrupt):
                print()
            except Exception as mod_error:
                _logger.error("model config session raised unexpectedly", exc_info=True)
                print(f"{DIM_RED}[!] internal error: {mod_error}{RESET}\n")
            continue

        label = dict((k, v) for k, v in SERVICES)[service]
        try:
            if service == "gemini":
                run_gemini_chat()
            else:
                run_simple_chat(service, label)
        except (EOFError, KeyboardInterrupt):
            print()
        except Exception as session_error:  # noqa: BLE001 -- last-resort guard so
            # one broken session (bad key, provider outage, an unhandled edge
            # case in a provider adapter) returns to the service picker
            # instead of crashing the whole menu process.
            _logger.error("%s session crashed", service, exc_info=True)
            print(f"\n{DIM_RED}[!] session error: {session_error}{RESET}\n")

        print()  # spacing before menu redraw


if __name__ == "__main__":
    main()
