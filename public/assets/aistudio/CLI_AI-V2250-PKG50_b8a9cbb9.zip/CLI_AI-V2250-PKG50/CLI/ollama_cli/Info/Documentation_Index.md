---
name: ollama-cloud-api
description: Documentation index for the Ollama Cloud CLI tool and API integrations. Covers base URLs, authentication, streaming, OpenAI compatibility, and integration with the BEJSON 104a configuration system.
---

# Ollama Cloud CLI & API Documentation Index

## Overview

The **Ollama Cloud CLI** (`prompt_ollama.py`) is a command-line interface tool to test and prompt Ollama Cloud AI models using credentials sourced from secure environment files and BEJSON 104a configuration presets. 
It interfaces with the Ollama API, allowing you to build applications with both cloud and local models.

### Base URLs

Depending on your integration needs, you can use either the direct Ollama API or the OpenAI-compatible endpoints:

| API | Direct cloud access | Local Ollama server |
| --- | --- | --- |
| **Ollama** | `https://ollama.com/api` | `http://localhost:11434/api` |
| **OpenAI compatibility** | `https://ollama.com/v1` | `http://localhost:11434/v1` |
| **Anthropic client base URL** | `https://ollama.com` | `http://localhost:11434` |

> *The Anthropic client appends `/v1/messages` to its base URL.*

### Authentication

- **Cloud requests** need an API key. 
- **Local requests** do not. 
- To use cloud models through your local server, sign in to Ollama.
- Creating or deleting models requires a local Ollama server. 

**Ollama API example:**
Set `OLLAMA_API_KEY` to your API key, then call a cloud model:
```bash
curl https://ollama.com/api/chat \
  -H "Authorization: Bearer $OLLAMA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma4:31b",
    "messages": [{"role": "user", "content": "Why is the sky blue?"}],
    "stream": false
  }'
```
> Read the answer from `message.content`. For local inference, use `http://localhost:11434/api/chat` with a downloaded model and omit the authorization header.

## Libraries & Integration

Use Ollama’s official libraries with either a local server or the hosted API. For direct cloud access, set the host to `https://ollama.com` and supply your API key in the `Authorization: Bearer` header.

### BEJSON Integration (`lib_bejson_AI_bejson_ollama.py`)

The internal AI library wrappers use the OpenAI-compatible endpoint:
- **Endpoint:** `https://ollama.com/v1/chat/completions`
- **Auth:** Uses `OLLAMA_KEY_1..10` from the secure environment file (`secureenv_file.json`).
- **Key Registry:** `OllamaKeyRegistry` supports up to 10 keys with round-robin rotation.

## CLI Usage (`prompt_ollama.py`)

**Usage:**
```bash
python3 prompt_ollama.py [prompt] [options]
```

**Options:**
- `-m`, `--model` : Model ID to use (default from preset).
- `--set-model` : Set a new default model in the CLI 104a configuration preset permanently.
- `-s`, `--system`: System instruction override.
- `-l`, `--list-models`: List available Ollama Cloud models.
- `-i`, `--info` : Display loaded API keys and registry info.

**Models (preset defaults):**
- `llama3.2:3b` (Default)
- `gemma2:9b`
- `phi3:mini`

## API Reference Index

For full API endpoint documentation, refer to the official [Ollama API Reference](https://docs.ollama.com/api).

### Core Endpoints
- **Generate:** Generate a response for a given prompt (`POST /api/generate`)
- **Chat:** Generate the next message in a chat with a provided model (`POST /api/chat`)
- **Embed:** Generate embeddings from a model (`POST /api/embed`)

### Model Management (Local Server)
- **Tags:** List models that are available locally (`GET /api/tags`)
- **Ps:** List models that are currently loaded into memory (`GET /api/ps`)
- **Show model details:** Show information about a model including details, modelfile, template, parameters, license, and system prompt (`POST /api/show`)
- **Create:** Create a model from a Modelfile (`POST /api/create`)
- **Copy:** Copy a model (`POST /api/copy`)
- **Delete:** Delete a model and its data (`DELETE /api/delete`)
- **Pull:** Download a model from the ollama library (`POST /api/pull`)
- **Push:** Upload a model to a model library (`POST /api/push`)

## Versioning

Ollama’s API isn’t strictly versioned, but the API is expected to be stable and backwards compatible. Deprecations are rare and will be announced in the release notes.

**Current CLI Integration Version:** 1.0.0
**BEJSON Format:** 104a
