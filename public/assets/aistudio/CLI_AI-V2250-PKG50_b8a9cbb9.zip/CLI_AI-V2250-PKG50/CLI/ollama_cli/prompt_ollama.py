"""
Tool:           prompt_ollama.py
Family:         Ollama CLI
Description:    Command-line interface tool to test and prompt Ollama Cloud AI models
                using credentials sourced from secure environment files and BEJSON 104a configuration presets.
Version:        1.1.0
Date:           2026-09-16
Author:         Elton Boehnen
Contact:        eltonboehnen@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  7b1c4e2a-3d9f-4a8b-9e5c-1b3f7a0d9c5e

Changelog:
  1.1.0 (2026-09-16) -- Path resolution now goes through the shared
        CLI/config/cli_shared_config.py bootstrap (portable_mode guard +
        library_path) instead of hardcoded relative Path math. Added a
        model_registry_source switch: --list-models reads from the
        unified lib/ai_model_registry.bejson (service key "Ollama") by
        default, falling back to prompter.model_reg.models (legacy) if
        set to "legacy" or the unified registry has no entries yet.
  1.0.0 - Initial creation.
"""

import logging
import sys
import os
import argparse
from pathlib import Path

# Setup paths to ensure lib/Core and lib/AI are importable, via the shared
# CLI config instead of hardcoded relative path math.
CLI_DIR = Path(__file__).resolve().parent
CLI_ROOT = CLI_DIR.parent

_CONFIG_DIR = CLI_ROOT / "config"
if str(_CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(_CONFIG_DIR))
from cli_shared_config import bootstrap as _cli_bootstrap

_SHARED = _cli_bootstrap(CLI_DIR)
PROJECT_ROOT = _SHARED["PROJECT_ROOT"]
CORE_DIR = _SHARED["CORE_DIR"]
AI_DIR = _SHARED["AI_DIR"]
MODEL_REGISTRY_SOURCE = _SHARED["MODEL_REGISTRY_SOURCE"]
AI_MODEL_REGISTRY_PATH = _SHARED["AI_MODEL_REGISTRY_PATH"]

from lib_bejson_Core_bejson_env import source_env, resolve_path
from lib_bejson_Core_bejson_core import bejson_core_load_file, bejson_core_atomic_write, bejson_core_get_field_map
from lib_bejson_AI_ai_dispatch import ai_dispatch_call
from lib_bejson_AI_bejson_ollama import get_standard_prompter
from lib_bejson_AI_ai_call_log import log_ai_call
import lib_bejson_AI_ai_console_log as console_log

console_log.setup_logging(PROJECT_ROOT)
_logger = logging.getLogger("cli_ai.ollama")

VERSION = "1.1.0"

DEFAULT_SECURE_ENV = "/storage/emulated/0/.env/secure/secureenv_file.json"
CONFIG_FILE_PATH = CLI_DIR / "ollama_cli_config.104a.bejson"

SCHEMA_CLI_CONFIG = {
    "Format": "BEJSON",
    "Format_Version": "104a",
    "Format_Creator": "Elton Boehnen",
    "Schema_Name": "OllamaCLIConfig",
    "Records_Type": ["CLIConfig"],
    "Fields": [
        {"name": "env_file_path", "type": "string"},
        {"name": "default_model_id", "type": "string"},
        {"name": "default_system_instruction", "type": "string"},
        {"name": "auto_refresh_models", "type": "boolean"}
    ],
    "Values": [
        [
            DEFAULT_SECURE_ENV,
            "llama3.2:3b",
            "You are a helpful assistant. Provide clear, accurate, and concise information.",
            False
        ]
    ]
}


def ensure_config_preset() -> dict:
    if not CONFIG_FILE_PATH.exists():
        os.makedirs(CONFIG_FILE_PATH.parent, exist_ok=True)
        bejson_core_atomic_write(str(CONFIG_FILE_PATH), SCHEMA_CLI_CONFIG)
        console_log.ok(f"Initialized BEJSON 104a config file at: {CONFIG_FILE_PATH}")

    try:
        data = bejson_core_load_file(str(CONFIG_FILE_PATH))
        fmap = bejson_core_get_field_map(data)
        values = data.get("Values", [])[0]
        return {
            "env_file_path": values[fmap.get("env_file_path", 0)],
            "default_model_id": values[fmap.get("default_model_id", 1)],
            "default_system_instruction": values[fmap.get("default_system_instruction", 2)],
            "auto_refresh_models": values[fmap.get("auto_refresh_models", 3)]
        }
    except Exception as e:
        _logger.warning("failed to parse %s, using built-in defaults: %s", CONFIG_FILE_PATH, e)
        console_log.warn(f"Failed to parse {CONFIG_FILE_PATH}, using built-in defaults: {e}")
        return {
            "env_file_path": DEFAULT_SECURE_ENV,
            "default_model_id": "llama3.2:3b",
            "default_system_instruction": "You are a helpful assistant. Provide clear, accurate, and concise information.",
            "auto_refresh_models": False
        }


def main():
    config = ensure_config_preset()

    env_path = resolve_path(config["env_file_path"])
    if not source_env(env_path):
        source_env(DEFAULT_SECURE_ENV)

    parser = argparse.ArgumentParser(
        description="CLI tool to test prompts against Ollama Cloud AI models using BEJSON presets."
    )
    parser.add_argument(
        "prompt",
        nargs="?",
        help="Prompt text to send to Ollama Cloud."
    )
    parser.add_argument(
        "-m", "--model",
        type=str,
        default=None,
        help=f"Model ID to use (default from preset: {config['default_model_id']})."
    )
    parser.add_argument(
        "-s", "--system",
        type=str,
        default=None,
        help="System instruction override."
    )
    parser.add_argument(
        "-l", "--list-models",
        action="store_true",
        help="List available Ollama Cloud models."
    )
    parser.add_argument(
        "-i", "--info",
        action="store_true",
        help="Display loaded API keys and registry info."
    )
    parser.add_argument(
        "--set-model",
        type=str,
        help="Set a new default model in the CLI 104a configuration preset permanently."
    )

    args = parser.parse_args()
    prompter = get_standard_prompter()

    if args.info:
        console_log.heading("--- Ollama Cloud Configuration Info ---")
        print(f"Author / Creator : Elton Boehnen (boehnenelton2024@gmail.com)")
        print(f"Config File      : {CONFIG_FILE_PATH}")
        print(f"Env File Sourced : {env_path}")
        print(f"API Keys Loaded  : {len(prompter.key_reg.keys)}")
        print(f"Active Model     : {prompter.model_reg.active_model_id}")
        print(f"Preset Model     : {config['default_model_id']}")
        print(f"Total Local Models: {len(prompter.model_reg.models)}")
        if not args.prompt and not args.list_models and not args.set_model:
            return

    if args.set_model:
        try:
            data = bejson_core_load_file(str(CONFIG_FILE_PATH))
            fmap = bejson_core_get_field_map(data)
            if "default_model_id" in fmap and data.get("Values"):
                data["Values"][0][fmap["default_model_id"]] = args.set_model
                bejson_core_atomic_write(str(CONFIG_FILE_PATH), data)
                console_log.ok(f"Successfully set default model to: {args.set_model} in {CONFIG_FILE_PATH.name}")
                config["default_model_id"] = args.set_model
            else:
                console_log.error("Failed to update config: invalid schema structure.")
        except Exception as e:
            console_log.error(f"Failed to update config: {e}")
            
        if not args.prompt and not args.list_models and not args.info:
            return

    if args.list_models:
        console_log.heading("--- Available Ollama Cloud Models ---")
        preset_model = args.model or config.get("default_model_id") or prompter.model_reg.active_model_id
        if MODEL_REGISTRY_SOURCE == "unified":
            from lib_ai_model_registry import AIModelRegistry
            unified_models = AIModelRegistry(str(AI_MODEL_REGISTRY_PATH), {}).load().get_models("Ollama")
            if unified_models:
                display_models = [m["id"] for m in unified_models]
            else:
                console_log.warn("No Ollama entries in the unified registry yet -- falling back to legacy.")
                display_models = [m["id"] for m in prompter.model_reg.models]
        else:
            display_models = [m["id"] for m in prompter.model_reg.models]
        for idx, mid in enumerate(display_models, 1):
            is_active = " (preset active)" if mid == preset_model else ""
            print(f"{idx:2d}. {mid}{is_active}")
        if not args.prompt:
            return

    if not args.prompt:
        if not args.info and not args.list_models and not args.set_model:
            parser.print_help()
        return

    selected_model = args.model or config.get("default_model_id") or prompter.model_reg.active_model_id
    system_instruction = args.system or config.get("default_system_instruction")

    console_log.ok(f"Prompting Ollama model: {selected_model}...")

    response = ai_dispatch_call(
        provider="ollama",
        user_input=args.prompt,
        model_id=selected_model,
        system_instruction=system_instruction
    )

    if response.get("success"):
        console_log.heading("=== Response ===")
        print(response.get("content", ""))
        log_ai_call("ollama", args.prompt, response.get("content", ""))
    else:
        console_log.error(f"Prompt failed: {response.get('error')}")
        log_ai_call("ollama", args.prompt, f"ERROR: {response.get('error')}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
    except Exception as fatal_error:
        _logger.error("fatal error in prompt_ollama main()", exc_info=True)
        console_log.error(f"fatal error: {fatal_error}")
        sys.exit(1)
