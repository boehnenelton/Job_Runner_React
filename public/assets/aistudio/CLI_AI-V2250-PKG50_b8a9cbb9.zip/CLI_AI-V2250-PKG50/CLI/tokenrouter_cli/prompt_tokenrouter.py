"""
Tool:           prompt_tokenrouter.py
Family:         TokenRouter CLI
Description:    Command-line interface tool to test and prompt TokenRouter AI models
                using credentials sourced from secure environment files and BEJSON 104a configuration presets.
Version:        1.1.0
Date:           2026-09-16
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  9e4f5a6b-7c8d-4e2f-1a3b-5c6d7e8f9a0b

Changelog:
  1.1.0 (2026-09-16) -- Path resolution now goes through the shared
        CLI/config/cli_shared_config.py bootstrap (portable_mode guard +
        library_path) instead of hardcoded relative Path math. Added a
        model_registry_source switch: --list-models reads from the
        unified lib/ai_model_registry.bejson (service key "TokenRoute",
        matching the client's dropdown value) by default, falling back to
        the existing live-TokenRouter-API/legacy-registry path if set to
        "legacy" or the unified registry has no entries yet. TokenRoute is
        an AUTO_GENERATING_SERVICES entry, so --refresh could eventually
        route through AIModelRegistry.update_registry() too -- left
        pointed at the existing live fetch for this pass, since that
        already works and isn't part of what was asked for here.
  1.0.0 - Initial creation. Standalone CLI tool for TokenRouter model prompting.
"""

import logging
import sys
import os
import argparse
import requests
import uuid
from pathlib import Path

# Setup paths to ensure lib/Core and lib/AI are importable, via the shared
# CLI config instead of hardcoded relative path math.
CLI_DIR = Path(__file__).resolve().parent
CLI_ROOT = CLI_DIR.parent  # CLI_AI/CLI/ -- all *_cli tool folders live here

_CONFIG_DIR = CLI_ROOT / "config"
if str(_CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(_CONFIG_DIR))
from cli_shared_config import bootstrap as _cli_bootstrap

_SHARED = _cli_bootstrap(CLI_DIR)
PROJECT_ROOT = _SHARED["PROJECT_ROOT"]  # CLI_AI/ -- lib/, reports/, tests/, etc.
CORE_DIR = _SHARED["CORE_DIR"]
AI_DIR = _SHARED["AI_DIR"]
MODEL_REGISTRY_SOURCE = _SHARED["MODEL_REGISTRY_SOURCE"]
AI_MODEL_REGISTRY_PATH = _SHARED["AI_MODEL_REGISTRY_PATH"]

# Mandatory Environment & BEJSON Imports
from lib_bejson_Core_bejson_env import source_env, resolve_path
from lib_bejson_Core_bejson_core import bejson_core_load_file, bejson_core_atomic_write, bejson_core_get_field_map
from lib_bejson_AI_ai_dispatch import ai_dispatch_call
from lib_bejson_AI_bejson_tokenrouter import get_standard_prompter, TokenRouterKeyRegistry, TokenRouterModelRegistry
from lib_bejson_AI_ai_call_log import log_ai_call
import lib_bejson_AI_ai_console_log as console_log

console_log.setup_logging(PROJECT_ROOT)
_logger = logging.getLogger("cli_ai.tokenrouter")

VERSION = "1.1.0"

DEFAULT_SECURE_ENV = "/storage/emulated/0/.env/secure/secureenv_file.py"
CONFIG_FILE_PATH = CLI_DIR / "tokenrouter_cli_config.104a.bejson"

# BEJSON 104a Schema for TokenRouter CLI Configuration Preset
SCHEMA_CLI_CONFIG = {
    "Format": "BEJSON",
    "Format_Version": "104a",
    "Format_Creator": "Elton Boehnen",
    "Schema_Name": "TokenRouterCLIConfig",
    "Records_Type": ["CLIConfig"],
    "Fields": [
        {"name": "env_file_path", "type": "string"},
        {"name": "default_model_id", "type": "string"},
        {"name": "default_system_instruction", "type": "string"},
        {"name": "auto_refresh_models", "type": "boolean"}
    ],
    "Values": [
        [
            DEFAULT_SECURE_ENV,
            "z-ai/glm-5.3-free",
            "You are an intelligent assistant, please reply concisely.",
            True
        ]
    ]
}


def ensure_config_preset() -> dict:
    """
    Ensures that the BEJSON 104a config file exists on first run with default presets.
    Returns the parsed configuration values as a dictionary.
    """
    if not CONFIG_FILE_PATH.exists():
        os.makedirs(CONFIG_FILE_PATH.parent, exist_ok=True)
        bejson_core_atomic_write(str(CONFIG_FILE_PATH), SCHEMA_CLI_CONFIG)
        console_log.ok(f"Initialized BEJSON 104a config file at: {CONFIG_FILE_PATH}")

    try:
        data = bejson_core_load_file(str(CONFIG_FILE_PATH))
        fmap = bejson_core_get_field_map(data)
        values = data.get("Values", [])[0]
        return {
            "env_file_path": values[fmap.get("env_file_path", 0)],
            "default_model_id": values[fmap.get("default_model_id", 1)],
            "default_system_instruction": values[fmap.get("default_system_instruction", 2)],
            "auto_refresh_models": values[fmap.get("auto_refresh_models", 3)]
        }
    except Exception as e:
        _logger.warning("failed to parse %s, using built-in defaults: %s", CONFIG_FILE_PATH, e)
        console_log.warn(f"Failed to parse {CONFIG_FILE_PATH}, using built-in defaults: {e}")
        return {
            "env_file_path": DEFAULT_SECURE_ENV,
            "default_model_id": "z-ai/glm-5.3-free",
            "default_system_instruction": "You are an intelligent assistant, please reply concisely.",
            "auto_refresh_models": True
        }


def refresh_tokenrouter_models(key_registry: TokenRouterKeyRegistry, model_registry: TokenRouterModelRegistry) -> list:
    """
    Pulls live models from TokenRouter GET /v1/models endpoint using an available API key.
    """
    keys = key_registry.keys
    if not keys:
        console_log.warn("No TokenRouter API keys available to refresh models.")
        return []

    url = "https://api.tokenrouter.com/v1/models"
    for key in keys:
        try:
            resp = requests.get(url, headers={"Authorization": f"Bearer {key}"}, timeout=15)
            if resp.status_code == 200:
                data = resp.json().get("data", [])
                models = [m.get("id") for m in data if m.get("id")]
                return models
            _logger.debug("model refresh key attempt returned HTTP %s", resp.status_code)
        except requests.RequestException as request_error:
            _logger.debug("model refresh key attempt failed: %s", request_error)
            continue
    return []


def main():
    config = ensure_config_preset()

    # Source environment dynamically from config file preset
    env_path = resolve_path(config["env_file_path"])
    if not source_env(env_path):
        source_env(DEFAULT_SECURE_ENV)

    parser = argparse.ArgumentParser(
        description="CLI tool to test prompts against TokenRouter models using BEJSON presets."
    )
    parser.add_argument(
        "prompt",
        nargs="?",
        help="Prompt text to send to TokenRouter."
    )
    parser.add_argument(
        "-m", "--model",
        type=str,
        default=None,
        help=f"Model ID to use (default from preset: {config['default_model_id']})."
    )
    parser.add_argument(
        "-s", "--system",
        type=str,
        default=None,
        help="System instruction override."
    )
    parser.add_argument(
        "-r", "--refresh",
        action="store_true",
        help="Refresh live model list from TokenRouter's model catalog."
    )
    parser.add_argument(
        "-l", "--list-models",
        action="store_true",
        help="List available TokenRouter models."
    )
    parser.add_argument(
        "-i", "--info",
        action="store_true",
        help="Display loaded API keys and registry info."
    )
    parser.add_argument(
        "-v", "--version",
        action="store_true",
        help="Show version information."
    )
    parser.add_argument(
        "--config",
        action="store_true",
        help="Display path to BEJSON 104a configuration file."
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset configuration preset file to factory default."
    )
    parser.add_argument(
        "--register",
        action="store_true",
        help="Register project with master index database."
    )

    args = parser.parse_args()

    if args.version:
        print(f"TokenRouter CLI Tool Version {VERSION}")
        return

    if args.config:
        print(f"Configuration file path: {CONFIG_FILE_PATH}")
        return

    if args.reset:
        if CONFIG_FILE_PATH.exists():
            CONFIG_FILE_PATH.unlink()
        ensure_config_preset()
        console_log.ok("Factory reset configuration complete.")
        return

    if args.register:
        reg_script = Path("/storage/emulated/0/Labortory/AI Tools/cli_project_register.py")
        if reg_script.exists():
            os.system(f"{sys.executable} {reg_script} --register \"{PROJECT_ROOT}\"")
        else:
            console_log.warn("Project registration script not found.")
        return

    prompter = get_standard_prompter()

    if args.refresh:
        console_log.ok("Fetching live model catalog from TokenRouter API...")
        live_models = refresh_tokenrouter_models(prompter.key_reg, prompter.model_reg)
        if live_models:
            console_log.ok(f"Found {len(live_models)} models from TokenRouter API.")
        else:
            console_log.warn("Could not refresh models from live API.")

    if args.info:
        console_log.heading("--- TokenRouter Configuration Info ---")
        print(f"Author / Creator : Elton Boehnen (boehnenelton2024@gmail.com)")
        print(f"Config File      : {CONFIG_FILE_PATH}")
        print(f"Env File Sourced : {env_path}")
        print(f"API Keys Loaded  : {len(prompter.key_reg.keys)}")
        print(f"Active Model     : {prompter.model_reg.active_model_id}")
        print(f"Preset Model     : {config['default_model_id']}")
        print(f"Total Local Models: {len(prompter.model_reg.models)}")
        if not args.prompt and not args.list_models:
            return

    if args.list_models:
        console_log.heading("--- Available TokenRouter Models ---")
        if MODEL_REGISTRY_SOURCE == "unified":
            from lib_ai_model_registry import AIModelRegistry
            unified_models = AIModelRegistry(str(AI_MODEL_REGISTRY_PATH), {}).load().get_models("TokenRoute")
            if unified_models:
                display_models = [m["id"] for m in unified_models]
            else:
                console_log.warn("No TokenRoute entries in the unified registry yet -- falling back to legacy.")
                display_models = [m["id"] for m in prompter.model_reg.models]
        else:
            live_models = refresh_tokenrouter_models(prompter.key_reg, prompter.model_reg)
            display_models = live_models if live_models else [m["id"] for m in prompter.model_reg.models]
        preset_model = args.model or config.get("default_model_id") or prompter.model_reg.active_model_id
        for idx, mid in enumerate(display_models, 1):
            is_active = " (preset active)" if mid == preset_model else ""
            print(f"{idx:2d}. {mid}{is_active}")
        if not args.prompt:
            return

    if not args.prompt:
        if not args.refresh and not args.info and not args.list_models:
            parser.print_help()
        return

    selected_model = args.model or config.get("default_model_id") or prompter.model_reg.active_model_id
    system_instruction = args.system or config.get("default_system_instruction")

    console_log.ok(f"Prompting TokenRouter model: {selected_model}...")

    response = ai_dispatch_call(
        provider="tokenrouter",
        user_input=args.prompt,
        model_id=selected_model,
        system_instruction=system_instruction
    )

    if response.get("success"):
        console_log.heading("=== Response ===")
        print(response.get("content", ""))
        log_ai_call("tokenrouter", args.prompt, response.get("content", ""))
    else:
        console_log.error(f"Prompt failed: {response.get('error')}")
        log_ai_call("tokenrouter", args.prompt, f"ERROR: {response.get('error')}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
    except Exception as fatal_error:
        _logger.error("fatal error in prompt_tokenrouter main()", exc_info=True)
        console_log.error(f"fatal error: {fatal_error}")
        sys.exit(1)
