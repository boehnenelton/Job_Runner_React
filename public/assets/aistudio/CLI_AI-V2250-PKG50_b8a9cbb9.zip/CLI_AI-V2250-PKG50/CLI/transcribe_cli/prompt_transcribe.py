"""
Tool:           prompt_transcribe.py
Family:         CLI
Description:    Command-line tool to request an audio/video transcription
                 from a local file, via Gemini's multimodal
                 generate_content endpoint
                 (lib_bejson_AI_bejson_gemini_transcribe.py /
                 lib_bejson_AI_ai_transcribe_dispatch.py). Mirrors the
                 *_cli tooling pattern already used by gemini_cli /
                 groq_cli / openrouter_cli (BEJSON 104a config preset,
                 secure-env key sourcing, credited About/Info, shared
                 call-log feed) but is single-shot (one file in, one
                 transcript out) rather than an interactive chat loop,
                 since transcription has no multi-turn concept.
Version:        1.1.0
Date:           2026-09-16
Author:         Elton Boehnen
Contact:        eltonboehnen@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  6d2a8f13-9b4c-47e5-8f2a-1c6d3b9e7a58
Release_Version: 300

Changelog:
  1.1.0 (2026-09-16) -- Path resolution now goes through the shared
        CLI/config/cli_shared_config.py bootstrap (portable_mode guard +
        library_path) instead of hardcoded relative Path math. No model
        listing feature exists in this tool (transcription is Gemini-only,
        single-shot), so MODEL_REGISTRY_SOURCE/AI_MODEL_REGISTRY_PATH are
        resolved for consistency but not yet acted on here.
  1.0.0 (2026-09-03) -- Initial creation. New CLI tool folder; no existing
        CLI/*_cli tool was modified to add this (menu_cli's addition of a
        "t" entry is a separate additive change, see prompt_menu.py 1.5.0
        changelog).
"""

import logging
import sys
import os
import argparse
from pathlib import Path
from typing import Optional

# Setup paths to ensure lib/Core and lib/AI are importable
CLI_DIR = Path(__file__).resolve().parent
CLI_ROOT = CLI_DIR.parent  # CLI_AI/CLI/ -- all *_cli tool folders live here

_CONFIG_DIR = CLI_ROOT / "config"
if str(_CONFIG_DIR) not in sys.path:
    sys.path.insert(0, str(_CONFIG_DIR))
from cli_shared_config import bootstrap as _cli_bootstrap

_SHARED = _cli_bootstrap(CLI_DIR)
PROJECT_ROOT = _SHARED["PROJECT_ROOT"]  # CLI_AI/ -- lib/, reports/, tests/, etc.
CORE_DIR = _SHARED["CORE_DIR"]
AI_DIR = _SHARED["AI_DIR"]
MODEL_REGISTRY_SOURCE = _SHARED["MODEL_REGISTRY_SOURCE"]
AI_MODEL_REGISTRY_PATH = _SHARED["AI_MODEL_REGISTRY_PATH"]

from lib_bejson_Core_bejson_env import source_env, resolve_path
from lib_bejson_Core_bejson_core import bejson_core_load_file, bejson_core_atomic_write, bejson_core_get_field_map
from lib_bejson_AI_ai_transcribe_dispatch import ai_transcribe_dispatch
from lib_bejson_AI_ai_call_log import log_ai_call
import lib_bejson_AI_ai_console_log as console_log

console_log.setup_logging(PROJECT_ROOT)
_logger = logging.getLogger("cli_ai.transcribe")

VERSION = "1.1.0"

DEFAULT_SECURE_ENV = "/storage/emulated/0/.env/secure/secureenv_file.py"
CONFIG_FILE_PATH = CLI_DIR / "transcribe_cli_config.104a.bejson"

# BEJSON 104a Schema for CLI Configuration Preset -- same shape/pattern as
# gemini_cli_config.104a.bejson.
SCHEMA_CLI_CONFIG = {
    "Format": "BEJSON",
    "Format_Version": "104a",
    "Format_Creator": "Elton Boehnen",
    "Schema_Name": "TranscribeInteractiveCLIConfig",
    "Records_Type": ["CLIConfig"],
    "Fields": [
        {"name": "env_file_path", "type": "string"},
        {"name": "default_model_id", "type": "string"},
        {"name": "default_mode", "type": "string"},
        {"name": "default_domain_context", "type": "boolean"},
        {"name": "default_chunk_seconds", "type": "integer"},
    ],
    "Values": [
        [
            DEFAULT_SECURE_ENV,
            "gemini-3.6-flash",
            "verbatim",
            True,
            600,
        ]
    ],
}


def ensure_config_preset() -> dict:
    """Ensures the BEJSON 104a config file exists on first run with default presets."""
    if not CONFIG_FILE_PATH.exists():
        os.makedirs(CONFIG_FILE_PATH.parent, exist_ok=True)
        bejson_core_atomic_write(str(CONFIG_FILE_PATH), SCHEMA_CLI_CONFIG)
        print(f"[+] Initialized BEJSON 104a config file at: {CONFIG_FILE_PATH}")

    try:
        data = bejson_core_load_file(str(CONFIG_FILE_PATH))
        fmap = bejson_core_get_field_map(data)
        values = data.get("Values", [])[0]
        return {
            "env_file_path": values[fmap.get("env_file_path", 0)],
            "default_model_id": values[fmap.get("default_model_id", 1)],
            "default_mode": values[fmap.get("default_mode", 2)],
            "default_domain_context": values[fmap.get("default_domain_context", 3)],
            "default_chunk_seconds": values[fmap.get("default_chunk_seconds", 4)],
        }
    except Exception as e:
        print(f"[!] Warning: Failed to parse {CONFIG_FILE_PATH}, using built-in defaults: {e}")
        return {
            "env_file_path": DEFAULT_SECURE_ENV,
            "default_model_id": "gemini-3.6-flash",
            "default_mode": "verbatim",
            "default_domain_context": True,
            "default_chunk_seconds": 600,
        }


def print_about(config: dict) -> None:
    print(f"""
prompt_transcribe.py -- Gemini Audio/Video Transcription CLI Tool
Version      : {VERSION}
RELATIONAL_ID: 6d2a8f13-9b4c-47e5-8f2a-1c6d3b9e7a58

Config File  : {CONFIG_FILE_PATH}
Default Model: {config.get('default_model_id')}
Default Mode : {config.get('default_mode')}

Author       : Elton Boehnen
Email        : boehnenelton2024@gmail.com
Site         : boehnenelton2024.pages.dev
GitHub       : github.com/boehnenelton
""")


def main() -> int:
    config = ensure_config_preset()

    env_path = resolve_path(config["env_file_path"])
    if not source_env(env_path):
        source_env(DEFAULT_SECURE_ENV)

    parser = argparse.ArgumentParser(
        prog="prompt_transcribe",
        description="Request an audio/video transcription from a local file via Gemini.",
        epilog="""
Usage Examples:
  # 1. Verbatim transcription of a short audio clip:
  prompt_transcribe.py podcast.mp3

  # 2. Speaker-diarized transcription with timestamps:
  prompt_transcribe.py meeting.m4a --mode diarization

  # 3. Ask for logical segment/chapter markers:
  prompt_transcribe.py lecture.mp4 --segment

  # 4. Large file (over ~15MB): chunk via ffmpeg first, then transcribe each chunk:
  prompt_transcribe.py long_interview.wav --long --chunk-seconds 600

  # 5. Save the transcript to a file instead of only printing it:
  prompt_transcribe.py voice_memo.wav -o voice_memo.txt

  # 6. Show version/credit/config info:
  prompt_transcribe.py --about
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("file", nargs="?", help="Path to the audio or video file to transcribe.")
    parser.add_argument("-m", "--model", type=str, default=None,
                         help=f"Model ID override (default from preset: {config['default_model_id']}).")
    parser.add_argument("--mode", choices=["verbatim", "diarization"], default=config["default_mode"],
                         help="Transcription mode (default from preset).")
    parser.add_argument("--segment", action="store_true",
                         help="Ask Gemini to mark logical segments/chapters in the output.")
    parser.add_argument("--long", action="store_true",
                         help="Chunk the file via ffmpeg before transcribing (for files over ~15MB).")
    parser.add_argument("--chunk-seconds", type=int, default=config["default_chunk_seconds"],
                         help=f"Chunk duration in seconds when --long is set (default from preset: {config['default_chunk_seconds']}).")
    parser.add_argument("--no-domain-context", action="store_true",
                         help="Disable the BEJSON/BEHTML/MFDB terminology dictionary in the prompt.")
    parser.add_argument("-o", "--output", type=str, default=None,
                         help="Write the transcript to this file (in addition to printing it).")
    parser.add_argument("--about", action="store_true", help="Show version, config, and author credit info.")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose debug logging.")

    args = parser.parse_args()

    if args.about:
        print_about(config)
        return 0

    if args.verbose:
        logging.getLogger("cli_ai.transcribe").setLevel(logging.DEBUG)

    if not args.file:
        parser.print_help()
        print("\n[!] Missing target media file argument.")
        return 1

    file_path = Path(args.file).expanduser().absolute()
    if not file_path.exists():
        print(f"[!] Target file does not exist: {file_path}")
        return 1

    print(f"[*] Transcribing: {file_path.name} (mode: {args.mode}, model: {args.model or config['default_model_id']})")
    if args.long:
        print(f"[*] Long-media chunking enabled: ~{args.chunk_seconds}s per chunk (requires ffmpeg).")

    response = ai_transcribe_dispatch(
        "gemini",
        file_path,
        model_id=args.model,
        mode=args.mode,
        segment=args.segment,
        long_media=args.long,
        chunk_seconds=args.chunk_seconds,
    )

    log_label = f"transcribe:{file_path.name}"
    if not response.get("success"):
        err = response.get("error", "unknown error")
        print(f"\n[!] Transcription failed: {err}")
        _logger.error("transcription failed for %s: %s", file_path, err)
        log_ai_call("gemini", log_label, f"ERROR: {err}")
        return 1

    transcript = response.get("content", "")
    print("\n----- TRANSCRIPT -----\n")
    print(transcript)
    print("\n-----------------------")

    log_ai_call("gemini", log_label, transcript)

    if args.output:
        out_path = Path(args.output).expanduser().absolute()
        try:
            out_path.write_text(transcript, encoding="utf-8")
            print(f"\n[+] Transcript written to: {out_path}")
        except OSError as e:
            print(f"\n[!] Failed to write output file {out_path}: {e}")
            return 1

    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print()
        sys.exit(130)
    except Exception as fatal_error:  # noqa: BLE001 -- last-resort guard, matches
        # prompt_gemini.py's entry-point pattern: log the traceback, print a
        # clean line, exit non-zero instead of a raw stack trace.
        _logger.error("fatal error in prompt_transcribe main()", exc_info=True)
        console_log.error(f"fatal error: {fatal_error}")
        sys.exit(1)
