# CLI_AI

A multi-provider AI chat/CLI ecosystem: one shared library family
(`lib/`) backing both a Flask chat client (`client/`) and a set of
standalone command-line tools (`CLI/`) for testing and using seven AI
providers — Gemini (SDK and REST), Groq, Grok (xAI), HuggingFace,
Ollama Cloud, OpenRouter, and TokenRouter — plus a local Ollama service
(`OllamaLocal`, no key) available in the chat client.

Author: Elton Boehnen · eltonboehnen@gmail.com · boehnenelton2024.pages.dev · [github.com/boehnenelton](https://github.com/boehnenelton)

## Layout

```
client/     Flask chat client — the primary interface (see below)
CLI/        Standalone per-provider CLI tools + a menu launcher
lib/        Shared library family every tool and the client import from
  lib/Core/   BEJSON format core: read/write, field-map cache, strict validator
  lib/AI/     Provider dispatch, model registry, context bubble, keys, keywords
profiles/   A separate Flask app for managing AI system-instruction profiles
dev/        change-log.md, docs/, tests/, logs/ — project history and internals
reports/    Audits and analysis reports
data/       Runtime data (logs, structured output)
```

`GEMINI.MD` at the root records the original environment intent and
constraints this project was built against.

## The chat client (`client/`)

```bash
cd client
python3 app.py
```

Starts a Flask server (default `127.0.0.1:5000`, configurable via
`client/client_constants.py`'s self-healing config file) and opens the
chat UI. Configuration lives in `client/config/config.json`
(`portable_mode` — keep `false`; `library_path` — where `lib/` is;
`secure_env_path` — where your API keys live).

**Providers & models.** The service/model dropdowns are populated from
`lib/ai_model_registry.bejson` — Gemini, Groq, Grok, HuggingFace, and
Ollama have static hardcoded defaults; OpenRouter and TokenRouter pull
their live (free-tier-filtered) catalog on refresh, falling back to one
default model each until a refresh succeeds. Every provider is dispatched
through `lib/AI/lib_bejson_AI_ai_dispatch.py`, one shared code path
regardless of which SDK or REST API sits underneath.

**Attachments vs. Context — two entirely independent systems, each with
its own file list, on purpose:**

- **Attachments** (Attach tab → Attachments sub-tab): files you check are
  sent along with your *next* message only, and every send auto-unchecks
  them (persisted server-side, not just in the page). The model is told
  these are what you're actively working on together — normal, freely
  discussable working material it can read, modify, and hand back to you.
- **Context** (Attach tab → Context sub-tab): files you check here, plus
  whatever's in the quick-text box, are what the **Save** button stages
  and chunks into a single persistent block, injected into *every* turn
  from then on — until the next Save replaces it (Save always wipes and
  rebuilds from scratch; it never accumulates). The model is explicitly
  instructed to never reference, mention, or admit this material exists,
  and that anything it produces under that influence must come out as its
  own original wording — never a copy, quote, or citation. This is
  background study material, not a working document.

These have never overlapped — checking a file as an Attachment has no
effect on Context, and vice versa.

**Context Bubble (v2).** Everything the model is sent besides your message
comes from five ranked *allotments*: **Persistent Policy** (1), **Profile**
(2, the selected profile's System_Instruction), **Attachments** (3),
**Context** (4, the saved chunk) and **Chat History** (5, earlier turns of
the session). Each gets a percentage of the total token budget (Settings →
Token Budget, `max_context_tokens`; default 8000). Ranks, percentages and
on/off switches live in `lib/AI/config/context_bubble.bejson` — edit it and
the next message uses it. A fresh file splits the budget evenly (20% each).

- **Spill-up:** budget an allotment doesn't use is released. Allotments
  that are over their own share claim it in rank order (1 first), each
  drawing evenly from every donor. When a donor fills its own share, the
  borrower shrinks back toward its baseline. Unassigned percent is
  donated too.
- **Truncation:** anything still over its grant is cut, with a visible
  marker. Chat History keeps its *newest* turns; the others keep their start.
  Large attachments are therefore truncated at their allotment — raise the
  token budget if you need more of a big file.
- **Chunking:** each allotment is chunked (Chunked-104a) into
  `client/data/context/bubble/allotments/`, the whole bubble is chunked
  again (`Context_Bubble.104a.bejson`), and the prompt is built from that
  bubble chunk after every SHA-256 hash is verified.
- **Lifecycle:** the bubble is destroyed and rebuilt every
  `Rebuild_Interval_Turns` turns (default 5, set in `context_bubble.bejson`)
  or immediately when attachments, the saved context, the policy, the
  profile or the config change — a rebuild restarts the 5-turn count. Chat
  History refreshes every turn without counting as a change.
- **Resilience:** sources are capped at the token budget (plus 1 KB), so a
  huge attachment can't bloat the bubble or slow a turn. If anything about
  building or verifying the bubble fails (disk full, corrupt chunk, bad
  state), the prompt still carries the policy, profile and attachments from
  an unchunked in-memory bubble and the next turn recovers on its own. A
  corrupt `context_bubble.bejson` falls back to the registered defaults
  without overwriting your file.
- **More allotments:** write a builder `fn(ctx) -> str` and call
  `ai_bubble_register_allotment(name, fn, ...)`; raise
  `BUBBLE_MAX_ALLOTMENTS` (default 8) in
  `lib/AI/lib_bejson_AI_ai_context_bubble.py` if you need more than 8.
- **Feature switches:** every allotment can be enabled/disabled (and its weight changed) at runtime from Attach > Bubble or `POST /api/context/bubble/allotments`. Shares are normalised over what is enabled, so switching Brain off makes the others grow and switching it on shrinks them again; the bubble rebuilds on the next prompt. Set `Normalize_Baselines` to false in `context_bubble.bejson` for the legacy behaviour.

The **Bubble sub-tab** previews exactly what the next prompt would carry,
with per-allotment budget, use, spill and truncation, and the number of
turns until the next rebuild (it doesn't touch the live bubble or counter).
Local streaming services (OllamaLocal, LiteRT-LM) already send history as
chat messages, so their bubble leaves Chat History out.

### Local model (Ollama) and chat logs

**OllamaLocal** runs a model on the device through your own Ollama server
(`lib/AI/lib_bejson_AI_bejson_ollamalocal.py`, provider key `ollamalocal`).
Open **Settings > Local Model (Ollama)**, pick a model (default
`qwen2.5-coder:1.5b`; 0.5b / 3b / 7b also listed) and press **Set up /
Start**. In the background it installs Ollama if missing (Termux:
`pkg install ollama`), runs `ollama serve` as a subprocess, and pulls the
model with live progress. Choosing the **Ollama Local** service then streams
tokens as they are generated and sends the session's earlier turns as
context. Stop cancels generation. The existing `Ollama` service is still
Ollama Cloud (keyed) and is untouched.

**LiteRTLM** runs Gemma 4 E2B (`gemma-4-e2b`) on the device through the
OpenAI-compatible server of Google's LiteRT-LM (`lib/AI/lib_bejson_AI_bejson_litertlm.py`,
provider key `litertlm`, no API key). Install `litert-lm` and import the model
with the litert-lm CLI first (this tool does not download models), then open
**Settings > Local Model (LiteRT-LM)** and press **Start**: it runs
`litert-lm serve --port 9379` as a subprocess (or reuses a server already
answering at `http://127.0.0.1:9379`; override with `LITERTLM_URL`) and checks
the model is listed on `/v1/models`. Choosing the **LiteRT-LM Local** service
streams tokens over SSE like Ollama Local and sends earlier turns as context
(`litertlm_history_messages`, default 20). It is also available to scripts as
`ai_dispatch_call("litertlm", ...)`.

**Chat logs.** Every exchange on every service is written to
`data/chat_logs/<session_id>.bejson` (BEJSON 104, one record per message).
The **Logs** tab lists past chats and can open, save (download), or delete
them; **New chat** starts a fresh session. Tap a message bubble to select it
and use **Copy**.

## The CLI tools (`CLI/`)

One folder per provider, each a standalone script:

```bash
cd CLI/groq_cli
python3 prompt_groq.py "your prompt here"
python3 prompt_groq.py -l          # list available models
python3 prompt_groq.py -i          # show loaded keys / registry info
python3 prompt_groq.py -m <model_id> -s "<system instruction>" "prompt"
```

Available tools: `gemini_cli`, `groq_cli`, `grok_cli`, `huggingface_cli`,
`ollama_cli`, `openrouter_cli`, `tokenrouter_cli`, `transcribe_cli`
(audio/video transcription via Gemini), and `menu_cli` — an interactive
launcher that also validates every config file in the project and can
configure the active model per service.

All CLI tools share one config, `CLI/config/cli_shared_config.104a.bejson`,
resolved via `CLI/config/cli_shared_config.py`: `portable_mode` (keep
`false`), `library_path` (defaults to `../../lib/`), and
`model_registry_source` — `"unified"` (default; reads
`lib/ai_model_registry.bejson`, the same source the chat client uses) or
`"legacy"` (each provider's own dedicated model registry, exactly as
these tools worked before the unified registry existed).

## Brain (persistent memory)

Brain stores long-term notes in an MFDB at `data/brain/` and recalls them
into chat messages through the Context Bubble. Code: `lib/AI/lib_bejson_AI_brain_*.py`
(extension files of the AI family), CLI `CLI/brain_cli/cli_brain_manager.py`,
and the **Brain** tab in the chat client (Memories, Proposed, Snapshots,
Settings). The AI may only add/update/archive through a guarded path: its notes
are capped at priority 60, never pinned, and anything touching your own, locked
or pinned notes waits in **Proposed** for approval. Settings: `write_policy`
(`auto` applies small new AI notes, `review` holds all) and `memory_mode`
(`inline`, `pass`, `off`). Tests: `python3 -m unittest discover -s dev/tests/brain`.

## Versioning

Deliverables are named `CLI_AI-V<major>-PKG<n>` — `V` bumps mark a
release boundary (a cohesive, tested body of work); `PKG` increments on
every packaged delivery within that. Current: **V2.23.0 / PKG45** (tracker: `.bejson_project.json`). Full history in
`dev/change-log.md`.

- **Gemini.md gate:** `lib/AI/config/gemini_md_gate.104a.bejson` (`enabled`, `home_subdir`, `file_name`, `heading`, `max_chars`). When enabled and `~/.gemini/GEMINI.md` exists (any capitalisation of folder or file), its text is injected into the Persistent Policy allotment after `Persistent_Policy.md`, under that allotment's current rank and budget.
