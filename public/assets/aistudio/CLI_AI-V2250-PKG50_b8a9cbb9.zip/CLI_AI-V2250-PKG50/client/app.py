import os
import sys
import json
import time
import threading
import subprocess
import logging
from flask import Flask, render_template, request, jsonify, Response, send_file

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_DIR = os.path.join(BASE_DIR, 'static')

def load_bejson_config(config_path):
    if not os.path.exists(config_path):
        return {}
    with open(config_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if "Values" not in data or not data["Values"]:
        return {}
    config = {}
    fields = [f["name"] for f in data.get("Fields", [])]
    for row in data["Values"]:
        setting_name = None
        setting_val = None
        for i, field_name in enumerate(fields):
            if i < len(row):
                if field_name == "setting_name":
                    setting_name = row[i]
                elif field_name == "setting_value":
                    setting_val = row[i]
        if setting_name:
            config[setting_name] = setting_val
    return config

from client_constants import load_client_constants
CONFIG_DIR = os.path.join(BASE_DIR, 'config')
CLIENT_CONSTANTS = load_client_constants(CONFIG_DIR)

# Load config and patch sys.path before initializing the rest of the app
CONFIG_PATH = os.path.join(CONFIG_DIR, 'config.json')
APP_CONFIG = load_bejson_config(CONFIG_PATH)

# Portability mode is not implemented yet (GEMINI.MD: "if it's set to true it
# should do nothing and exit with a warning message"). Only `false` is
# supported for now, which points the client at a client-dependent library
# path rather than a portable subdirectory.
if APP_CONFIG.get("portable_mode") is True:
    print(
        "WARNING: portable_mode is set to true, but portable mode is not "
        "yet implemented. Set portable_mode to false in "
        "client/config/config.json and point library_path at the AI "
        "libraries directory. Exiting.",
        file=sys.stderr,
    )
    sys.exit(1)

lib_path = APP_CONFIG.get("library_path")
if lib_path:
    if not os.path.isabs(lib_path):
        lib_path = os.path.abspath(os.path.join(BASE_DIR, lib_path))

    if os.path.exists(lib_path) and lib_path not in sys.path:
        sys.path.insert(0, lib_path)

    # ai_dispatch_call (below) needs lib/AI and its Core dependency on
    # sys.path too - previously only the lib/ root was added, which was
    # enough for lib_ai_model_registry but not for the AI dispatch family.
    for _sub in ("AI", "Core"):
        _sub_path = os.path.join(lib_path, _sub)
        if os.path.exists(_sub_path) and _sub_path not in sys.path:
            sys.path.insert(0, _sub_path)

# Load Secure Environment Keys
def load_secure_env(path):
    if not os.path.exists(path): return {}
    with open(path, 'r', encoding='utf-8') as f:
        try: data = json.load(f)
        except Exception: return {}
    keys = {}
    fields = [f.get("name") for f in data.get("Fields", [])]
    for row in data.get("Values", []):
        var_name = None
        var_val = None
        for i, field_name in enumerate(fields):
            if i < len(row):
                if field_name == "var_name": var_name = row[i]
                elif field_name == "var_value": var_val = row[i]
        if var_name: keys[var_name] = var_val
    return keys

secure_env_path = APP_CONFIG.get("secure_env_path")
API_KEYS = load_secure_env(secure_env_path) if secure_env_path else {}
for k, v in API_KEYS.items():
    if k and v:
        os.environ[k] = str(v)

if not API_KEYS:
    print(f" WARNING: no keys loaded from secure_env_path: {secure_env_path!r} "
          f"(exists: {os.path.exists(secure_env_path) if secure_env_path else False}). "
          f"Every provider will report 'No valid API keys' until this is fixed — "
          f"see Settings > Environment in the UI, or edit "
          f"client/config/config.json's secure_env_path directly.")


def _update_config_setting(name: str, value) -> bool:
    """Updates one setting_name row's setting_value in-place in
    client/config/config.json, using the file's own Fields array to find
    the right column indices rather than assuming positions (same
    field-map-cache discipline as load_bejson_config above). Returns
    False if config.json doesn't exist or has no matching row."""
    if not os.path.exists(CONFIG_PATH):
        return False
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        data = json.load(f)
    fields = [f.get("name") for f in data.get("Fields", [])]
    try:
        name_idx = fields.index("setting_name")
        value_idx = fields.index("setting_value")
    except ValueError:
        return False
    found = False
    for row in data.get("Values", []):
        if len(row) > max(name_idx, value_idx) and row[name_idx] == name:
            row[value_idx] = value
            found = True
            break
    if not found:
        return False
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    return True


def _reload_secure_env(new_path: str) -> dict:
    """Re-points the client at a different secure env file at runtime (no
    restart needed): reloads API_KEYS, re-applies them to os.environ (so
    every provider's env_var_prefix-based KeyRegistry picks them up on its
    next call), persists the new path into config.json, and refreshes
    MODEL_REGISTRY's api_keys reference so a subsequent live model-list
    refresh uses the new keys too. Returns the same status shape as
    /api/settings/env_status."""
    global secure_env_path, API_KEYS, APP_CONFIG
    secure_env_path = new_path
    API_KEYS = load_secure_env(new_path) if new_path else {}
    for k, v in API_KEYS.items():
        if k and v:
            os.environ[k] = str(v)
    _update_config_setting("secure_env_path", new_path)
    APP_CONFIG["secure_env_path"] = new_path
    if MODEL_REGISTRY is not None:
        MODEL_REGISTRY.api_keys = API_KEYS
    return {
        "path": new_path,
        "exists": bool(new_path and os.path.exists(new_path)),
        "key_count": len(API_KEYS),
        "key_names": sorted(API_KEYS.keys()),
    }


app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)

try:
    from lib_bejson_AI_ai_dispatch import ai_dispatch_call
except ImportError as e:
    ai_dispatch_call = None
    print(f"lib_bejson_AI_ai_dispatch not found ({e}) — /api/chat will be unable to serve any service.")

# Client-facing service name -> ai_dispatch_call provider key. The two
# don't always match ("TokenRoute" here vs. "tokenrouter" in
# ai_dispatch.py's PROVIDERS - a pre-existing naming inconsistency in this
# project, not introduced here) so this mapping is the single place that
# reconciles it, rather than hardcoding the translation at each call site.
SERVICE_TO_DISPATCH_PROVIDER = {
    "Gemini": "gemini",
    "GeminiREST": "geminirest",
    "Groq": "groq",
    "Grok": "grok",
    "HuggingFace": "huggingface",
    "Ollama": "ollama",
    "OpenRouter": "openrouter",
    "TokenRoute": "tokenrouter",
}

# ── AI Model Registry ────────────────────────────────────────
REGISTRY_PATH = os.path.join(BASE_DIR, '..', 'lib', 'ai_model_registry.bejson')
try:
    from lib_ai_model_registry import AIModelRegistry
    MODEL_REGISTRY = AIModelRegistry(REGISTRY_PATH, API_KEYS)
    MODEL_REGISTRY.load()
except ImportError:
    MODEL_REGISTRY = None
    print("lib_ai_model_registry not found — /api/models will use fallback.")

# ── Chat logs + local Ollama server (v2.13.0) ─────────────────────────
_client_logger = logging.getLogger("cli_ai.client")
DATA_DIR = os.path.abspath(os.path.join(BASE_DIR, '..', 'data'))

from chat_logs import ChatLogStore, valid_session_id
CHAT_LOGS = ChatLogStore(os.path.join(DATA_DIR, 'chat_logs'))

def _log_message(session_id, role, sender, service, model, content):
    """Append one message to the session's BEJSON chat log (no-op without a
    valid session id; a logging failure never breaks the chat itself)."""
    if not session_id:
        return
    try:
        CHAT_LOGS.append(session_id, role, sender, service, model, content)
    except Exception as e:
        _client_logger.error("Chat log write failed: %s", e)


# ── AI_Profile files with embedded Parser / Renderer (v2.15.0) ────────
# Profiles live in profiles_dir (config.json, relative to this folder). A
# profile's embedded code only runs once the user has reviewed it and
# approved its fingerprint; approvals are stored in data/.
_profiles_dir_cfg = APP_CONFIG.get("profiles_dir") or "../profiles/profiles"
if not os.path.isabs(_profiles_dir_cfg):
    _profiles_dir_cfg = os.path.abspath(os.path.join(BASE_DIR, _profiles_dir_cfg))
try:
    from profile_support import ProfileStore, profile_safe_name
    PROFILE_STORE = ProfileStore(_profiles_dir_cfg, os.path.join(DATA_DIR, 'approved_profile_code.bejson'))
except ImportError as _e:
    PROFILE_STORE = None
    profile_safe_name = None
    _client_logger.warning("Profile support unavailable (%s) - profiles disabled.", _e)


def _profiles_unavailable():
    return jsonify({"status": "error", "response": "Profile support is unavailable - check server logs."}), 503


def _resolve_profile_instruction(name):
    """(instruction, error_message). No name -> (None, None). An unknown or
    invalid profile is an error rather than a silent fallback."""
    if not name:
        return None, None
    if PROFILE_STORE is None:
        return None, "Profile support is unavailable - check server logs."
    instruction = PROFILE_STORE.system_instruction(name)
    if instruction is None:
        return None, f"Unknown or invalid profile: {name}"
    return instruction, None


@app.route('/api/profiles', methods=['GET'])
def api_profiles_list():
    if PROFILE_STORE is None:
        return _profiles_unavailable()
    return jsonify({"status": "success", "profiles": [PROFILE_STORE.summary(n) for n in PROFILE_STORE.names()]})


@app.route('/api/profiles/<name>', methods=['GET'])
def api_profiles_detail(name):
    if PROFILE_STORE is None:
        return _profiles_unavailable()
    detail = PROFILE_STORE.detail(name)
    if detail is None:
        return jsonify({"status": "error", "response": "Unknown or invalid profile."}), 404
    return jsonify({"status": "success", "profile": detail})


@app.route('/api/profiles/<name>/approve', methods=['POST'])
def api_profiles_approve(name):
    if PROFILE_STORE is None:
        return _profiles_unavailable()
    fingerprint = (request.json or {}).get('fingerprint')
    if not isinstance(fingerprint, str):
        return jsonify({"status": "error", "response": "fingerprint is required."}), 400
    result = PROFILE_STORE.approve(name, fingerprint)
    if not result["success"]:
        return jsonify({"status": "error", "response": result["reason"]}), 409
    return jsonify({"status": "success", "fingerprint": result["fingerprint"]})


@app.route('/api/profiles/<name>/revoke', methods=['POST'])
def api_profiles_revoke(name):
    if PROFILE_STORE is None:
        return _profiles_unavailable()
    detail = PROFILE_STORE.detail(name)
    fingerprint = (detail or {}).get('fingerprint') or (request.json or {}).get('fingerprint')
    if not isinstance(fingerprint, str):
        return jsonify({"status": "error", "response": "Nothing to revoke."}), 400
    result = PROFILE_STORE.revoke(fingerprint)
    return jsonify({"status": "success" if result["success"] else "error", "response": result.get("reason", "")})


@app.route('/api/profiles/<name>/sandbox', methods=['GET'])
def api_profiles_sandbox(name):
    """srcdoc for the sandboxed renderer iframe. Refused unless approved."""
    if PROFILE_STORE is None:
        return _profiles_unavailable()
    out = PROFILE_STORE.sandbox(name)
    if not out.get("success"):
        return jsonify({"status": "error", "response": out.get("reason") or "Sandbox unavailable."}), 403
    return jsonify({"status": "success", "srcdoc": out["srcdoc"],
                    "iframe_attributes": out["iframe_attributes"],
                    "parser_language": out.get("parser_language"),
                    "fingerprint": out.get("fingerprint")})


@app.route('/api/profiles/<name>/parse', methods=['POST'])
def api_profiles_parse(name):
    """Runs a profile's PYTHON parser server-side (approved profiles only).
    JavaScript parsers run in the browser sandbox instead."""
    if PROFILE_STORE is None:
        return _profiles_unavailable()
    raw_text = (request.json or {}).get('raw_text')
    if not isinstance(raw_text, str):
        return jsonify({"status": "error", "response": "raw_text is required."}), 400
    detail = PROFILE_STORE.detail(name)
    if detail is None or detail.get("parser_language") != "python":
        return jsonify({"status": "error", "response": "Profile has no Python parser."}), 400
    out = PROFILE_STORE.run_parser(name, raw_text)
    if not out.get("success"):
        return jsonify({"status": "error", "response": out.get("reason") or "Parser failed."}), 422
    return jsonify({"status": "success", "result": out["result"]})


@app.route('/api/models', methods=['GET'])
def api_models():
    service = request.args.get('service', '')
    source_type = MODEL_REGISTRY.get_model_source_type(service) if MODEL_REGISTRY else None

    if MODEL_REGISTRY:
        models = MODEL_REGISTRY.get_models(service)
        if models:
            return jsonify({'models': models, 'source_type': source_type})

    # Fallback: Gemini static list if registry unavailable
    if service in ('Gemini', 'GeminiREST'):
        models = [
            {'id': 'gemini-3.8-flash',      'name': 'Gemini 3.8 Flash'},
            {'id': 'gemini-3.7-flash',      'name': 'Gemini 3.7 Flash'},
            {'id': 'gemini-3.6-flash',      'name': 'Gemini 3.6 Flash'},
            {'id': 'gemini-3.5-flash',      'name': 'Gemini 3.5 Flash'},
            {'id': 'gemini-3.5-flash-lite', 'name': 'Gemini 3.5 Flash Lite'},
        ]
        return jsonify({'models': models, 'source_type': 'hardcoded'})

    return jsonify({'models': [], 'source_type': source_type, 'error': f'No models found for service: {service}'})


@app.route('/api/models/update', methods=['POST'])
def api_models_update():
    """Trigger a live registry refresh for specified services."""
    if not MODEL_REGISTRY:
        return jsonify({'status': 'error', 'message': 'Registry not available.'})
    data = request.json or {}
    services = data.get('services', ['OpenRouter', 'TokenRoute'])
    try:
        MODEL_REGISTRY.update_registry(services=services)
        summary = {s: len(MODEL_REGISTRY.get_models(s)) for s in services}
        return jsonify({'status': 'success', 'updated': summary})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

# ── Settings: environment file path (browse + point-at-it) ──────────────
# The single biggest cause of "No valid API keys" for every provider at
# once: secure_env_path in config.json defaulted to an Android-only path
# that silently doesn't exist on whatever device this actually runs on --
# load_secure_env() just returns {} with no visible error anywhere in the
# UI. These three endpoints let the person actually see that status and
# fix it without hand-editing a BEJSON config file.

_BROWSE_START_CANDIDATES = [
    "/storage/emulated/0/.env/secure",
    "/storage/emulated/0",
    os.path.expanduser("~"),
]


@app.route('/api/settings/env_status', methods=['GET'])
def api_settings_env_status():
    return jsonify({
        "path": secure_env_path,
        "exists": bool(secure_env_path and os.path.exists(secure_env_path)),
        "key_count": len(API_KEYS),
        "key_names": sorted(API_KEYS.keys()),
    })


@app.route('/api/settings/env_path', methods=['POST'])
def api_settings_env_path():
    data = request.json or {}
    new_path = (data.get('path') or '').strip()
    if not new_path:
        return jsonify({'status': 'error', 'message': 'No path given.'})
    status = _reload_secure_env(new_path)
    if not status['exists']:
        return jsonify({'status': 'error', 'message': f'No file found at {new_path}', **status})
    if status['key_count'] == 0:
        return jsonify({'status': 'error', 'message': 'File exists but no keys were parsed from it (check its Fields/Values shape).', **status})
    return jsonify({'status': 'success', **status})


# ── Settings > Token Budget (v2.11.2) ────────────────────────────────────
# max_context_tokens is the total token budget for the assembled Context
# Bubble (the "~N / 8000 tokens" figure on the Bubble sub-tab). It lives in
# lib/AI/config/ai_constants.bejson and is read fresh on every bubble
# assembly, so a change here applies to the very next message. Uses the
# library's own ai_constants_load()/ai_constants_set() -- the library itself
# is not modified.
TOKEN_BUDGET_MIN = 500
TOKEN_BUDGET_MAX = 2000000

try:
    from lib_bejson_AI_ai_constants import (
        ai_constants_load, ai_constants_set, ai_constants_get_defaults, ai_constants_init,
    )
    _TOKEN_SETTINGS_AVAILABLE = True
except ImportError as _e:
    _TOKEN_SETTINGS_AVAILABLE = False
    print(f"lib_bejson_AI_ai_constants not found ({_e}) — token budget settings unavailable.")


def _token_budget_payload():
    from pathlib import Path
    cfg = Path(AI_CONFIG_DIR)
    ai_constants_init(cfg)
    effective = ai_constants_load(cfg)
    return {
        'status': 'success',
        'max_context_tokens': effective.get('max_context_tokens'),
        'default': ai_constants_get_defaults().get('max_context_tokens'),
        'min': TOKEN_BUDGET_MIN,
        'max': TOKEN_BUDGET_MAX,
    }


@app.route('/api/settings/tokens', methods=['GET'])
def api_settings_tokens_get():
    if not _TOKEN_SETTINGS_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Constants library unavailable.'})
    try:
        return jsonify(_token_budget_payload())
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Could not read token budget: {e}'})


@app.route('/api/settings/tokens', methods=['POST'])
def api_settings_tokens_set():
    if not _TOKEN_SETTINGS_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Constants library unavailable.'})
    data = request.json or {}
    reset = bool(data.get('reset'))
    raw = data.get('max_context_tokens')
    from pathlib import Path
    cfg = Path(AI_CONFIG_DIR)
    if reset:
        value = None  # None restores the library default on next load
    else:
        try:
            value = int(str(raw).strip())
        except (TypeError, ValueError):
            return jsonify({'status': 'error', 'message': 'Max tokens must be a whole number.'})
        if value < TOKEN_BUDGET_MIN or value > TOKEN_BUDGET_MAX:
            return jsonify({'status': 'error',
                            'message': f'Max tokens must be between {TOKEN_BUDGET_MIN} and {TOKEN_BUDGET_MAX}.'})
    try:
        ai_constants_init(cfg)
        if not ai_constants_set(cfg, 'max_context_tokens', value):
            return jsonify({'status': 'error', 'message': 'Could not write ai_constants.bejson.'})
        return jsonify(_token_budget_payload())
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Save failed: {e}'})


@app.route('/api/settings/browse', methods=['GET'])
def api_settings_browse():
    """Server-side directory listing so the person can navigate this
    device's real filesystem from the browser and pick the actual env
    file, instead of guessing a path. This only makes sense because
    client and server are the same device here (Termux/Android) -- a
    browser's own file input cannot see the server's filesystem."""
    req_path = request.args.get('path', '').strip()

    if not req_path:
        candidates = [p for p in _BROWSE_START_CANDIDATES if os.path.isdir(p)]
        start = candidates[0] if candidates else os.path.expanduser("~")
        req_path = start

    req_path = os.path.abspath(req_path)
    if not os.path.isdir(req_path):
        return jsonify({'status': 'error', 'message': f'Not a directory: {req_path}'})

    try:
        names = sorted(os.listdir(req_path), key=lambda n: n.lower())
    except PermissionError:
        return jsonify({'status': 'error', 'message': f'Permission denied: {req_path}'})

    entries = []
    for name in names:
        if name.startswith('.') and name not in ('.env',):
            continue  # hide dotfiles/dirs except the .env folder itself, which is exactly what's usually being browsed to
        full = os.path.join(req_path, name)
        try:
            is_dir = os.path.isdir(full)
        except OSError:
            continue
        if is_dir or name.lower().endswith(('.json', '.py', '.bejson')):
            entries.append({"name": name, "is_dir": is_dir, "full_path": full})

    parent = os.path.dirname(req_path.rstrip('/')) or '/'
    return jsonify({
        'status': 'success',
        'current_path': req_path,
        'parent_path': parent if parent != req_path else None,
        'entries': entries,
    })

# ── Context Bubble (v2, ranked allotments) ───────────────────
# Each turn the bubble is assembled from ranked, budgeted allotments (persistent
# policy, profile, attachments, context, chat history), each chunked into
# <context_dir>/bubble/ and the whole bubble chunked and prepended to the
# prompt (lib_bejson_AI_ai_context_bubble.py). Unused budget spills up to the
# highest-ranking over-budget allotment. The bubble is rebuilt every 5 turns or
# the moment attachments / context / policy / profile / config change.
# Ranks, percentages and enable flags: lib/AI/config/context_bubble.bejson.
# Total budget: max_context_tokens in ai_constants.bejson (Settings > Token
# Budget). context_dir is per-client (client/data/context); config_dir is the
# shared lib/AI/config.
#
# Two genuinely separate tracked-file systems, each backed by its own
# directory (same generic lib_bejson_AI_ai_context_files.py library,
# instantiated twice against two different dirs -- it has no module-level
# state, so this is safe):
#   ATTACH_DIR   -- Attachments sub-tab. Checking a file here means it's
#                   sent WITH THE NEXT MESSAGE ONLY (see /api/chat below);
#                   every send auto-unchecks them all (client-side). Never
#                   injected into the persistent bubble.
#   CONTEXT_DIR  -- Context sub-tab. Checking a file here + the quick-text
#                   box only curate what the NEXT Save will chunk. The
#                   only thing actually registered as a persistent Context
#                   Bubble section is "Staged Chunk" (context_chunker.py):
#                   hitting Save wipes whatever was previously
#                   staged/chunked, re-stages+re-chunks the currently-
#                   enabled context files plus the quick-text box, and
#                   that chunk becomes the injected content from then on
#                   -- until the next Save replaces it again.
# These were one shared list/checkbox in an earlier pass, which conflated
# "send this with my message" and "study this silently forever" into the
# same action -- split apart per explicit follow-up instruction.
ATTACH_DIR = os.path.join(BASE_DIR, 'data', 'attachments')
CONTEXT_DIR = os.path.join(BASE_DIR, 'data', 'context')
AI_CONFIG_DIR = os.path.join(BASE_DIR, '..', 'lib', 'AI', 'config')
BRAIN_STORE = None
BRAIN_HANDLE = None
try:
    from lib_bejson_AI_ai_context_bubble import (
        ai_bubble_init, ai_bubble_prepare, ai_bubble_preview, BubbleIntegrityError,
        ai_bubble_config_update,
    )
    from lib_bejson_AI_ai_bubble_allotments import register_builtin_allotments
    from lib_bejson_AI_ai_context_files import (
        ai_context_files_list,
        ai_context_files_import,
        ai_context_files_toggle,
        ai_context_files_delete,
    )
    import context_chunker
    # Five built-in allotments (policy, profile, attachments, context, chat
    # history) -- ranks, percentages and enable flags live in
    # lib/AI/config/context_bubble.bejson and are re-read every turn.
    register_builtin_allotments(
        ai_context_files_list, ATTACH_DIR, os.path.join(ATTACH_DIR, 'imports'),
        context_chunker.chunker_build_section)
    # Brain (v2.23.0): persistent memory. Registered BEFORE ai_bubble_init so its two
    # allotments (brain_pinned, brain_recall) get rows in context_bubble.bejson. A Brain
    # failure never disables the rest of the bubble.
    try:
        from lib_bejson_AI_brain_store import BrainStore
        from lib_bejson_AI_brain_bubble import brain_bubble_register
        BRAIN_STORE = BrainStore(os.path.join(DATA_DIR, 'brain'), config_dir=AI_CONFIG_DIR)
        BRAIN_STORE.init()
        BRAIN_HANDLE = brain_bubble_register(BRAIN_STORE)
    except Exception as _brain_err:
        BRAIN_STORE = BRAIN_HANDLE = None
        _client_logger.warning("Brain unavailable (%s) - memory features disabled.", _brain_err)
    ai_bubble_init(
        CONTEXT_DIR, AI_CONFIG_DIR,
        policy_text="You are an AI assistant accessed through Elton Boehnen's CLI_AI chat client.",
    )
    CONTEXT_BUBBLE_AVAILABLE = True
except ImportError as e:
    CONTEXT_BUBBLE_AVAILABLE = False
    context_chunker = None
    _client_logger.warning("Context bubble libraries not found (%s) - context file/bubble endpoints unavailable.", e)


def _content_dir():
    return os.path.join(CONTEXT_DIR, 'imports')


def _attach_content_dir():
    return os.path.join(ATTACH_DIR, 'imports')


# ── Attachments (Attach sub-tab: per-message, never injected as context) ────

@app.route('/api/attach/files', methods=['GET'])
def api_attach_files_list_route():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'files': [], 'error': 'Context system unavailable.'})
    return jsonify({'files': ai_context_files_list(ATTACH_DIR)})


@app.route('/api/attach/files', methods=['POST'])
def api_attach_files_import_route():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    filename = (data.get('filename') or 'untitled.txt').strip()
    content = data.get('content') or ''
    if not content.strip():
        return jsonify({'status': 'error', 'message': 'File is empty.'})
    record = ai_context_files_import(ATTACH_DIR, filename, content)
    return jsonify({'status': 'success', 'file': record})


@app.route('/api/attach/files/toggle', methods=['POST'])
def api_attach_files_toggle_route():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    file_id = data.get('file_id')
    new_state = ai_context_files_toggle(ATTACH_DIR, file_id) if file_id else None
    if new_state is None:
        return jsonify({'status': 'error', 'message': f'File not found: {file_id}'})
    return jsonify({'status': 'success', 'enabled': new_state})


@app.route('/api/attach/files/<file_id>', methods=['DELETE'])
def api_attach_files_delete_route(file_id):
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    ok = ai_context_files_delete(ATTACH_DIR, file_id)
    if not ok:
        return jsonify({'status': 'error', 'message': f'File not found: {file_id}'})
    return jsonify({'status': 'success'})


@app.route('/api/attach/import_folder', methods=['POST'])
def api_attach_import_folder():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    files = data.get('files', [])
    imported = []
    for f in files:
        rel_path = (f.get('relative_path') or '').strip()
        content = f.get('content') or ''
        if not rel_path or not content.strip():
            continue
        imported.append(ai_context_files_import(ATTACH_DIR, rel_path, content))
    return jsonify({'status': 'success', 'imported': imported})


@app.route('/api/attach/import_zip', methods=['POST'])
def api_attach_import_zip():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    b64 = data.get('content_base64')
    if not b64:
        return jsonify({'status': 'error', 'message': 'No zip content provided.'})
    try:
        import base64
        zip_bytes = base64.b64decode(b64)
        entries = context_chunker.chunker_extract_zip_entries(zip_bytes)
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Failed to read zip: {e}'})
    imported = [
        ai_context_files_import(ATTACH_DIR, e['relative_path'], e['content'])
        for e in entries
    ]
    return jsonify({'status': 'success', 'imported': imported, 'skipped_binary': True})


# ── Context (Context sub-tab: staged, chunked, persistently injected) ───────

@app.route('/api/context/import_folder', methods=['POST'])
def api_context_import_folder():
    """Accepts {"files": [{"relative_path": ..., "content": ...}, ...]} --
    the JS side reads each File from a webkitdirectory input as text and
    sends them all in one batch. Each becomes its own tracked context file,
    named by its relative path (so folder structure is preserved for the
    chunker's Relative_Path field later)."""
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    files = data.get('files', [])
    imported = []
    for f in files:
        rel_path = (f.get('relative_path') or '').strip()
        content = f.get('content') or ''
        if not rel_path or not content.strip():
            continue
        imported.append(ai_context_files_import(CONTEXT_DIR, rel_path, content))
    return jsonify({'status': 'success', 'imported': imported})


@app.route('/api/context/import_zip', methods=['POST'])
def api_context_import_zip():
    """Accepts {"content_base64": "..."} -- a zip file, base64-encoded
    client-side. Every text-decodable entry becomes its own tracked
    context file, named by its path inside the zip."""
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    b64 = data.get('content_base64')
    if not b64:
        return jsonify({'status': 'error', 'message': 'No zip content provided.'})
    try:
        import base64
        zip_bytes = base64.b64decode(b64)
        entries = context_chunker.chunker_extract_zip_entries(zip_bytes)
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Failed to read zip: {e}'})

    imported = [
        ai_context_files_import(CONTEXT_DIR, e['relative_path'], e['content'])
        for e in entries
    ]
    return jsonify({'status': 'success', 'imported': imported, 'skipped_binary': True})


@app.route('/api/context/quick_text', methods=['GET'])
def api_context_quick_text_get():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'text': ''})
    return jsonify({'text': context_chunker.chunker_load_quick_text(CONTEXT_DIR)})


@app.route('/api/context/quick_text', methods=['POST'])
def api_context_quick_text_set():
    """Persists the quick-text draft on its own (e.g. a debounced
    autosave), independent of Save -- so it survives a reload even before
    the user commits it into a chunk."""
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    context_chunker.chunker_save_quick_text(CONTEXT_DIR, data.get('text', ''))
    return jsonify({'status': 'success'})


@app.route('/api/context/save_chunk', methods=['POST'])
def api_context_save_chunk():
    """Context sub-tab's Save button: every time this is hit, it's a
    deliberate user action, not a background poll -- so it always wipes
    whatever was previously staged/chunked and re-stages+re-chunks from
    scratch (no skip-if-unchanged optimization here; that's still
    available to other callers via chunker_run_save's force=False
    default, just not used by this button). Folds in the quick-text box
    alongside the enabled context files."""
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    enabled = [f for f in ai_context_files_list(CONTEXT_DIR) if f['enabled']]
    data = request.json or {}
    quick_text = data.get('quick_text', '')
    result = context_chunker.chunker_run_save(CONTEXT_DIR, enabled, _content_dir(), quick_text=quick_text, force=True)
    return jsonify({'status': 'success', **result})


@app.route('/api/context/files', methods=['GET'])
def api_context_files_list_route():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'files': [], 'error': 'Context system unavailable.'})
    return jsonify({'files': ai_context_files_list(CONTEXT_DIR)})


@app.route('/api/context/files', methods=['POST'])
def api_context_files_import_route():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    filename = (data.get('filename') or 'untitled.txt').strip()
    content = data.get('content') or ''
    if not content.strip():
        return jsonify({'status': 'error', 'message': 'File is empty.'})
    record = ai_context_files_import(CONTEXT_DIR, filename, content)
    return jsonify({'status': 'success', 'file': record})


@app.route('/api/context/files/toggle', methods=['POST'])
def api_context_files_toggle_route():
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    data = request.json or {}
    file_id = data.get('file_id')
    new_state = ai_context_files_toggle(CONTEXT_DIR, file_id) if file_id else None
    if new_state is None:
        return jsonify({'status': 'error', 'message': f'File not found: {file_id}'})
    return jsonify({'status': 'success', 'enabled': new_state})


@app.route('/api/context/files/<file_id>', methods=['DELETE'])
def api_context_files_delete_route(file_id):
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'})
    ok = ai_context_files_delete(CONTEXT_DIR, file_id)
    if not ok:
        return jsonify({'status': 'error', 'message': f'File not found: {file_id}'})
    return jsonify({'status': 'success'})


@app.route('/api/context/bubble', methods=['GET'])
def api_context_bubble():
    """Live preview of what the next prompt's bubble would contain. Built in a
    throw-away temp directory: it does not touch the live bubble, the turn
    counter or the rebuild schedule."""
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'text': '', 'error': 'Context system unavailable.'})
    session_id = valid_session_id(request.args.get('session_id'))
    extras = {'history': _session_history(session_id)}
    try:
        return jsonify(ai_bubble_preview(CONTEXT_DIR, AI_CONFIG_DIR, '', extras=extras))
    except Exception as e:
        _client_logger.error("Bubble preview failed: %s", e)
        return jsonify({'text': '', 'error': f'Bubble preview failed: {e}'})


@app.route('/api/context/bubble/allotments', methods=['POST'])
def api_context_bubble_allotments():
    """Enable/disable allotments (or retune weights) and return the re-flowed
    bubble preview. Body: {"changes": {name: {"enabled": bool, "pct": 0..100}},
    "normalize": bool?, "session_id": str?}. All-or-nothing; the live bubble
    rebuilds on the next prompt because the config signature changes."""
    if not CONTEXT_BUBBLE_AVAILABLE:
        return jsonify({'status': 'error', 'message': 'Context system unavailable.'}), 503
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or not isinstance(body.get('changes', {}), dict):
        return jsonify({'status': 'error', 'message': 'Body must be {"changes": {...}}.'}), 400
    normalize = body.get('normalize')
    try:
        ai_bubble_config_update(AI_CONFIG_DIR, body.get('changes', {}), normalize=normalize)
    except ValueError as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400
    except Exception as e:
        _client_logger.error("Bubble allotment update failed: %s", e)
        return jsonify({'status': 'error', 'message': f'Update failed: {e}'}), 500
    session_id = valid_session_id(body.get('session_id'))
    try:
        preview = ai_bubble_preview(CONTEXT_DIR, AI_CONFIG_DIR, '',
                                    extras={'history': _session_history(session_id)})
    except Exception as e:
        _client_logger.error("Bubble preview failed: %s", e)
        preview = {'text': '', 'error': f'Bubble preview failed: {e}'}
    return jsonify({'status': 'success', 'bubble': preview})


def _session_history(session_id):
    """Prior user/assistant turns of a session as [{role, content}, ...]."""
    if not session_id:
        return []
    return [{"role": m["role"], "content": m["content"]}
            for m in CHAT_LOGS.load(session_id) if m["role"] in ("user", "assistant")]


def _assemble_dispatch_input(message, attached_file_ids, profile_instruction=None,
                             session_id=None, include_history=True):
    """Builds the text actually sent to a provider: the context bubble (policy,
    profile, attachments, context, chat history -- ranked, budgeted, chunked)
    prepended to the user's message. Shared by /api/chat and /api/chat/stream.
    include_history=False when the caller already sends prior turns itself.
    Returns (dispatch_input, bubble_stats)."""
    if CONTEXT_BUBBLE_AVAILABLE:
        extras = {
            'attached_file_ids': attached_file_ids or [],
            'profile_instruction': profile_instruction or '',
            'history': _session_history(session_id) if include_history else [],
        }
        skip = () if include_history else ('chat_history',)
        try:
            bubble = ai_bubble_prepare(CONTEXT_DIR, AI_CONFIG_DIR, message, extras=extras, skip=skip)
            stats = {k: v for k, v in bubble.items() if k != 'text'}
            if BRAIN_HANDLE is not None:
                stats['brain_recalled'] = [
                    {'id': r['id'], 'title': r['title'], 'category': r['category'], 'matched': r['matched']}
                    for r in BRAIN_HANDLE.last_recall]
            if bubble.get('text'):
                # Prepended to user_input rather than passed as system_instruction:
                # ai_dispatch_call's system_instruction isn't honoured by every
                # provider, so prepending guarantees all services receive it. Each
                # allotment carries its own directive (attachments are discussable,
                # background context is not).
                return f"{bubble['text']}\n\n---\n\n{message}", stats
            return message, stats
        except Exception as e:
            _client_logger.error("Context bubble assembly failed: %s", e)
    # Fallback (bubble unavailable or failed): profile instruction only.
    dispatch_input = message
    if profile_instruction:
        dispatch_input = (
            "[PROFILE INSTRUCTION — follow this for the format and behaviour "
            "of your reply.]\n" + profile_instruction + "\n[END PROFILE INSTRUCTION]\n\n---\n\n"
            + dispatch_input
        )
    return dispatch_input, None


@app.route('/api/chat', methods=['POST'])
def api_chat():
    data = request.json
    service = data.get('service')
    model = data.get('model')
    message = data.get('message')
    attached_file_ids = data.get('attached_file_ids', [])
    session_id = valid_session_id(data.get('session_id'))
    service_label = data.get('service_label') or service
    profile_instruction, profile_error = _resolve_profile_instruction(data.get('profile'))
    if profile_error:
        return jsonify({"status": "error", "response": profile_error})

    if not message:
        return jsonify({"status": "error", "response": "Message cannot be empty."})

    if ai_dispatch_call is None:
        return jsonify({"status": "error", "response": "AI dispatch library is unavailable - check server logs."})

    provider = SERVICE_TO_DISPATCH_PROVIDER.get(service)
    if not provider:
        return jsonify({"status": "error", "response": f"Unknown service: {service}"})

    dispatch_input, bubble_stats = _assemble_dispatch_input(
        message, attached_file_ids, profile_instruction, session_id=session_id)

    try:
        result = ai_dispatch_call(provider, dispatch_input, model_id=model or None)
    except Exception as e:
        return jsonify({"status": "error", "response": f"Internal error: {str(e)}"})

    if result.get("success"):
        reply_text = result.get("content") or "No response"
        _log_message(session_id, "user", "User", service, model, message)
        _log_message(session_id, "assistant", service_label, service, model, reply_text)
        return jsonify({"status": "success", "response": reply_text, "bubble_stats": bubble_stats})
    return jsonify({"status": "error", "response": result.get("error") or "Request failed."})

# ── Chat logs ─────────────────────────────────────────────────────────
@app.route('/api/logs', methods=['GET'])
def api_logs_list():
    return jsonify({"sessions": CHAT_LOGS.list_sessions()})


@app.route('/api/logs/<sid>', methods=['GET'])
def api_logs_get(sid):
    if not valid_session_id(sid):
        return jsonify({"error": "Invalid session id"}), 400
    return jsonify({"messages": CHAT_LOGS.load(sid)})


@app.route('/api/logs/<sid>', methods=['DELETE'])
def api_logs_delete(sid):
    if not valid_session_id(sid):
        return jsonify({"error": "Invalid session id"}), 400
    return jsonify({"deleted": CHAT_LOGS.delete(sid)})


@app.route('/api/logs/<sid>/download', methods=['GET'])
def api_logs_download(sid):
    if not valid_session_id(sid) or not CHAT_LOGS.exists(sid):
        return jsonify({"error": "Not found"}), 404
    return send_file(CHAT_LOGS.path_of(sid), as_attachment=True, download_name=f"chat-{sid}.bejson")


if BRAIN_STORE is not None:
    from brain_routes import register_brain_routes
    register_brain_routes(app, BRAIN_STORE, BRAIN_HANDLE, _client_logger)


@app.route('/')
def index():
    return render_template('chat.html', constants=CLIENT_CONSTANTS)

def launch_browser():
    # Wait a moment for server to start
    time.sleep(1.5)
    try:
        # Termux clipboard and open
        subprocess.run(['termux-clipboard-set'], input=SERVER_URL.encode(), check=False)
        subprocess.run(['termux-open', SERVER_URL], check=False)
    except Exception as e:
        print(f"Failed to launch browser: {e}")

if __name__ == '__main__':
    PORT = CLIENT_CONSTANTS.get('port', 5000)
    HOST = CLIENT_CONSTANTS.get('host', '127.0.0.1')
    SERVER_URL = f"http://{HOST}:{PORT}"
    
    print("=" * 60)
    print(f" CLI AI V15 - Multi-Provider Chat")
    print(f" Server running at: {SERVER_URL}")
    print(f" Secure Env: {secure_env_path}")
    print(f" Loaded APIs: {list(API_KEYS.keys())}")
    print("=" * 60)

    threading.Thread(target=launch_browser, daemon=True).start()
    app.run(host='127.0.0.1', port=PORT, debug=False)
