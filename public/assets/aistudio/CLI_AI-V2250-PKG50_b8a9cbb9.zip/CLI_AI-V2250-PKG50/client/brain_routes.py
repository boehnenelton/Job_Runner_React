"""
Name:           brain_routes.py
Description:    Flask routes for the Brain tab (/api/brain/*). Thin layer over lib_bejson_AI_brain_*; every write goes through BrainStore.apply as the "user" actor, so user edits are written as user-origin, locked memories. Errors are returned as {status:"error", code, name, response}.
Version:        1.0.0
Date Created:   2026-10-27
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  01ceb20c-1219-48cd-ac11-66c89213070f
"""

from functools import wraps

from flask import jsonify, request

from lib_bejson_AI_brain_errors import BrainError
from lib_bejson_AI_brain_config import brain_config_load, brain_config_set
from lib_bejson_AI_brain_keywords import brain_keywords_recall
from lib_bejson_AI_brain_schema_registry import CatF, MemF, STATUS_ACTIVE, STATUS_ARCHIVED, schema_registry_split_keywords
import lib_bejson_AI_brain_snapshots as snapshots

VERSION = "1.0.0"
RELATIONAL_ID = "01ceb20c-1219-48cd-ac11-66c89213070f"
SETTABLE = {"write_policy": ("auto", "review"), "memory_mode": ("inline", "pass", "off")}


# JSON view of one memory row (category name resolved, keywords as a list).
def _memory_json(row: dict, cat_names: dict) -> dict:
    return {
        "id": row[MemF.ID], "category_id": row[MemF.CATEGORY_FK], "category": cat_names.get(row[MemF.CATEGORY_FK], "?"),
        "title": row[MemF.TITLE], "content": row[MemF.CONTENT], "keywords": schema_registry_split_keywords(row[MemF.KEYWORDS]),
        "priority": row[MemF.PRIORITY], "confidence": row[MemF.CONFIDENCE], "status": row[MemF.STATUS],
        "origin": row[MemF.ORIGIN], "pinned": bool(row[MemF.PINNED]), "locked": bool(row[MemF.LOCKED]),
        "supersedes": row[MemF.SUPERSEDES_FK], "created_at": row[MemF.CREATED_AT], "updated_at": row[MemF.UPDATED_AT],
    }


def _category_json(row: dict, counts: dict) -> dict:
    return {
        "id": row[CatF.ID], "name": row[CatF.NAME], "description": row[CatF.DESCRIPTION],
        "keywords": schema_registry_split_keywords(row[CatF.KEYWORDS]), "status": row[CatF.STATUS],
        "origin": row[CatF.ORIGIN], "protected": bool(row[CatF.PROTECTED]), "memories": counts.get(row[CatF.ID], 0),
    }


def register_brain_routes(app, store, handle, logger):
    # Wraps a route so BrainError and unexpected errors become JSON.
    def guarded(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except BrainError as exc:
                return jsonify({"status": "error", "code": exc.code, "name": exc.name, "response": exc.message}), 400
            except Exception as exc:  # noqa: BLE001 - routes always answer in JSON
                logger.error("Brain route %s failed: %s", fn.__name__, exc)
                return jsonify({"status": "error", "response": f"Internal error: {exc}"}), 500
        return wrapper

    def names():
        return {c[CatF.ID]: c[CatF.NAME] for c in store.categories(include_archived=True)}

    def body():
        return request.get_json(silent=True) or {}

    @app.route("/api/brain/status", methods=["GET"])
    @guarded
    def api_brain_status():
        info = store.status()
        info["limits"] = {k: store.limits[k] for k in ("max_memories", "max_content_chars", "max_title_chars", "ai_max_priority", "auto_max_priority")}
        return jsonify({"status": "success", **info})

    @app.route("/api/brain/categories", methods=["GET"])
    @guarded
    def api_brain_categories():
        counts = {}
        for row in store.memories(status=STATUS_ACTIVE):
            counts[row[MemF.CATEGORY_FK]] = counts.get(row[MemF.CATEGORY_FK], 0) + 1
        rows = store.categories(include_archived=request.args.get("all") == "1")
        return jsonify({"status": "success", "categories": [_category_json(r, counts) for r in rows]})

    @app.route("/api/brain/categories", methods=["POST"])
    @guarded
    def api_brain_category_create():
        d = body()
        res = store.apply({"op": "category_create", "name": d.get("name"), "description": d.get("description") or d.get("name"),
                           "keywords": d.get("keywords")})
        return jsonify({"status": "success", **res})

    @app.route("/api/brain/categories/<cat_id>/archive", methods=["POST"])
    @guarded
    def api_brain_category_archive(cat_id):
        return jsonify({"status": "success", **store.apply({"op": "category_archive", "id": cat_id})})

    @app.route("/api/brain/memories", methods=["GET"])
    @guarded
    def api_brain_memories():
        cat_names = names()
        rows = store.memories(category=request.args.get("category") or None, status=request.args.get("status") or None,
                              text=request.args.get("q") or None, include_archived=request.args.get("all") == "1")
        rows.sort(key=lambda r: (-int(bool(r[MemF.PINNED])), -r[MemF.PRIORITY], r[MemF.TITLE].casefold()))
        return jsonify({"status": "success", "memories": [_memory_json(r, cat_names) for r in rows]})

    @app.route("/api/brain/memories", methods=["POST"])
    @guarded
    def api_brain_memory_create():
        d = body()
        op = {"op": "memory_add", "category": d.get("category") or "General", "title": d.get("title"), "content": d.get("content"),
              "keywords": d.get("keywords"), "pinned": bool(d.get("pinned"))}
        for key in ("priority", "confidence"):
            if d.get(key) is not None:
                op[key] = d[key]
        return jsonify({"status": "success", **store.apply(op)})

    @app.route("/api/brain/memories/<mem_id>", methods=["PUT"])
    @guarded
    def api_brain_memory_update(mem_id):
        d = body()
        fields = {k: d[k] for k in ("title", "content", "keywords", "category", "priority", "confidence", "pinned", "locked", "status") if k in d}
        return jsonify({"status": "success", **store.apply({"op": "memory_update", "id": mem_id, "fields": fields})})

    @app.route("/api/brain/memories/<mem_id>", methods=["DELETE"])
    @guarded
    def api_brain_memory_archive(mem_id):
        return jsonify({"status": "success", **store.apply({"op": "memory_archive", "id": mem_id})})

    @app.route("/api/brain/memories/<mem_id>/pin", methods=["POST"])
    @guarded
    def api_brain_memory_pin(mem_id):
        return jsonify({"status": "success", **store.apply({"op": "memory_pin", "id": mem_id, "pinned": bool(body().get("pinned", True))})})

    @app.route("/api/brain/memories/<mem_id>/restore", methods=["POST"])
    @guarded
    def api_brain_memory_restore(mem_id):
        return jsonify({"status": "success", **store.apply({"op": "memory_update", "id": mem_id, "fields": {"status": STATUS_ACTIVE}})})

    @app.route("/api/brain/proposals", methods=["GET"])
    @guarded
    def api_brain_proposals():
        cat_names = names()
        data = store.proposals()
        memories = []
        for entry in data["memories"]:
            item = _memory_json(entry, cat_names)
            old = entry.get("supersedes")
            item["replaces"] = _memory_json(old, cat_names) if old else None
            memories.append(item)
        return jsonify({"status": "success", "categories": [_category_json(c, {}) for c in data["categories"]], "memories": memories})

    @app.route("/api/brain/proposals/<prop_id>/<verb>", methods=["POST"])
    @guarded
    def api_brain_proposal_act(prop_id, verb):
        if verb not in ("approve", "reject"):
            return jsonify({"status": "error", "response": "Unknown action."}), 404
        return jsonify({"status": "success", **store.apply({"op": f"proposal_{verb}", "id": prop_id})})

    @app.route("/api/brain/snapshots", methods=["GET"])
    @guarded
    def api_brain_snapshots():
        rows = [{k: s[k] for k in ("tier", "filename", "created_at", "reason", "valid")} | {"hash": (s["hash"] or "")[:12]}
                for s in snapshots.snapshots_list(store)]
        return jsonify({"status": "success", "snapshots": rows})

    @app.route("/api/brain/snapshots", methods=["POST"])
    @guarded
    def api_brain_snapshot_create():
        entry = snapshots.snapshots_create(store, "default", (body().get("reason") or "manual").strip()[:120])
        return jsonify({"status": "success", "tier": entry["tier"], "filename": entry["filename"]})

    @app.route("/api/brain/snapshots/rollback", methods=["POST"])
    @guarded
    def api_brain_rollback():
        d = body()
        ref = f"{d.get('tier')}/{d.get('filename')}" if d.get("tier") else d.get("filename")
        return jsonify({"status": "success", **snapshots.snapshots_rollback(store, ref or "")})

    @app.route("/api/brain/recall/preview", methods=["GET"])
    @guarded
    def api_brain_recall_preview():
        found = brain_keywords_recall(store, request.args.get("q", ""), 0, None)
        return jsonify({"status": "success", "recalled": [{k: r[k] for k in ("id", "title", "category", "matched", "score")} for r in found]})

    @app.route("/api/brain/settings", methods=["GET", "POST"])
    @guarded
    def api_brain_settings():
        if request.method == "POST":
            changes = {k: v for k, v in body().items() if k in SETTABLE}
            for key, value in changes.items():
                if value not in SETTABLE[key]:
                    return jsonify({"status": "error", "code": 0, "name": "E_BRAIN_SETTING_INVALID",
                                    "response": "%s must be one of: %s" % (key, ", ".join(SETTABLE[key]))}), 400
            for key, value in changes.items():
                brain_config_set(store.config_dir, key, value)
            store.limits.update(brain_config_load(store.config_dir))
        return jsonify({"status": "success", **{k: store.limits[k] for k in SETTABLE}, "options": {k: list(v) for k, v in SETTABLE.items()}})
