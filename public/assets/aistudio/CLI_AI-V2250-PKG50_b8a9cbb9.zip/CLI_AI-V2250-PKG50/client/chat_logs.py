"""
Module:         chat_logs.py
Component of:   CLI_AI chat client (client/)
Description:    Per-session chat logs stored as BEJSON 104 files
                (data/chat_logs/<session_id>.bejson), one record per message,
                via the lib/Core BEJSON core (field map cache, atomic writes).
                Logs every service's exchanges, not only OllamaLocal.
Version:        1.0.0
Date:           2026-10-12
Author:         Elton Boehnen
Contact:        boehnenelton2024@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
RELATIONAL_ID:  c18c7c02-2797-44b2-88f1-02e0a644f38b

Changelog:
  1.0.0 (2026-10-12) -- Initial creation.
"""

import logging
import os
import re
import sys
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_CORE_DIR = os.path.abspath(os.path.join(BASE_DIR, '..', 'lib', 'Core'))
if _CORE_DIR not in sys.path:
    sys.path.insert(0, _CORE_DIR)

from lib_bejson_Core_bejson_core import (
    bejson_core_create_104,
    bejson_core_atomic_write,
    bejson_core_load_file,
    bejson_core_get_field_map,
    bejson_core_add_record,
)

logger = logging.getLogger(__name__)

VERSION = "1.0.0"

# ── Schema registry (single source of field names) ─────────────────────
ENTITY_MESSAGE = "ChatMessage"
MSG_ID = "msg_id"
MSG_SESSION_FK = "msg_session_fk"
MSG_ROLE = "msg_role"
MSG_SENDER = "msg_sender"
MSG_SERVICE = "msg_service"
MSG_MODEL = "msg_model"
MSG_CONTENT = "msg_content"
MSG_CREATED_AT = "msg_created_at"
MSG_FIELD_NAMES = (MSG_ID, MSG_SESSION_FK, MSG_ROLE, MSG_SENDER, MSG_SERVICE,
                   MSG_MODEL, MSG_CONTENT, MSG_CREATED_AT)

SESSION_ID_RE = re.compile(r"^[0-9a-fA-F-]{8,64}$")
TITLE_MAX_CHARS = 80


def valid_session_id(session_id: Any) -> Optional[str]:
    """Return the id if it is a safe session id, else None."""
    if isinstance(session_id, str) and SESSION_ID_RE.match(session_id):
        return session_id
    return None


class ChatLogStore:
    def __init__(self, directory: str):
        self.dir = os.path.abspath(directory)
        os.makedirs(self.dir, exist_ok=True)
        self._lock = threading.Lock()

    def path_of(self, session_id: str) -> str:
        sid = valid_session_id(session_id)
        if not sid:
            raise ValueError("Invalid session id")
        return os.path.join(self.dir, f"{sid}.bejson")

    def exists(self, session_id: str) -> bool:
        return os.path.exists(self.path_of(session_id))

    @staticmethod
    def _new_doc() -> dict:
        fields = [{"name": n, "type": "string"} for n in MSG_FIELD_NAMES]
        return bejson_core_create_104(ENTITY_MESSAGE, fields, [])

    @staticmethod
    def _to_messages(doc: dict) -> List[Dict[str, Any]]:
        fmap = bejson_core_get_field_map(doc)
        out = []
        for row in doc.get("Values", []):
            out.append({
                "id": row[fmap[MSG_ID]],
                "role": row[fmap[MSG_ROLE]],
                "sender": row[fmap[MSG_SENDER]],
                "service": row[fmap[MSG_SERVICE]],
                "model": row[fmap[MSG_MODEL]],
                "content": (row[fmap[MSG_CONTENT]] or "").strip(),
                "created_at": row[fmap[MSG_CREATED_AT]],
            })
        return out

    def append(self, session_id: str, role: str, sender: str, service: Optional[str],
               model: Optional[str], content: str) -> bool:
        path = self.path_of(session_id)
        with self._lock:
            doc = bejson_core_load_file(path) if os.path.exists(path) else self._new_doc()
            if not doc:
                logger.error("Cannot read chat log %s", path)
                return False
            fmap = bejson_core_get_field_map(doc)
            row = [None] * len(doc["Fields"])
            row[fmap[MSG_ID]] = str(uuid.uuid4())
            row[fmap[MSG_SESSION_FK]] = session_id
            row[fmap[MSG_ROLE]] = role
            row[fmap[MSG_SENDER]] = sender
            row[fmap[MSG_SERVICE]] = service
            row[fmap[MSG_MODEL]] = model
            row[fmap[MSG_CONTENT]] = content
            row[fmap[MSG_CREATED_AT]] = datetime.now(timezone.utc).isoformat(timespec="seconds")
            if not bejson_core_add_record(doc, row):
                return False
            return bool(bejson_core_atomic_write(path, doc))

    def load(self, session_id: str) -> List[Dict[str, Any]]:
        path = self.path_of(session_id)
        if not os.path.exists(path):
            return []
        with self._lock:
            doc = bejson_core_load_file(path)
        return self._to_messages(doc) if doc else []

    def list_sessions(self) -> List[Dict[str, Any]]:
        out = []
        names = [n for n in os.listdir(self.dir) if n.endswith(".bejson")]
        names.sort(key=lambda n: os.path.getmtime(os.path.join(self.dir, n)), reverse=True)
        for name in names:
            sid = name[:-len(".bejson")]
            if not valid_session_id(sid):
                continue
            msgs = self.load(sid)
            first_user = next((m["content"] for m in msgs if m["role"] == "user"), "(empty)")
            out.append({
                "id": sid,
                "title": first_user[:TITLE_MAX_CHARS],
                "count": len(msgs),
                "updated": msgs[-1]["created_at"] if msgs else None,
            })
        return out

    def delete(self, session_id: str) -> bool:
        path = self.path_of(session_id)
        with self._lock:
            if os.path.exists(path):
                os.remove(path)
                return True
        return False
