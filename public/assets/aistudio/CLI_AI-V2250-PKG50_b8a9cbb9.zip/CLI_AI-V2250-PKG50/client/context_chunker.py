"""
Module:         context_chunker.py
Component of:   CLI_AI chat client (client/)
Description:    Backs the Attach tab's File/Folder/Zip import buttons and its
                 Save button. "Save" copies every currently-enabled attached
                 file into a stage folder, chunks that stage folder using the
                 Chunked-104 schema (ported from Elton's CLI_Chunker.py --
                 see CHANGELOG below for exactly what was and wasn't carried
                 over), stores the resulting chunk in a chunks/ subdirectory,
                 and keeps the most recent chunk registered as a Context
                 Bubble custom section (lib_bejson_AI_ai_context_bubble.py)
                 so it's injected as persistent context on every turn, not
                 just the turn it was saved on.

                 Re-chunking on Save is skipped (a fast no-op) unless at
                 least one enabled attached file's content hash differs from
                 the manifest recorded at the last successful chunk -- so
                 clicking Save repeatedly with nothing changed doesn't do
                 needless work. The manifest also records each file's
                 tracked path, per the request that this "store the paths of
                 the files".

                 Every Save wipes whatever was previously staged/chunked
                 first, then re-stages+re-chunks the currently-enabled
                 attached files from scratch — exactly one chunk is ever
                 the active persistent context, not an accumulating
                 history. (An earlier version of this module kept the last
                 3 chunk files as a rollback window, on a guessed reading
                 of an ambiguous instruction; a follow-up instruction
                 clarified "wipe" was meant literally, so that history was
                 removed.)

                 Ported from CLI_Chunker.py's Chunked-104 code path
                 (bejson_utility_create_chunked_104/run_chunk), adapted to
                 call CLI_AI's own lib/Core functions (bejson_core_atomic_write,
                 etc.) instead of CLI_Chunker's embedded copy of the same
                 library, since CLI_AI already has a real one on lib/Core.
                 CLI_Chunker's unchunk/restore/registry/history/MFDB/104db
                 code paths were not ported -- out of scope for "inject into
                 the chat client's context", which only ever needs the
                 forward chunk → context-text direction.
Version:        1.2.0
Date:           2026-09-25
Author:         Elton Boehnen
Contact:        eltonboehnen@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  8d2f4a91-3c6e-4b1a-9f7d-2e5c8a0b4d61

Changelog:
  1.2.0 (2026-09-25) -- Added the quick-text box: chunker_run_save() now
        accepts an optional `quick_text` string, folded in as one more
        virtual source ("_quick_note.txt") alongside real attached files
        -- same hashing/change-detection, same stage, same chunk, same
        persistent injection. Always persisted separately
        (chunker_load_quick_text/chunker_save_quick_text) so the box's
        draft survives a page reload even before Save is clicked. The
        "nothing to save -> wipe" early return now checks for neither
        enabled files NOR quick_text, instead of just no enabled files.
  1.1.0 (2026-09-22) -- Corrected per follow-up instruction: "wipe" was
        meant literally. Every Save now wipes all previous chunk file(s)
        before writing the new one -- exactly one chunk is ever the
        active persistent context, replacing the 1.0.0 "keep last 3 as a
        rollback window" behavior (a guess at an ambiguous instruction
        that turned out to be wrong). Also fixed a same-session bug: an
        intermediate edit wiped the manifest/chunk files *before* the
        force/changed check, which would have silently emptied the
        persistent section on a would-be no-op call; the wipe now only
        happens once actually committed to writing a new chunk (or on the
        "nothing enabled" path, which always wipes since there's nothing
        to check against). app.py's Save endpoint now always passes
        force=True (a button press is a deliberate action, not a poll),
        and the "Imported Files" custom section is no longer registered
        as a live per-turn injection -- only the explicit Save button
        injects anything now, via "Staged Chunk".
  1.0.0 (2026-09-21) -- Initial creation, ported from CLI_Chunker.py
        (Chunked-104 path only; see Description above).
"""

import hashlib
import json
import logging
import os
import shutil
import sys
import time
import zipfile
from pathlib import Path
from typing import List, Optional

_logger = logging.getLogger(__name__)

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_CORE_DIR = os.path.join(os.path.dirname(_THIS_DIR), "lib", "Core")
if _CORE_DIR not in sys.path:
    sys.path.insert(0, _CORE_DIR)

from lib_bejson_Core_bejson_core import bejson_core_atomic_write, bejson_core_load_file
from lib_bejson_Core_bejson_validator import validate_bejson

# ── Defaults (matches CLI_Chunker.py's DEFAULT_EXTENSIONS/DEFAULT_EXCLUDES) ──
DEFAULT_EXTENSIONS = [".py", ".js", ".ts", ".html", ".css", ".md", ".json", ".sh", ".txt", ".bejson", ".tsx", ".jsx"]
DEFAULT_EXCLUDES = [".git", "__pycache__", "node_modules", "output", ".mfdb_lock", "dist", "build"]

CHUNKED_104_FIELDS = [
    {"name": "File_Name",      "type": "string"},
    {"name": "File_Extension", "type": "string"},
    {"name": "File_Content",   "type": "string"},
    {"name": "File_Version",   "type": "string"},
    {"name": "File_Hash",      "type": "string"},
    {"name": "Relative_Path",  "type": "string"},
    {"name": "Is_Binary",      "type": "boolean"},
]

_CONFIG_FILENAME = "chunker_config.json"
_MANIFEST_FILENAME = "chunker_manifest.json"


# ── Paths ─────────────────────────────────────────────────────────────────

def _stage_dir(context_dir) -> Path:
    return Path(context_dir) / "chunker_stage"


def _chunks_dir(context_dir) -> Path:
    return Path(context_dir) / "chunks"


def _config_path(context_dir) -> Path:
    return Path(context_dir) / _CONFIG_FILENAME


def _manifest_path(context_dir) -> Path:
    return Path(context_dir) / _MANIFEST_FILENAME


# ── Config (customizable extensions/excludes) ───────────────────────────────

def chunker_load_config(context_dir) -> dict:
    path = _config_path(context_dir)
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"extensions": list(DEFAULT_EXTENSIONS), "exclude_dirs": list(DEFAULT_EXCLUDES)}


def chunker_save_config(context_dir, extensions: Optional[List[str]], exclude_dirs: Optional[List[str]]) -> dict:
    cfg = {
        "extensions": extensions if extensions is not None else list(DEFAULT_EXTENSIONS),
        "exclude_dirs": exclude_dirs if exclude_dirs is not None else list(DEFAULT_EXCLUDES),
    }
    Path(context_dir).mkdir(parents=True, exist_ok=True)
    _config_path(context_dir).write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return cfg


# ── Hashing / manifest (change detection) ───────────────────────────────────

def _hash_bytes(raw: bytes) -> str:
    return hashlib.sha1(raw).hexdigest()


def _load_manifest(context_dir) -> dict:
    path = _manifest_path(context_dir)
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"files": {}}  # {tracked_path: {"hash": ..., "file_id": ...}}


def _save_manifest(context_dir, manifest: dict) -> None:
    _manifest_path(context_dir).write_text(json.dumps(manifest, indent=2), encoding="utf-8")


# ── Zip / folder expansion helpers (used by app.py's import endpoints) ──────

def chunker_extract_zip_entries(zip_bytes: bytes) -> List[dict]:
    """
    Given raw zip bytes, returns [{"relative_path": ..., "content": ...}, ...]
    for every text-decodable entry (binary entries are skipped -- this is for
    text context, not a general-purpose archive extractor). Caller is
    responsible for feeding each entry into ai_context_files_import().
    """
    import io
    out = []
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            try:
                raw = zf.read(info)
                text = raw.decode("utf-8")
            except (UnicodeDecodeError, Exception):
                continue  # binary or unreadable -- skip, matches CLI_Chunker's is_binary skip behavior
            out.append({"relative_path": info.filename, "content": text})
    return out


# ── Staging + chunking ───────────────────────────────────────────────────────

def _wipe_persistent_chunk(context_dir) -> None:
    """Clears the persistent injected content entirely: removes every chunk
    file on disk and the manifest's last_chunk pointer, so
    chunker_build_section() has nothing to return until the next successful
    chunk. Stage dir is left to the caller (chunker_run_save re-populates it
    immediately after calling this)."""
    chunks_dir = _chunks_dir(context_dir)
    if chunks_dir.exists():
        for f in chunks_dir.glob("chunk_*.104a.bejson"):
            f.unlink(missing_ok=True)
    manifest = _load_manifest(context_dir)
    manifest["files"] = {}
    manifest["last_chunk"] = None
    _save_manifest(context_dir, manifest)


def _quick_text_path(context_dir) -> Path:
    return Path(context_dir) / "quick_text.txt"


def chunker_load_quick_text(context_dir) -> str:
    path = _quick_text_path(context_dir)
    if path.exists():
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            pass
    return ""


def chunker_save_quick_text(context_dir, text: str) -> None:
    """Persists the Context sub-tab's quick-text draft so it survives a
    page reload even before Save is clicked. Does not by itself affect
    the persistent chunk -- only chunker_run_save() does that."""
    path = _quick_text_path(Path(context_dir))
    path.parent.mkdir(parents=True, exist_ok=True)
    if text and text.strip():
        path.write_text(text, encoding="utf-8")
    elif path.exists():
        path.unlink()


def chunker_run_save(context_dir, enabled_files: List[dict], content_dir, quick_text: str = "", force: bool = False) -> dict:
    """
    enabled_files: the currently-ENABLED records from ai_context_files_list()
    (each has file_id/filename/char_count/etc.) -- "filename" doubles as the
    relative path for folder/zip-imported entries.
    content_dir: the directory ai_context_files.py stores each file_id's .txt
    content under (so this function can read the actual bytes to stage/hash).
    quick_text: the Context sub-tab's free-text box, if any. Non-blank text
    is folded in as one more virtual file ("_quick_note.txt") alongside the
    real attached files -- same staging, same hashing, same chunk, same
    persistent injection. Always persisted to disk (chunker_load_quick_text)
    regardless of whether this call actually chunks, so the box's contents
    survive a page reload.

    Every call first WIPES whatever was previously staged/chunked (every
    prior chunk file deleted, manifest cleared) -- this is not additive.
    If there is nothing to save (no enabled files AND no quick_text), the
    wipe is all that happens (the persistent section then has nothing to
    inject) and this returns early. Otherwise the wipe is followed by a
    full re-stage + re-chunk of everything, which becomes the new
    persistent content.

    force=True (used by the Save button) always performs the full
    wipe-then-rechunk cycle. force=False additionally skips the rechunk
    (though NOT the initial wipe-if-nothing-to-save case above) when the
    combined source set's paths+hashes exactly match what was chunked last
    time -- kept for any future caller that wants that optimization; the
    Save button itself always passes force=True.

    Returns {"chunked": bool, "reason": str, "file_count": int,
             "chunk_path": str|None}.
    """
    context_dir = Path(context_dir)
    chunker_save_quick_text(context_dir, quick_text)
    quick_text = (quick_text or "").strip()

    if not enabled_files and not quick_text:
        _wipe_persistent_chunk(context_dir)
        stage = _stage_dir(context_dir)
        if stage.exists():
            shutil.rmtree(stage)
        return {"chunked": False, "reason": "Nothing to save — wiped persistent context.", "file_count": 0, "chunk_path": None}

    # Build one combined source list: the real enabled files, plus a
    # virtual entry for the quick-text box (if any) using a synthetic
    # file_id so it participates in hashing/change-detection exactly like
    # a real file, without needing a real content_dir entry on disk.
    sources = list(enabled_files)
    if quick_text:
        sources.append({"file_id": "__quick_text__", "filename": "_quick_note.txt", "_inline_content": quick_text})

    manifest = _load_manifest(context_dir)
    old_files = manifest.get("files", {})
    new_files = {}
    changed = force or (set(old_files.keys()) != {f["filename"] for f in sources})

    # Stage: clear and re-copy every source at its tracked relative path.
    stage = _stage_dir(context_dir)
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True, exist_ok=True)

    values = []
    for f in sources:
        if "_inline_content" in f:
            raw_text = f["_inline_content"]
        else:
            content_path = Path(content_dir) / f"{f['file_id']}.txt"
            if not content_path.exists():
                continue
            raw_text = content_path.read_text(encoding="utf-8", errors="replace")
        raw_bytes = raw_text.encode("utf-8")
        file_hash = _hash_bytes(raw_bytes)

        rel_path = f["filename"]
        new_files[rel_path] = {"hash": file_hash, "file_id": f["file_id"]}
        if not changed and old_files.get(rel_path, {}).get("hash") != file_hash:
            changed = True

        dest = stage / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(raw_text, encoding="utf-8")

        name = Path(rel_path).name
        values.append([
            name,                    # File_Name
            Path(rel_path).suffix,   # File_Extension
            raw_text,                # File_Content
            "latest",                # File_Version
            file_hash,               # File_Hash
            rel_path,                # Relative_Path
            False,                   # Is_Binary (unreadable/binary entries never reach here)
        ])

    if not changed:
        return {"chunked": False, "reason": "No changes since last save.", "file_count": len(sources), "chunk_path": None}

    doc = {
        "Format": "BEJSON",
        "Format_Version": "104a",
        "Format_Creator": "Elton Boehnen",
        "Schema_Name": "Chunked-104a",
        "Schema_Version": "1.0.1",
        "Schema_Description": "Chat client attached-files chunk.",
        "Chunk_Date-YYYY-MM-DD": time.strftime("%Y-%m-%d", time.gmtime()),
        "Records_Type": ["Chunked"],
        "Fields": CHUNKED_104_FIELDS,
        "Values": values,
    }

    res = validate_bejson(doc)
    if not res.valid:
        return {"chunked": False, "reason": f"Validation failed: {res.errors}", "file_count": len(values), "chunk_path": None}

    # Committed to replacing the persistent content: wipe every previous
    # chunk file first (not additive, not a rolling history — exactly one
    # chunk is ever the active persistent context), then write the new one.
    chunks_dir = _chunks_dir(context_dir)
    if chunks_dir.exists():
        for old in chunks_dir.glob("chunk_*.104a.bejson"):
            old.unlink(missing_ok=True)
    chunks_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    out_path = chunks_dir / f"chunk_{stamp}.104a.bejson"
    bejson_core_atomic_write(str(out_path), doc)

    manifest["files"] = new_files
    manifest["last_chunk"] = str(out_path)
    _save_manifest(context_dir, manifest)

    return {"chunked": True, "reason": "Saved.", "file_count": len(values), "chunk_path": str(out_path)}


def _render_chunk_as_text(doc: dict) -> str:
    """Compact file-separator text block, matching CLI_Chunker's bejson_utility_chunk_to_text style."""
    fields = [f["name"] for f in doc.get("Fields", [])]
    idx = {name: i for i, name in enumerate(fields)}
    parts = []
    for row in doc.get("Values", []):
        rel_path = row[idx["Relative_Path"]]
        content = row[idx["File_Content"]]
        parts.append(f"--- FILE: {rel_path} ---\n{content}")
    return "\n\n".join(parts)


def chunker_build_section(constants: dict, cwd: str, config_dir, context_dir) -> tuple:
    """
    Matches ai_bubble_register_section()'s builder_fn signature. Loads the
    most recently saved chunk (if any) and returns its rendered text, so the
    last Save persists into every subsequent turn's context -- not just the
    turn it was saved on.
    """
    manifest = _load_manifest(context_dir)
    last_chunk = manifest.get("last_chunk")
    if not last_chunk or not Path(last_chunk).exists():
        return "", 0
    doc = bejson_core_load_file(last_chunk)
    if not doc:
        return "", 0
    text = _render_chunk_as_text(doc)
    return text, len(text)
