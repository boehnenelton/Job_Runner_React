# Project status

STATUS UPDATE (2026-09-16, audit remediation pass): this file originally
described a design-only phase ("not integrating functionality yet"). That
phase has since ended — `app.py` and `chat.js` now carry live API dispatch
(`/api/chat`, `/api/models`, `/api/models/update`) against Gemini/OpenRouter/
TokenRoute. The UI/behavior specs below still describe the intended design
and remain in effect; only the "no functionality yet" framing is outdated.

## instructions:

bottom layer, the toolbar Just above input box I want it to act as a tab for sure it will switch the chat areas content to different tabs the input box will remain at the bottom. 

on the chat tab I want it to be empty by default until a chat begins all the fluff needsto removed, The bubble padding needs to be reduced. chats should show the sender name then the timestamp then a line below the message but not until messages have been sent or received Don't need any fluff or previews.

Settings card should open up a full screen dialogue overlay with an x to close and it should be an inverted background color which would be white inverting other colors as well. setting should be grouped in groups and collapsed by an expandable at a group header, showing the title on the header and defaulting to closed. it's service group uses a combo box to switch services and a second combo box to switch models under that service selected above.//

