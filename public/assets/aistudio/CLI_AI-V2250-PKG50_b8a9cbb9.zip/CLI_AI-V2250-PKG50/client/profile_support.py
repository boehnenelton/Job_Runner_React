"""
Name:           profile_support.py
Description:    Client-side support for AI_Profile files with embedded
                Parser / Renderer code: lists and loads profiles from the
                configured profiles directory, and persists which code
                fingerprints the user has approved (BEJSON 104 file). All
                validation, fingerprinting, execution and sandbox building is
                delegated to lib_bejson_AI_gemini_standard_profiles; this
                module only owns files and the approval list.
Version:        1.0.0
Date Created:   2026-10-18
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  7c1d4f0e-92b6-4d58-a3e1-0b5f6d2c8a47
"""
import datetime
import json
import logging
import os
import re
import threading
from typing import Any, Dict, List, Optional, Set

import lib_bejson_AI_gemini_standard_profiles as _profiles
from lib_bejson_Core_bejson_core import bejson_core_atomic_write, bejson_core_get_field_map

VERSION = "1.0.0"
logger = logging.getLogger("cli_ai.client.profiles")

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_APPROVAL_RECORD = "ApprovedProfileCode"
_APPROVAL_FIELDS = [
    {"name": "fingerprint", "type": "string"},
    {"name": "profile_name", "type": "string"},
    {"name": "parser_language", "type": "string"},
    {"name": "approved_at", "type": "string"},
]


def profile_safe_name(name: Any) -> Optional[str]:
    """Returns *name* when it is a plain profile name (letters, digits, _ -),
    else None. Keeps every request inside the profiles directory."""
    return name if isinstance(name, str) and _NAME_RE.match(name) else None


class ProfileStore:
    """Profiles directory + approval list. Thread safe."""

    def __init__(self, profiles_dir: str, approvals_path: str) -> None:
        self.profiles_dir = os.path.abspath(profiles_dir)
        self.approvals_path = os.path.abspath(approvals_path)
        self._lock = threading.Lock()

    # ── approvals ─────────────────────────────────────────────────────────
    def _read_approvals(self) -> Dict[str, Any]:
        if not os.path.isfile(self.approvals_path):
            return {}
        try:
            with open(self.approvals_path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, ValueError) as exc:
            logger.error("Could not read approvals file: %s", exc)
            return {}

    def approved_fingerprints(self) -> Set[str]:
        doc = self._read_approvals()
        if not doc.get("Values"):
            return set()
        idx = bejson_core_get_field_map(doc).get("fingerprint")
        if idx is None:
            return set()
        return {row[idx] for row in doc["Values"] if len(row) > idx and isinstance(row[idx], str)}

    def _write_rows(self, rows: List[List[Any]]) -> bool:
        doc = {
            "Format": "BEJSON", "Format_Version": "104", "Format_Creator": "Elton Boehnen",
            "Records_Type": [_APPROVAL_RECORD],
            "Fields": [dict(f) for f in _APPROVAL_FIELDS],
            "Values": rows,
        }
        os.makedirs(os.path.dirname(self.approvals_path), exist_ok=True)
        return bool(bejson_core_atomic_write(self.approvals_path, doc))

    def _rows(self) -> List[List[Any]]:
        doc = self._read_approvals()
        return [list(r) for r in doc.get("Values", [])] if doc else []

    def approve(self, name: str, fingerprint: str) -> Dict[str, Any]:
        """Approves the profile's code ONLY if *fingerprint* equals the
        fingerprint of the code as it is on disk right now (so the user
        approves exactly what they reviewed)."""
        profile = self.load(name)
        if profile is None:
            return {"success": False, "reason": "unknown profile"}
        loaded = _profiles.gemini_profiles_load_embedded(profile, (), 0, syntax_check_js=True)
        if not loaded["has_embedded"]:
            return {"success": False, "reason": "profile has no embedded code"}
        if not loaded["success"]:
            return {"success": False, "reason": "; ".join(loaded["errors"])}
        if loaded["fingerprint"] != fingerprint:
            return {"success": False, "reason": "profile changed since it was reviewed; reopen it and review again"}
        with self._lock:
            rows = self._rows()
            if not any(r and r[0] == fingerprint for r in rows):
                language = (loaded["parser"] or {}).get("language", "")
                rows.append([fingerprint, name, language,
                             datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")])
                if not self._write_rows(rows):
                    return {"success": False, "reason": "could not write the approvals file"}
        return {"success": True, "fingerprint": fingerprint}

    def revoke(self, fingerprint: str) -> Dict[str, Any]:
        with self._lock:
            rows = self._rows()
            kept = [r for r in rows if not (r and r[0] == fingerprint)]
            if len(kept) != len(rows) and not self._write_rows(kept):
                return {"success": False, "reason": "could not write the approvals file"}
        return {"success": True}

    # ── profiles ──────────────────────────────────────────────────────────
    def _path(self, name: str) -> Optional[str]:
        safe = profile_safe_name(name)
        if safe is None:
            return None
        path = os.path.join(self.profiles_dir, safe + ".bejson")
        return path if os.path.isfile(path) else None

    def load(self, name: str) -> Optional[Dict[str, Any]]:
        """The parsed profile document, or None when missing/unreadable/not
        a valid AI_Profile."""
        path = self._path(name)
        if path is None:
            return None
        try:
            with open(path, "r", encoding="utf-8") as fh:
                doc = json.load(fh)
        except (OSError, ValueError) as exc:
            logger.error("Could not read profile %s: %s", name, exc)
            return None
        return doc if _profiles.gemini_profiles_validate(doc) else None

    def names(self) -> List[str]:
        if not os.path.isdir(self.profiles_dir):
            return []
        out = [f[:-7] for f in os.listdir(self.profiles_dir)
               if f.endswith(".bejson") and profile_safe_name(f[:-7])]
        return sorted(out, key=lambda n: (n != "default", n))

    def summary(self, name: str) -> Dict[str, Any]:
        """Cheap per-profile facts for the picker."""
        profile = self.load(name)
        if profile is None:
            return {"name": name, "valid": False, "has_embedded": False, "approved": False}
        loaded = _profiles.gemini_profiles_load_embedded(
            profile, self.approved_fingerprints(), 0, syntax_check_js=False)
        return {"name": name, "valid": True, "has_embedded": loaded["has_embedded"],
                "approved": loaded["approved"],
                "parser_language": (loaded["parser"] or {}).get("language")}

    def detail(self, name: str) -> Optional[Dict[str, Any]]:
        """Everything the review panel needs, including the code itself."""
        profile = self.load(name)
        if profile is None:
            return None
        loaded = _profiles.gemini_profiles_load_embedded(
            profile, self.approved_fingerprints(), 0, syntax_check_js=True)
        return {
            "name": name, "valid": True, "has_embedded": loaded["has_embedded"],
            "approved": loaded["approved"], "fingerprint": loaded["fingerprint"],
            "errors": loaded["errors"],
            "parser_language": (loaded["parser"] or {}).get("language"),
            "parser": (loaded["parser"] or {}).get("code"),
            "renderer": loaded["renderer"],
        }

    def system_instruction(self, name: str) -> Optional[str]:
        profile = self.load(name)
        if profile is None:
            return None
        value = _profiles.gemini_profiles_get_value(profile, "System_Instruction", 0)
        return value if isinstance(value, str) else ""

    def run_parser(self, name: str, raw_text: str) -> Dict[str, Any]:
        profile = self.load(name)
        if profile is None:
            return {"success": False, "reason": "unknown profile"}
        return _profiles.gemini_profiles_run_parser(profile, raw_text, self.approved_fingerprints())

    def sandbox(self, name: str) -> Dict[str, Any]:
        profile = self.load(name)
        if profile is None:
            return {"success": False, "reason": "unknown profile", "srcdoc": ""}
        out = _profiles.gemini_profiles_build_sandbox(profile, self.approved_fingerprints())
        parser = _profiles.gemini_profiles_get_parser(profile, 0)
        out["parser_language"] = parser["language"] if parser else None
        return out
