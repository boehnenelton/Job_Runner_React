/*
 * Name:          brain.js
 * Description:   Brain tab for the CLI_AI chat client: Memories, Proposed, Snapshots, Settings, plus "Recalled" badges under AI replies.
 *                All text is written with textContent (memories can contain AI-written text), never innerHTML.
 * Version:       1.0.0
 * Date Created:  2026-10-27
 * Author:        Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
 * RELATIONAL_ID: f3beaae8-0915-4602-87ca-9875c3109834
 */
(function () {
    'use strict';
    const $ = (id) => document.getElementById(id);
    if (!$('tab-Brain')) return;

    let categories = [];
    let editingId = null;
    let loaded = false;

    function el(tag, cls, text) {
        const node = document.createElement(tag);
        if (cls) node.className = cls;
        if (text !== undefined) node.textContent = text;
        return node;
    }

    function toast(msg) {
        const t = $('toast');
        if (!t) return;
        t.textContent = msg;
        t.classList.add('becss-toast--show');
        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => t.classList.remove('becss-toast--show'), 1800);
    }

    async function api(method, url, body) {
        const opts = { method: method, headers: { 'Content-Type': 'application/json' } };
        if (body !== undefined) opts.body = JSON.stringify(body);
        const resp = await fetch(url, opts);
        const data = await resp.json().catch(() => ({}));
        if (!resp.ok || data.status === 'error') throw new Error(data.response || ('HTTP ' + resp.status));
        return data;
    }

    function emptyNote(list, text) {
        list.textContent = '';
        list.appendChild(el('li', 'becss-logs__empty', text));
    }

    // ── sub-tabs ────────────────────────────────────────────────────────────
    const chips = document.querySelectorAll('.becss-braintab-chip');
    const panels = {
        memories: $('braintab-memories'), proposed: $('braintab-proposed'),
        snapshots: $('braintab-snapshots'), settings: $('braintab-settings')
    };
    function showSub(key) {
        chips.forEach(c => c.classList.toggle('becss-braintab-chip--active', c.dataset.braintab === key));
        Object.keys(panels).forEach(k => panels[k].classList.toggle('becss-braintab-panel--active', k === key));
        if (key === 'memories') loadMemories();
        if (key === 'proposed') loadProposals();
        if (key === 'snapshots') loadSnapshots();
        if (key === 'settings') loadSettings();
    }
    chips.forEach(c => c.addEventListener('click', () => showSub(c.dataset.braintab)));

    // ── categories ──────────────────────────────────────────────────────────
    async function loadCategories() {
        const data = await api('GET', '/api/brain/categories');
        categories = (data.categories || []).filter(c => c.status === 'active');
        const filter = $('brainCategoryFilter');
        const keep = filter.value;
        filter.textContent = '';
        const all = el('option', '', 'All categories'); all.value = ''; filter.appendChild(all);
        const ed = $('brainEdCategory'); ed.textContent = '';
        categories.forEach(c => {
            const o = el('option', '', c.name + ' (' + c.memories + ')'); o.value = c.name; filter.appendChild(o);
            const o2 = el('option', '', c.name); o2.value = c.name; ed.appendChild(o2);
        });
        filter.value = keep;
    }

    // ── memories ────────────────────────────────────────────────────────────
    async function loadMemories() {
        const list = $('brainMemList');
        try {
            await loadCategories();
            const params = new URLSearchParams();
            if ($('brainCategoryFilter').value) params.set('category', $('brainCategoryFilter').value);
            if ($('brainSearch').value.trim()) params.set('q', $('brainSearch').value.trim());
            const data = await api('GET', '/api/brain/memories?' + params.toString());
            const rows = data.memories || [];
            if (!rows.length) return emptyNote(list, 'No memories yet. Tap Add, or type /remember in the chat.');
            list.textContent = '';
            rows.forEach(m => list.appendChild(memoryRow(m)));
        } catch (e) {
            emptyNote(list, 'Error: ' + e.message);
        }
    }

    function memoryRow(m) {
        const li = el('li', 'becss-logs__row becss-brain-card' + (m.pinned ? ' becss-logs__row--current' : ''));
        const info = el('div', 'becss-logs__info');
        const title = el('div', 'becss-logs__title', (m.pinned ? '★ ' : '') + m.title);
        const meta = el('div', 'becss-logs__meta',
            m.category + ' · ' + (m.origin === 'ai' ? 'AI note' : 'your note') + ' · priority ' + m.priority +
            (m.keywords.length ? ' · ' + m.keywords.join(', ') : ''));
        const body = el('div', 'becss-brain-card__body', m.content);
        info.append(title, meta, body);
        const actions = el('div', 'becss-logs__actions');
        const edit = el('button', 'becss-logs__btn', 'Edit');
        edit.addEventListener('click', () => openEditor(m));
        const pin = el('button', 'becss-logs__btn', m.pinned ? 'Unpin' : 'Pin');
        pin.addEventListener('click', async () => {
            try { await api('POST', '/api/brain/memories/' + m.id + '/pin', { pinned: !m.pinned }); loadMemories(); }
            catch (e) { toast(e.message); }
        });
        actions.append(edit, pin);
        li.append(info, actions);
        return li;
    }

    function openEditor(memory) {
        editingId = memory ? memory.id : null;
        $('brainEditor').hidden = false;
        $('brainEdCategory').value = memory ? memory.category : ($('brainCategoryFilter').value || 'General');
        $('brainEdTitle').value = memory ? memory.title : '';
        $('brainEdContent').value = memory ? memory.content : '';
        $('brainEdKeywords').value = memory ? memory.keywords.join(', ') : '';
        $('brainEdPriority').value = memory ? memory.priority : 50;
        $('brainEdPinned').checked = memory ? memory.pinned : false;
        $('brainEdArchive').hidden = !memory;
        $('brainEdStatus').textContent = memory && memory.origin === 'ai'
            ? 'Saving your edit makes this note yours: it is locked against AI changes.' : '';
        $('brainEdTitle').focus();
    }
    function closeEditor() { $('brainEditor').hidden = true; editingId = null; }

    $('brainAddBtn').addEventListener('click', () => openEditor(null));
    $('brainEdCancel').addEventListener('click', closeEditor);
    $('brainCategoryFilter').addEventListener('change', loadMemories);
    let searchTimer = null;
    $('brainSearch').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadMemories, 250); });

    $('brainEdSave').addEventListener('click', async () => {
        const payload = {
            category: $('brainEdCategory').value, title: $('brainEdTitle').value, content: $('brainEdContent').value,
            keywords: $('brainEdKeywords').value, priority: parseInt($('brainEdPriority').value, 10), pinned: $('brainEdPinned').checked
        };
        try {
            if (editingId) await api('PUT', '/api/brain/memories/' + editingId, payload);
            else await api('POST', '/api/brain/memories', payload);
            closeEditor(); toast('Saved'); loadMemories();
        } catch (e) { $('brainEdStatus').textContent = e.message; }
    });
    $('brainEdArchive').addEventListener('click', async () => {
        if (!editingId || !confirm('Archive this memory? It can be restored from the database later, but the AI will stop seeing it.')) return;
        try { await api('DELETE', '/api/brain/memories/' + editingId); closeEditor(); toast('Archived'); loadMemories(); }
        catch (e) { $('brainEdStatus').textContent = e.message; }
    });

    // ── proposals ───────────────────────────────────────────────────────────
    function setProposalCount(n) {
        const badge = $('brainProposalCount');
        badge.hidden = !n;
        badge.textContent = n ? String(n) : '';
    }

    async function loadProposals() {
        const list = $('brainProposedList');
        try {
            const data = await api('GET', '/api/brain/proposals');
            const cats = data.categories || [], mems = data.memories || [];
            setProposalCount(cats.length + mems.length);
            if (!cats.length && !mems.length) return emptyNote(list, 'Nothing waiting for review.');
            list.textContent = '';
            cats.forEach(c => list.appendChild(proposalRow('New category: ' + c.name, c.description, c.id)));
            mems.forEach(m => {
                const head = (m.replaces ? 'Change to: ' : 'New: ') + m.category + ' / ' + m.title;
                const row = proposalRow(head, m.content, m.id);
                if (m.replaces) {
                    const old = el('div', 'becss-brain-card__old', 'Replaces: ' + m.replaces.content);
                    row.querySelector('.becss-logs__info').appendChild(old);
                }
                list.appendChild(row);
            });
        } catch (e) { emptyNote(list, 'Error: ' + e.message); }
    }

    function proposalRow(heading, text, id) {
        const li = el('li', 'becss-logs__row becss-brain-card');
        const info = el('div', 'becss-logs__info');
        info.append(el('div', 'becss-logs__title', heading), el('div', 'becss-brain-card__body', text));
        const actions = el('div', 'becss-logs__actions');
        [['Approve', 'approve'], ['Reject', 'reject']].forEach(([label, verb]) => {
            const b = el('button', 'becss-logs__btn', label);
            b.addEventListener('click', async () => {
                try { await api('POST', '/api/brain/proposals/' + id + '/' + verb); toast(label + 'd'); loadProposals(); refreshCount(); }
                catch (e) { toast(e.message); }
            });
            actions.appendChild(b);
        });
        li.append(info, actions);
        return li;
    }

    async function refreshCount() {
        try { const s = await api('GET', '/api/brain/status'); setProposalCount(s.proposals || 0); } catch (e) { /* badge is optional */ }
    }

    // ── snapshots ───────────────────────────────────────────────────────────
    async function loadSnapshots() {
        const list = $('brainSnapList');
        try {
            const data = await api('GET', '/api/brain/snapshots');
            const rows = data.snapshots || [];
            if (!rows.length) return emptyNote(list, 'No snapshots yet.');
            list.textContent = '';
            rows.forEach(s => {
                const li = el('li', 'becss-logs__row');
                const info = el('div', 'becss-logs__info');
                const when = s.created_at ? new Date(s.created_at).toLocaleString() : s.filename;
                info.append(el('div', 'becss-logs__title', when),
                    el('div', 'becss-logs__meta', s.tier + ' · ' + (s.reason || '') + (s.valid ? '' : ' · DAMAGED')));
                const actions = el('div', 'becss-logs__actions');
                const roll = el('button', 'becss-logs__btn', 'Roll back');
                roll.disabled = !s.valid;
                roll.addEventListener('click', async () => {
                    if (!confirm('Roll the Brain back to ' + when + '?\nA safety snapshot of the current state is saved first.')) return;
                    try { const r = await api('POST', '/api/brain/snapshots/rollback', { tier: s.tier, filename: s.filename });
                          toast('Rolled back'); loadSnapshots(); loadMemories(); refreshCount(); }
                    catch (e) { toast(e.message); }
                });
                actions.appendChild(roll);
                li.append(info, actions);
                list.appendChild(li);
            });
        } catch (e) { emptyNote(list, 'Error: ' + e.message); }
    }
    $('brainSnapNow').addEventListener('click', async () => {
        try { await api('POST', '/api/brain/snapshots', { reason: 'manual' }); toast('Snapshot saved'); loadSnapshots(); }
        catch (e) { toast(e.message); }
    });
    $('brainSnapRefresh').addEventListener('click', loadSnapshots);

    // ── settings ────────────────────────────────────────────────────────────
    async function loadSettings() {
        try {
            const [st, cfg] = await Promise.all([api('GET', '/api/brain/status'), api('GET', '/api/brain/settings')]);
            $('brainStatusBox').textContent = st.categories + ' categories · ' + st.memories_active + ' memories (' + st.memories_pinned +
                ' pinned) · ' + st.proposals + ' proposed · ' + st.snapshots + ' snapshots' +
                (st.recovery_notices && st.recovery_notices.length ? '\n' + st.recovery_notices.join('\n') : '');
            [['brainModeSelect', 'memory_mode'], ['brainPolicySelect', 'write_policy']].forEach(([id, key]) => {
                const sel = $(id); sel.textContent = '';
                cfg.options[key].forEach(v => { const o = el('option', '', v); o.value = v; sel.appendChild(o); });
                sel.value = cfg[key];
            });
            setProposalCount(st.proposals || 0);
        } catch (e) { $('brainStatusBox').textContent = 'Error: ' + e.message; }
    }
    $('brainSettingsSave').addEventListener('click', async () => {
        try {
            await api('POST', '/api/brain/settings', { memory_mode: $('brainModeSelect').value, write_policy: $('brainPolicySelect').value });
            $('brainSettingsStatus').textContent = 'Saved. Applies to your next message.';
        } catch (e) { $('brainSettingsStatus').textContent = e.message; }
    });

    // ── chat integration ────────────────────────────────────────────────────
    // "Recalled" line under an AI reply: which notes were sent along with the user's message.
    function renderRecalled(messageEl, list) {
        if (!messageEl || !list || !list.length) return;
        if (messageEl.querySelector('.becss-recalled')) return;
        const row = el('div', 'becss-recalled');
        row.appendChild(el('span', 'becss-recalled__label', 'Recalled'));
        list.forEach(r => {
            const badge = el('span', 'becss-recalled__badge', r.title);
            badge.title = r.category + (r.matched && r.matched.length ? ' · matched: ' + r.matched.join(', ') : '');
            row.appendChild(badge);
        });
        messageEl.appendChild(row);
    }

    window.BrainUI = {
        renderRecalled: renderRecalled,
        onShow: function () { showSub(document.querySelector('.becss-braintab-chip--active').dataset.braintab); loaded = true; }
    };
    refreshCount();
})();
