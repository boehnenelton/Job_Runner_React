document.addEventListener('DOMContentLoaded', () => {
    const statusHeader = document.getElementById('statusHeader');
    const statusText = document.getElementById('statusText');
    const chatInput = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendBtn');
    const chatHistory = document.getElementById('chatHistory');
    const expandBtn = document.getElementById('expandBtn');
    const arrowIcon = document.getElementById('arrowIcon');
    const settingsBtn = document.getElementById('settingsBtn');
    const settingsOverlay = document.getElementById('settingsOverlay');
    const closeSettings = document.getElementById('closeSettings');
    const serviceSelect = document.getElementById('serviceSelect');
    const modelSelect = document.getElementById('modelSelect');
    const refreshModelsBtn = document.getElementById('refreshModelsBtn');
    const sourceTypeBadge = document.getElementById('sourceTypeBadge');

    // ── Active request state (AbortController for timeout + Stop) ─────────
    let activeController = null;
    const SEND_TIMEOUT_MS = window.CLIENT_CONSTANTS?.send_timeout_ms || 120000;

    // ── Chat session (server writes each exchange to a BEJSON chat log) ───
    function newSessionId() {
        if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
            const r = Math.random() * 16 | 0;
            return (c === 'x' ? r : (r & 3 | 8)).toString(16);
        });
    }
    let sessionId = localStorage.getItem('cliai_session') || newSessionId();
    localStorage.setItem('cliai_session', sessionId);

    // Settings Overlay Toggle
    settingsBtn.addEventListener('click', () => {
        settingsOverlay.classList.add('becss-settings-overlay--active');
        loadEnvStatus();
        loadTokenBudget();
    });
    closeSettings.addEventListener('click', () => {
        settingsOverlay.classList.remove('becss-settings-overlay--active');
    });

    // ── Settings > Environment: status, manual path, server-side browse ──
    const envStatus = document.getElementById('envStatus');
    const envPathInput = document.getElementById('envPathInput');
    const envSaveBtn = document.getElementById('envSaveBtn');
    const envBrowseBtn = document.getElementById('envBrowseBtn');
    const envBrowser = document.getElementById('envBrowser');
    const envBrowserPath = document.getElementById('envBrowserPath');
    const envBrowserList = document.getElementById('envBrowserList');
    const envActionStatus = document.getElementById('envActionStatus');

    async function loadEnvStatus() {
        envStatus.textContent = 'Loading...';
        try {
            const resp = await fetch('/api/settings/env_status');
            const data = await resp.json();
            envPathInput.value = data.path || '';
            if (data.exists && data.key_count > 0) {
                envStatus.textContent = `OK — ${data.key_count} key(s) loaded from ${data.path}`;
                envStatus.className = 'becss-env-status becss-env-status--ok';
            } else if (data.exists) {
                envStatus.textContent = `File found at ${data.path}, but 0 keys were parsed from it.`;
                envStatus.className = 'becss-env-status becss-env-status--error';
            } else {
                envStatus.textContent = `No file found at ${data.path || '(not set)'} — every provider will report "No valid API keys" until this is fixed.`;
                envStatus.className = 'becss-env-status becss-env-status--error';
            }
        } catch (e) {
            envStatus.textContent = 'Error loading status.';
            envStatus.className = 'becss-env-status becss-env-status--error';
        }
    }

    envSaveBtn.addEventListener('click', async () => {
        envActionStatus.textContent = 'Saving...';
        try {
            const resp = await fetch('/api/settings/env_path', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ path: envPathInput.value })
            });
            const data = await resp.json();
            envActionStatus.textContent = data.status === 'success'
                ? `Loaded ${data.key_count} key(s).`
                : (data.message || 'Failed.');
            loadEnvStatus();
        } catch (e) {
            envActionStatus.textContent = 'Save failed.';
        }
    });

    async function browseTo(path) {
        const url = path ? `/api/settings/browse?path=${encodeURIComponent(path)}` : '/api/settings/browse';
        const resp = await fetch(url);
        const data = await resp.json();
        if (data.status !== 'success') {
            envBrowserPath.textContent = data.message || 'Error browsing.';
            envBrowserList.innerHTML = '';
            return;
        }
        envBrowserPath.textContent = data.current_path;
        let html = '';
        if (data.parent_path) {
            html += `<li class="becss-env-browser__item becss-env-browser__item--dir" data-path="${data.parent_path}" data-dir="true">.. (up)</li>`;
        }
        html += data.entries.map(e => `
            <li class="becss-env-browser__item ${e.is_dir ? 'becss-env-browser__item--dir' : ''}" data-path="${e.full_path}" data-dir="${e.is_dir}">
                ${e.is_dir ? '📁' : '📄'} ${e.name}
            </li>
        `).join('');
        envBrowserList.innerHTML = html;
        envBrowserList.querySelectorAll('.becss-env-browser__item').forEach(item => {
            item.addEventListener('click', () => {
                if (item.dataset.dir === 'true') {
                    browseTo(item.dataset.path);
                } else {
                    envPathInput.value = item.dataset.path;
                    envBrowser.style.display = 'none';
                }
            });
        });
    }

    envBrowseBtn.addEventListener('click', () => {
        const isOpen = envBrowser.style.display !== 'none';
        if (isOpen) {
            envBrowser.style.display = 'none';
        } else {
            envBrowser.style.display = 'flex';
            browseTo(envPathInput.value ? envPathInput.value.replace(/\/[^/]*$/, '') : '');
        }
    });

    // ── Settings > Token Budget: max_context_tokens for the Context Bubble ──
    const maxTokensInput = document.getElementById('maxTokensInput');
    const maxTokensHint = document.getElementById('maxTokensHint');
    const maxTokensStatus = document.getElementById('maxTokensStatus');
    const maxTokensSaveBtn = document.getElementById('maxTokensSaveBtn');
    const maxTokensResetBtn = document.getElementById('maxTokensResetBtn');

    function applyTokenBudget(data) {
        maxTokensInput.value = data.max_context_tokens;
        maxTokensInput.min = data.min;
        maxTokensInput.max = data.max;
        maxTokensHint.textContent = `Total token budget for the assembled Context Bubble (shown as "used / max" on the Bubble tab). Default ${data.default}, allowed ${data.min}–${data.max}. Applies to your next message.`;
    }

    async function loadTokenBudget() {
        maxTokensStatus.textContent = '';
        try {
            const resp = await fetch('/api/settings/tokens');
            const data = await resp.json();
            if (data.status === 'success') {
                applyTokenBudget(data);
            } else {
                maxTokensStatus.textContent = data.message || 'Could not load.';
                maxTokensStatus.className = 'becss-env-status becss-env-status--error';
            }
        } catch (e) {
            maxTokensStatus.textContent = 'Error loading token budget.';
            maxTokensStatus.className = 'becss-env-status becss-env-status--error';
        }
    }

    async function saveTokenBudget(body) {
        maxTokensStatus.textContent = 'Saving...';
        maxTokensStatus.className = 'becss-env-status';
        try {
            const resp = await fetch('/api/settings/tokens', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            const data = await resp.json();
            if (data.status === 'success') {
                applyTokenBudget(data);
                maxTokensStatus.textContent = `Saved — max context tokens is now ${data.max_context_tokens}.`;
                maxTokensStatus.className = 'becss-env-status becss-env-status--ok';
                if (typeof loadBubblePreview === 'function') loadBubblePreview();
            } else {
                maxTokensStatus.textContent = data.message || 'Save failed.';
                maxTokensStatus.className = 'becss-env-status becss-env-status--error';
            }
        } catch (e) {
            maxTokensStatus.textContent = 'Save failed.';
            maxTokensStatus.className = 'becss-env-status becss-env-status--error';
        }
    }

    maxTokensSaveBtn.addEventListener('click', () => saveTokenBudget({ max_context_tokens: maxTokensInput.value }));
    maxTokensResetBtn.addEventListener('click', () => saveTokenBudget({ reset: true }));

    // Live model loading
    async function loadModels(service, autoUpdateOnEmpty = true) {
        modelSelect.innerHTML = '<option>Loading...</option>';
        try {
            const resp = await fetch(`/api/models?service=${encodeURIComponent(service)}`);
            const data = await resp.json();
            applySourceTypeUI(data.source_type);
            if (data.models && data.models.length > 0) {
                modelSelect.innerHTML = data.models.map(m => `<option value="${m.id}">${m.name}</option>`).join('');
            } else if (autoUpdateOnEmpty && data.source_type === 'remote') {
                // Auto-fetch from live API if registry is empty for a remote-type service
                await updateRegistry([service]);
                await loadModels(service, false);
            } else {
                modelSelect.innerHTML = '<option value="">No models found</option>';
            }
        } catch (e) {
            modelSelect.innerHTML = '<option value="">Error loading models</option>';
        }
    }

    // Reflects the service's model-source classification in the UI
    function applySourceTypeUI(sourceType) {
        const isRemote = sourceType === 'remote';
        sourceTypeBadge.textContent = sourceType === 'remote' ? 'Live'
            : sourceType === 'hardcoded' ? 'Static' : '';
        sourceTypeBadge.classList.toggle('becss-service-bar__badge--remote', isRemote);
        refreshModelsBtn.classList.toggle('becss-service-bar__refresh-btn--hidden', !isRemote);
    }

    async function updateRegistry(services) {
        try {
            await fetch('/api/models/update', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ services: services || ['OpenRouter', 'TokenRoute'] })
            });
        } catch (e) {
            console.error('Failed to update registry:', e);
        }
    }

    serviceSelect.addEventListener('change', () => loadModels(serviceSelect.value));

    refreshModelsBtn.addEventListener('click', async () => {
        refreshModelsBtn.classList.add('becss-service-bar__refresh-btn--spinning');
        const activeService = serviceSelect.value;
        await updateRegistry([activeService]);
        await loadModels(activeService, false);
        refreshModelsBtn.classList.remove('becss-service-bar__refresh-btn--spinning');
    });

    // Initial load
    loadModels(serviceSelect.value);

    // ── Markdown renderer (v2.11.2) ───────────────────────────────────────
    // Small, dependency-free, HTML-safe: all input is escaped FIRST, then
    // markdown syntax is converted, so model output can never inject markup.
    // Supports: fenced code, headings, bold/italic/strike, inline code,
    // links (http/https only), ordered/unordered lists (nested by indent),
    // blockquotes, hr, simple tables. Single newlines inside a paragraph
    // are preserved as line breaks.
    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function renderInline(escaped) {
        const codeSpans = [];
        let out = escaped.replace(/`([^`\n]+)`/g, (m, c) => {
            codeSpans.push(c);
            return '\u0000' + (codeSpans.length - 1) + '\u0000';
        });
        out = out
            .replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g,
                '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
            .replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>')
            .replace(/__([^_\n]+?)__/g, '<strong>$1</strong>')
            .replace(/(^|[^*\w])\*([^*\s][^*\n]*?)\*(?!\*)/g, '$1<em>$2</em>')
            .replace(/~~([^~\n]+?)~~/g, '<del>$1</del>');
        return out.replace(/\u0000(\d+)\u0000/g, (m, i) => '<code>' + codeSpans[i] + '</code>');
    }

    function renderListItems(items) {
        let html = '';
        const stack = [];
        for (const it of items) {
            while (stack.length && it.indent < stack[stack.length - 1].indent) {
                html += '</li></' + stack.pop().tag + '>';
            }
            const tag = it.ordered ? 'ol' : 'ul';
            if (!stack.length || it.indent > stack[stack.length - 1].indent) {
                html += '<' + tag + '>';
                stack.push({ indent: it.indent, tag: tag });
            } else {
                html += '</li>';
            }
            html += '<li>' + renderInline(it.text);
        }
        while (stack.length) html += '</li></' + stack.pop().tag + '>';
        return html;
    }

    function splitTableRow(line) {
        let t = line.trim();
        if (t.startsWith('|')) t = t.slice(1);
        if (t.endsWith('|')) t = t.slice(0, -1);
        return t.split('|').map(c => c.trim());
    }

    // Fenced code renders as its own card: language label + Copy button + the
    // code. `code` is already HTML-escaped; Copy reads textContent, so it
    // copies the real characters. The click is handled in attachBubbleEvents.
    function codeCard(lang, code) {
        const l = String(lang || '').toLowerCase();
        const names = { py: 'python', python3: 'python', sh: 'bash', shell: 'bash', zsh: 'bash',
                        js: 'javascript', ts: 'typescript', yml: 'yaml', md: 'markdown' };
        const label = names[l] || l || 'code';
        return '<div class="becss-code"><div class="becss-code__bar"><span class="becss-code__lang">' +
            label.replace(/[^\w+#.-]/g, '') + '</span><button type="button" class="becss-code__copy">Copy</button></div>' +
            '<pre><code>' + code + '</code></pre></div>';
    }

    function mdToHtml(src) {
        const lines = escapeHtml(String(src).replace(/\r\n?/g, '\n')).split('\n');
        const out = [];
        let i = 0;
        const isBlockStart = (ln) =>
            /^\s*```/.test(ln) || /^\s{0,3}#{1,6}\s/.test(ln) || /^\s{0,3}&gt;/.test(ln) ||
            /^\s*([-*+]|\d+[.)])\s+/.test(ln) || /^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(ln);

        while (i < lines.length) {
            const line = lines[i];

            if (!line.trim()) { i++; continue; }

            // fenced code block
            const fence = line.match(/^\s*```\s*([\w+-]*)/);
            if (fence) {
                const buf = [];
                i++;
                while (i < lines.length && !/^\s*```/.test(lines[i])) { buf.push(lines[i]); i++; }
                i++; // closing fence (or EOF)
                out.push(codeCard(fence[1], buf.join('\n')));
                continue;
            }

            // heading
            const h = line.match(/^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/);
            if (h) {
                out.push('<h' + h[1].length + '>' + renderInline(h[2]) + '</h' + h[1].length + '>');
                i++;
                continue;
            }

            // horizontal rule
            if (/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(line)) { out.push('<hr>'); i++; continue; }

            // blockquote
            if (/^\s{0,3}&gt;/.test(line)) {
                const buf = [];
                while (i < lines.length && /^\s{0,3}&gt;/.test(lines[i])) {
                    buf.push(lines[i].replace(/^\s{0,3}&gt;\s?/, ''));
                    i++;
                }
                out.push('<blockquote>' + buf.map(renderInline).join('<br>') + '</blockquote>');
                continue;
            }

            // list
            if (/^\s*([-*+]|\d+[.)])\s+/.test(line)) {
                const items = [];
                while (i < lines.length) {
                    const m = lines[i].match(/^(\s*)([-*+]|\d+[.)])\s+(.*)$/);
                    if (m) {
                        items.push({ indent: m[1].replace(/\t/g, '    ').length, ordered: /\d/.test(m[2]), text: m[3] });
                        i++;
                    } else if (lines[i].trim() && /^\s{2,}\S/.test(lines[i]) && items.length) {
                        items[items.length - 1].text += '<br>' + renderInline(lines[i].trim());
                        i++;
                    } else {
                        break;
                    }
                }
                out.push(renderListItems(items));
                continue;
            }

            // table (header row + separator row)
            if (line.includes('|') && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(lines[i + 1])) {
                const head = splitTableRow(line);
                i += 2;
                const rows = [];
                while (i < lines.length && lines[i].trim() && lines[i].includes('|')) {
                    rows.push(splitTableRow(lines[i]));
                    i++;
                }
                let t = '<div class="becss-message__table-wrap"><table><thead><tr>' +
                    head.map(c => '<th>' + renderInline(c) + '</th>').join('') + '</tr></thead><tbody>';
                rows.forEach(r => { t += '<tr>' + r.map(c => '<td>' + renderInline(c) + '</td>').join('') + '</tr>'; });
                out.push(t + '</tbody></table></div>');
                continue;
            }

            // paragraph: consecutive plain lines, newlines kept as <br>
            const buf = [];
            while (i < lines.length && lines[i].trim() && !isBlockStart(lines[i])) {
                buf.push(renderInline(lines[i]));
                i++;
            }
            if (!buf.length) { buf.push(renderInline(line)); i++; }
            out.push('<p>' + buf.join('<br>') + '</p>');
        }
        return out.join('');
    }

    // Message Builder -- log style: "SENDER  time" then the message below.
    // User/System text is shown verbatim (escaped, pre-wrap); AI replies are
    // markdown-rendered. The raw text is kept on the element for Copy.
    function buildMessage(kind, sender, text, renderMarkdown, createdAtIso, model) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'becss-message becss-message--' + kind;
        const timeStr = (createdAtIso ? new Date(createdAtIso) : new Date())
            .toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        msgDiv.innerHTML = `
            <button class="becss-message__copy-btn" aria-label="Copy">Copy</button>
            <div class="becss-message__header" role="button" tabindex="0" aria-expanded="true" title="Tap to fold / unfold">
                <span class="becss-message__chev" aria-hidden="true">&#9662;</span>
                <span class="becss-message__sender">${escapeHtml(sender)}</span>
                ${model ? `<span class="becss-message__model" title="Model">${escapeHtml(model)}</span>` : ''}
                <span class="becss-message__time">${timeStr}</span>
            </div>
            <div class="becss-message__text ${renderMarkdown ? '' : 'becss-message__text--plain'}">${renderMarkdown ? mdToHtml(text) : escapeHtml(text)}</div>
        `;
        msgDiv._rawText = String(text);
        attachBubbleEvents(msgDiv);
        return msgDiv;
    }

    // Display name of the currently selected service (e.g. "Gemini REST")
    function currentServiceLabel() {
        const opt = serviceSelect.options[serviceSelect.selectedIndex];
        return opt ? opt.textContent.trim() : (serviceSelect.value || 'AI');
    }

    // ── Clipboard + toast helpers (v2.18.0) ───────────────────────────────
    const toastEl = document.getElementById('toast');
    let toastTimer = null;
    function toast(msg) {
        toastEl.textContent = msg;
        toastEl.classList.add('becss-toast--show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => toastEl.classList.remove('becss-toast--show'), 1800);
    }
    async function copyText(text) {
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(text);
                return true;
            }
        } catch (e) { /* fall through to the legacy path */ }
        try {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
            document.body.appendChild(ta);
            ta.select();
            const ok = document.execCommand('copy');
            ta.remove();
            return ok;
        } catch (e) { return false; }
    }

    // Message click-to-select, per-message Copy, and the context-aware strip
    function selectedMessage() { return chatHistory.querySelector('.becss-message--selected'); }
    function messageSender(msgDiv) {
        const el = msgDiv.querySelector('.becss-message__sender');
        return el ? el.textContent.trim() : '';
    }
    function attachBubbleEvents(msgDiv) {
        msgDiv.addEventListener('click', (e) => {
            if (e.target.classList.contains('becss-message__copy-btn')) return;
            // Code card: Copy button copies just that block
            const codeBtn = e.target.closest('.becss-code__copy');
            if (codeBtn) {
                const code = codeBtn.closest('.becss-code').querySelector('code');
                copyText(code ? code.textContent : '').then(ok => {
                    codeBtn.textContent = ok ? 'Copied!' : 'Failed';
                    toast(ok ? 'Code copied' : 'Copy failed');
                    setTimeout(() => codeBtn.textContent = 'Copy', 1500);
                });
                return;
            }
            // Header tap folds / unfolds the whole message (sender stays visible)
            if (e.target.closest('.becss-message__header')) { toggleCollapsed(msgDiv); return; }
            // Don't toggle selection while the user is selecting text or following a link
            if (e.target.closest('a')) return;
            const sel = window.getSelection && window.getSelection();
            if (sel && String(sel).length > 0) return;
            const isSelected = msgDiv.classList.contains('becss-message--selected');
            document.querySelectorAll('.becss-message--selected').forEach(el => {
                el.classList.remove('becss-message--selected');
            });
            if (!isSelected) msgDiv.classList.add('becss-message--selected');
            updateChatBar();
        });
        const copyBtn = msgDiv.querySelector('.becss-message__copy-btn');
        if (copyBtn) {
            copyBtn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const text = msgDiv._rawText || msgDiv.querySelector('.becss-message__text')?.innerText || '';
                const ok = await copyText(text);
                copyBtn.textContent = ok ? 'Copied!' : 'Copy failed';
                toast(ok ? 'Copied to clipboard' : 'Copy failed - select the text and copy manually');
                setTimeout(() => copyBtn.textContent = 'Copy', 1500);
            });
        }
    }
    function toggleCollapsed(msgDiv) {
        const collapsed = msgDiv.classList.toggle('becss-message--collapsed');
        const head = msgDiv.querySelector('.becss-message__header');
        if (head) head.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        if (collapsed && msgDiv.classList.contains('becss-message--selected')) {
            msgDiv.classList.remove('becss-message--selected');
            updateChatBar();
        }
    }
    chatHistory.addEventListener('keydown', (e) => {
        const head = e.target.closest && e.target.closest('.becss-message__header');
        if (head && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); toggleCollapsed(head.closest('.becss-message')); }
    });
    function clearSelection() {
        document.querySelectorAll('.becss-message--selected').forEach(el => el.classList.remove('becss-message--selected'));
        updateChatBar();
    }
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { hideInputMenu(); if (selectedMessage()) clearSelection(); }
    });

    // Resend: only offered for the user's own messages. Sends the same text
    // again; whatever is typed in the input is kept and put back afterwards.
    function resendMessage(msgDiv) {
        if (activeController) { toast('Wait for the reply to finish, or press Stop'); return; }
        const draft = chatInput.value;
        chatInput.value = msgDiv._rawText || '';
        clearSelection();
        sendBtn.click();
        chatInput.value = draft;
        chatInput.style.height = 'auto';
        if (draft) chatInput.style.height = chatInput.scrollHeight + 'px';
    }
    async function copyWholeChat() {
        const parts = Array.from(chatHistory.querySelectorAll('.becss-message')).map(m =>
            messageSender(m) + ':\n' + (m._rawText || ''));
        if (!parts.length) { toast('Nothing to copy yet'); return; }
        toast((await copyText(parts.join('\n\n'))) ? 'Chat copied' : 'Copy failed');
    }

    // Clear = wipe this chat's saved log and the screen; Reset = start a fresh chat
    // (the old one stays in the Logs tab).
    function abortActiveRequest() {
        if (activeController) { activeController.abort(); activeController = null; }
    }
    async function clearChatHistory() {
        if (!chatHistory.querySelector('.becss-message')) return;
        if (!confirm('Clear this chat? Its saved log is deleted too.')) return;
        abortActiveRequest();
        try { await fetch('/api/logs/' + sessionId, { method: 'DELETE' }); } catch (e) { /* log may not exist yet */ }
        chatHistory.innerHTML = '';
        updateChatBar();
        toast('Chat cleared');
    }
    function resetChat() {
        if (chatHistory.querySelector('.becss-message') && !confirm('Start a new chat? This one stays in the Logs tab.')) return;
        abortActiveRequest();
        startNewChat(false);
        toast('New chat started');
    }

    // ── Chat strip: "chatting with" + actions that depend on the situation ─
    const chatBar = document.getElementById('chatBar');
    const chatWho = document.getElementById('chatWho');
    const chatBarActions = document.getElementById('chatBarActions');
    function chatBarButton(label, handler, extraClass, disabled) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'becss-chatbar__btn' + (extraClass ? ' ' + extraClass : '');
        b.textContent = label;
        if (disabled) b.disabled = true;
        b.addEventListener('click', handler);
        return b;
    }
    function updateChatWho() {
        const model = modelSelect.value;
        chatWho.innerHTML = 'Chatting with <b>' + escapeHtml(currentServiceLabel()) + '</b>' +
            (model ? ' · ' + escapeHtml(model) : '');
    }
    function updateChatBar() {
        updateChatWho();
        chatBarActions.innerHTML = '';
        const sel = selectedMessage();
        chatBar.classList.toggle('becss-chatbar--selecting', !!sel);
        if (sel) {
            const isUser = sel.classList.contains('becss-message--user');
            chatBarActions.appendChild(chatBarButton('Copy', async () => {
                toast((await copyText(sel._rawText || '')) ? 'Copied to clipboard' : 'Copy failed');
            }));
            if (isUser) {   // context-aware: Resend only exists on your own messages
                chatBarActions.appendChild(chatBarButton('Resend', () => resendMessage(sel), 'becss-chatbar__btn--accent', !!activeController));
            }
            chatBarActions.appendChild(chatBarButton('Copy chat', copyWholeChat));
            chatBarActions.appendChild(chatBarButton('✕', clearSelection));
            return;
        }
        const hasMessages = !!chatHistory.querySelector('.becss-message');
        chatBarActions.appendChild(chatBarButton('Clear', clearChatHistory, '', !hasMessages));
        chatBarActions.appendChild(chatBarButton('Reset', resetChat));
    }
    new MutationObserver(updateChatBar).observe(chatHistory, { childList: true });
    new MutationObserver(updateChatBar).observe(modelSelect, { childList: true });
    modelSelect.addEventListener('change', updateChatBar);
    serviceSelect.addEventListener('change', updateChatBar);
    updateChatBar();

    // ── Context menu on the message box: Paste, Send, ... (v2.18.0) ───────
    const inputMenu = document.getElementById('inputMenu');
    function hideInputMenu() { inputMenu.hidden = true; inputMenu.innerHTML = ''; }
    function fireInput() { chatInput.dispatchEvent(new Event('input', { bubbles: true })); }
    function insertAtCaret(text, start, end) {
        chatInput.value = chatInput.value.slice(0, start) + text + chatInput.value.slice(end);
        const pos = start + text.length;
        chatInput.focus();
        chatInput.setSelectionRange(pos, pos);
        fireInput();
    }
    function showInputMenu(x, y) {
        const start = chatInput.selectionStart, end = chatInput.selectionEnd;
        const hasSel = end > start, hasText = chatInput.value.length > 0;
        const sending = !!activeController;
        const items = [
            ['Paste', async () => {
                try {
                    const clip = await navigator.clipboard.readText();
                    if (clip) insertAtCaret(clip, start, end); else toast('Clipboard is empty');
                } catch (e) { toast('Paste blocked by the browser - use the keyboard paste'); chatInput.focus(); }
            }, true],
            ['Cut', async () => {
                if (await copyText(chatInput.value.slice(start, end))) insertAtCaret('', start, end);
            }, hasSel],
            ['Copy', async () => {
                toast((await copyText(chatInput.value.slice(start, end))) ? 'Copied to clipboard' : 'Copy failed');
            }, hasSel],
            ['Select all', () => { chatInput.focus(); chatInput.select(); }, hasText],
            null,
            ['Clear', () => { chatInput.value = ''; fireInput(); chatInput.focus(); }, hasText],
            ['Send', () => sendBtn.click(), hasText && !sending],
        ];
        inputMenu.innerHTML = '';
        items.forEach(it => {
            const li = document.createElement('li');
            if (!it) { li.className = 'becss-ctxmenu__sep'; inputMenu.appendChild(li); return; }
            li.className = 'becss-ctxmenu__item' + (it[2] ? '' : ' becss-ctxmenu__item--disabled');
            li.setAttribute('role', 'menuitem');
            li.textContent = it[0];
            li.addEventListener('click', () => { hideInputMenu(); it[1](); });
            inputMenu.appendChild(li);
        });
        inputMenu.hidden = false;
        const w = inputMenu.offsetWidth, h = inputMenu.offsetHeight;
        inputMenu.style.left = Math.max(6, Math.min(x, window.innerWidth - w - 6)) + 'px';
        inputMenu.style.top = Math.max(6, Math.min(y - h, window.innerHeight - h - 6)) + 'px';
    }
    chatInput.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        showInputMenu(e.clientX, e.clientY);
    });
    inputMenu.addEventListener('mousedown', (e) => e.preventDefault());   // keep input focus + selection
    document.addEventListener('mousedown', (e) => { if (!inputMenu.hidden && !inputMenu.contains(e.target)) hideInputMenu(); });
    document.addEventListener('touchstart', (e) => { if (!inputMenu.hidden && !inputMenu.contains(e.target)) hideInputMenu(); }, { passive: true });
    window.addEventListener('resize', hideInputMenu);
    chatHistory.addEventListener('scroll', hideInputMenu);

    chatHistory.textContent = '';   // drop the template whitespace so :empty works for the hint

    // 1. Up Arrow / Door mechanism
    let expanded = false;
    expandBtn.addEventListener('click', () => {
        expanded = !expanded;
        arrowIcon.style.transform = expanded ? 'rotate(0deg)' : 'rotate(180deg)';
    });

    // 2. Auto-resize input textarea
    chatInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

    // 3. Status Cycle
    const states = { 'idle': 'Idle', 'sending': 'Sending...', 'receiving': 'AI Receiving', 'waiting': 'Waiting...', 'timeout': 'Timed out' };
    function setStatus(state) {
        statusHeader.setAttribute('data-state', state);
        statusText.textContent = states[state] || state;
    }

    // ── Send/Stop toggle helpers ──────────────────────────────────────────
    function setSending(isSending) {
        if (isSending) {
            sendBtn.classList.add('becss-send-btn--sending');
            sendBtn.title = 'Stop';
        } else {
            sendBtn.classList.remove('becss-send-btn--sending');
            sendBtn.title = 'Send';
        }
    }

    // ── Collect attached file IDs (checked items in the Attachments sub-tab)
    function getAttachedFileIds() {
        const list = document.getElementById('attachFileList');
        const items = list.querySelectorAll('.becss-attach__file-item');
        const ids = [];
        items.forEach(item => {
            const cb = item.querySelector('.becss-attach__file-checkbox');
            if (cb && cb.checked) {
                ids.push(item.dataset.fileId);
            }
        });
        return ids;
    }

    // ── Auto-uncheck all attachments after send (server-side too, so the
    // persisted enabled flag matches what the UI shows after a reload)
    function uncheckAllAttachments() {
        const list = document.getElementById('attachFileList');
        const checked = list.querySelectorAll('.becss-attach__file-checkbox:checked');
        checked.forEach(cb => {
            const item = cb.closest('.becss-attach__file-item');
            const fileId = item && item.dataset.fileId;
            cb.checked = false;
            if (item) item.classList.add('becss-attach__file-item--disabled');
            if (fileId) {
                fetch('/api/attach/files/toggle', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ file_id: fileId })
                }).catch(() => {});
            }
        });
        if (window.__updateAttachSelectAllState) window.__updateAttachSelectAllState();
    }

    // ── Main send logic ───────────────────────────────────────────────────
    sendBtn.addEventListener('click', async () => {
        // If currently sending, STOP
        if (activeController) {
            activeController.abort();
            activeController = null;
            setSending(false);
            setStatus('idle');
            return;
        }

        const text = chatInput.value.trim();
        if (!text) return;

        // Add User message
        chatHistory.appendChild(buildMessage('user', 'User', text, false));

        chatHistory.scrollTop = chatHistory.scrollHeight;
        chatInput.value = '';
        chatInput.style.height = 'auto';

        // Get selected settings
        const service = serviceSelect.value;
        const model = modelSelect.value;
        const serviceLabel = currentServiceLabel();  // sender label for the AI reply

        // Collect attached files
        const attachedIds = getAttachedFileIds();

        setStatus('sending');
        setSending(true);

        // Create AbortController for timeout + manual stop
        activeController = new AbortController();
        const timeoutId = setTimeout(() => {
            if (activeController) activeController.abort();
        }, SEND_TIMEOUT_MS);

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: text,
                    service: service,
                    model: model,
                    attached_file_ids: attachedIds,
                    session_id: sessionId,
                    service_label: serviceLabel,
                    profile: selectedProfileName()
                }),
                signal: activeController.signal
            });

            setStatus('receiving');

            const data = await response.json();

            const aiReply = buildMessage('ai', serviceLabel, data.response || 'Error: No response content', true, undefined, model);
            chatHistory.appendChild(aiReply);
            if (data.status === 'success') await applyProfileRenderer(aiReply, data.response);
            if (data.bubble_stats && window.BrainUI) window.BrainUI.renderRecalled(aiReply, data.bubble_stats.brain_recalled);

            // Auto-uncheck all attachments after successful send
            uncheckAllAttachments();

        } catch (error) {
            if (error.name === 'AbortError') {
                // Could be timeout or manual stop
                chatHistory.appendChild(buildMessage('ai', 'System', 'Request stopped or timed out.', false));
                setStatus('timeout');
            } else {
                chatHistory.appendChild(buildMessage('ai', 'System', 'Error connecting to server.', false));
            }
        } finally {
            clearTimeout(timeoutId);
            activeController = null;
            chatHistory.scrollTop = chatHistory.scrollHeight;
            setSending(false);
            // Restore idle after a brief delay if status was timeout
            setTimeout(() => {
                if (statusHeader.getAttribute('data-state') === 'timeout') {
                    setStatus('idle');
                }
            }, 3000);
            if (statusHeader.getAttribute('data-state') !== 'timeout') {
                setStatus('idle');
            }
        }
    });

    // ── Profiles: embedded Parser / Renderer (v2.15.0) ────────────────────
    // A profile may carry its own parse(raw_text) and render(parsed, container)
    // code. It only runs after the user has reviewed it and approved its
    // fingerprint (Settings > Profile Code). The renderer, and a JavaScript
    // parser, run in <iframe sandbox="allow-scripts"> (opaque origin, no
    // network, no access to this page). A Python parser runs on the server.
    const profileSelect = document.getElementById('profileSelect');
    const profileInfo = document.getElementById('profileInfo');
    const profileReview = document.getElementById('profileReview');
    const profileMeta = document.getElementById('profileMeta');
    const profileParserLang = document.getElementById('profileParserLang');
    const profileParserCode = document.getElementById('profileParserCode');
    const profileRendererCode = document.getElementById('profileRendererCode');
    const profileApproveBtn = document.getElementById('profileApproveBtn');
    const profileRevokeBtn = document.getElementById('profileRevokeBtn');
    const PROFILE_STORAGE_KEY = 'cliai.profile';
    const SANDBOX_ATTRIBUTES = 'sandbox="allow-scripts"';
    const SANDBOX_TIMEOUT_MS = 10000;
    let activeProfile = null;            // detail of the selected profile, or null
    const sandboxCache = new Map();      // fingerprint -> sandbox payload

    function selectedProfileName() { return profileSelect.value || undefined; }

    async function loadProfiles() {
        let list = [];
        try {
            const r = await fetch('/api/profiles');
            const j = await r.json();
            if (j.status === 'success') list = j.profiles;
        } catch (e) { /* profiles are optional; leave the picker at "No profile" */ }
        const wanted = profileSelect.value || localStorage.getItem(PROFILE_STORAGE_KEY) || '';
        profileSelect.innerHTML = '';
        const none = document.createElement('option');
        none.value = ''; none.textContent = 'No profile';
        profileSelect.appendChild(none);
        list.forEach(p => {
            const o = document.createElement('option');
            o.value = p.name;
            o.textContent = p.name + (p.has_embedded ? (p.approved ? ' \u2713' : ' \u26A0') : '');
            o.disabled = !p.valid;
            profileSelect.appendChild(o);
        });
        profileSelect.value = list.some(p => p.name === wanted && p.valid) ? wanted : '';
        await refreshActiveProfile();
    }

    async function refreshActiveProfile() {
        activeProfile = null;
        const name = profileSelect.value;
        if (name) {
            try {
                const r = await fetch('/api/profiles/' + encodeURIComponent(name));
                const j = await r.json();
                if (r.ok && j.status === 'success') activeProfile = j.profile;
            } catch (e) { /* treated as no profile */ }
        }
        renderProfilePanel();
    }

    function renderProfilePanel() {
        const p = activeProfile;
        profileReview.hidden = !(p && p.has_embedded);
        if (!p) {
            profileInfo.textContent = 'Select a profile in the Service bar to review its embedded parser and renderer.';
            return;
        }
        if (!p.has_embedded) {
            profileInfo.textContent = p.name + ' has no embedded parser or renderer.';
            return;
        }
        profileInfo.textContent = p.name + ' carries its own code. Read it before approving: it runs every time this profile replies.';
        profileMeta.className = 'becss-profile-meta ' + (p.approved ? 'becss-profile-meta--approved' : 'becss-profile-meta--pending');
        profileMeta.textContent = (p.approved ? 'APPROVED' : 'NOT APPROVED') + ' \u00B7 fingerprint ' + p.fingerprint;
        profileParserLang.textContent = p.parser_language || 'none';
        profileParserCode.textContent = p.parser || '(none)';
        profileRendererCode.textContent = p.renderer || '(none)';
        profileApproveBtn.hidden = p.approved;
        profileRevokeBtn.hidden = !p.approved;
    }

    profileSelect.addEventListener('change', () => {
        localStorage.setItem(PROFILE_STORAGE_KEY, profileSelect.value);
        refreshActiveProfile();
    });

    profileApproveBtn.addEventListener('click', async () => {
        const p = activeProfile;
        if (!p || !p.fingerprint) return;
        if (!confirm('Approve this ' + (p.parser_language || '') + ' parser and renderer for "' + p.name +
                     '"? Only approve code you have read.')) return;
        const r = await fetch('/api/profiles/' + encodeURIComponent(p.name) + '/approve', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fingerprint: p.fingerprint })
        });
        if (!r.ok) {
            const j = await r.json().catch(() => ({}));
            alert(j.response || 'Approval failed.');
        }
        await loadProfiles();
    });

    profileRevokeBtn.addEventListener('click', async () => {
        const p = activeProfile;
        if (!p) return;
        await fetch('/api/profiles/' + encodeURIComponent(p.name) + '/revoke', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}'
        });
        sandboxCache.clear();
        await loadProfiles();
    });

    // Replaces an AI message's text with the profile's rendering of it.
    // Never throws: on any failure the plain reply stays and a note says why.
    async function applyProfileRenderer(msgDiv, rawText) {
        const prof = activeProfile;
        if (!prof || !prof.has_embedded || !rawText) return;
        const textDiv = msgDiv.querySelector('.becss-message__text');
        const addNote = (t) => {
            const n = document.createElement('div');
            n.className = 'becss-profile-note';
            n.textContent = t;
            textDiv.appendChild(n);
        };
        if (!prof.approved) {
            addNote('Profile code not approved \u2014 showing the plain reply. Review it in Settings \u203A Profile Code.');
            return;
        }
        try {
            const base = '/api/profiles/' + encodeURIComponent(prof.name);
            let sb = sandboxCache.get(prof.fingerprint);
            if (!sb) {
                const r = await fetch(base + '/sandbox');
                const j = await r.json();
                if (!r.ok || j.status !== 'success') throw new Error(j.response || 'sandbox unavailable');
                if (j.iframe_attributes !== SANDBOX_ATTRIBUTES) throw new Error('unexpected sandbox attributes');
                sb = j;
                sandboxCache.set(prof.fingerprint, sb);
            }
            let parsed = null;
            if (sb.parser_language === 'python') {
                const r = await fetch(base + '/parse', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ raw_text: rawText })
                });
                const j = await r.json();
                if (!r.ok || j.status !== 'success') throw new Error(j.response || 'parser failed');
                parsed = j.result;
            }
            const iframe = document.createElement('iframe');
            iframe.setAttribute('sandbox', 'allow-scripts');   // never allow-same-origin
            iframe.className = 'becss-profile-frame';
            iframe.title = 'Rendered reply';
            const outcome = new Promise((resolve, reject) => {
                const finish = (err) => {
                    clearTimeout(timer);
                    window.removeEventListener('message', onMessage);
                    if (err) reject(err); else resolve();
                };
                const timer = setTimeout(() => finish(new Error('renderer timed out')), SANDBOX_TIMEOUT_MS);
                function onMessage(ev) {
                    if (ev.source !== iframe.contentWindow) return;
                    const d = ev.data || {};
                    if (d.type === 'ready') {
                        iframe.contentWindow.postMessage(
                            sb.parser_language === 'python'
                                ? { type: 'render', parsed: parsed }
                                : { type: 'run', raw: rawText }, '*');
                    } else if (d.type === 'rendered') {
                        if (Number.isFinite(d.height)) {
                            iframe.style.height = Math.min(Math.max(d.height, 24), 2000) + 'px';
                        }
                        finish(null);
                    } else if (d.type === 'error') {
                        finish(new Error(String(d.stage) + ': ' + String(d.message)));
                    }
                }
                window.addEventListener('message', onMessage);
            });
            textDiv.innerHTML = '';
            textDiv.appendChild(iframe);
            iframe.srcdoc = sb.srcdoc;
            try {
                await outcome;
            } catch (err) {
                textDiv.innerHTML = mdToHtml(rawText);
                addNote('Profile renderer failed (' + err.message + ') \u2014 showing the plain reply.');
            }
        } catch (err) {
            textDiv.innerHTML = mdToHtml(rawText);
            addNote('Profile renderer unavailable (' + err.message + ') \u2014 showing the plain reply.');
        }
    }

    loadProfiles();

    // ── Logs tab: past chats (BEJSON chat logs) ───────────────────────────
    const logsList = document.getElementById('logsList');

    function switchToChatTab() {
        const chip = Array.from(document.querySelectorAll('.becss-tool-chip'))
            .find(c => c.textContent.trim() === 'Chat');
        if (chip) chip.click();
    }

    async function loadLogs() {
        logsList.innerHTML = '<li class="becss-logs__empty">Loading...</li>';
        try {
            const data = await (await fetch('/api/logs')).json();
            const sessions = data.sessions || [];
            if (!sessions.length) {
                logsList.innerHTML = '<li class="becss-logs__empty">No chat logs yet.</li>';
                return;
            }
            logsList.innerHTML = '';
            sessions.forEach(sess => {
                const li = document.createElement('li');
                li.className = 'becss-logs__row' + (sess.id === sessionId ? ' becss-logs__row--current' : '');
                const when = sess.updated ? new Date(sess.updated).toLocaleString() : '';
                li.innerHTML = `
                    <div class="becss-logs__info">
                        <div class="becss-logs__title">${escapeHtml(sess.title)}</div>
                        <div class="becss-logs__meta">${sess.count} msgs${when ? ' · ' + escapeHtml(when) : ''}</div>
                    </div>
                    <div class="becss-logs__actions">
                        <button class="becss-logs__btn" data-act="open">Open</button>
                        <a class="becss-logs__btn" href="/api/logs/${sess.id}/download">Save</a>
                        <button class="becss-logs__btn" data-act="delete">Del</button>
                    </div>`;
                li.querySelector('[data-act="open"]').addEventListener('click', () => openLog(sess.id));
                li.querySelector('[data-act="delete"]').addEventListener('click', async () => {
                    if (!confirm('Delete this chat log?')) return;
                    await fetch('/api/logs/' + sess.id, { method: 'DELETE' });
                    if (sess.id === sessionId) startNewChat(false);
                    loadLogs();
                });
                logsList.appendChild(li);
            });
        } catch (e) {
            logsList.innerHTML = '<li class="becss-logs__empty">Error loading chat logs.</li>';
        }
    }

    async function openLog(id) {
        const data = await (await fetch('/api/logs/' + id)).json();
        sessionId = id;
        localStorage.setItem('cliai_session', id);
        chatHistory.innerHTML = '';
        (data.messages || []).forEach(m => {
            const isUser = m.role === 'user';
            chatHistory.appendChild(buildMessage(isUser ? 'user' : 'ai',
                m.sender || (isUser ? 'User' : 'AI'), m.content, !isUser, m.created_at, isUser ? undefined : m.model));
        });
        switchToChatTab();
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }

    function startNewChat(switchTab) {
        sessionId = newSessionId();
        localStorage.setItem('cliai_session', sessionId);
        chatHistory.innerHTML = '';
        if (switchTab !== false) switchToChatTab();
    }

    document.getElementById('newChatBtn').addEventListener('click', () => startNewChat(true));
    document.getElementById('refreshLogsBtn').addEventListener('click', loadLogs);
    document.getElementById('clearAllLogsBtn').addEventListener('click', async () => {
        if (!confirm('Delete ALL saved chat logs? This cannot be undone.')) return;
        try {
            const data = await (await fetch('/api/logs')).json();
            await Promise.all((data.sessions || []).map(sess => fetch('/api/logs/' + sess.id, { method: 'DELETE' })));
            chatHistory.innerHTML = '';
            toast('All chat logs deleted');
        } catch (e) { toast('Could not delete the logs'); }
        loadLogs();
    });

    // Restore the current session's messages after a page reload
    (async () => {
        try {
            const data = await (await fetch('/api/logs/' + sessionId)).json();
            (data.messages || []).forEach(m => {
                const isUser = m.role === 'user';
                chatHistory.appendChild(buildMessage(isUser ? 'user' : 'ai',
                    m.sender || (isUser ? 'User' : 'AI'), m.content, !isUser, m.created_at, isUser ? undefined : m.model));
            });
            chatHistory.scrollTop = chatHistory.scrollHeight;
        } catch (e) { /* no log yet */ }
    })();

    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendBtn.click();
        }
    });

    // 4. Toolbar chips active state interaction & Tab Switching
    // NOTE: "Context" tab removed from toolbar — it's now a sub-tab inside Attach
    const toolChips = document.querySelectorAll('.becss-tool-chip');
    const tabContents = {
        'Chat': document.getElementById('chatHistory'),
        'Attach': document.getElementById('tab-Attach'),
        'Service': document.getElementById('tab-Service'),
        'Brain': document.getElementById('tab-Brain'),
        'Logs': document.getElementById('tab-Logs')
    };

    toolChips.forEach(chip => {
        chip.addEventListener('click', function() {
            toolChips.forEach(c => c.classList.remove('becss-tool-chip--active'));
            this.classList.add('becss-tool-chip--active');

            // Hide all tabs
            Object.values(tabContents).forEach(tab => {
                if(tab) tab.classList.remove('becss-tab-content--active');
            });

            // Show active tab
            const tabName = this.textContent.trim();
            if(tabContents[tabName]) {
                tabContents[tabName].classList.add('becss-tab-content--active');
            }

            // Lazy-refresh tab-specific data on activation
            if (tabName === 'Logs') loadLogs();
            if (tabName === 'Brain' && window.BrainUI) window.BrainUI.onShow();
            if (tabName === 'Attach') {
                const activeSubtab = document.querySelector('.becss-subtab-chip--active');
                const activeKey = activeSubtab && activeSubtab.dataset.subtab;
                if (activeKey === 'context') {
                    loadContextFiles();
                    loadQuickText();
                } else if (activeKey === 'bubble') {
                    loadBubblePreview();
                } else {
                    loadAttachFiles();
                }
            }
        });
    });

    // ── Sub-tab switching (Attachments / Context / Bubble inside Attach) ───────────
    const subtabChips = document.querySelectorAll('.becss-subtab-chip');
    const subtabPanels = {
        'attachments': document.getElementById('subtab-attachments'),
        'context': document.getElementById('subtab-context'),
        'bubble': document.getElementById('subtab-bubble')
    };

    subtabChips.forEach(chip => {
        chip.addEventListener('click', function() {
            subtabChips.forEach(c => c.classList.remove('becss-subtab-chip--active'));
            this.classList.add('becss-subtab-chip--active');

            Object.values(subtabPanels).forEach(p => {
                if (p) p.classList.remove('becss-subtab-panel--active');
            });

            const key = this.dataset.subtab;
            if (subtabPanels[key]) {
                subtabPanels[key].classList.add('becss-subtab-panel--active');
            }

            // Lazy-load data
            if (key === 'attachments') loadAttachFiles();
            if (key === 'context') {
                loadContextFiles();
                loadQuickText();
            }
            if (key === 'bubble') loadBubblePreview();
        });
    });

    // ── Generic controller factory for a checkbox+file list, backed by one
    // of the two independent /api/attach/* or /api/context/* endpoint sets.
    // Both sub-tabs use the exact same DOM/CSS shape, differing only in
    // which API base they talk to -- this avoids maintaining two near-
    // identical copies of the same ~80 lines.
    function makeFileListController(apiBase, listEl, selectAllBtn) {
        async function load() {
            listEl.innerHTML = '<li class="becss-attach__empty">Loading...</li>';
            try {
                const resp = await fetch(`${apiBase}/files`);
                const data = await resp.json();
                render(data.files || []);
            } catch (e) {
                listEl.innerHTML = '<li class="becss-attach__empty">Error loading files.</li>';
            }
        }

        function render(files) {
            if (!files.length) {
                listEl.innerHTML = '<li class="becss-attach__empty">No files yet.</li>';
                updateSelectAllState();
                return;
            }
            listEl.innerHTML = files.map(f => `
                <li class="becss-attach__file-item ${f.enabled ? '' : 'becss-attach__file-item--disabled'}" data-file-id="${f.file_id}">
                    <input type="checkbox" class="becss-attach__file-checkbox" ${f.enabled ? 'checked' : ''}>
                    <div class="becss-attach__file-info">
                        <span class="becss-attach__file-name">${f.filename}</span>
                        <span class="becss-attach__file-meta">${f.char_count} chars</span>
                    </div>
                    <button class="becss-attach__file-delete" title="Remove">&times;</button>
                </li>
            `).join('');

            listEl.querySelectorAll('.becss-attach__file-checkbox').forEach(cb => {
                cb.addEventListener('change', async (e) => {
                    const fileId = e.target.closest('.becss-attach__file-item').dataset.fileId;
                    await fetch(`${apiBase}/files/toggle`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ file_id: fileId })
                    });
                    load();
                });
            });

            listEl.querySelectorAll('.becss-attach__file-delete').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    const fileId = e.target.closest('.becss-attach__file-item').dataset.fileId;
                    await fetch(`${apiBase}/files/${encodeURIComponent(fileId)}`, { method: 'DELETE' });
                    load();
                });
            });

            updateSelectAllState();
        }

        function updateSelectAllState() {
            const checkboxes = listEl.querySelectorAll('.becss-attach__file-checkbox');
            if (!selectAllBtn) return;
            if (!checkboxes.length) {
                selectAllBtn.textContent = 'Select All';
                selectAllBtn.classList.remove('becss-attach__select-all-btn--all-selected');
                return;
            }
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            selectAllBtn.textContent = allChecked ? 'Deselect All' : 'Select All';
            selectAllBtn.classList.toggle('becss-attach__select-all-btn--all-selected', allChecked);
        }

        if (selectAllBtn) {
            selectAllBtn.addEventListener('click', async () => {
                const checkboxes = listEl.querySelectorAll('.becss-attach__file-checkbox');
                if (!checkboxes.length) return;
                const allChecked = Array.from(checkboxes).every(cb => cb.checked);
                for (const cb of checkboxes) {
                    const shouldBeChecked = !allChecked;
                    if (cb.checked !== shouldBeChecked) {
                        const fileId = cb.closest('.becss-attach__file-item').dataset.fileId;
                        await fetch(`${apiBase}/files/toggle`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ file_id: fileId })
                        });
                    }
                }
                load();
            });
        }

        return { load, updateSelectAllState };
    }

    function wireImportButtons(apiBase, fileInput, folderInput, zipInput, onDone) {
        fileInput.addEventListener('change', async () => {
            const files = Array.from(fileInput.files || []);
            for (const file of files) {
                try {
                    const content = await file.text();
                    await fetch(`${apiBase}/files`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ filename: file.name, content: content })
                    });
                } catch (e) {
                    console.error('Failed to import', file.name, e);
                }
            }
            fileInput.value = '';
            onDone();
        });

        folderInput.addEventListener('change', async () => {
            const files = Array.from(folderInput.files || []);
            const payload = [];
            for (const file of files) {
                try {
                    const content = await file.text();
                    payload.push({ relative_path: file.webkitRelativePath || file.name, content: content });
                } catch (e) {
                    console.error('Failed to read', file.name, e);
                }
            }
            if (payload.length) {
                await fetch(`${apiBase}/import_folder`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ files: payload })
                });
            }
            folderInput.value = '';
            onDone();
        });

        zipInput.addEventListener('change', async () => {
            const file = zipInput.files && zipInput.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = async () => {
                const base64 = reader.result.split(',')[1]; // strip data: prefix
                await fetch(`${apiBase}/import_zip`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ content_base64: base64 })
                });
                zipInput.value = '';
                onDone();
            };
            reader.readAsDataURL(file);
        });
    }

    // ── Attachments sub-tab: sent with the next message only ─────────────
    const attachController = makeFileListController(
        '/api/attach',
        document.getElementById('attachFileList'),
        document.getElementById('attachSelectAllBtn')
    );
    window.__updateAttachSelectAllState = attachController.updateSelectAllState;
    wireImportButtons(
        '/api/attach',
        document.getElementById('attachFileImportInput'),
        document.getElementById('attachFolderImportInput'),
        document.getElementById('attachZipImportInput'),
        attachController.load
    );
    function loadAttachFiles() { attachController.load(); }

    // ── Context sub-tab: staged, chunked, persistently injected ──────────
    const contextController = makeFileListController(
        '/api/context',
        document.getElementById('contextFileList'),
        document.getElementById('contextSelectAllBtn')
    );
    wireImportButtons(
        '/api/context',
        document.getElementById('contextFileImportInput'),
        document.getElementById('contextFolderImportInput'),
        document.getElementById('contextZipImportInput'),
        contextController.load
    );
    function loadContextFiles() { contextController.load(); }

    // ── Quick-text box (Context sub-tab): merged into the same chunk as
    // the checked context files. Autosaved (debounced) so a reload doesn't
    // lose a draft typed before Save is clicked.
    const contextQuickText = document.getElementById('contextQuickText');
    let quickTextSaveTimer = null;

    async function loadQuickText() {
        try {
            const resp = await fetch('/api/context/quick_text');
            const data = await resp.json();
            contextQuickText.value = data.text || '';
        } catch (e) { /* leave whatever's currently typed */ }
    }

    contextQuickText.addEventListener('input', () => {
        clearTimeout(quickTextSaveTimer);
        quickTextSaveTimer = setTimeout(() => {
            fetch('/api/context/quick_text', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: contextQuickText.value })
            }).catch(() => {});
        }, 600);
    });

    // ── Save (Context sub-tab): wipes + rechunks enabled context files
    // plus the quick-text box into the persistent Context Bubble section.
    const saveChunkBtn = document.getElementById('saveChunkBtn');
    const saveChunkStatus = document.getElementById('saveChunkStatus');
    saveChunkBtn.addEventListener('click', async () => {
        saveChunkStatus.textContent = 'Saving...';
        try {
            const resp = await fetch('/api/context/save_chunk', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ quick_text: contextQuickText.value })
            });
            const data = await resp.json();
            if (data.chunked) {
                saveChunkStatus.textContent = `Saved (${data.file_count} sources).`;
            } else {
                saveChunkStatus.textContent = data.reason || 'Nothing to save.';
            }
            loadBubblePreview();
        } catch (e) {
            saveChunkStatus.textContent = 'Save failed.';
        }
    });

    // ── Context window panel (Attach > Bubble) ───────────────────────────
    // Live view of the bubble: window usage, per-allotment share of the window,
    // enable/disable switches (the bubble re-flows: remaining allotments grow
    // when one is switched off), weights, and the text each allotment holds.
    // All server text goes in through textContent -- never innerHTML.
    const bubbleText = document.getElementById('bubbleText');
    const bubbleStats = document.getElementById('bubbleStats');
    const bubbleBar = document.getElementById('bubbleBar');
    const bubbleRows = document.getElementById('bubbleRows');
    const bubbleGroups = document.getElementById('bubbleGroups');
    const bubbleMsg = document.getElementById('bubbleMsg');
    const bubbleViewLabel = document.getElementById('bubbleViewLabel');
    const refreshBubbleBtn = document.getElementById('refreshBubbleBtn');
    const BUBBLE_SHADES = ['#FFFFFF', '#DE2626', '#888888', '#F08A8A', '#BBBBBB', '#7A1010', '#555555', '#E8E8E8'];
    let bubbleData = null;
    let bubbleView = '';   // '' = whole bubble, else an allotment name
    let bubbleBusy = false;

    function bubbleEl(tag, cls, text) {
        const el = document.createElement(tag);
        if (cls) el.className = cls;
        if (text !== undefined) el.textContent = text;
        return el;
    }
    const fmtPct = v => (Math.round(v * 10) / 10).toString() + '%';

    async function postBubbleChange(changes) {
        if (bubbleBusy) return;
        bubbleBusy = true;
        bubbleMsg.textContent = '';
        try {
            const resp = await fetch('/api/context/bubble/allotments', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ changes, session_id: sessionId })
            });
            const data = await resp.json();
            if (data.status !== 'success') { bubbleMsg.textContent = data.message || 'Update failed.'; return; }
            renderBubble(data.bubble);
        } catch (e) {
            bubbleMsg.textContent = 'Update failed.';
        } finally {
            bubbleBusy = false;
        }
    }

    function renderBubble(data) {
        bubbleData = data;
        const active = data.allotments || [];
        const catalog = data.catalog || [];
        const byName = {};
        active.forEach(a => { byName[a.name] = a; });
        const shade = {};
        catalog.forEach((c, i) => { shade[c.name] = BUBBLE_SHADES[i % BUBBLE_SHADES.length]; });

        bubbleStats.textContent = `~${data.used_tokens || 0} / ${data.max_context_tokens} tokens · rebuild in ${data.turns_until_rebuild} turn(s) (every ${data.rebuild_interval})`;

        bubbleBar.replaceChildren();
        active.forEach(a => {
            const seg = bubbleEl('div', 'becss-bubble-bar__seg');
            seg.style.width = (a.share_pct || 0) + '%';
            seg.style.background = shade[a.name] || '#000';
            seg.title = `${a.label}: ${fmtPct(a.share_pct || 0)}`;
            bubbleBar.appendChild(seg);
        });

        // group switches (e.g. Brain = brain_pinned + brain_recall)
        bubbleGroups.replaceChildren();
        const groups = {};
        catalog.forEach(c => { if (c.group && c.available) (groups[c.group] = groups[c.group] || []).push(c); });
        Object.keys(groups).forEach(g => {
            const members = groups[g];
            const on = members.every(m => m.enabled);
            const btn = bubbleEl('button', 'becss-bubble-group' + (on ? ' becss-bubble-group--on' : ''),
                g.charAt(0).toUpperCase() + g.slice(1) + (on ? ': on' : ': off'));
            btn.type = 'button';
            btn.dataset.group = g;
            btn.addEventListener('click', () => {
                const ch = {};
                members.forEach(m => { ch[m.name] = { enabled: !on }; });
                postBubbleChange(ch);
            });
            bubbleGroups.appendChild(btn);
        });

        bubbleRows.replaceChildren();
        catalog.forEach(c => {
            const a = byName[c.name];
            const row = bubbleEl('div', 'becss-bubble-row' + (c.enabled && c.available ? '' : ' becss-bubble-row--off'));
            row.dataset.name = c.name;
            const sw = bubbleEl('span', 'becss-bubble-row__swatch');
            sw.style.background = shade[c.name];
            row.appendChild(sw);
            row.appendChild(bubbleEl('span', 'becss-bubble-row__name', `#${c.rank} ${c.label}`));
            row.appendChild(bubbleEl('span', 'becss-bubble-row__share', a ? fmtPct(a.share_pct) : 'off'));

            const detail = bubbleEl('div', 'becss-bubble-row__detail');
            const tl = bubbleEl('label', 'becss-bubble-row__toggle');
            const cb = document.createElement('input');
            cb.type = 'checkbox'; cb.className = 'becss-bubble-row__enable';
            cb.checked = !!c.enabled; cb.disabled = !c.available;
            cb.addEventListener('change', () => postBubbleChange({ [c.name]: { enabled: cb.checked } }));
            tl.appendChild(cb);
            tl.appendChild(document.createTextNode(c.available ? 'enabled' : 'not available'));
            detail.appendChild(tl);

            const wl = bubbleEl('label', '', 'weight ');
            const w = document.createElement('input');
            w.type = 'number'; w.min = '0'; w.max = '100'; w.step = '1';
            w.className = 'becss-bubble-row__weight'; w.value = String(c.pct);
            w.addEventListener('change', () => {
                const v = Number(w.value);
                if (!Number.isFinite(v) || v < 0 || v > 100) { bubbleMsg.textContent = 'Weight must be 0 to 100.'; w.value = String(c.pct); return; }
                postBubbleChange({ [c.name]: { pct: v } });
            });
            wl.appendChild(w);
            detail.appendChild(wl);

            if (a) {
                const spill = a.spill_in_tokens ? ` +${a.spill_in_tokens} spill` : (a.spill_out_tokens ? ` -${a.spill_out_tokens} lent` : '');
                detail.appendChild(bubbleEl('span', '', `${a.used_tokens}/${a.budget_tokens} tokens${spill}`));
                const flags = [];
                if (a.empty) flags.push('empty');
                if (a.truncated) flags.push('truncated');
                if (a.dropped) flags.push('dropped');
                if (flags.length) detail.appendChild(bubbleEl('span', 'becss-bubble-row__flag', flags.join(', ')));
                const v = bubbleEl('button', 'becss-bubble-row__view', bubbleView === c.name ? 'show all' : 'view text');
                v.type = 'button';
                v.addEventListener('click', () => { bubbleView = bubbleView === c.name ? '' : c.name; renderBubble(bubbleData); });
                detail.appendChild(v);
            }
            row.appendChild(detail);
            bubbleRows.appendChild(row);
        });

        const shown = bubbleView ? byName[bubbleView] : null;
        if (bubbleView && !shown) bubbleView = '';
        bubbleViewLabel.textContent = shown ? `Showing: ${shown.label} only` : 'Showing: full assembled bubble';
        bubbleText.textContent = (shown ? shown.text : data.text) || '(empty — nothing enabled to include yet)';
    }

    async function loadBubblePreview() {
        bubbleStats.textContent = 'Loading...';
        bubbleMsg.textContent = '';
        try {
            const resp = await fetch('/api/context/bubble?session_id=' + encodeURIComponent(sessionId));
            const data = await resp.json();
            if (data.error) {
                bubbleStats.textContent = data.error;
                bubbleText.textContent = '';
                return;
            }
            renderBubble(data);
        } catch (e) {
            bubbleStats.textContent = 'Error loading preview.';
        }
    }

    refreshBubbleBtn.addEventListener('click', async () => {
        refreshBubbleBtn.classList.add('becss-context-preview__refresh-btn--spinning');
        await loadBubblePreview();
        refreshBubbleBtn.classList.remove('becss-context-preview__refresh-btn--spinning');
    });
});
