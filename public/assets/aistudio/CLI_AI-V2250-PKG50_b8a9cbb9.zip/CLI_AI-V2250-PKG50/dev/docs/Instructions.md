The library ai profiles should be migrated to use this schema found in the profiles folder with This_Case_Fields and no CrammedFieldNames, integrate a configuration option to enable profile calls and to select a profile personalized tool within This environment and reconfigure the AI Library service calls to use this new schema when enabled profiles. Begin integrating  it into the menu options as well with persistent configuration settings and defaults 

I moved the profiles prototype to inside the cli folder, start by validating the schema with the libraries, redirect it to use any ibraries it shares with rest of ecosystem and use same lib folder as rest eco system then update old ai profile linbraries to match new schema if the schemas invalid fix it keep it 104a though if possible or you could vhhbhbm Nested Core for the schemavvv

validate the schema with libs first iby copying any needed into the cli system then validating.
/storage/emulated/0/Admin/libraries/libraries_104


each CLI tool went in the profile system should maintain its own configuration therefore it is on profile configuration and persistent state of Which profile is selected and the configuration should be moved out of the profile folder itself

profiles themselves Should stay where they are

update to cli ai pkg 13 when done

Make sure you add a switch within the CLI AI config environment to disable the profiles and the system could run completely with the profile of missing if  needed