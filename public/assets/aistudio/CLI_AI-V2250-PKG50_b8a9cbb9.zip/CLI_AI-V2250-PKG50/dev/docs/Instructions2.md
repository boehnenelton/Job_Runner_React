
Add a master config exported via library with a enable logging per service so a gemini_enable_loghing, openrouter_enable_logging etc

Make sure the key library is having strong key rotation system with error detection and cool down my new agent 

Make sure the AI libraries has a context folder that is rebuilt every prompt I like new agent and a context button with different budgets is built into the AI libraries and a library funnel that's optional all features are optional and they should work with all services