# Instructions 3 — Services & Extensions: The Modularity Intent

Date: 2026-09-18
Author: Elton Boehnen (dictated; recorded by Claude for continuity across sessions)

## The classification

Every file under `lib/AI/` (and its siblings like `lib/lib_ai_model_registry.py`)
is one of two things:

- **A Service.** Something that talks to one specific external provider's
  API and can produce a response to a prompt: Gemini, Grok, Groq,
  HuggingFace, OpenRouter, TokenRouter, Ollama, and any future provider.
  A Service's job is narrow: take a prompt (and whatever config a call
  needs), talk to its one provider, hand back a response in the shared
  shape. Nothing else.

- **An Extension** (also called a Feature). Something that adds a
  capability to a call *without caring which Service is making that
  call*: logging every call, injecting assembled context ahead of the
  prompt, watching for trigger keywords, parsing structured output out of
  a response, handling slash-commands, querying the Workspace Brain for
  relevant context. An Extension's job is to do its one thing to
  whichever Service is currently in use — it never contains
  Service-specific code, and it never assumes which Service it's
  attached to.

## The goal: Lego-brick composability

I want Services and Extensions to snap together like Lego bricks. Any
Extension should attach to any Service, cleanly, with no code changes on
either side — just an attachment/configuration step. Practically, that
means:

- An Extension is never hardcoded into one Service's file. If
  `context_bubble` only ever gets called from inside `bejson_gemini.py`,
  that's wrong — it should be just as available to Grok, Groq,
  OpenRouter, or whatever comes next, with the same code, unmodified.
- A Service never hand-imports and calls specific Extensions itself
  (no `from lib_bejson_AI_ai_call_log import log_ai_call` sitting inside
  a provider file, and no CLI prompter script hand-wiring `log_ai_call`
  and `console_log` into its own body either). That's copy-paste
  coupling, not attachment — it means turning logging on or off, or
  swapping which Extensions are active, requires touching N different
  files instead of flipping N independent switches.
- Whether an Extension is active for a given Service is a configuration
  decision, not a code decision — a switch you flip, not a line you
  comment out or copy into a new file.

## The example (illustrative, not a literal spec)

The example I gave — taking the context bubble currently associated with
the Gemini chat client and attaching it to a prompter for a completely
different service (I used OpenRouter as a stand-in) — was hypothetical.
The point isn't "make this exact pairing work." The point is: if that
pairing, or any other Extension-to-Service pairing, isn't at least
*possible* without editing either side's code, the architecture isn't
modular enough yet. Any Extension, on any Service, seamlessly — that's
the bar.

## What this supersedes

Wherever an Extension currently lives inside, or is only reachable from,
one specific Service's code path (or one specific CLI script), that's a
gap against this intent, not an acceptable permanent home for it. See
`reports/modularity-report.md` for a concrete assessment of where the
codebase stands against this goal today and what's recommended to close
the gap.
