# CLI_AI — AI Library Architecture

Three tiers, confirmed against what's actually imported and wired
together in `lib/AI/` (and the client-side modules that plug into it),
not against how any file describes itself.

1. **Calls** — everything whose only job is "reach a provider, get a
   normalized answer back." Nothing here knows about context, chunking,
   or UI.
2. **Context Bubble** — a hub, not a single library. One assembler with a
   fixed set of built-in sections, plus an open registration point that
   lets anything else — inside `lib/AI/` or outside it — plug in a
   section without the bubble knowing what that section is.
3. **Modular Components** — features that aren't calls and aren't bubble
   machinery, but bind onto the chat/service layer. Not all of them feed
   the bubble; some feed straight into a Call instead (see the diagram —
   that distinction is the main thing worth getting right here).

Two libraries turned out to be **dormant**: ported into this project at
some point, never imported by anything. Flagged explicitly below rather
than implied as active, since a diagram that shows every file as equally
"wired in" would be misleading.

## Diagram

```mermaid
flowchart TB
    subgraph CALLS["TIER 1 — CALLS"]
        direction TB
        DISPATCH["ai_dispatch.py<br/><i>ai_dispatch_call() — one signature,<br/>one AIResponse shape, 8 providers</i>"]
        TRANSDISPATCH["ai_transcribe_dispatch.py<br/><i>same pattern, for file-based<br/>transcription instead of text<br/>providers: gemini, gemini_rest</i>"]
        ADAPTERS["Per-provider adapters<br/><i>bejson_gemini / geminirest / groq / grok /<br/>huggingface / ollama / openrouter / tokenrouter / genai</i>"]
        OACOMPAT["ai_openai_compatible_base.py<br/><i>shared REST client — HuggingFace + others<br/>that speak the OpenAI wire format</i>"]
        REGBASE["ai_registry_base.py<br/><i>shared Key/Model/Profile registry<br/>building blocks every adapter reuses</i>"]
        MODELREG["lib_ai_model_registry.py<br/><i>unified model list, static + live,<br/>free-tier filtered</i>"]
        RESPONSE["ai_response.py<br/><i>AIResponse — the common shape<br/>normalizing 4+ different provider conventions</i>"]
        ERRORS["bejson_errors.py<br/><i>E_AI_* error code registry</i>"]
        CALLLOG["ai_call_log.py<br/><i>append-only call history</i>"]
        CONSOLELOG["ai_console_log.py<br/><i>colored terminal + file logging</i>"]
        PROFILES["gemini_standard_profiles.py<br/><i>system-instruction profile manager</i>"]

        DISPATCH --> ADAPTERS
        ADAPTERS --> OACOMPAT
        ADAPTERS --> REGBASE
        DISPATCH --> RESPONSE
        DISPATCH --> MODELREG
        DISPATCH --> ERRORS
        DISPATCH -.logs to.-> CALLLOG
        DISPATCH -.logs to.-> CONSOLELOG
        ADAPTERS -.reads.-> PROFILES
    end

    subgraph BUBBLE["TIER 2 — CONTEXT BUBBLE (a hub, not one file)"]
        direction TB
        ASSEMBLER["ai_context_bubble.py (v2)<br/><i>ai_bubble_prepare() — ranked allotments,<br/>spill-up budgets, chunk + verify, 5-turn rebuild</i>"]
        CONSTANTS["ai_constants.py<br/><i>max_context_tokens + chars_per_token</i>"]
        BUBBLECFG["config/context_bubble.bejson<br/><i>per-allotment rank, pct, enabled,<br/>refresh, keep, directive; rebuild interval</i>"]
        REGISTER(["ai_bubble_register_allotment(name, builder_fn, ...)<br/><i>the plugin hook — capped by<br/>BUBBLE_MAX_ALLOTMENTS</i>"])
        ALLOTMENTS["ai_bubble_allotments.py<br/><i>built-ins: policy, profile, attachments,<br/>context, chat history</i>"]

        ASSEMBLER --> CONSTANTS
        ASSEMBLER --> BUBBLECFG
        ASSEMBLER --- REGISTER
        ALLOTMENTS --> REGISTER
    end

    subgraph CLIENTREG["External registrants (client/, not lib/AI/)"]
        direction TB
        CTXFILES["ai_context_files.py<br/><i>lib/AI/ — generic tracked-file list,<br/>instantiated twice: Attachments + Context</i>"]
        CHUNKER["context_chunker.py<br/><i>client/ — stages + chunks enabled Context<br/>files + quick-text into one persistent block</i>"]
    end

    subgraph MODULAR["TIER 3 — MODULAR COMPONENTS"]
        direction TB
        STRUCTINSTR["ai_structured_instruction.py<br/><i>shapes what a model is told to output —<br/>generic delimited lists, or the tuned<br/>104db 'chunker project' prompt</i>"]
        STRUCTRECV["ai_structured_reception.py<br/><i>parses that specific output back apart —<br/>generic list parser, or full project rebuild</i>"]
        CMDSYS["ai_command_system.py<br/><i>⚠ DORMANT — slash-command registry/<br/>dispatcher, not imported anywhere yet</i>"]
        BRAIN["brain_helper.py<br/><i>⚠ DORMANT — Workspace Brain MFDB +<br/>policy node queries, not imported anywhere yet</i>"]
    end

    CHUNKER -->|"builder_fn: 'context' allotment source"| ALLOTMENTS
    CTXFILES -.->|"tracks files; client's own<br/>builder registers separately"| CHUNKER
    STRUCTINSTR -->|"instruction text prepended<br/>to user_input"| DISPATCH
    STRUCTRECV -.->|"parses DISPATCH's response,<br/>not the request"| DISPATCH
    ASSEMBLER -->|"assembled bubble text<br/>prepended to user_input"| DISPATCH

    classDef dormant fill:#2a2a2a,stroke:#666,color:#999,stroke-dasharray: 4 3
    class CMDSYS,BRAIN dormant
```

## What each tier actually means

### Tier 1 — Calls

Everything here answers one question: *how do I reach a provider and get
a normalized answer back?* `ai_dispatch_call(provider, user_input, ...)`
is the single entry point every caller (the client, every CLI tool) goes
through — it doesn't know or care whether the caller is a Flask route or
a terminal script. The 9 provider adapters underneath it exist specifically
so calling code never has to know that Groq returns a bare string,
OpenRouter returns `{content, thought}`, and GenAI returns `None` on
failure — `ai_response.py`'s `AIResponse` shape is what actually makes
"any of 8 providers, one code path" true. `ai_registry_base.py` and
`ai_openai_compatible_base.py` are the reason adding a new provider is
mostly config, not a new REST client from scratch.

### Tier 2 — Context Bubble

`ai_context_bubble.py` (v2, rebuilt 2026-10-20) owns one job: turn a set
of **ranked allotments** into one budgeted text block. Each allotment has
a rank (1 = highest), a baseline percentage of `max_context_tokens`, and a
builder function; they are listed in `config/context_bubble.bejson`.
Unused budget spills to over-budget allotments in rank order, each drawing
evenly from the donors; what is still over its grant is truncated.
Every allotment is chunked (Chunked-104a, via the frozen Core lib) into
the bubble directory, the whole bubble is chunked again, and the prompt is
rendered from that chunk after hash verification. The bubble persists
between turns and is rebuilt every 5 turns or when stable content changes.

`ai_bubble_allotments.py` registers the five built-ins (policy, profile,
attachments, context, chat history) through
`ai_bubble_register_allotment(name, builder_fn, ...)` — the plugin hook.
Anything else can register the same way; the number of allotments is
capped by the declared constant `BUBBLE_MAX_ALLOTMENTS`. The *context*
allotment's text comes from `context_chunker.chunker_build_section()`
(whatever the Context tab's Save last chunked). `ai_context_files.py`
itself is still just a tracked-file list, instantiated twice (Attachments
and Context). The keyword and knowledge-pool sections of v1 are gone
until a keyword system exists.

### Tier 3 — Modular Components

Features that bind onto the chat/service layer without being a call or
bubble machinery themselves. The Structured-Instruction/Reception pair
is the clearest current example, and it's worth being precise about its
data path: it does **not** go through the Context Bubble. Its
instruction text gets prepended straight onto a call's `user_input` (same
pattern the bubble itself uses, just via a different route in), and its
reception half parses that call's *response*, not its request. If a
future use case wanted a structured-instruction's output living in the
bubble instead — say, a standing set of parsed items re-injected every
turn — that would mean someone writing a `builder_fn` that calls
`structured_reception_parse_list()` internally and registering *that*.
Nothing does that today.

`ai_command_system.py` and `brain_helper.py` are real, complete libraries
that are currently connected to nothing — no CLI tool, no client route
imports either one. They're listed here for completeness and to save a
future session from assuming they're active because they exist.

## Update 2026-10-18 — profiles carry their own Parser and Renderer

The Structured-Instruction/Reception pair above was driven by a per-profile
`Mode` hint, which meant one "mode" library and one "parser" library for every
profile that wanted custom output handling. That design is retired for new
profiles. An `AI_Profile` now has three optional columns:

| Column | Holds | Contract |
|---|---|---|
| `Parser_Language` | `python` or `javascript` | chosen per profile |
| `Parser` | source code | defines `parse(raw_text)` returning a JSON-serialisable value |
| `Renderer` | vanilla JavaScript | defines `render(parsed, container)` |

The instruction half needs no library: it is the profile's `System_Instruction`.
`gemini_profiles_load_embedded()` validates structure and fingerprints the code
when a profile loads; `gemini_profiles_run_parser()` and
`gemini_profiles_build_sandbox()` refuse to do anything until the caller has
pinned that fingerprint as approved. Execution and sandbox hosting live in
`lib_bejson_AI_profile_parser_runtime.py` (Tier 1, no knowledge of context or UI).

Trust model: embedded code is executable content, and `profile_generator` makes
a model write profiles. Generated or imported profiles stay unapproved until a
person has read the code. Isolation, strongest first: browser sandbox (opaque
origin iframe, CSP `default-src 'none'`) > node `vm` child process > Python
child process with rlimits. Prefer `javascript` for any profile you did not
write yourself. `ai_structured_instruction` / `ai_structured_reception` are
kept (external clients import them) but are not wired to profiles.

### Client wiring (2026-10-18, v2.15.0)
The chat client now consumes profiles: a picker in the Service bar, a review panel under Settings > Profile Code, and
`/api/profiles*` routes backed by `client/profile_support.py`. Approvals persist in `data/approved_profile_code.bejson`
(BEJSON 104, one row per approved fingerprint). A selected profile's `System_Instruction` is prepended to the outgoing
message (like the context bubble) on both chat routes. Replies are drawn by the profile's Renderer inside a
`sandbox="allow-scripts"` iframe; a JavaScript parser runs in that same iframe, a Python parser runs server side.
Editing a profile file after approval changes its fingerprint, so trust is withdrawn automatically.

