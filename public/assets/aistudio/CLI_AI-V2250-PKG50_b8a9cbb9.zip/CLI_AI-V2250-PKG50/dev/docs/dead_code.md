
## Removed 2026-09-16 (audit remediation pass) — additional finding, not in original audit

**Directories removed:** three literal-quote-named directories —
`./'/storage/emulated/0'/`, `client/'/storage/emulated/0'/`, and
`CLI/menu_cli/'/storage/emulated/0'/` — each containing
`.env/logs/download_maintenance_service.log` and
`.env/system/Automation/download_maintenance.lock`.

**Why they were dead:** these are not project files. The literal `'`
characters are part of the directory *name* — some external process
(the log lines reference a `Download_Maintenance_Service`, which does
not exist anywhere in this project's code; `grep -rn` for it and for
`storage/emulated/0'` across every `.py` file found zero matches) wrote
to a relative path like `'/storage/emulated/0'/...` instead of the
absolute path `/storage/emulated/0/...`, almost certainly from an
unrelated device-level automation script running with an unquoted or
mis-escaped path while its CWD happened to be inside this project tree.
This left runtime junk (a log and a stale lock file) checked into three
separate spots in this delivery. Flagging for Elton: worth checking
whatever `Download_Maintenance_Service` script runs on-device for a
quoting bug in its path construction — this project's own code has no
reference to it.

## Removed 2026-09-16 (audit remediation pass)

**Files removed:**
- `client/chat_ui.html` — pre-Flask monolithic UI, superseded by
  `client/templates/chat.html`. `grep -rn "chat_ui" --include=*.py
  --include=*.html --include=*.js` across the project matched only the
  unrelated `chat_ui()` route handler function name in `app.py`; no
  reference to the file `chat_ui.html` (or any `render_template` call
  naming it) exists anywhere.
- `client/vchat_theme.html` — orphaned "V-CHAT" theme prototype, fully
  self-contained with its own inline CSS/JS. `grep -rn "vchat_theme"`
  found zero references anywhere in the project.
- `client/test_keys.py` — one-off debug script that duplicated
  `app.py`'s config/secure-env loading logic against a hardcoded absolute
  device path (`/storage/emulated/0/Labortory/AI Tools/CLI_AI-V15-PKG15/...`),
  violating the no-hardcoded-paths rule and carrying no assertions (not a
  real test). `grep -rn "test_keys" --include=*.py` found zero references.
- `data/structured_output/TestProfile/` (containing
  `profiles/grumpy_sysadmin.bejson`) — failed profile-generation artifact:
  the BEJSON file carries only a `Record_Type_Parent` field and a single
  row, missing every other field the schema defines. Not referenced by
  any code path.
- `.pytest_cache/` (root) — cache artifact, should never have been
  packaged; regenerated automatically by pytest.
- All `__pycache__/` and `*.pyc` files project-wide — build artifacts,
  excluded from delivery per the packaging exclusion rules.

**Also fixed in this pass (not deletions, but stale-content corrections):**
- `profiles/profiles/default.bejson` — `System_Instruction` had leaked a
  `TESTBOT` test instruction ("terse, bullet-point only... prefix every
  reply with [TESTBOT]") into the shipped default profile. Replaced with
  the generic assistant instruction from `profiles/profile_template.bejson`,
  which is what the default profile is supposed to carry.
- `client/instructions.md` — stated "we are not integrating functionality
  yet," contradicting the live `/api/chat`, `/api/models`, and
  `/api/models/update` dispatch already implemented in `app.py`/`chat.js`.
  Annotated with a status update rather than deleted, since the UI/behavior
  specs in the rest of the file are still the active design intent.

## Removed 2026-09-04 (full-project staleness sweep)

**Files removed:** `fix_paths.py`, `fix_test_paths.py` (project root).

**Why they were dead:** one-off migration helper scripts, not part of any
established file convention in this project (no `*_cli` naming, not under
`lib/` or `CLI/` or `dev/`). `fix_paths.py` hardcoded
`ROOT = Path("/storage/emulated/0/Labortory/AI Tools/CLI_AI-V9-PKG11")` --
a path from before the CLI/ restructure and the V9->V11 package renames,
already stale relative to this delivery's own path. Most of its
`REPLACEMENTS` pairs were no-ops (`old == new`, e.g.
`('project_root / "dev" / "logs"', 'project_root / "dev" / "logs"')`),
suggesting the actual rewrite had already happened by the time this
script's last edit was saved. `grep -rln "fix_paths\|fix_test_paths"`
across every `.py`/`.md` file in the project found zero references to
either name. Both were almost certainly the throwaway tooling used to
bulk-rewrite `dev/logs`/`dev/docs`/`dev/tests` paths during an earlier
restructure and were simply never deleted afterward.

**Also removed in this same sweep:**

**Files removed:**
- `.bejson_project.json.bak` (project root)
- `lib/Core/cli/CLI_Doc_Chunker/.bejson_project.json.bak`

**Why they were dead:** both are pre-edit snapshots of their live
`.bejson_project.json` counterpart, left behind by a prior session's edit
tooling. `diff` against the live file confirmed they were stale content,
not distinct data; `grep -rn "\.bak"` across every `.py` file in the
project found zero references to either path. No code path reads a
`.bak` file anywhere in this project.

## Removed 2026-08-22 (menu validator misalignment fix)

**File removed:** `lib/AI/gemini_model_registry.104a.bejson` (top-level, pre-
registry-overhaul location).

**Why it was dead:** `lib_bejson_AI_bejson_gemini.py` and
`lib_bejson_AI_bejson_interactions.py` both resolve their model registry
path via `CONFIG_DIR = get_self_contained_dir(__file__)` ->
`lib/AI/config/gemini_model_registry.104a.bejson` (since the 2026-08-22
self-contained-storage overhaul). Nothing in the codebase read the old
top-level path anymore except `menu_cli/prompt_menu.py`'s
`CONFIG_FILES_TO_VALIDATE` list, which was itself stale. Verified with
`grep -rn "gemini_model_registry"` across every `.py` file before
deleting -- only the two `STD_MODEL_PATH` definitions (both pointing at
the new `config/` location) and the now-fixed validator list referenced
the name at all.

**Root cause of the reported bug:** `CONFIG_FILES_TO_VALIDATE` was written
before the registry overhaul and never updated afterward. It checked only
that one dead Gemini path and silently skipped groq/openrouter/grok/
huggingface's real model registries entirely, so "Validate config files"
gave false green results while never checking the files that actually
back the non-Gemini providers. Fixed to check all five providers' real
`lib/AI/config/*_model_registry.104a.bejson` files, matching the current
`SERVICES` list one-for-one.

## 2026-10-18 — Mode field API removed (v2.14.0 / PKG 36)
Removed from `lib_bejson_AI_gemini_standard_profiles` 4.0.0: `PROFILE_MODE_FIELD`, `gemini_profiles_get_mode()`, `gemini_profiles_set_mode()`,
the `Mode=` kwarg of `gemini_profiles_create()`. Verified with `grep -rn` across every `.py` before removal: only `dev/tests/test_profile_mode.py`
(deleted, replaced by `test_profile_parser.py`) and the docs referenced them; no shipped profile had a `Mode` column. A legacy `Mode` column in an
old file still validates and is ignored.

Superseded but intentionally kept (external clients import them): `lib_bejson_AI_ai_structured_instruction.py` and
`lib_bejson_AI_ai_structured_reception.py`. Nothing in this project calls them; new profiles use `System_Instruction` + an embedded `Parser`.


## 2026-10-20 — Context Bubble v2 rebuild (v2.18.0 / PKG 40)
Removed from `lib_bejson_AI_ai_context_bubble.py` (1.0.1 -> 2.0.0), verified with `grep -rn` across every `.py` that only `client/app.py` called them:
`ai_bubble_assemble()`, `ai_bubble_register_section()`, `ai_bubble_clear_custom_sections()` and the private builders for cwd `context.bejson`,
active-task `checklist_*.bejson`, env drip, keyword triggers and the knowledge-pool drip. The compression/amnesia helpers were kept unchanged.
Replaced by `ai_bubble_prepare()` / `ai_bubble_register_allotment()`; the client now registers five allotments instead of seven sections.

Now unused by the bubble (left in place, not removed): the `pct_*`, `knowledge_drip_interval`, `env_drip_interval`, `global_default_cooldown`,
`observer_*` rows in `lib/AI/config/ai_constants.bejson` (only `max_context_tokens` and `chars_per_token` are read), and `lib_bejson_AI_ai_keywords.py`
(nothing imports it; no keyword system yet). Stale doc reference: `lib_bejson_AI_ai_context_files.py` comments still mention `ai_bubble_register_section()`;
its `ai_context_files_build_section()` is no longer registered (the client's Context content reaches the bubble via `context_chunker.chunker_build_section`).
The client's old fixed instruction text ("[CONTEXT — ... NEVER reference ...]" wrapper and the separate "[ATTACHMENTS ...]" / "[PROFILE INSTRUCTION ...]" blocks)
moved into per-allotment directives in `lib_bejson_AI_ai_bubble_allotments.py` / `context_bubble.bejson`; the old text survives only as the bubble-unavailable
fallback for the profile instruction.

2026-11-02 (PKG47): none removed. The Bubble sub-tab's plain-text stats lines were replaced by the structured panel (chat.js `loadBubblePreview` now delegates to `renderBubble`).
