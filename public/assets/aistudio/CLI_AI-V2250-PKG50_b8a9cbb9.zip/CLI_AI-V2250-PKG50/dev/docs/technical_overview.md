# Technical Overview — Class/Function Map

Per standing policy (Code Cleanup & Discretion): a compact map of
`File_Name / Function_Name(var1, var2, var3)` per file, built incrementally
as files are touched. This file did not exist before 2026-09-03; it is
seeded here with the files added/changed while building the Gemini
transcription capability. Older files in the project are not yet covered —
add their entries the next time each is touched, rather than back-filling
the whole tree in one pass (surgical scope).

## New files (2026-09-03)

### lib/AI/lib_bejson_AI_bejson_gemini_transcribe.py
- `clean_domain_terminology(text)`
- `detect_media_mime_type(file_path)`
- `_build_system_prompt(mode, segment, domain_context, extra_instructions)`
- `_read_media_b64(file_path)`
- `get_standard_transcribe_api()`
- `class GeminiTranscribeAPI`
  - `__init__(self, key_registry, model_registry)`
  - `transcribe(self, file_path, model_id, mode, segment, domain_context, clean_domain_terms, mime_type, extra_instructions)`
  - `transcribe_long_media(self, file_path, chunk_seconds, keep_chunks, **transcribe_kwargs)`

### lib/AI/lib_bejson_AI_bejson_gemini_rest_transcribe.py (2026-10-16)
- `get_rest_transcribe_api()`
- `class GeminiRestTranscribeAPI(GeminiTranscribeAPI)`
  - `__init__(self, key_registry, model_registry)`
  - `transcribe(self, file_path, model_id, mode, segment, domain_context, clean_domain_terms, mime_type, extra_instructions)`

### lib/AI/lib_bejson_AI_ai_transcribe_dispatch.py
- `_adapt_gemini_rest_transcribe(file_path, model_id, mode, segment, long_media, chunk_seconds, **config)` (2026-10-16)
- `_adapt_gemini_transcribe(file_path, model_id, mode, segment, long_media, chunk_seconds, **config)`
- `ai_transcribe_dispatch(provider, file_path, model_id, mode, segment, long_media, chunk_seconds, **config)`

### lib/AI/lib_bejson_AI_bejson_errors.py (additive)
- `class TranscribeMediaNotFoundError`
- `class TranscribeUnsupportedMediaError`
- `class TranscribeMediaTooLargeError`
- `class TranscribeChunkingUnavailableError`
- `class TranscribeChunkingFailedError`

### CLI/transcribe_cli/prompt_transcribe.py
- `ensure_config_preset()`
- `print_about(config)`
- `main()`

### CLI/menu_cli/prompt_menu.py (additive)
- `run_transcribe_session()`
- `print_menu()` — added `"t"` branch (unchanged otherwise)
- `main()` — added `__transcribe__` dispatch branch (unchanged otherwise)

### dev/tests/transcribe_cli/test_cli_prompt_transcribe.py
- `class TestDomainCleanup` — pure-function tests, no keys/network required
- `class TestMediaTypeDetection`
- `class TestRegistryLoading`
- `class TestDispatchInputValidation`
- `class TestLiveTranscription` — skipped automatically if `ffmpeg` is absent

## New files (2026-09-11)

### lib/AI/lib_bejson_AI_bejson_openai.py
- `get_standard_prompter()`
- `class OpenAIKeyRegistry(file_path)`
  - `load(self)`
- `class OpenAIModelRegistry(file_path)`
- `class OpenAIProfile(file_path)`
- `class OpenAIStandardPrompter(key_registry_path, model_registry_path, profile_path)`
  - `prompt(self, user_input, model_id, system_instruction)`

### CLI/openai_cli/prompt_openai.py
- `ensure_config_preset()`
- `refresh_openai_models(key_registry, model_registry)`
- `main()`

### dev/tests/openai_cli/test_cli_prompt_openai.py
- `class TestOpenAICLI`
  - `test_key_loading(self)`
  - `test_model_registry(self)`
  - `test_ai_dispatch_prompt(self)`

## New files (2026-09-16)

### lib/lib_ai_model_registry.py
- `_build_field_map(fields)`
- `_registry_to_bejson(records)`
- `_bejson_to_records(data)`
- `class AIModelRegistry(registry_path, api_keys)`
  - `load(self)`
  - `_save(self)`
  - `_seed_gemini_defaults(self)`
  - `_fetch_openrouter(self)`
  - `_fetch_tokenroute(self)`
  - `update_registry(self, services)`
  - `get_models(self, service)`
  - `get_all_records(self)`
  - `get_services(self)`
  - `is_auto_generating(service)` (staticmethod, added 1.1.0)
  - `get_model_source_type(service)` -> "hardcoded"|"remote" (added 1.2.0,
    wraps is_auto_generating with the naming client/app.py uses)

### CLI/config/cli_shared_config.py (added 2026-09-16)
- `bootstrap(cli_dir)` — resolves CORE_DIR/AI_DIR/LIB_DIR from
  cli_shared_config.104a.bejson, enforces portable_mode, returns
  MODEL_REGISTRY_SOURCE + AI_MODEL_REGISTRY_PATH. Called by every
  CLI/*_cli/prompt_*.py tool and menu_cli at the top of the file, before
  any lib_bejson_* import.
- `_load_or_init()` — loads or creates cli_shared_config.104a.bejson with
  defaults (portable_mode=false, library_path=../../lib/,
  model_registry_source=unified).

### client/app.py
- `load_bejson_config(config_path)`
- `load_secure_env(path)`
- `api_models()`
- `api_models_update()`
- `api_chat()` -- assembles+prepends the Context Bubble each turn (`_assemble_dispatch_input` -> `ai_bubble_prepare`)
- `chat_ui()`
- `launch_browser()`
- `api_context_files_list_route/import_route/toggle_route/delete_route()`
- `api_context_import_folder()`, `api_context_import_zip()`
- `api_context_save_chunk()`
- `api_context_bubble()` -- side-effect-free preview (`ai_bubble_preview`), per-allotment stats
- `_session_history(session_id)` -- feeds the `chat_history` allotment

### lib/AI/lib_bejson_AI_ai_context_bubble.py v2.0.0 (rebuilt 2026-10-20)
- `ai_bubble_register_allotment/unregister/clear/registered_names` -- plugin hook; `BUBBLE_MAX_ALLOTMENTS`
- `ai_bubble_config_init/load` -- `config/context_bubble.bejson` (name, rank, pct, enabled, refresh, keep, label, directive; header `Rebuild_Interval_Turns`)
- `ai_bubble_allocate(total_chars, items)` -- pure spill-up allocator
- `ai_bubble_prepare(context_dir, config_dir, msg, extras, skip)` -- per-turn: rebuild-or-reuse, chunk, verify, render
- `ai_bubble_preview(...)`, `ai_bubble_destroy(root)`, `ai_bubble_init(...)`, `ai_bubble_minimal(...)`
- carried over: `ai_bubble_set_compressor/compress_history/save|load_amnesia_recap/rebirth`

### lib/AI/lib_bejson_AI_ai_bubble_allotments.py v1.0.0
- `register_builtin_allotments(list_files, attach_dir, attach_content_dir, context_section_fn)` -- policy(1), profile(2), attachments(3), context(4), chat_history(5)

### lib/AI/lib_bejson_AI_ai_context_files.py (added 2026-09-21)
- `ai_context_files_init/list/import/toggle/delete(context_dir, ...)`
- `ai_context_files_build_section(...)` -- v1 custom-section builder, no longer registered (kept; see dev/docs/dead_code.md)

### client/context_chunker.py (added 2026-09-21)
- `chunker_load_config/save_config`, `chunker_extract_zip_entries`
- `chunker_run_save(context_dir, enabled_files, content_dir, force=False)`
  -- stage + hash + chunk + manifest, no-ops if nothing changed
- `chunker_build_section(...)` -- source of the `context` allotment: the most recently saved chunk

### lib/AI/lib_bejson_AI_ai_structured_instruction.py (added 2026-09-27; superseded 2026-10-18 for new profiles — instruction text belongs in the profile's System_Instruction, parsing in its Parser)
- `structured_instruction_list(fields, count=None, block_name="ITEM")` --
  generic instruction text for N delimited [ITEM]...[/ITEM] blocks
- `structured_instruction_chunker_project()` -- Elton's tuned BEJSON-104db
  "chunker" instruction set, verbatim, for generating a whole project

### lib/AI/lib_bejson_AI_ai_structured_reception.py (added 2026-09-27; superseded 2026-10-18 for new profiles — see embedded Parser)
- `structured_reception_parse_list(raw_text, block_name="ITEM")` -- parses
  output produced under structured_instruction_list()'s format
- `structured_reception_rebuild_project(raw_text, destination=None)` --
  extracts a 104db project doc from raw model output (tolerates code
  fences/stray text) and rebuilds it to real files, matching CLI_Chunker.py's
  own run_unchunk() 104db branch exactly (including touch-only binary rows)


## client/static/js/chat.js (v2.11.2 additions)
- chat.js / escapeHtml (str)
- chat.js / renderInline (escaped)
- chat.js / renderListItems (items)
- chat.js / splitTableRow (line)
- chat.js / mdToHtml (src)
- chat.js / buildMessage (kind, sender, text, renderMarkdown)
- chat.js / currentServiceLabel ()
- app.py / _token_budget_payload ()
- app.py / api_settings_tokens_get ()
- app.py / api_settings_tokens_set ()
- chat.js / applyTokenBudget (data)
- chat.js / loadTokenBudget ()
- chat.js / saveTokenBudget (body)

## lib/AI/lib_bejson_AI_gemini_standard_profiles.py (v4.0.0 — embedded Parser/Renderer, replaces Mode)
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_create (name, archetype, persona, instruction, **kwargs incl. optional Parser_Language, Parser, Renderer; ValueError on bad code)
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_validate (doc) -- now also runs the static code checks
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_get_parser (profile, record_index) -> {language, code} | None
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_set_parser (profile, language, code, record_index)
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_get_renderer (profile, record_index)
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_set_renderer (profile, code, record_index)
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_validate_embedded (profile, record_index, syntax_check_js) -> [problems]
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_embedded_fingerprint (profile, record_index) -> sha256 | None
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_load_embedded (profile, approved_fingerprints, record_index, syntax_check_js) -- call on profile load; executes nothing
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_run_parser (profile, raw_text, approved_fingerprints, record_index, timeout) -- refuses unless approved
- lib_bejson_AI_gemini_standard_profiles.py / gemini_profiles_build_sandbox (profile, approved_fingerprints, record_index) -- refuses unless approved
- Removed in 4.0.0: gemini_profiles_get_mode, gemini_profiles_set_mode, PROFILE_MODE_FIELD, Mode= kwarg (a legacy "Mode" column in old files is tolerated and ignored)
- Columns (optional, appended last, all "string"): Parser_Language ("python"|"javascript"), Parser (source of `parse(raw_text)`), Renderer (vanilla JS source of `render(parsed, container)`)

## lib/AI/lib_bejson_AI_profile_parser_runtime.py (v1.0.0, added 2026-10-18)
- lib_bejson_AI_profile_parser_runtime.py / runtime_normalize_language (language)
- lib_bejson_AI_profile_parser_runtime.py / runtime_fingerprint (language, parser, renderer)
- lib_bejson_AI_profile_parser_runtime.py / runtime_validate_parser (language, code), runtime_validate_python_parser (code), runtime_validate_javascript_parser (code), runtime_validate_renderer (code)
- lib_bejson_AI_profile_parser_runtime.py / runtime_javascript_syntax_error (code, timeout) -- best effort via `node --check`
- lib_bejson_AI_profile_parser_runtime.py / runtime_run_parser (language, code, raw_text, timeout), runtime_run_python_parser (code, raw_text, timeout, memory_mb), runtime_run_javascript_parser (code, raw_text, timeout)
- lib_bejson_AI_profile_parser_runtime.py / sandbox_build_srcdoc (parser_language, parser_code, renderer_code) -- srcdoc for `<iframe sandbox="allow-scripts">`; message protocol in its docstring

## v2.13.0 (PKG 31) — OllamaLocal, streaming, chat logs

lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.is_ready ()
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.installed_models ()
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.has_model (tag)
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.status ()
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.ensure_binary ()
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.start ()
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.stop ()
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.pull_model (tag, progress_cb)
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.setup (tag)
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalServer.setup_async (tag)
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalStandardPrompter.build_messages (user_input, system_instruction, history)
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalStandardPrompter.prompt (user_input, model_id, system_instruction, **config)
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / OllamaLocalStandardPrompter.stream (messages, model_id, **config)
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / get_standard_server (log_dir)
lib/AI/lib_bejson_AI_bejson_ollamalocal.py / get_standard_prompter ()
lib/AI/lib_bejson_AI_ai_dispatch.py / _adapt_ollamalocal (user_input, model_id, system_instruction, **config)
client/chat_logs.py / valid_session_id (session_id)
client/chat_logs.py / ChatLogStore.append (session_id, role, sender, service, model, content)
client/chat_logs.py / ChatLogStore.load (session_id)
client/chat_logs.py / ChatLogStore.list_sessions ()
client/chat_logs.py / ChatLogStore.delete (session_id)
client/app.py / _assemble_dispatch_input (message, attached_file_ids)
client/app.py / _log_message (session_id, role, sender, service, model, content)
client/app.py / api_chat_stream ()
client/app.py / api_logs_list | api_logs_get | api_logs_delete | api_logs_download (sid)
client/app.py / api_ollamalocal_status | api_ollamalocal_setup | api_ollamalocal_stop ()
client/static/js/chat.js / sendStreaming (text, service, model, serviceLabel, attachedIds)
client/static/js/chat.js / loadLogs () | openLog (id) | startNewChat (switchTab)
client/static/js/chat.js / refreshOllamaLocal () | startOllamaLocalPoll () | stopOllamaLocalPoll ()

## client/profile_support.py (v1.0.0, added 2026-10-18)
- profile_support.py / profile_safe_name (name)
- profile_support.py / ProfileStore.__init__ (profiles_dir, approvals_path)
- profile_support.py / ProfileStore.names ()
- profile_support.py / ProfileStore.load (name) -- validated AI_Profile doc or None
- profile_support.py / ProfileStore.summary (name), ProfileStore.detail (name)
- profile_support.py / ProfileStore.approved_fingerprints (), approve (name, fingerprint), revoke (fingerprint)
- profile_support.py / ProfileStore.system_instruction (name)
- profile_support.py / ProfileStore.run_parser (name, raw_text), ProfileStore.sandbox (name)

## client/app.py (v2.15.0 additions)
- app.py / api_profiles_list (), api_profiles_detail (name), api_profiles_approve (name), api_profiles_revoke (name), api_profiles_sandbox (name), api_profiles_parse (name)
- app.py / _resolve_profile_instruction (name)
- app.py / _assemble_dispatch_input (message, attached_file_ids, profile_instruction) -- profile_instruction is new, optional
- /api/chat and /api/chat/stream accept an optional "profile" name; unknown profile is an error, never a silent fallback

## client/static/js/chat.js (v2.15.0 additions)
- chat.js / loadProfiles (), refreshActiveProfile (), renderProfilePanel (), selectedProfileName ()
- chat.js / applyProfileRenderer (msgDiv, rawText) -- never throws; sandbox iframe + postMessage protocol



## profiles/app.py (v2.1.0 additions)
- app.py / apply_embedded_code (data, body) -> problem string | None -- applies Parser_Language/Parser/Renderer via the shared lib, then static + `node --check` validation; PUT returns 422 and writes nothing on a problem
- app.py / write_bejson (filepath, data) -- now also strips _bejson_field_map
- Edit dialog: "Embedded Code" section (edParserLang, edParserCode, edRendererCode)
\n

## v2.17.0 (PKG 39) — LiteRT-LM local service

lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.is_ready ()
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.installed_models ()
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.has_model (model_id)
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.status ()
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.ensure_binary ()
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.start ()
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.stop ()
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.setup (model_id)
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMServer.setup_async (model_id)
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMStandardPrompter.build_messages (user_input, system_instruction, history)
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMStandardPrompter.prompt (user_input, model_id, system_instruction, **config)
lib/AI/lib_bejson_AI_bejson_litertlm.py / LiteRTLMStandardPrompter.stream (messages, model_id, **config)
lib/AI/lib_bejson_AI_bejson_litertlm.py / get_standard_server (log_dir)
lib/AI/lib_bejson_AI_bejson_litertlm.py / get_standard_prompter ()
lib/AI/lib_bejson_AI_ai_dispatch.py / _adapt_litertlm (user_input, model_id, system_instruction, **config)
client/app.py / LOCAL_STREAM_SERVICES (dict) ; api_chat_stream () now serves OllamaLocal + LiteRTLM
client/app.py / api_litertlm_status | api_litertlm_setup | api_litertlm_stop ()
client/static/js/chat.js / refreshLiteRTLM () | startLiteRTLMPoll () | stopLiteRTLMPoll () | loadLiteRTLMModelChoices ()


## client/static/js/chat.js (v2.19.0 additions)
- chat.js / buildMessage (kind, sender, text, renderMarkdown, createdAtIso, model)
- chat.js / copyText (text)
- chat.js / toast (msg)
- chat.js / selectedMessage ()
- chat.js / clearSelection ()
- chat.js / resendMessage (msgDiv)
- chat.js / copyWholeChat ()
- chat.js / clearChatHistory ()
- chat.js / resetChat ()
- chat.js / pollServerState ()
- chat.js / startLocalServer ()
- chat.js / stopLocalServer ()
- chat.js / updateChatBar ()
- chat.js / showInputMenu (x, y)
- chat.js / hideInputMenu ()

## client/static/js/chat.js (v2.20.0 additions)
- chat.js / codeCard (lang, code)
- chat.js / toggleCollapsed (msgDiv)

## client/brain_routes.py (v2.23.0)
- brain_routes.py / register_brain_routes (app, store, handle, logger)
- brain_routes.py / _memory_json (row, cat_names)
- brain_routes.py / _category_json (row, counts)
- Routes: GET /api/brain/status; GET,POST /api/brain/categories; POST /api/brain/categories/<id>/archive; GET,POST /api/brain/memories; PUT,DELETE /api/brain/memories/<id>; POST .../pin, .../restore; GET /api/brain/proposals; POST /api/brain/proposals/<id>/approve|reject; GET,POST /api/brain/snapshots; POST /api/brain/snapshots/rollback; GET /api/brain/recall/preview; GET,POST /api/brain/settings

## client/static/js/brain.js (v2.23.0)
- brain.js / window.BrainUI.onShow ()
- brain.js / window.BrainUI.renderRecalled (messageEl, list)
- brain.js / loadMemories (), loadProposals (), loadSnapshots (), loadSettings ()

## lib/AI/lib_bejson_AI_brain_*.py (v2.23.0)
- Full signatures: see the standalone Brain project docs; entry points: BrainStore (root_dir, config_dir, limits, clock), brain_keywords_recall (store, user_msg, turn, cooldown_state), brain_bubble_register (store), snapshots_{list,create,create_if_changed,prune,maintain,validate,rollback} (store, ...)
