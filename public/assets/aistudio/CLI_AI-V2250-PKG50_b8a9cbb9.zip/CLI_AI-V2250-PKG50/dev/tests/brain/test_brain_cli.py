"""
Name:        test_brain_cli.py
Description: CLI contract tests: one JSON object per call, exit codes 0/20/30.
Version:     1.0.0
Date:        2026-10-24
Author:      Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID: bed577d9-5587-4394-8953-dcd1f3f71161
"""

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

CLI = Path(__file__).resolve().parents[3] / "CLI" / "brain_cli" / "cli_brain_manager.py"


class TestCli(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="brain_cli_")
        self.conf = tempfile.mkdtemp(prefix="brain_cli_cfg_")

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)
        shutil.rmtree(self.conf, ignore_errors=True)

    def run_cli(self, *args):
        proc = subprocess.run([sys.executable, str(CLI), "--root", self.root, "--config-dir", self.conf, *args],
                              capture_output=True, text=True, timeout=120)
        return proc.returncode, json.loads(proc.stdout)

    def test_environment_exit_code_before_init(self):
        code, out = self.run_cli("status")
        self.assertEqual((code, out["ok"], out["code"]), (20, False, 240))

    def test_full_cycle(self):
        self.assertEqual(self.run_cli("init")[0], 0)
        code, out = self.run_cli("memory-add", "--title", "Hi", "--content", "there", "--keywords", "hello,world")
        self.assertEqual(code, 0)
        mem_id = out["data"]["id"]
        code, out = self.run_cli("memory-get", mem_id)
        self.assertEqual(out["data"]["brmem_title"], "Hi")
        code, out = self.run_cli("--actor", "ai", "memory-add", "--title", "Hi", "--content", "x")
        self.assertEqual(code, 0)
        code, out = self.run_cli("memory-add", "--title", "x" * 90, "--content", "c")
        self.assertEqual((code, out["code"]), (30, 248))
        code, out = self.run_cli("snapshot", "--reason", "cli")
        self.assertEqual(code, 0)
        code, out = self.run_cli("rollback", "../../nope")
        self.assertEqual((code, out["code"]), (20, 243))
        code, out = self.run_cli("verify")
        self.assertEqual(code, 0)

    def test_argument_error_is_json(self):
        code, out = self.run_cli("--nonsense")
        self.assertEqual((code, out["ok"]), (30, False))


if __name__ == "__main__":
    unittest.main(verbosity=2)
