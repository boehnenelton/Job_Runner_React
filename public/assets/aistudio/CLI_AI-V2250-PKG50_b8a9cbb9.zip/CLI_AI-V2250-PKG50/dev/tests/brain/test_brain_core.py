"""
Name:        test_brain_core.py
Description: Phase 1-2 tests for the Brain family: round-trip, conformance, manifest integrity, post-reset, concurrency, limits, AI-writer safety matrix, batch atomicity, snapshots, rollback, tamper, lockdir exclusion, crash injection, caches.
Version:     1.0.0
Date:        2026-10-24
Author:      Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID: acb500d9-1d94-42e6-9775-231bd5e82244
"""

import json
import re
import shutil
import sys
import tempfile
import threading
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
LIB_AI = HERE.parents[2] / "lib" / "AI"
sys.path.insert(0, str(LIB_AI))

import lib_bejson_AI_brain_core_bridge  # noqa: E402,F401
import lib_bejson_AI_brain_errors as E  # noqa: E402
from lib_bejson_AI_brain_errors import BrainError  # noqa: E402
from lib_bejson_AI_brain_schema_registry import CatF, MemF, ENTITY_CATEGORY, ENTITY_MEMORY, schema_registry_primary_key  # noqa: E402
from lib_bejson_AI_brain_store import BrainStore  # noqa: E402
import lib_bejson_AI_brain_snapshots as S  # noqa: E402
from lib_bejson_Core_mfdb_core import mfdb_core_deep_verify  # noqa: E402


class SimulatedCrash(BaseException):
    pass


class Clock:
    def __init__(self):
        self.t = datetime(2026, 10, 1, 12, 0, 0, tzinfo=timezone.utc)

    def __call__(self):
        return self.t

    def advance(self, **kw):
        self.t += timedelta(**kw)


class BrainTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="brain_test_"))
        self.clock = Clock()
        self.store = BrainStore(self.tmp, clock=self.clock)
        self.store.init()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def add(self, title="T", content="C", actor="user", **kw):
        op = {"op": "memory_add", "category": "General", "title": title, "content": content}
        op.update(kw)
        return self.store.apply(op, actor)

    def errcode(self, fn):
        with self.assertRaises(BrainError) as ctx:
            fn()
        return ctx.exception.code


class TestAiFamilyIntegration(BrainTestCase):
    def test_brain_error_joins_ai_exception_tree(self):
        from lib_bejson_AI_bejson_errors import AIException, AIFatalError, AIRecoverableError
        fatal = BrainError(E.E_BRAIN_CORRUPT, "x")
        soft = BrainError(E.E_BRAIN_MEMORY_INVALID, "y")
        self.assertIsInstance(fatal, AIFatalError)
        self.assertIsInstance(soft, AIRecoverableError)
        self.assertIsInstance(soft, AIException)
        self.assertEqual((fatal.code, fatal.error_code, fatal.fatal, soft.fatal), (241, 241, True, False))
        self.assertEqual(self.errcode(lambda: self.store.apply({"op": "memory_pin", "id": "nope"})), E.E_BRAIN_MEMORY_NOT_FOUND)

    def test_new_files_use_ai_family_names(self):
        names = sorted(p.name for p in LIB_AI.glob("lib_bejson_AI_brain_*.py"))
        self.assertTrue(all(n.startswith("lib_bejson_AI_brain_") for n in names), names)


class TestPhase1(BrainTestCase):
    def test_round_trip(self):
        res = self.add("Coffee", "Likes dark roast", keywords=["coffee", "roast"], priority=70, confidence=0.9, pinned=True)
        row = self.store.get_memory(res["id"])
        self.assertEqual(row[MemF.TITLE], "Coffee")
        self.assertEqual(row[MemF.CONTENT], "Likes dark roast")
        self.assertEqual(row[MemF.KEYWORDS], "coffee|roast")
        self.assertEqual(row[MemF.PRIORITY], 70)
        self.assertAlmostEqual(row[MemF.CONFIDENCE], 0.9)
        self.assertTrue(row[MemF.PINNED])
        self.assertEqual(row[MemF.ORIGIN], "user")
        self.assertEqual(row[MemF.STATUS], "active")
        again = BrainStore(self.tmp, clock=self.clock)
        self.assertEqual(again.get_memory(res["id"]), row)

    def test_conformance_no_field_literals_outside_registry(self):
        pattern = re.compile(r"""["'](br(cat|mem)_[a-z_]+|BrainCategory|BrainMemory)["']""")
        offenders = []
        for path in LIB_AI.glob("lib_bejson_AI_brain_*.py"):
            if path.name.endswith("schema_registry.py"):
                continue
            text = re.sub(r'^""".*?"""', "", path.read_text(encoding="utf-8"), count=1, flags=re.S)
            for number, line in enumerate(text.splitlines(), 1):
                if line.lstrip().startswith("#"):
                    continue
                if pattern.search(line):
                    offenders.append(f"{path.name}:{number}: {line.strip()}")
        cli = HERE.parents[2] / "CLI" / "brain_cli" / "cli_brain_manager.py"
        if cli.is_file():
            for number, line in enumerate(cli.read_text(encoding="utf-8").splitlines(), 1):
                if pattern.search(line) and not line.lstrip().startswith("#"):
                    offenders.append(f"cli_brain_manager.py:{number}: {line.strip()}")
        self.assertEqual(offenders, [])

    def test_manifest_integrity(self):
        for i in range(5):
            self.add(f"Title {i}", "content")
        manifest = str(self.store.manifest)
        findings = mfdb_core_deep_verify(manifest)
        self.assertEqual([f for f in findings if "error" in f or f.get("warning") == "COUNT_MISMATCH"], [])
        doc = json.loads(self.store.manifest.read_text())
        names = [f["name"] for f in doc["Fields"]]
        for row in doc["Values"]:
            entry = dict(zip(names, row))
            self.assertEqual(entry["primary_key"], schema_registry_primary_key(entry["entity_name"]))
            rows = self.store._rows(entry["entity_name"])
            self.assertEqual(entry["record_count"], len(rows))
            keys = [r[entry["primary_key"]] for r in rows]
            self.assertEqual(len(keys), len(set(keys)))

    def test_post_reset_state(self):
        self.assertFalse(self.store.init())
        cats = self.store.categories()
        self.assertEqual(sorted(c[CatF.NAME] for c in cats), ["General", "Preferences", "Projects"])
        self.assertEqual(len({c[CatF.ID] for c in cats}), 3)
        self.assertEqual(self.store.memories(), [])
        self.assertEqual([s["reason"] for s in S.snapshots_list(self.store, "default")], ["baseline"])

    def test_not_initialised(self):
        empty = BrainStore(self.tmp / "other")
        self.assertEqual(self.errcode(empty.categories), E.E_BRAIN_NOT_INITIALIZED)

    def test_concurrency_eight_writers(self):
        limits = dict(self.store.limits, lock_timeout_seconds=120)
        errors = []

        def worker(n):
            try:
                st = BrainStore(self.tmp, limits=limits, clock=self.clock)
                for i in range(4):
                    st.apply({"op": "memory_add", "category": "General", "title": f"w{n}-{i}", "content": "x"})
            except BaseException as exc:  # noqa: BLE001
                errors.append(repr(exc))

        threads = [threading.Thread(target=worker, args=(n,)) for n in range(8)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(errors, [])
        self.assertEqual(len(self.store.memories()), 32)
        self.assertEqual([f for f in self.store.verify() if "error" in f], [])

    def test_limits_and_validation(self):
        self.assertEqual(self.errcode(lambda: self.add("x" * 81)), E.E_BRAIN_MEMORY_INVALID)
        self.assertEqual(self.errcode(lambda: self.add("ok", "y" * 2001)), E.E_BRAIN_MEMORY_INVALID)
        self.assertEqual(self.errcode(lambda: self.add("ok", "c", keywords=["abc"])), E.E_BRAIN_MEMORY_INVALID)
        self.assertEqual(self.errcode(lambda: self.add("ok", "c", keywords=[f"word{i}" for i in range(9)])), E.E_BRAIN_LIMIT_EXCEEDED)
        self.assertEqual(self.errcode(lambda: self.add("ok", "c", priority=101)), E.E_BRAIN_MEMORY_INVALID)
        self.add("dup", "c")
        self.assertEqual(self.errcode(lambda: self.add("DUP", "c")), E.E_BRAIN_MEMORY_INVALID)
        self.assertEqual(self.errcode(lambda: self.store.apply({"op": "category_create", "name": "general"})), E.E_BRAIN_CATEGORY_EXISTS)
        small = BrainStore(self.tmp, limits=dict(self.store.limits, max_memories=2), clock=self.clock)
        small.apply({"op": "memory_add", "category": "General", "title": "a1", "content": "c"})
        self.assertEqual(self.errcode(lambda: small.apply({"op": "memory_add", "category": "General", "title": "a2", "content": "c"})), E.E_BRAIN_LIMIT_EXCEEDED)
        general = next(c for c in self.store.categories() if c[CatF.NAME] == "General")
        self.assertEqual(self.errcode(lambda: self.store.apply({"op": "category_archive", "id": general[CatF.ID]})), E.E_BRAIN_CATEGORY_PROTECTED)
        self.assertEqual(self.errcode(lambda: self.add("x", "y", category="Nope")), E.E_BRAIN_MEMORY_INVALID if False else self.errcode(lambda: self.store.apply({"op": "memory_add", "category": "Nope", "title": "t", "content": "c"})))

    def test_batch_is_atomic(self):
        before = self.store.content_hash()
        ops = [{"op": "memory_add", "category": "General", "title": "ok1", "content": "c"},
               {"op": "memory_add", "category": "General", "title": "", "content": "c"}]
        self.assertEqual(self.errcode(lambda: self.store.apply_batch(ops)), E.E_BRAIN_MEMORY_INVALID)
        self.assertEqual(self.store.content_hash(), before)
        self.assertFalse(self.store.txn_dir.exists())
        self.assertEqual(self.store.memories(), [])

    def test_batch_within_batch_dependency(self):
        res = self.store.apply_batch([
            {"op": "category_create", "name": "Recipes", "description": "food"},
            {"op": "memory_add", "category": "Recipes", "title": "Soup", "content": "salt"},
        ])
        self.assertEqual(res[1]["status"], "active")

    def test_lock_outside_database_dir(self):
        self.assertNotIn(str(self.store.db_dir), str(self.store.lock_path))
        self.assertEqual(self.store.lock_path.parent, self.store.state_dir)


class TestAiWriter(BrainTestCase):
    def test_auto_low_priority_active_and_clamped(self):
        res = self.add("ai low", "c", actor="ai", priority=30, pinned=True)
        row = self.store.get_memory(res["id"])
        self.assertEqual(row[MemF.STATUS], "active")
        self.assertFalse(row[MemF.PINNED])
        self.assertEqual(row[MemF.ORIGIN], "ai")

    def test_high_priority_needs_review_and_is_capped(self):
        res = self.add("ai high", "c", actor="ai", priority=95)
        row = self.store.get_memory(res["id"])
        self.assertEqual(row[MemF.STATUS], "proposed")
        self.assertEqual(row[MemF.PRIORITY], 60)

    def test_review_policy_holds_everything(self):
        st = BrainStore(self.tmp, limits=dict(self.store.limits, write_policy="review"), clock=self.clock)
        res = st.apply({"op": "memory_add", "category": "General", "title": "r", "content": "c", "priority": 10}, "ai")
        self.assertEqual(res["status"], "proposed")

    def test_user_memory_changes_only_by_revision(self):
        mine = self.add("Mine", "original", priority=80)
        res = self.store.apply({"op": "memory_update", "id": mine["id"], "fields": {"content": "ai rewrite", "priority": 99}}, "ai")
        self.assertEqual(res["status"], "proposed")
        self.assertEqual(res["revision_of"], mine["id"])
        untouched = self.store.get_memory(mine["id"])
        self.assertEqual(untouched[MemF.CONTENT], "original")
        rev = self.store.get_memory(res["id"])
        self.assertEqual(rev[MemF.SUPERSEDES_FK], mine["id"])
        self.assertEqual(rev[MemF.PRIORITY], 60)
        # a second AI edit reuses the same pending revision
        again = self.store.apply({"op": "memory_update", "id": mine["id"], "fields": {"content": "second"}}, "ai")
        self.assertEqual(again["id"], res["id"])
        self.assertEqual(len([m for m in self.store.memories(status="proposed")]), 1)
        # approval applies it to the original and closes the revision
        self.store.apply({"op": "proposal_approve", "id": res["id"]})
        self.assertEqual(self.store.get_memory(mine["id"])[MemF.CONTENT], "second")
        self.assertEqual(self.store.get_memory(res["id"])[MemF.STATUS], "archived")

    def test_reject_revision(self):
        mine = self.add("Mine", "original")
        res = self.store.apply({"op": "memory_update", "id": mine["id"], "fields": {"content": "bad"}}, "ai")
        self.store.apply({"op": "proposal_reject", "id": res["id"]})
        self.assertEqual(self.store.get_memory(mine["id"])[MemF.CONTENT], "original")
        self.assertEqual(self.store.proposals()["memories"], [])

    def test_ai_cannot_archive_user_or_locked_or_pinned(self):
        mine = self.add("Mine", "c")
        self.assertEqual(self.errcode(lambda: self.store.apply({"op": "memory_archive", "id": mine["id"]}, "ai")), E.E_BRAIN_WRITE_FORBIDDEN)
        own = self.add("Own", "c", actor="ai")
        self.store.apply({"op": "memory_pin", "id": own["id"], "pinned": True})
        self.assertEqual(self.errcode(lambda: self.store.apply({"op": "memory_archive", "id": own["id"]}, "ai")), E.E_BRAIN_WRITE_FORBIDDEN)
        free = self.add("Free", "c", actor="ai")
        self.assertEqual(self.store.apply({"op": "memory_archive", "id": free["id"]}, "ai")["status"], "archived")

    def test_ai_forbidden_operations(self):
        mine = self.add("Mine", "c")
        for op in ({"op": "proposal_approve", "id": mine["id"]}, {"op": "memory_pin", "id": mine["id"]},
                   {"op": "category_archive", "id": "x"}, {"op": "proposal_reject", "id": "x"}):
            self.assertEqual(self.errcode(lambda op=op: self.store.apply(op, "ai")), E.E_BRAIN_WRITE_FORBIDDEN)

    def test_ai_category_is_proposed_and_memory_in_it_waits(self):
        res = self.store.apply_batch([
            {"op": "category_create", "name": "Garden", "description": "plants"},
            {"op": "memory_add", "category": "Garden", "title": "Tomato", "content": "water daily", "priority": 10},
        ], "ai")
        self.assertEqual([r["status"] for r in res], ["proposed", "proposed"])
        props = self.store.proposals()
        self.assertEqual(len(props["categories"]), 1)
        self.assertEqual(self.errcode(lambda: self.store.apply({"op": "proposal_approve", "id": res[1]["id"]})), E.E_BRAIN_MEMORY_INVALID)
        self.store.apply({"op": "proposal_approve", "id": res[0]["id"]})
        self.store.apply({"op": "proposal_approve", "id": res[1]["id"]})
        self.assertEqual(self.store.get_memory(res[1]["id"])[MemF.STATUS], "active")

    def test_batch_and_rate_limits(self):
        ops = [{"op": "memory_add", "category": "General", "title": f"b{i}", "content": "c"} for i in range(11)]
        self.assertEqual(self.errcode(lambda: self.store.apply_batch(ops, "ai")), E.E_BRAIN_LIMIT_EXCEEDED)
        st = BrainStore(self.tmp, limits=dict(self.store.limits, max_ai_writes_per_hour=3), clock=self.clock)
        for i in range(3):
            st.apply({"op": "memory_add", "category": "General", "title": f"r{i}", "content": "c"}, "ai")
        self.assertEqual(self.errcode(lambda: st.apply({"op": "memory_add", "category": "General", "title": "r9", "content": "c"}, "ai")), E.E_BRAIN_LIMIT_EXCEEDED)
        self.clock.advance(hours=2)
        st.apply({"op": "memory_add", "category": "General", "title": "r10", "content": "c"}, "ai")

    def test_no_hard_delete(self):
        a = self.add("A", "c")
        total = len(self.store._rows(ENTITY_MEMORY))
        self.store.apply({"op": "memory_archive", "id": a["id"]})
        self.assertEqual(len(self.store._rows(ENTITY_MEMORY)), total)
        self.assertEqual(self.store.get_memory(a["id"])[MemF.STATUS], "archived")

    def test_ai_duplicate_title_becomes_update(self):
        first = self.add("Same", "one", actor="ai")
        second = self.add("same", "two", actor="ai")
        self.assertEqual(first["id"], second["id"])
        self.assertEqual(self.store.get_memory(first["id"])[MemF.CONTENT], "two")


class TestSnapshots(BrainTestCase):
    def test_default_tier_keeps_baseline_plus_five(self):
        for i in range(12):
            self.clock.advance(seconds=5)
            self.add(f"m{i}", "c")
        default = S.snapshots_list(self.store, "default")
        self.assertEqual(len(default), 6)
        self.assertEqual(sum(1 for e in default if e["reason"] == "baseline"), 1)

    def test_daily_keeps_seven_distinct_and_skips_unchanged(self):
        for day in range(9):
            self.clock.advance(days=1)
            self.add(f"day{day}", "c")
        daily = S.snapshots_list(self.store, "daily")
        self.assertEqual(len(daily), 7)
        self.assertEqual(len({e["hash"] for e in daily}), 7)
        count = len(daily)
        self.clock.advance(days=1)
        S.snapshots_maintain(self.store)
        self.assertEqual(len(S.snapshots_list(self.store, "daily")), count)

    def test_monthly_keeps_one(self):
        for month in range(3):
            self.clock.advance(days=32)
            self.add(f"mo{month}", "c")
        self.assertEqual(len(S.snapshots_list(self.store, "monthly")), 1)

    def test_snapshot_has_no_lockdir_and_headers(self):
        junk = self.store.db_dir / "data" / "braincategory.bejson.lockdir"
        junk.mkdir()
        (junk / "lock_meta.json").write_text("{}")
        entry = S.snapshots_create(self.store, "default", "manual")
        doc = json.loads(Path(entry["path"]).read_text())
        self.assertIn("Brain_Snapshot_Reason", doc)
        self.assertEqual(doc["Brain_Content_Hash"], self.store.content_hash())
        self.assertNotIn("lockdir", Path(entry["path"]).read_text())
        self.assertTrue(entry["filename"].endswith("_brain_snapshot.bejson"))
        self.assertRegex(entry["filename"], r"^\d{8}T\d{6}Z_brain_snapshot\.bejson$")

    def test_rollback_round_trip_and_safety_snapshot(self):
        a = self.add("A", "state A")
        state_a = self.store.content_hash()
        snap = S.snapshots_create(self.store, "default", "state A")
        self.clock.advance(seconds=5)
        self.add("B", "state B")
        state_b = self.store.content_hash()
        generation = self.store.generation
        result = S.snapshots_rollback(self.store, f"default/{snap['filename']}")
        self.assertEqual(self.store.content_hash(), state_a)
        self.assertGreater(self.store.generation, generation)
        self.assertEqual([m[MemF.TITLE] for m in self.store.memories()], ["A"])
        self.assertEqual(self.store.get_memory(a["id"])[MemF.CONTENT], "state A")
        S.snapshots_rollback(self.store, result["safety_snapshot"])
        self.assertEqual(self.store.content_hash(), state_b)
        self.assertEqual([f for f in self.store.verify() if "error" in f], [])
        self.assertFalse(self.store.staging_dir.exists())

    def test_audit_survives_rollback(self):
        snap = S.snapshots_create(self.store, "default", "x")
        self.add("later", "c")
        S.snapshots_rollback(self.store, snap["filename"])
        import lib_bejson_AI_brain_audit as audit
        actions = [r["audit_action"] for r in audit.brain_audit_tail(self.store.state_dir, 100)]
        self.assertIn("write:memory_add", actions)
        self.assertIn("rollback", actions)

    def test_tampered_content_refused(self):
        self.add("A", "c")
        snap = S.snapshots_create(self.store, "default", "x")
        before = self.store.content_hash()
        path = Path(snap["path"])
        text = path.read_text()
        self.assertIn('"Brain_Content_Hash": "' + snap["hash"] + '"', text)
        path.write_text(text.replace(snap["hash"], "0" * 64))
        self.assertEqual(self.errcode(lambda: S.snapshots_rollback(self.store, snap["filename"])), E.E_BRAIN_ROLLBACK_VERIFY_FAILED)
        self.assertEqual(self.store.content_hash(), before)
        self.assertFalse(self.store.staging_dir.exists())

    def test_damaged_and_missing_and_traversal(self):
        snap = S.snapshots_create(self.store, "default", "x")
        Path(snap["path"]).write_text("{not json")
        self.assertEqual(self.errcode(lambda: S.snapshots_rollback(self.store, snap["filename"])), E.E_BRAIN_SNAPSHOT_INVALID)
        self.assertEqual(self.errcode(lambda: S.snapshots_rollback(self.store, "default/nope.bejson")), E.E_BRAIN_SNAPSHOT_NOT_FOUND)
        self.assertEqual(self.errcode(lambda: S.snapshots_rollback(self.store, "../../etc/passwd")), E.E_BRAIN_PATH_GUARD)
        self.assertEqual(self.errcode(lambda: S.snapshots_rollback(self.store, "default/../../x")), E.E_BRAIN_PATH_GUARD)


class TestCrashRecovery(BrainTestCase):
    def crash_at(self, point):
        def hook(name):
            if name == point:
                raise SimulatedCrash(name)
        self.store.crash_hook = hook

    def test_crash_mid_apply_is_undone(self):
        self.add("keep", "c")
        before = self.store.content_hash()
        self.crash_at("mid_apply")
        ops = [{"op": "memory_add", "category": "General", "title": "n1", "content": "c"},
               {"op": "memory_add", "category": "General", "title": "n2", "content": "c"}]
        with self.assertRaises(SimulatedCrash):
            self.store.apply_batch(ops)
        self.assertTrue(self.store.txn_dir.exists())
        reopened = BrainStore(self.tmp, clock=self.clock)
        self.assertEqual(reopened.content_hash(), before)
        self.assertFalse(reopened.txn_dir.exists())
        self.assertTrue(reopened.recovery_notices)
        self.assertEqual([f for f in reopened.verify() if "error" in f], [])

    def test_crash_after_txn_copy_leaves_database_untouched(self):
        before = self.store.content_hash()
        self.crash_at("after_txn_copy")
        with self.assertRaises(SimulatedCrash):
            self.add("never", "c")
        reopened = BrainStore(self.tmp, clock=self.clock)
        self.assertEqual(reopened.content_hash(), before)
        self.assertFalse(reopened.txn_dir.exists())

    def test_crash_between_renames_restores_previous_state(self):
        self.add("A", "c")
        snap = S.snapshots_create(self.store, "default", "A")
        self.clock.advance(seconds=5)
        self.add("B", "c")
        state_b = self.store.content_hash()
        self.crash_at("swap_between_renames")
        with self.assertRaises(SimulatedCrash):
            S.snapshots_rollback(self.store, snap["filename"])
        self.assertFalse(self.store.db_dir.exists())
        reopened = BrainStore(self.tmp, clock=self.clock)
        self.assertEqual(reopened.content_hash(), state_b)
        self.assertFalse(reopened.staging_dir.exists())
        self.assertEqual([f for f in reopened.verify() if "error" in f], [])

    def test_crash_after_renames_finishes_cleanup(self):
        self.add("A", "c")
        snap = S.snapshots_create(self.store, "default", "A")
        state_a = self.store.content_hash()
        self.clock.advance(seconds=5)
        self.add("B", "c")
        self.crash_at("swap_after_renames")
        with self.assertRaises(SimulatedCrash):
            S.snapshots_rollback(self.store, snap["filename"])
        reopened = BrainStore(self.tmp, clock=self.clock)
        self.assertEqual(reopened.content_hash(), state_a)
        self.assertFalse(reopened.db_dir.with_name("brain_mfdb.old").exists())

    def test_failed_verify_before_swap_changes_nothing(self):
        self.add("A", "c")
        snap = S.snapshots_create(self.store, "default", "A")
        self.clock.advance(seconds=5)
        self.add("B", "c")
        state_b = self.store.content_hash()
        self.crash_at("before_swap")
        with self.assertRaises(SimulatedCrash):
            S.snapshots_rollback(self.store, snap["filename"])
        reopened = BrainStore(self.tmp, clock=self.clock)
        self.assertEqual(reopened.content_hash(), state_b)

    def test_lock_released_after_crash(self):
        self.crash_at("mid_apply")
        with self.assertRaises(SimulatedCrash):
            self.add("x", "c")
        self.store.crash_hook = None
        self.add("after", "c")


if __name__ == "__main__":
    unittest.main(verbosity=2)
