"""
Name:           test_brain_routes.py
Description:    Flask test-client checks for the /api/brain/* routes (isolated temp BrainStore, no real app data touched).
Version:        1.0.0
Date Created:   2026-10-27
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  15b280be-0731-448e-aec7-d4776697da95
"""
import sys
import tempfile
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PROJECT_ROOT / "lib" / "AI"))
sys.path.insert(0, str(PROJECT_ROOT / "lib"))
sys.path.insert(0, str(PROJECT_ROOT / "client"))

from flask import Flask  # noqa: E402
from lib_bejson_AI_brain_store import BrainStore  # noqa: E402
from brain_routes import register_brain_routes  # noqa: E402


class BrainRoutesTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        store = BrainStore(str(Path(self.tmp.name) / "brain"), config_dir=str(PROJECT_ROOT / "lib" / "AI" / "config"))
        store.init()
        self.store = store
        app = Flask(__name__)
        register_brain_routes(app, store, None, None)
        self.c = app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def _add(self, **kw):
        body = {"category": "General", "title": "Coffee", "content": "User drinks espresso daily", "keywords": "coffee, espresso", "priority": 50}
        body.update(kw)
        return self.c.post("/api/brain/memories", json=body)

    def test_add_list_edit_pin_archive(self):
        r = self._add(); self.assertEqual(r.status_code, 200, r.get_json())
        rows = self.c.get("/api/brain/memories").get_json()["memories"]
        self.assertEqual(len(rows), 1); mid = rows[0]["id"]
        self.assertEqual(rows[0]["origin"], "user")
        self.assertEqual(self.c.put("/api/brain/memories/" + mid, json={"title": "Coffee", "content": "Now tea", "keywords": "green tea, coffee", "priority": 50, "category": "General", "pinned": False}).status_code, 200)
        self.assertTrue(self.c.get("/api/brain/memories").get_json()["memories"][0]["locked"])
        self.assertEqual(self.c.post("/api/brain/memories/%s/pin" % mid, json={"pinned": True}).status_code, 200)
        self.assertTrue(self.c.get("/api/brain/memories").get_json()["memories"][0]["pinned"])
        self.assertEqual(self.c.delete("/api/brain/memories/" + mid).status_code, 200)
        self.assertEqual(self.c.get("/api/brain/memories").get_json()["memories"], [])

    def test_invalid_input_is_400_with_code(self):
        r = self._add(keywords="hi")
        self.assertEqual(r.status_code, 400); self.assertEqual(r.get_json()["status"], "error"); self.assertIn("code", r.get_json())

    def test_recall_preview_and_status(self):
        self._add()
        hit = self.c.get("/api/brain/recall/preview?q=I%20love%20espresso").get_json()["recalled"]
        self.assertEqual(len(hit), 1)
        self.assertEqual(self.c.get("/api/brain/recall/preview?q=weather").get_json()["recalled"], [])
        st = self.c.get("/api/brain/status").get_json()
        self.assertEqual(st["memories_active"], 1)

    def test_settings_validate_and_apply(self):
        self.assertEqual(self.c.post("/api/brain/settings", json={"write_policy": "review", "memory_mode": "pass"}).status_code, 200)
        cfg = self.c.get("/api/brain/settings").get_json()
        self.assertEqual((cfg["write_policy"], cfg["memory_mode"]), ("review", "pass"))
        self.assertEqual(self.c.post("/api/brain/settings", json={"write_policy": "bogus"}).status_code, 400)

    def test_proposals_approve_and_snapshots(self):
        from lib_bejson_AI_brain_schema_registry import CatF  # noqa: F401
        out = self.store.apply({"op": "memory_add", "category": "General", "title": "AI note", "content": "likes tea", "keywords": ["tea time"], "priority": 80}, actor="ai")
        self.assertTrue(out)
        props = self.c.get("/api/brain/proposals").get_json()
        self.assertEqual(len(props["memories"]), 1)
        self.assertEqual(self.c.post("/api/brain/proposals/%s/approve" % props["memories"][0]["id"]).status_code, 200)
        self.assertEqual(self.c.get("/api/brain/proposals").get_json()["memories"], [])
        self.assertEqual(self.c.post("/api/brain/snapshots", json={"reason": "manual"}).status_code, 200)
        snaps = self.c.get("/api/brain/snapshots").get_json()["snapshots"]
        self.assertTrue(snaps)
        r = self.c.post("/api/brain/snapshots/rollback", json={"tier": snaps[-1]["tier"], "filename": snaps[-1]["filename"]})
        self.assertEqual(r.status_code, 200, r.get_json())


if __name__ == "__main__":
    unittest.main()
