/*
 * Name:          e2e_browser.js
 * Description:   Drives the real chat UI in Chromium (Playwright) against
 *                e2e_server.py: pick a profile, read its code, approve it,
 *                send a message, check the sandboxed rendering, and probe the
 *                sandbox (no parent access, no storage, no network). Covers an
 *                unapproved profile (plain reply + note) for both languages.
 * Version:       1.0.0
 * Date Created:  2026-10-18
 * Author:        Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
 * RELATIONAL_ID: 8e50c2b7-1f96-4a3d-b0e4-72a9d15c6f38
 * Usage:         node e2e_browser.js <base_url>   (needs the global playwright package)
 */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const base = process.argv[2] || 'http://127.0.0.1:5099';
const failures = [];
const check = (label, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + label); if (!ok) failures.push(label); };

async function openProfileGroup(page) { await page.evaluate(() => { document.getElementById('profileGroup').open = true; }); }
async function openService(page) { await page.click('.becss-tool-chip:has-text("Service")'); }
async function openChat(page) { await page.click('.becss-tool-chip:has-text("Chat")'); }
async function selectProfile(page, name) {
  await openService(page);
  await page.waitForFunction((n) => [...document.querySelectorAll('#profileSelect option')].some(o => o.value === n), name);
  await page.selectOption('#profileSelect', name);
  await page.waitForFunction((n) => document.getElementById('profileInfo').textContent.includes(n), name);
}
async function send(page, text) {
  await openChat(page);
  await page.fill('#chatInput', text);
  await page.click('#sendBtn');
}

(async () => {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', e => pageErrors.push(String(e)));
  let dialogs = 0;
  page.on('dialog', async d => { dialogs++; if (d.type() === 'confirm') await d.accept(); else await d.dismiss(); });
  await page.goto(base);

  // ---- 1. picker lists profiles, code-carrying ones flagged unapproved
  await openService(page);
  await page.waitForFunction(() => document.querySelectorAll('#profileSelect option').length >= 4);
  const labels = await page.$$eval('#profileSelect option', os => os.map(o => o.textContent));
  check('picker lists default + both examples', ['No profile', 'default', 'example_parser_python \u26A0', 'example_parser_javascript \u26A0'].every(l => labels.includes(l)));

  // ---- 2. unapproved python profile: plain reply + note, no iframe
  await selectProfile(page, 'example_parser_python');
  await send(page, 'list please');
  await page.waitForSelector('.becss-message--ai .becss-profile-note');
  const note = await page.textContent('.becss-message--ai .becss-profile-note');
  check('unapproved: note shown', /not approved/i.test(note));
  check('unapproved: no iframe', (await page.$$('.becss-profile-frame')).length === 0);

  // ---- 3. review panel + approve
  await page.click('#settingsBtn');
  await openProfileGroup(page);
  check('review: NOT APPROVED shown', /NOT APPROVED/.test(await page.textContent('#profileMeta')));
  check('review: parser code visible', (await page.textContent('#profileParserCode')).includes('def parse'));
  check('review: renderer code visible', (await page.textContent('#profileRendererCode')).includes('function render'));
  await page.click('#profileApproveBtn');
  await page.waitForFunction(() => /^APPROVED/.test(document.getElementById('profileMeta').textContent));
  check('approve: confirm dialog was shown', dialogs === 1);
  await page.click('#closeSettings');

  // ---- 4. approved python profile: sandboxed render of server-parsed value
  await page.evaluate(() => document.getElementById('chatHistory').innerHTML = '');
  await send(page, 'list please');
  await page.waitForSelector('.becss-message--ai iframe.becss-profile-frame');
  const handle = await page.$('.becss-message--ai iframe.becss-profile-frame');
  check('iframe sandbox attribute is exactly allow-scripts', (await handle.getAttribute('sandbox')) === 'allow-scripts');
  const frame = await handle.contentFrame();
  await frame.waitForSelector('li');
  const items = await frame.$$eval('li', ls => ls.map(l => l.textContent));
  check('python parser -> renderer shows 3 items', items.length === 3 && items[0] === 'Alpha \u2014 first' && items[1] === 'Beta');
  check('renderer used textContent: markup stays literal', items[2].includes('<b>Gamma</b>') && (await frame.$$('b')).length === 0 && (await frame.$$('img')).length === 0);
  check('no dialog from injected onerror', dialogs === 1);
  const h = await handle.evaluate(el => parseInt(el.style.height, 10));
  check('iframe height follows content', h >= 24 && h < 2000);

  // ---- 5. sandbox probes from INSIDE the iframe
  const probe = await frame.evaluate(async (origin) => {
    const out = {};
    try { out.parent = String(window.parent.document.title); } catch (e) { out.parent = 'blocked:' + e.name; }
    try { out.storage = String(window.localStorage.length); } catch (e) { out.storage = 'blocked:' + e.name; }
    try { document.cookie = 'x=1'; out.cookie = document.cookie || 'blocked:empty'; } catch (e) { out.cookie = 'blocked:' + e.name; }
    try { await fetch(origin + '/api/profiles'); out.fetch = 'allowed'; } catch (e) { out.fetch = 'blocked:' + e.name; }
    try { out.origin = String(window.origin); } catch (e) { out.origin = 'err'; }
    return out;
  }, base);
  check('sandbox: parent DOM blocked', probe.parent.startsWith('blocked:'));
  check('sandbox: localStorage blocked', probe.storage.startsWith('blocked:'));
  check('sandbox: cookies blocked', probe.cookie.startsWith('blocked:'));
  check('sandbox: network blocked by CSP/opaque origin', probe.fetch.startsWith('blocked:'));
  check('sandbox: opaque origin', probe.origin === 'null');

  // ---- 6. javascript profile end to end (parser also in the sandbox)
  await selectProfile(page, 'example_parser_javascript');
  await page.click('#settingsBtn');
  await openProfileGroup(page);
  await page.waitForFunction(() => document.getElementById('profileParserLang').textContent === 'javascript');
  await page.click('#profileApproveBtn');
  await page.waitForFunction(() => /^APPROVED/.test(document.getElementById('profileMeta').textContent));
  await page.click('#closeSettings');
  await page.evaluate(() => document.getElementById('chatHistory').innerHTML = '');
  await send(page, 'list please');
  await page.waitForSelector('.becss-message--ai iframe.becss-profile-frame');
  const f2 = await (await page.$('.becss-message--ai iframe.becss-profile-frame')).contentFrame();
  await f2.waitForSelector('li');
  const items2 = await f2.$$eval('li', ls => ls.map(l => l.textContent));
  check('javascript parser + renderer both in sandbox', items2.length === 3 && items2[0] === 'Alpha \u2014 first');

  // ---- 7. revoke
  await page.click('#settingsBtn');
  await openProfileGroup(page);
  await page.click('#profileRevokeBtn');
  await page.waitForFunction(() => /^NOT APPROVED/.test(document.getElementById('profileMeta').textContent));
  check('revoke returns to NOT APPROVED', true);
  await page.click('#closeSettings');
  await page.evaluate(() => document.getElementById('chatHistory').innerHTML = '');
  await send(page, 'list please');
  await page.waitForSelector('.becss-message--ai .becss-profile-note');
  check('after revoke: plain reply again', (await page.$$('.becss-profile-frame')).length === 0);

  // ---- 8. plain profile / no profile behave as before
  await selectProfile(page, 'default');
  await page.evaluate(() => document.getElementById('chatHistory').innerHTML = '');
  await send(page, 'hello');
  await page.waitForSelector('.becss-message--ai');
  await page.waitForTimeout(300);
  check('profile without code: no iframe, no note', (await page.$$('.becss-profile-frame, .becss-profile-note')).length === 0);

  check('no uncaught page errors', pageErrors.length === 0);
  if (pageErrors.length) console.log(pageErrors.join('\n'));
  await browser.close();
  console.log(failures.length ? '\nFAILED: ' + failures.length : '\nALL PASSED');
  process.exit(failures.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
