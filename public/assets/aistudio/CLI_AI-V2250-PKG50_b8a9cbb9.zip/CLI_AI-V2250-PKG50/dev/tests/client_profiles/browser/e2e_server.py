"""
Name:           e2e_server.py
Description:    Starts the real client Flask app on a scratch profiles directory
                and a scratch approvals file, with the provider call replaced by
                a fake that always replies with a small list. Used by
                e2e_browser.js (a real Chromium via Playwright). Optional test
                tooling - not part of the normal test run.
Version:        1.0.0
Date Created:   2026-10-18
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  d41f7a93-6c28-4e0b-8a55-91b3c7e2f064
Usage:          python3 e2e_server.py <port>
"""
import importlib
import os
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5099

sys.path.insert(0, str(ROOT / "client"))
os.chdir(ROOT / "client")
app_mod = importlib.import_module("app")

scratch = Path(tempfile.mkdtemp(prefix="e2e_profiles_"))
pdir = scratch / "profiles"
pdir.mkdir()
for name in ("default", "example_parser_python", "example_parser_javascript"):
    shutil.copy(ROOT / "profiles" / "profiles" / f"{name}.bejson", pdir / f"{name}.bejson")

from profile_support import ProfileStore  # noqa: E402
app_mod.PROFILE_STORE = ProfileStore(str(pdir), str(scratch / "data" / "approved.bejson"))
app_mod.ai_dispatch_call = lambda provider, text, model_id=None, **kw: {
    "success": True, "content": "- Alpha | first\n- Beta\n- <b>Gamma</b> | <img src=x onerror=alert(1)>"}

try:
    app_mod.app.run(host="127.0.0.1", port=PORT, threaded=True, use_reloader=False)
finally:
    shutil.rmtree(scratch, ignore_errors=True)
