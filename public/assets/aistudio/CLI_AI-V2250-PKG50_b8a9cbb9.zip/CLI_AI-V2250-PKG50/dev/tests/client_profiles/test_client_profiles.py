"""
Name:           test_client_profiles.py
Description:    Client profile support (client/profile_support.py + /api/profiles*
                routes + profile instruction in /api/chat): listing, review
                detail, fingerprint-pinned approval, sandbox/parse gating,
                tamper-after-approval, path safety, approvals file format and
                System_Instruction injection. Uses a scratch profiles dir and
                approvals file; a fake dispatch replaces the provider call.
Version:        1.0.0
Date Created:   2026-10-18
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  b3a96e21-4d07-4c85-9f12-6e8d0a7c51f3
Run:            python3 dev/tests/client_profiles/test_client_profiles.py
"""
import importlib
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
EXPECT = {"items": [{"title": "Alpha", "detail": "first"}, {"title": "Beta", "detail": ""}]}
SAMPLE = "- Alpha | first\n- Beta\nnoise"


class ClientProfileTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT / "client"))
        os.chdir(ROOT / "client")
        cls.app_mod = importlib.import_module("app")
        cls.tmp = Path(tempfile.mkdtemp(prefix="client_profiles_"))
        cls.pdir = cls.tmp / "profiles"
        cls.pdir.mkdir()
        for n in ("default", "example_parser_python", "example_parser_javascript"):
            shutil.copy(ROOT / "profiles" / "profiles" / f"{n}.bejson", cls.pdir / f"{n}.bejson")
        cls.approvals = cls.tmp / "data" / "approved.bejson"
        from profile_support import ProfileStore
        cls.store = ProfileStore(str(cls.pdir), str(cls.approvals))
        cls.app_mod.PROFILE_STORE = cls.store
        # Keep the context bubble's files in the scratch dir, not the package tree.
        cls.app_mod.CONTEXT_DIR = str(cls.tmp / "bubble_ctx")
        cls.app_mod.AI_CONFIG_DIR = str(cls.tmp / "bubble_cfg")
        cls.app_mod.ai_bubble_init(cls.app_mod.CONTEXT_DIR, cls.app_mod.AI_CONFIG_DIR)
        cls.client = cls.app_mod.app.test_client()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def detail(self, name):
        return self.client.get(f"/api/profiles/{name}").get_json()["profile"]

    def test_01_list_and_detail(self):
        r = self.client.get("/api/profiles").get_json()
        byname = {p["name"]: p for p in r["profiles"]}
        self.assertEqual(list(byname)[0], "default")
        self.assertFalse(byname["default"]["has_embedded"])
        self.assertTrue(byname["example_parser_python"]["has_embedded"])
        self.assertFalse(byname["example_parser_python"]["approved"])
        self.assertEqual(byname["example_parser_javascript"]["parser_language"], "javascript")
        d = self.detail("example_parser_python")
        self.assertIn("def parse", d["parser"])
        self.assertIn("function render", d["renderer"])
        self.assertEqual(len(d["fingerprint"]), 64)
        self.assertEqual(d["errors"], [])

    def test_02_unapproved_is_gated(self):
        self.assertEqual(self.client.get("/api/profiles/example_parser_python/sandbox").status_code, 403)
        r = self.client.post("/api/profiles/example_parser_python/parse", json={"raw_text": SAMPLE})
        self.assertEqual(r.status_code, 422)
        self.assertIn("not approved", r.get_json()["response"])

    def test_03_approve_requires_the_reviewed_fingerprint(self):
        r = self.client.post("/api/profiles/example_parser_python/approve", json={"fingerprint": "0" * 64})
        self.assertEqual(r.status_code, 409)
        self.assertEqual(self.client.post("/api/profiles/example_parser_python/approve", json={}).status_code, 400)
        self.assertEqual(self.client.post("/api/profiles/default/approve",
                                          json={"fingerprint": "x"}).status_code, 409)
        self.assertFalse(self.approvals.exists())

    def test_04_approve_then_run(self):
        fp = self.detail("example_parser_python")["fingerprint"]
        r = self.client.post("/api/profiles/example_parser_python/approve", json={"fingerprint": fp})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(self.detail("example_parser_python")["approved"])
        sb = self.client.get("/api/profiles/example_parser_python/sandbox").get_json()
        self.assertEqual(sb["iframe_attributes"], 'sandbox="allow-scripts"')
        self.assertIn("default-src 'none'", sb["srcdoc"])
        self.assertEqual(sb["parser_language"], "python")
        out = self.client.post("/api/profiles/example_parser_python/parse", json={"raw_text": SAMPLE}).get_json()
        self.assertEqual(out["result"], EXPECT)
        # approving twice does not duplicate the row
        self.client.post("/api/profiles/example_parser_python/approve", json={"fingerprint": fp})
        doc = json.loads(self.approvals.read_text())
        self.assertEqual(len(doc["Values"]), 1)

    def test_05_approvals_file_is_valid_bejson(self):
        import lib_bejson_Core_bejson_validator as V
        V.bejson_validator_validate_string(self.approvals.read_text())
        doc = json.loads(self.approvals.read_text())
        self.assertEqual(doc["Records_Type"], ["ApprovedProfileCode"])
        self.assertEqual([f["name"] for f in doc["Fields"]],
                         ["fingerprint", "profile_name", "parser_language", "approved_at"])

    def test_06_javascript_profile(self):
        d = self.detail("example_parser_javascript")
        self.client.post("/api/profiles/example_parser_javascript/approve", json={"fingerprint": d["fingerprint"]})
        sb = self.client.get("/api/profiles/example_parser_javascript/sandbox").get_json()
        self.assertEqual(sb["parser_language"], "javascript")
        self.assertIn("function parse", sb["srcdoc"])
        # JS parsers run in the browser, not through the Python parse route
        r = self.client.post("/api/profiles/example_parser_javascript/parse", json={"raw_text": SAMPLE})
        self.assertEqual(r.status_code, 400)

    def test_07_tamper_after_approval_revokes_trust(self):
        path = self.pdir / "example_parser_python.bejson"
        doc = json.loads(path.read_text())
        i = [f["name"] for f in doc["Fields"]].index("Renderer")
        doc["Values"][0][i] += "\n// edited after approval\n"
        path.write_text(json.dumps(doc))
        self.assertFalse(self.detail("example_parser_python")["approved"])
        self.assertEqual(self.client.get("/api/profiles/example_parser_python/sandbox").status_code, 403)
        # the old fingerprint can no longer be approved against the edited file
        self.assertEqual(self.client.post("/api/profiles/example_parser_python/approve",
                                          json={"fingerprint": json.loads(self.approvals.read_text())["Values"][0][0]}).status_code, 409)

    def test_08_malicious_edit_is_invalid_not_runnable(self):
        path = self.pdir / "example_parser_python.bejson"
        doc = json.loads(path.read_text())
        i = [f["name"] for f in doc["Fields"]].index("Parser")
        doc["Values"][0][i] = "import os\n\ndef parse(raw_text):\n    return os.listdir('.')\n"
        path.write_text(json.dumps(doc))
        self.assertEqual(self.client.get("/api/profiles/example_parser_python").status_code, 404)
        byname = {p["name"]: p for p in self.client.get("/api/profiles").get_json()["profiles"]}
        self.assertFalse(byname["example_parser_python"]["valid"])
        self.assertEqual(self.client.get("/api/profiles/example_parser_python/sandbox").status_code, 403)

    def test_09_revoke(self):
        d = self.detail("example_parser_javascript")
        self.assertTrue(d["approved"])
        self.assertEqual(self.client.post("/api/profiles/example_parser_javascript/revoke", json={}).status_code, 200)
        self.assertFalse(self.detail("example_parser_javascript")["approved"])
        self.assertEqual(self.client.get("/api/profiles/example_parser_javascript/sandbox").status_code, 403)

    def test_10_path_safety(self):
        outside = self.tmp / "secret.bejson"
        shutil.copy(self.pdir / "default.bejson", outside)
        for bad in ("..%2Fsecret", "..", "a%2Fb", "%2E%2E%2Fsecret"):
            self.assertIn(self.client.get(f"/api/profiles/{bad}").status_code, (404, 308, 400))
        self.assertIsNone(self.store.load("../secret"))
        self.assertIsNone(self.store.load("default.bejson"))
        self.assertIsNone(self.store.load("x" * 65))

    def test_11_profile_instruction_in_chat(self):
        seen = []

        def fake_dispatch(provider, text, model_id=None, **kw):
            seen.append(text)
            return {"success": True, "content": "ok"}
        original = self.app_mod.ai_dispatch_call
        self.app_mod.ai_dispatch_call = fake_dispatch
        try:
            instr = self.store.system_instruction("example_parser_javascript")
            body = {"message": "hello", "service": "Groq", "model": "m"}
            self.assertEqual(self.client.post("/api/chat", json=dict(body, profile="example_parser_javascript")).get_json()["status"], "success")
            # v2.18.0: the profile instruction travels in the context bubble's
            # "Profile" allotment, ahead of the user's message.
            self.assertTrue(seen[-1].startswith("[CONTEXT BUBBLE]"))
            self.assertIn("## Profile", seen[-1])
            self.assertIn(instr, seen[-1])
            self.assertLess(seen[-1].index(instr), seen[-1].rindex("hello"))
            self.assertTrue(seen[-1].rstrip().endswith("hello"))
            self.client.post("/api/chat", json=body)
            self.assertNotIn("## Profile", seen[-1])
            n = len(seen)
            r = self.client.post("/api/chat", json=dict(body, profile="no_such_profile")).get_json()
            self.assertEqual(r["status"], "error")
            self.assertEqual(len(seen), n, "provider must not be called for an unknown profile")
            r = self.client.post("/api/chat/stream", json={"message": "x", "service": "OllamaLocal", "profile": "nope"})
            self.assertEqual(r.status_code, 400)
        finally:
            self.app_mod.ai_dispatch_call = original


if __name__ == "__main__":
    unittest.main(verbosity=1)
