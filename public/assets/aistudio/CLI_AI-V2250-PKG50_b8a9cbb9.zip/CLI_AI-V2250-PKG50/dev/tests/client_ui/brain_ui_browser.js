/*
 * Name:          brain_ui_browser.js
 * Description:   Drives the Brain tab in Chromium against the real Flask routes: add, search, edit, pin,
 *                proposals (approve), snapshot + settings, and the Recalled badge row. No AI provider needed.
 * Version:       1.0.0
 * Date Created:  2026-10-27
 * Author:        Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
 * RELATIONAL_ID: d02edcba-2a3a-40d4-bf56-da9b52e2a425
 * Usage:         node brain_ui_browser.js <base_url>   (server must be running; run it on a COPY of the project, it writes data/brain)
 */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const base = process.argv[2] || 'http://127.0.0.1:5124';
const failures = [];
const check = (label, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + label); if (!ok) failures.push(label); };

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await (await browser.newContext()).newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('dialog', d => d.accept());
  await page.goto(base + '/');
  await page.click('.becss-tool-chip:has-text("Brain")');
  await page.waitForSelector('#tab-Brain', { state: 'visible', timeout: 5000 }).catch(() => {});
  check('Brain tab visible', await page.isVisible('#tab-Brain'));
  check('BrainUI defined', await page.evaluate(() => !!(window.BrainUI && window.BrainUI.renderRecalled)));

  await page.click('#brainAddBtn');
  await page.selectOption('#brainEdCategory', 'General');
  await page.fill('#brainEdTitle', 'Coffee habit');
  await page.fill('#brainEdContent', 'User drinks espresso <b>daily</b>');
  await page.fill('#brainEdKeywords', 'espresso, coffee');
  await page.click('#brainEdSave');
  await page.waitForSelector('#brainMemList .becss-brain-card');
  check('memory listed', (await page.textContent('#brainMemList')).includes('Coffee habit'));
  check('content rendered as text (no HTML injection)', await page.evaluate(() => !document.querySelector('#brainMemList b')));

  await page.fill('#brainSearch', 'zzzzzz'); await page.waitForTimeout(500);
  check('search filters to empty', (await page.textContent('#brainMemList')).includes('No memories'));
  await page.fill('#brainSearch', 'espresso'); await page.waitForTimeout(500);
  check('search finds it', (await page.textContent('#brainMemList')).includes('Coffee habit'));

  await page.click('#brainMemList .becss-logs__btn:has-text("Pin")'); await page.waitForTimeout(400);
  check('pinned star', (await page.textContent('#brainMemList')).includes('★'));

  await page.click('.becss-braintab-chip[data-braintab="snapshots"]');
  await page.click('#brainSnapNow'); await page.waitForTimeout(600);
  check('snapshot listed', (await page.locator('#brainSnapList .becss-logs__row').count()) >= 1);

  await page.click('.becss-braintab-chip[data-braintab="settings"]');
  await page.waitForTimeout(500);
  check('status box filled', (await page.textContent('#brainStatusBox')).includes('memories'));
  await page.selectOption('#brainPolicySelect', 'review'); await page.click('#brainSettingsSave'); await page.waitForTimeout(400);
  check('settings saved', (await page.textContent('#brainSettingsStatus')).includes('Saved'));

  await page.evaluate(() => { const d = document.createElement('div'); d.id = 'fakeMsg'; document.body.appendChild(d); window.BrainUI.renderRecalled(d, [{ title: 'Coffee habit', category: 'General', matched: ['espresso'] }]); });
  check('Recalled badge rendered', await page.locator('#fakeMsg .becss-recalled__badge').count() === 1);

  check('no page errors', errors.length === 0);
  if (errors.length) console.log(errors.join('\n'));
  await browser.close();
  if (failures.length) { console.log('\n' + failures.length + ' FAILED'); process.exit(1); }
  console.log('\nAll Brain UI checks passed');
})();
