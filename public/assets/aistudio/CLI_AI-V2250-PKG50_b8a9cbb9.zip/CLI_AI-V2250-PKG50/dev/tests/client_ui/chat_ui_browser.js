/*
 * Name:          chat_ui_browser.js
 * Description:   Drives the chat client (client/) in Chromium: chat strip, model name on
 *                replies, message select/copy, context-aware Resend, Stop/Start server,
 *                Clear/Reset, and the message-box context menu. /api/chat and the local
 *                server endpoints are mocked, so no AI provider is needed.
 * Version:       1.0.0
 * Date Created:  2026-10-20
 * Author:        Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
 * RELATIONAL_ID: 8c41d7e6-5b02-4f93-a1d8-3e7c9b60f245
 * Usage:         node chat_ui_browser.js <base_url>   (needs the global playwright package)
 */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const base = process.argv[2] || 'http://127.0.0.1:5123';
const failures = [];
const check = (label, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + label); if (!ok) failures.push(label); };

(async () => {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({ permissions: ['clipboard-read', 'clipboard-write'] });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('dialog', d => d.accept());

  let chatPosts = [], deletes = [], serverReady = false, setups = 0, stops = 0;
  await page.route('**/api/chat', async r => {
    chatPosts.push(JSON.parse(r.request().postData()));
    await r.fulfill({ json: { status: 'success', response: 'Hello **there**' } });
  });
  await page.route('**/api/logs/*', async r => {
    if (r.request().method() === 'DELETE') { deletes.push(r.request().url()); return r.fulfill({ json: { deleted: true } }); }
    return r.fulfill({ json: { messages: [] } });
  });
  await page.route('**/api/litertlm/status', r => r.fulfill({ json: { available: true, ready: serverReady, state: { phase: serverReady ? 'ready' : 'stopped' } } }));
  await page.route('**/api/litertlm/setup', r => { setups++; serverReady = true; r.fulfill({ json: { ok: true } }); });
  await page.route('**/api/litertlm/stop', r => { stops++; serverReady = false; r.fulfill({ json: { ok: true } }); });

  await page.goto(base);
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.waitForSelector('#chatBar');
  const btns = () => page.$$eval('#chatBarActions button', b => b.map(x => x.textContent.trim()));
  const chip = name => page.click(`.becss-tool-chip:text-is("${name}")`);
  const setService = async v => { await chip('Service'); await page.selectOption('#serviceSelect', v); await chip('Chat'); };
  const who = () => page.textContent('#chatWho');

  // empty chat: hint + strip
  check('empty-state hint is shown', await page.evaluate(() => document.getElementById('chatHistory').children.length === 0));
  check('strip names the service', /Chatting with/.test(await who()));
  check('empty chat: Clear disabled, Reset available',
    await page.$eval('#chatBarActions button:nth-child(1)', b => b.textContent === 'Clear' && b.disabled));

  // pick a non-local service and send
  await setService('GeminiREST');
  await page.waitForFunction(() => document.querySelectorAll('#modelSelect option').length >= 1);
  const model = await page.inputValue('#modelSelect');
  check('strip shows the model', model ? (await who()).includes(model) : true);
  check('non-local service: no server button', !(await btns()).some(t => /server/i.test(t)));

  await page.fill('#chatInput', 'hi there');
  await page.click('#sendBtn');
  await page.waitForSelector('.becss-message--ai');
  check('chat request sent', chatPosts.length === 1 && chatPosts[0].message === 'hi there');
  check('AI reply shows model name', model ? await page.$eval('.becss-message--ai .becss-message__model', e => e.textContent) === model : true);
  check('user message has no model label', (await page.$('.becss-message--user .becss-message__model')) === null);

  // selection: user message -> Resend offered; AI message -> not offered
  await page.click('.becss-message--user .becss-message__text');
  let b = await btns();
  check('user message selected: Copy + Resend offered', b.includes('Copy') && b.includes('Resend'));
  await page.click('.becss-message--ai .becss-message__text');
  b = await btns();
  check('AI message selected: Copy but NO Resend', b.includes('Copy') && !b.includes('Resend'));
  await page.click('#chatBarActions >> text=Copy');
  check('Copy writes the message text', (await page.evaluate(() => navigator.clipboard.readText())) === 'Hello **there**');
  await page.keyboard.press('Escape');
  check('Escape clears the selection', (await page.$('.becss-message--selected')) === null && (await btns()).includes('Reset'));

  // resend keeps the draft
  await page.fill('#chatInput', 'draft in progress');
  await page.click('.becss-message--user .becss-message__text');
  await page.click('#chatBarActions >> text=Resend');
  await page.waitForFunction(() => document.querySelectorAll('.becss-message--user').length === 2);
  check('Resend re-sent the same text', chatPosts.length === 2 && chatPosts[1].message === 'hi there');
  check('Resend kept the typed draft', (await page.inputValue('#chatInput')) === 'draft in progress');
  await page.fill('#chatInput', '');

  // message-box context menu
  await page.fill('#chatInput', 'hello menu');
  await page.click('#chatInput', { button: 'right' });
  await page.waitForSelector('#inputMenu:not([hidden])');
  const items = await page.$$eval('#inputMenu li.becss-ctxmenu__item', l => l.map(x => x.textContent));
  check('menu has Paste/Cut/Copy/Select all/Clear/Send', ['Paste', 'Cut', 'Copy', 'Select all', 'Clear', 'Send'].every(i => items.includes(i)));
  check('Cut/Copy disabled with no selection', await page.$$eval('#inputMenu .becss-ctxmenu__item--disabled', l => l.map(x => x.textContent).join()).then(t => /Cut/.test(t) && /Copy/.test(t)));
  await page.evaluate(() => navigator.clipboard.writeText(' PASTED'));
  await page.click('#inputMenu >> text=Paste');
  await page.waitForFunction(() => document.getElementById('chatInput').value.includes('PASTED'), null, { timeout: 3000 }).catch(() => {});
  check('Paste inserts clipboard text', (await page.inputValue('#chatInput')).includes('PASTED'));
  await page.click('#chatInput', { button: 'right' });
  await page.click('#inputMenu >> text=Send');
  await page.waitForFunction(() => document.querySelectorAll('.becss-message--user').length === 3);
  check('menu Send sends the message', chatPosts.length === 3 && chatPosts[2].message.includes('hello menu'));
  await page.fill('#chatInput', 'x');
  await page.click('#chatInput', { button: 'right' });
  await page.click('#inputMenu >> text=Clear');
  check('menu Clear empties the input', (await page.inputValue('#chatInput')) === '');
  await page.click('#chatInput', { button: 'right' });
  check('Send disabled when empty', await page.$eval('#inputMenu', m => [...m.querySelectorAll('.becss-ctxmenu__item--disabled')].some(x => x.textContent === 'Send')));
  await page.keyboard.press('Escape');
  check('Escape closes the menu', await page.$eval('#inputMenu', m => m.hidden));

  // context-aware local server control
  await setService('LiteRTLM');
  await page.waitForFunction(() => [...document.querySelectorAll('#chatBarActions button')].some(b => b.textContent === 'Start server'));
  b = await btns();
  check('local server stopped: only Start offered', b.includes('Start server') && !b.includes('Stop server'));
  await page.click('#chatBarActions >> text=Start server');
  await page.waitForFunction(() => [...document.querySelectorAll('#chatBarActions button')].some(b => b.textContent === 'Stop server'));
  b = await btns();
  check('local server running: only Stop offered', b.includes('Stop server') && !b.includes('Start server') && setups === 1);
  await page.click('#chatBarActions >> text=Stop server');
  await page.waitForFunction(() => [...document.querySelectorAll('#chatBarActions button')].some(b => b.textContent === 'Start server'));
  check('Stop calls the stop endpoint', stops === 1);
  await setService('GeminiREST');
  await page.waitForFunction(() => ![...document.querySelectorAll('#chatBarActions button')].some(b => /server/.test(b.textContent)));
  check('switching back to a remote service hides the server button', true);

  // clear / reset
  const sidBefore = await page.evaluate(() => localStorage.getItem('cliai_session'));
  await page.click('#chatBarActions >> text=Clear');
  await page.waitForFunction(() => document.querySelectorAll('.becss-message').length === 0);
  check('Clear deletes this session log and empties the chat', deletes.length === 1 && deletes[0].includes(sidBefore));
  check('Clear keeps the same session id', (await page.evaluate(() => localStorage.getItem('cliai_session'))) === sidBefore);
  await page.fill('#chatInput', 'again');
  await page.click('#sendBtn');
  await page.waitForSelector('.becss-message--ai');
  await page.click('#chatBarActions >> text=Reset');
  await page.waitForFunction(() => document.querySelectorAll('.becss-message').length === 0);
  check('Reset starts a new session id', (await page.evaluate(() => localStorage.getItem('cliai_session'))) !== sidBefore);

  // fold by header + code cards (v2.20.0)
  await page.route('**/api/chat', async r => {
    await r.fulfill({ json: { status: 'success', response: 'Run this:\n\n```python\nprint("a < b")\n```\n\nthen:\n\n```bash\nls -la\n```\n\n```\nplain\n```' } });
  });
  await page.fill('#chatInput', 'code please');
  await page.click('#sendBtn');
  await page.waitForSelector('.becss-message--ai .becss-code');
  const langs = await page.$$eval('.becss-message--ai .becss-code__lang', l => l.map(x => x.textContent));
  check('code fences become cards with language labels', langs.join() === 'python,bash,code');
  check('code card keeps code text unescaped-correctly', (await page.$eval('.becss-code code', c => c.textContent)) === 'print("a < b")');
  await page.click('.becss-message--ai .becss-code__copy');
  check('code card Copy copies only that block', (await page.evaluate(() => navigator.clipboard.readText())) === 'print("a < b")');
  check('code Copy does not select the message', (await page.$('.becss-message--selected')) === null);
  const aiMsg = page.locator('.becss-message--ai').last();
  await aiMsg.locator('.becss-message__header').click();
  check('header tap folds the message (body hidden, sender visible)',
    !(await aiMsg.locator('.becss-message__text').isVisible()) && await aiMsg.locator('.becss-message__sender').isVisible());
  check('folding does not select the message', (await page.$('.becss-message--selected')) === null);
  await aiMsg.locator('.becss-message__header').click();
  check('second header tap unfolds it', await aiMsg.locator('.becss-message__text').isVisible());
  await page.click('.becss-message--user >> nth=0');
  await page.locator('.becss-message--user').first().locator('.becss-message__header').click();
  check('folding a selected message drops its selection', (await page.$('.becss-message--selected')) === null);

  check('no page errors', errors.length === 0);
  if (errors.length) console.log(errors.join('\n'));
  await page.screenshot({ path: process.env.SHOT || '/tmp/claude-0/chat_ui.png' });
  await browser.close();
  console.log(failures.length ? ('\n' + failures.length + ' FAILED') : '\nALL PASSED');
  process.exit(failures.length ? 1 : 0);
})();
