/*
 * Name:          bubble_browser.js
 * Description:   Drives the Bubble sub-tab in real Chromium (Playwright) against
 *                bubble_server.py: the preview lists every allotment with budget,
 *                use and turns-until-rebuild; after a chat exchange the preview
 *                shows that history; preview refreshes do not advance the rebuild
 *                counter; the preview text carries no markup execution.
 * Version:       1.1.0
 * Date Created:  2026-10-20
 * Author:        Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
 * RELATIONAL_ID: e7e852e5-164e-4789-8697-204da57f80b8
 * Usage:         node bubble_browser.js <base_url>   (PLAYWRIGHT_MODULE=<path to playwright>)
 */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const base = process.argv[2] || 'http://127.0.0.1:5098';
const failures = [];
const check = (label, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + label); if (!ok) failures.push(label); };

async function openBubble(page) {
  await page.click('.becss-tool-chip:has-text("Attach")');
  await page.click('.becss-subtab-chip[data-subtab="bubble"]');
  await page.waitForFunction(() => {
    const t = document.getElementById('bubbleStats').textContent;
    return t && t !== 'Loading...' && t !== 'No preview loaded yet.';
  });
}
async function refresh(page) {
  await page.evaluate(() => { document.getElementById('bubbleStats').textContent = 'Loading...'; });
  await page.click('#refreshBubbleBtn');
  await page.waitForFunction(() => document.getElementById('bubbleStats').textContent !== 'Loading...');
}

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await (await browser.newContext()).newPage();
  const pageErrors = [];
  page.on('pageerror', e => pageErrors.push(String(e)));
  await page.goto(base);

  await openBubble(page);
  let stats = await page.textContent('#bubbleStats');
  check('stats header shows token budget and rebuild cadence', /\/ 8000 tokens/.test(stats) && /rebuild in \d+ turn\(s\) \(every 5\)/.test(stats));
  const rows = await page.textContent('#bubbleRows');
  for (const label of ['Persistent Policy', 'Profile', 'Attachments', 'Context', 'Chat History'])
    check('allotment row: ' + label, rows.includes(label));
  check('ranks shown 1..5', ['#1 ', '#2 ', '#3 ', '#4 ', '#5 '].every(r => rows.includes(r)));
  check('empty allotments flagged', /Attachments[\s\S]*?empty/.test(rows));
  const shareOf = async n => (await page.textContent(`.becss-bubble-row[data-name="${n}"] .becss-bubble-row__share`)).trim();
  check('equal shares at 20% when all enabled', (await shareOf('profile')) === '20%' && (await shareOf('context')) === '20%');
  check('bar has one segment per active allotment', (await page.locator('.becss-bubble-bar__seg').count()) === 5);

  // switch a feature off -> others grow; back on -> they shrink
  await page.uncheck('.becss-bubble-row[data-name="profile"] .becss-bubble-row__enable');
  await page.waitForFunction(() => document.querySelector('.becss-bubble-row[data-name="profile"] .becss-bubble-row__share').textContent.trim() === 'off');
  check('disabled allotment shows off', (await shareOf('profile')) === 'off');
  check('remaining allotments grow to 25%', (await shareOf('context')) === '25%' && (await shareOf('chat_history')) === '25%');
  check('bar segments drop to 4', (await page.locator('.becss-bubble-bar__seg').count()) === 4);
  await page.check('.becss-bubble-row[data-name="profile"] .becss-bubble-row__enable');
  await page.waitForFunction(() => document.querySelector('.becss-bubble-row[data-name="context"] .becss-bubble-row__share').textContent.trim() === '20%');
  check('re-enabled -> shares shrink back to 20%', (await shareOf('profile')) === '20%');

  // per-allotment text view
  await page.click('.becss-bubble-row[data-name="persistent_policy"] .becss-bubble-row__view');
  check('view text shows only that allotment', (await page.textContent('#bubbleViewLabel')).includes('Persistent Policy only'));
  check('single view carries the policy', (await page.textContent('#bubbleText')).includes('E2E POLICY'));
  await page.click('.becss-bubble-row[data-name="persistent_policy"] .becss-bubble-row__view');
  check('show all restores full bubble', (await page.textContent('#bubbleViewLabel')).includes('full assembled bubble'));

  // invalid weight is rejected client-side, nothing breaks
  await page.fill('.becss-bubble-row[data-name="context"] .becss-bubble-row__weight', '500');
  await page.dispatchEvent('.becss-bubble-row[data-name="context"] .becss-bubble-row__weight', 'change');
  check('out-of-range weight shows message', (await page.textContent('#bubbleMsg')).includes('0 to 100'));

  check('preview text carries the policy', (await page.textContent('#bubbleText')).includes('E2E POLICY'));

  // chat, then the preview must show the exchange in Chat History
  await page.click('.becss-tool-chip:has-text("Chat")');
  await page.fill('#chatInput', 'remember the word ZEPHYR');
  await page.click('#sendBtn');
  await page.waitForSelector('.becss-message--ai');
  await openBubble(page);
  await refresh(page);
  const text = await page.textContent('#bubbleText');
  check('history allotment shows the user message', text.includes('[user]: remember the word ZEPHYR'));
  check('history allotment shows the assistant reply', text.includes('[assistant]: echo: remember the word ZEPHYR'));

  // previews must not advance the rebuild counter
  const readLeft = async () => Number((await page.textContent('#bubbleStats')).match(/rebuild in (\d+)/)[1]);
  const before = await readLeft();
  await refresh(page); await refresh(page); await refresh(page);
  check('preview refreshes do not consume turns', (await readLeft()) === before);

  check('no uncaught page errors', pageErrors.length === 0);
  if (pageErrors.length) console.log(pageErrors.join('\n'));
  await browser.close();
  if (failures.length) { console.log('\n' + failures.length + ' FAILED'); process.exit(1); }
  console.log('\nALL PASSED');
})();
