"""
Name:           bubble_server.py
Description:    Starts the real client Flask app with the context bubble pointed at
                scratch directories and a fake provider call (replies "echo: <tail>").
                Used by bubble_browser.js (real Chromium via Playwright). Optional
                test tooling - not part of the normal test run.
Version:        1.0.0
Date Created:   2026-10-20
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  6fa20c85-d193-47e8-b7c4-3a58e9d01b72
Usage:          python3 bubble_server.py <port>
"""
import importlib
import os
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5098

sys.path.insert(0, str(ROOT / "client"))
os.chdir(ROOT / "client")
app_mod = importlib.import_module("app")

scratch = Path(tempfile.mkdtemp(prefix="e2e_bubble_"))
(scratch / "home").mkdir()
os.environ["HOME"] = str(scratch / "home")   # keep a real ~/.gemini out of the e2e run
app_mod.CONTEXT_DIR = str(scratch / "ctx")
app_mod.AI_CONFIG_DIR = str(scratch / "cfg")
app_mod.ATTACH_DIR = str(scratch / "attach")
from chat_logs import ChatLogStore  # noqa: E402
app_mod.CHAT_LOGS = ChatLogStore(str(scratch / "logs"))

import lib_bejson_AI_ai_context_bubble as B  # noqa: E402
from lib_bejson_AI_ai_bubble_allotments import register_builtin_allotments  # noqa: E402
B.ai_bubble_clear_allotments()
register_builtin_allotments(app_mod.ai_context_files_list, app_mod.ATTACH_DIR,
                            os.path.join(app_mod.ATTACH_DIR, "imports"),
                            app_mod.context_chunker.chunker_build_section)
app_mod.ai_bubble_init(app_mod.CONTEXT_DIR, app_mod.AI_CONFIG_DIR, policy_text="E2E POLICY")
app_mod.ai_dispatch_call = lambda provider, text, model_id=None, **kw: {
    "success": True, "content": "echo: " + text.rsplit("---", 1)[-1].strip()}

try:
    app_mod.app.run(host="127.0.0.1", port=PORT, threaded=True, use_reloader=False)
finally:
    shutil.rmtree(scratch, ignore_errors=True)
