"""
Test:           test_client_bubble_routes.py
Path:           dev/tests/context_bubble/test_client_bubble_routes.py
Description:    Context Bubble v2 through the real Flask routes: chat history,
                attachments (discussable directive, change -> rebuild), profile
                allotment, preview isolation, stream-route history skip.
                A fake dispatch replaces the provider; all bubble state lives
                in a scratch directory.
Version:        1.1.0
Date:           2026-11-01
Author:         Elton Boehnen
RELATIONAL_ID:  5d53d5be-6610-468f-973b-802c34815ecd
Run:            python3 dev/tests/context_bubble/test_client_bubble_routes.py
"""
import importlib
import json
import os
import shutil
import sys
import tempfile
import unittest
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]


class BubbleRouteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT / "client"))
        os.chdir(ROOT / "client")
        cls.app = importlib.import_module("app")
        cls.tmp = Path(tempfile.mkdtemp(prefix="bubble_routes_"))
        (cls.tmp / "home").mkdir()
        cls.old_home = os.environ.get("HOME")
        os.environ["HOME"] = str(cls.tmp / "home")   # keep a real ~/.gemini out of the tests
        cls.app.CONTEXT_DIR = str(cls.tmp / "ctx")
        cls.app.AI_CONFIG_DIR = str(cls.tmp / "cfg")
        cls.app.ATTACH_DIR = str(cls.tmp / "attach")
        from chat_logs import ChatLogStore
        cls.app.CHAT_LOGS = ChatLogStore(str(cls.tmp / "logs"))
        # re-register built-ins against the scratch attach dir
        import lib_bejson_AI_ai_context_bubble as B
        from lib_bejson_AI_ai_bubble_allotments import register_builtin_allotments
        B.ai_bubble_clear_allotments()
        register_builtin_allotments(cls.app.ai_context_files_list, cls.app.ATTACH_DIR,
                                    os.path.join(cls.app.ATTACH_DIR, "imports"),
                                    cls.app.context_chunker.chunker_build_section)
        cls.app.ai_bubble_init(cls.app.CONTEXT_DIR, cls.app.AI_CONFIG_DIR, policy_text="TEST POLICY")
        cls.client = cls.app.app.test_client()
        cls.seen = []

        def fake_dispatch(provider, text, model_id=None, **kw):
            cls.seen.append(text)
            return {"success": True, "content": f"reply-{len(cls.seen)}"}
        cls.orig = cls.app.ai_dispatch_call
        cls.app.ai_dispatch_call = fake_dispatch

    @classmethod
    def tearDownClass(cls):
        cls.app.ai_dispatch_call = cls.orig
        if cls.old_home is None:
            os.environ.pop("HOME", None)
        else:
            os.environ["HOME"] = cls.old_home
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def chat(self, msg, sid, **extra):
        body = {"message": msg, "service": "Groq", "model": "m", "session_id": sid}
        body.update(extra)
        r = self.client.post("/api/chat", json=body).get_json()
        self.assertEqual(r["status"], "success", r)
        return self.seen[-1], r["bubble_stats"]

    def test_01_history_attachments_policy_and_rebuild_cadence(self):
        sid = str(uuid.uuid4())
        p1, s1 = self.chat("first question", sid)
        self.assertIn("TEST POLICY", p1)
        self.assertNotIn("first question", p1.split("---")[0])   # nothing in history yet
        self.assertEqual(s1["reason"], "first")

        p2, s2 = self.chat("second question", sid)
        bubble2 = p2.split("\n\n---\n\n")[0]
        self.assertIn("[user]: first question", bubble2)
        self.assertIn("[assistant]: reply-1", bubble2)
        self.assertEqual(s2["reason"], "reuse")                  # history alone does not rebuild
        self.assertTrue(p2.endswith("second question"))

        # attach a file -> change -> rebuild, discussable directive present
        info = self.app.ai_context_files_import(self.app.ATTACH_DIR, "notes.txt", "ATTACH BODY 123")
        p3, s3 = self.chat("use my file", sid, attached_file_ids=[info["file_id"]])
        self.assertEqual(s3["reason"], "changed: attachments")
        self.assertIn("--- ATTACHED FILE: notes.txt ---\nATTACH BODY 123", p3)
        self.assertIn("freely discussable", p3)

        # client unchecks after send -> gone, rebuilt again, counter restarts
        p4, s4 = self.chat("next", sid)
        self.assertNotIn("ATTACH BODY 123", p4)
        self.assertEqual(s4["reason"], "changed: attachments")
        self.assertEqual(s4["turns_until_rebuild"], 4)

    def test_02_profile_allotment(self):
        sid = str(uuid.uuid4())
        with_profile = self.app._assemble_dispatch_input("m", [], "BE VERY BRIEF", session_id=sid)[0]
        self.assertIn("## Profile", with_profile)
        self.assertIn("BE VERY BRIEF", with_profile)
        without = self.app._assemble_dispatch_input("m", [], None, session_id=sid)[0]
        self.assertNotIn("BE VERY BRIEF", without)

    def test_03_stream_path_skips_history_allotment(self):
        sid = str(uuid.uuid4())
        self.app._log_message(sid, "user", "User", "Groq", "m", "EARLIER-Q")
        self.app._log_message(sid, "assistant", "Groq", "Groq", "m", "EARLIER-A")
        full = self.app._assemble_dispatch_input("m", [], None, session_id=sid)[0]
        self.assertIn("EARLIER-Q", full)
        stream = self.app._assemble_dispatch_input("m", [], None, session_id=sid, include_history=False)[0]
        self.assertNotIn("EARLIER-Q", stream)
        self.assertNotIn("## Chat History", stream)

    def test_04_preview_endpoint_is_side_effect_free(self):
        self.chat("seed", str(uuid.uuid4()))
        state_path = Path(self.app.CONTEXT_DIR) / "bubble_state.json"
        before = state_path.read_text()
        r = self.client.get("/api/context/bubble").get_json()
        self.assertEqual(r["reason"], "preview")
        self.assertEqual([a["name"] for a in r["allotments"]],
                         ["persistent_policy", "profile", "attachments", "context", "chat_history"])
        self.assertIn("TEST POLICY", r["text"])
        self.assertEqual(state_path.read_text(), before)

    def test_05_token_budget_setting_drives_truncation(self):
        sid = str(uuid.uuid4())
        self.client.post("/api/settings/tokens", json={"max_context_tokens": 500})
        big = self.app.ai_context_files_import(self.app.ATTACH_DIR, "big.txt",
                                               "\n".join(f"row {i:05d}" for i in range(3000)))
        p, s = self.chat("go", sid, attached_file_ids=[big["file_id"]])
        att = next(a for a in s["allotments"] if a["name"] == "attachments")
        self.assertTrue(att["truncated"])
        self.assertIn("[...truncated: over allotment budget]", p)
        self.assertLessEqual(len(p.split("\n\n---\n\n")[0]), 500 * 4)
        self.client.post("/api/settings/tokens", json={"reset": True})


    def test_06_allotment_switch_route_reflows_and_rebuilds(self):
        sid = str(uuid.uuid4())
        self.chat("warm", sid)
        r = self.client.post("/api/context/bubble/allotments",
                             json={"changes": {"profile": {"enabled": False}}}).get_json()
        self.assertEqual(r["status"], "success")
        sh = {a["name"]: a["share_pct"] for a in r["bubble"]["allotments"]}
        self.assertNotIn("profile", sh)
        self.assertEqual(set(sh.values()), {25.0})
        cat = {c["name"]: c for c in r["bubble"]["catalog"]}
        self.assertFalse(cat["profile"]["enabled"])
        _, st = self.chat("after toggle", sid)
        self.assertEqual(st["reason"], "changed: config")
        r = self.client.post("/api/context/bubble/allotments",
                             json={"changes": {"profile": {"enabled": True}}}).get_json()
        self.assertEqual({a["share_pct"] for a in r["bubble"]["allotments"]}, {20.0})

    def test_07_allotment_switch_route_validation(self):
        bad = [{"changes": {"nope": {"enabled": False}}}, {"changes": {"profile": {"enabled": "x"}}},
               {"changes": {"profile": {"pct": 500}}}, {"changes": []}]
        for body in bad:
            resp = self.client.post("/api/context/bubble/allotments", json=body)
            self.assertEqual(resp.status_code, 400, body)
            self.assertEqual(resp.get_json()["status"], "error")
        self.assertEqual(self.client.post("/api/context/bubble/allotments", data="x").status_code, 400)


if __name__ == "__main__":
    unittest.main(verbosity=1)
