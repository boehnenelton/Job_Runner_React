"""
Test:           test_gemini_gate.py
Path:           dev/tests/context_bubble/test_gemini_gate.py
Description:    Gemini.md config gate: case-insensitive ~/.gemini/GEMINI.md lookup, injection into
                the persistent_policy allotment, gate off / missing / corrupt config, rebuild when
                the file changes, budget truncation. HOME points at a scratch directory.
Version:        1.0.0
Date:           2026-11-02
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  5d2c8e17-3a4b-4f9d-b6e1-7c0a94d3f852
Run:            python3 dev/tests/context_bubble/test_gemini_gate.py
"""
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
for sub in ("lib/AI", "lib/Core"):
    sys.path.insert(0, str(ROOT / sub))

import lib_bejson_AI_ai_context_bubble as B  # noqa: E402
import lib_bejson_AI_ai_bubble_allotments as A  # noqa: E402

SHIPPED_GATE = ROOT / "lib" / "AI" / "config" / A.GEMINI_GATE_FILENAME


class GeminiGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="gemgate_"))
        self.home = self.tmp / "home"
        self.home.mkdir()
        self.ctx, self.cfg = self.tmp / "ctx", self.tmp / "cfg"
        self.old_home = os.environ.get("HOME")
        os.environ["HOME"] = str(self.home)
        B.ai_bubble_clear_allotments()
        A.register_builtin_allotments(lambda d: [], str(self.tmp / "att"), str(self.tmp / "att"), None)
        B.ai_bubble_init(self.ctx, self.cfg, policy_text="BASE POLICY")

    def tearDown(self):
        if self.old_home is None:
            os.environ.pop("HOME", None)
        else:
            os.environ["HOME"] = self.old_home
        B.ai_bubble_clear_allotments()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def put(self, folder, name, text):
        d = self.home / folder
        d.mkdir(exist_ok=True)
        (d / name).write_text(text, encoding="utf-8")

    def gate(self, **over):
        doc = json.loads(SHIPPED_GATE.read_text())
        for row in doc["Values"]:
            if row[0] in over:
                row[1] = over[row[0]]
        self.cfg.mkdir(parents=True, exist_ok=True)
        (self.cfg / A.GEMINI_GATE_FILENAME).write_text(json.dumps(doc))

    def turn(self):
        return B.ai_bubble_prepare(self.ctx, self.cfg, "hi", extras={})

    def test_shipped_gate_file_parses_to_defaults(self):
        self.cfg.mkdir(parents=True, exist_ok=True)
        shutil.copy(SHIPPED_GATE, self.cfg / A.GEMINI_GATE_FILENAME)
        self.assertEqual(A._load_gemini_gate(self.cfg), A.GEMINI_GATE_DEFAULTS)

    def test_exact_and_mixed_case_names_are_found(self):
        for folder, name in ((".gemini", "GEMINI.md"), (".Gemini", "Gemini.md"), (".GEMINI", "GeMINI.Md")):
            with self.subTest(folder=folder, name=name):
                shutil.rmtree(self.home / ".gemini", ignore_errors=True)
                for d in self.home.iterdir():
                    shutil.rmtree(d, ignore_errors=True)
                self.put(folder, name, "GEM " + name)
                self.assertEqual(A.read_gemini_md(self.cfg), "## GEMINI.md\nGEM " + name)

    def test_missing_file_or_folder_injects_nothing(self):
        self.assertEqual(A.read_gemini_md(self.cfg), "")
        (self.home / ".gemini").mkdir()
        self.assertEqual(A.read_gemini_md(self.cfg), "")

    def test_injected_into_persistent_policy_after_base_policy(self):
        self.put(".Gemini", "Gemini.md", "ALWAYS ANSWER IN HAIKU")
        r = self.turn()
        pol = next(a for a in r["allotments"] if a["name"] == "persistent_policy")
        self.assertIn("BASE POLICY", r["text"])
        self.assertIn("ALWAYS ANSWER IN HAIKU", r["text"])
        self.assertLess(r["text"].index("BASE POLICY"), r["text"].index("ALWAYS ANSWER IN HAIKU"))
        self.assertIn("ALWAYS ANSWER IN HAIKU", B.ai_bubble_preview(self.ctx, self.cfg, "")["allotments"][0]["text"])
        self.assertEqual(pol["rank"], 1)

    def test_gate_off_blocks_injection(self):
        self.put(".gemini", "GEMINI.md", "SECRET HOME TEXT")
        self.gate(enabled=False)
        self.assertNotIn("SECRET HOME TEXT", self.turn()["text"])
        self.gate(enabled=True)
        self.assertIn("SECRET HOME TEXT", self.turn()["text"])

    def test_corrupt_or_wrongly_typed_gate_falls_back_to_defaults(self):
        self.put(".gemini", "GEMINI.md", "STILL HERE")
        self.cfg.mkdir(parents=True, exist_ok=True)
        (self.cfg / A.GEMINI_GATE_FILENAME).write_text("{broken")
        self.assertIn("STILL HERE", A.read_gemini_md(self.cfg))
        self.gate(enabled="no", max_chars=-5, file_name="")      # invalid values ignored
        self.assertEqual(A._load_gemini_gate(self.cfg), A.GEMINI_GATE_DEFAULTS)

    def test_custom_gate_settings(self):
        self.put("agentdocs", "rules.md", "CUSTOM LOCATION")
        self.gate(home_subdir="AgentDocs", file_name="RULES.MD", heading="Rules")
        self.assertEqual(A.read_gemini_md(self.cfg), "## Rules\nCUSTOM LOCATION")

    def test_file_change_rebuilds_the_bubble(self):
        self.put(".gemini", "GEMINI.md", "v1")
        self.turn()
        self.assertEqual(self.turn()["reason"], "reuse")
        self.put(".gemini", "GEMINI.md", "v2 changed")
        r = self.turn()
        self.assertEqual(r["reason"], "changed: persistent_policy")
        self.assertIn("v2 changed", r["text"])

    def test_source_cap_and_budget_truncate(self):
        self.put(".gemini", "GEMINI.md", "G" * 50000)
        self.gate(max_chars=500)
        self.assertLessEqual(len(A.read_gemini_md(self.cfg)), 500 + 20)
        self.gate(max_chars=16000)
        from lib_bejson_AI_ai_constants import ai_constants_set
        ai_constants_set(self.cfg, "max_context_tokens", 200)
        r = self.turn()
        self.assertLessEqual(len(r["text"]), 200 * 4)

    def test_no_absolute_home_literal_in_library(self):
        src = (ROOT / "lib/AI/lib_bejson_AI_ai_bubble_allotments.py").read_text()
        self.assertNotIn("/home/", src)
        self.assertNotIn("/storage/", src)


if __name__ == "__main__":
    unittest.main(verbosity=1)
