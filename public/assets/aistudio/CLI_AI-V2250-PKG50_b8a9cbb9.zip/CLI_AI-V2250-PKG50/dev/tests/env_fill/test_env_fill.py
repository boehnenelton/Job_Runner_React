"""
File:        test_env_fill.py
Purpose:     Offline tests for source_env_fill (Core env 2.3.0), RoundRobinKeyRegistry 2.1.0
             and GenAIKeyManager 2.2.0. No network, no real keys, never touches the real
             secure store (HOME and SECUREENV_FILE are redirected to a temp dir).
Run:         python3 test_env_fill.py [path/to/lib_root_containing_AI_and_Core]
VERSION:     1.0.0
Author:      Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID: 0c5e7a31-9d42-4b68-a1f3-8e2d6b4c9a57
"""
import json, logging, os, sys, tempfile, unittest
from pathlib import Path

logging.disable(logging.CRITICAL)
ROOT = Path(sys.argv.pop(1)).resolve() if len(sys.argv) > 1 and Path(sys.argv[1]).is_dir() else None
if ROOT is None:
    here = Path(__file__).resolve()
    for up in here.parents:
        for cand in (up / "lib", up / "Lib_PY"):
            if (cand / "AI").is_dir() and (cand / "Core").is_dir():
                ROOT = cand
                break
        if ROOT:
            break
assert ROOT, "pass the lib root (folder containing AI/ and Core/)"
sys.path[:0] = [str(ROOT / "AI"), str(ROOT / "Core")]
import lib_bejson_Core_bejson_env as env          # noqa: E402
import lib_bejson_AI_ai_registry_base as rb       # noqa: E402
import lib_bejson_AI_bejson_genai as genai        # noqa: E402

PREFIXES = ("GEMINI", "GROQ", "XAI", "SECUREENV", "BEJSON_PATHS", "TOKENROUTER", "T_FILL")


def store_doc(rows):
    return {"Format": "BEJSON", "Format_Version": "104a", "Format_Creator": "t", "Records_Type": ["E"],
            "Fields": [{"name": "name", "type": "string"}, {"name": "value", "type": "string"}], "Values": rows}


class Base(unittest.TestCase):
    def setUp(self):
        self.saved = dict(os.environ)
        for k in list(os.environ):
            if k.startswith(PREFIXES):
                del os.environ[k]
        self.tmp = tempfile.mkdtemp()
        os.environ["HOME"] = self.tmp
        env.source_env_fill(force=True)  # reset cache with a clean env
        self.n = 0

    def tearDown(self):
        os.environ.clear(); os.environ.update(self.saved)
        env._FILL_REPORTS.clear()

    def write_store(self, rows, name="secureenv_file.json"):
        p = os.path.join(self.tmp, name)
        Path(p).write_text(json.dumps(store_doc(rows)), encoding="utf-8")
        os.environ["SECUREENV_FILE"] = p
        env.source_env_fill(force=True)
        return p

    def reg(self, **kw):
        self.n += 1
        return rb.RoundRobinKeyRegistry(os.path.join(self.tmp, f"k{self.n}.json"), **kw)


class TestFill(Base):
    def test_no_store_is_noop(self):
        r = env.source_env_fill(force=True)
        self.assertFalse(r["found"]); self.assertEqual(r["loaded"], 0)

    def test_fills_gaps_and_env_wins(self):
        os.environ["T_FILL_B"] = "real"
        self.write_store([["T_FILL_A", "a"], ["T_FILL_B", "from_store"], ["T_FILL_E", ""]])
        self.assertEqual(os.environ["T_FILL_A"], "a")
        self.assertEqual(os.environ["T_FILL_B"], "real")
        self.assertNotIn("T_FILL_E", os.environ)

    def test_report_has_no_values(self):
        self.write_store([["T_FILL_A", "supersecret"]])
        self.assertNotIn("supersecret", json.dumps(env.source_env_fill()))

    def test_paths_not_loaded_by_default(self):
        p = os.path.join(self.tmp, "paths.json")
        Path(p).write_text(json.dumps(store_doc([["T_FILL_ROOT", "/x"]])), encoding="utf-8")
        os.environ["BEJSON_PATHS_FILE"] = p
        env.source_env_fill(force=True)
        self.assertNotIn("T_FILL_ROOT", os.environ)
        env.source_env_fill(include_paths=True, force=True)
        self.assertEqual(os.environ["T_FILL_ROOT"], "/x")

    def test_python_store_not_executed(self):
        p = os.path.join(self.tmp, "secureenv_file.py")
        Path(p).write_text("import os; os.environ['T_FILL_PWN']='1'", encoding="utf-8")
        os.environ["SECUREENV_FILE"] = p
        env.source_env_fill(force=True)
        self.assertNotIn("T_FILL_PWN", os.environ)

    def test_existing_api_untouched(self):
        for n in ("source_env", "_load_env_file", "resolve_path", "get_env_path"):
            self.assertTrue(callable(getattr(env, n)))
        os.environ["HOME"] = self.tmp
        self.assertEqual(env.resolve_path("{HOME}/x"), os.path.normpath(self.tmp + "/x"))


class TestRegistry(Base):
    def test_prefix_only_reads_env(self):          # the bug: used to return []
        os.environ["GROQ_KEY_1"] = "c"; os.environ["GROQ_KEY_3"] = "d"
        self.assertEqual(self.reg(env_var_prefix="GROQ_KEY").keys, ["c", "d"])

    def test_env_var_and_prefix_dedupe(self):
        os.environ["GROQ_API_KEYS"] = "a,b"; os.environ["GROQ_KEY_1"] = "b"; os.environ["GROQ_KEY_2"] = "c"
        self.assertEqual(self.reg(env_var="GROQ_API_KEYS", env_var_prefix="GROQ_KEY").keys, ["a", "b", "c"])

    def test_store_keys_visible_env_wins(self):
        os.environ["GROQ_KEY_2"] = "real2"
        self.write_store([["GROQ_KEY_1", "s1"], ["GROQ_KEY_2", "s2"]])
        self.assertEqual(self.reg(env_var_prefix="GROQ_KEY").keys, ["s1", "real2"])

    def test_nothing_configured(self):
        self.assertEqual(self.reg(env_var="GROQ_API_KEYS", env_var_prefix="GROQ_KEY").keys, [])
        self.assertIsNone(self.reg(env_var_prefix="GROQ_KEY").get_next_key())

    def test_file_fallback_and_placeholders_unchanged(self):
        p = os.path.join(self.tmp, "kf.json")
        Path(p).write_text(json.dumps({"Format": "BEJSON", "Format_Version": "104a", "Format_Creator": "t",
            "Records_Type": ["ApiKey"], "Config_Version": 1,
            "Fields": [{"name": "key_slot", "type": "integer"}, {"name": "key", "type": "string"}],
            "Values": [[1, "YOUR_KEY_HERE"], [2, "filekey"]]}), encoding="utf-8")
        r = rb.RoundRobinKeyRegistry(p, env_var_prefix="GROQ_KEY")
        self.assertEqual(r.keys, ["filekey"])

    def test_works_without_core_env_fill(self):
        saved = rb._source_env_fill
        rb._source_env_fill = None
        try:
            os.environ["GROQ_KEY_1"] = "x"
            self.assertEqual(self.reg(env_var_prefix="GROQ_KEY").keys, ["x"])
        finally:
            rb._source_env_fill = saved


class TestGenai(Base):
    def test_numbered_and_list_keys(self):
        os.environ["GEMINI_API_KEYS"] = "a, b"; os.environ["GEMINI_KEY_1"] = "b"; os.environ["GEMINI_KEY_21"] = "z"
        self.write_store([["GEMINI_KEY_2", "s"]])
        m = genai.GenAIKeyManager(os.path.join(self.tmp, "none.bejson"))
        self.assertEqual(sorted(m.keys), ["a", "b", "s", "z"])
        self.assertEqual(m.get_key_count(), 4)


if __name__ == "__main__":
    unittest.main(verbosity=1)
