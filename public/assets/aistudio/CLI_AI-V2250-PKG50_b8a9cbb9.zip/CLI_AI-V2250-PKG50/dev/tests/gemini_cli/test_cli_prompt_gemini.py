"""
Tool:           test_cli_prompt_gemini.py
Family:         CLI
Description:    Unit and integration tests for the Gemini CLI tool.
Version:        1.0.0
Date:           2026-08-22
Author:         Elton Boehnen
Contact:        boehnenelton2024@gmail.com
Format_Creator: Elton Boehnen
"""

import unittest
import sys
import os
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = TESTS_DIR.parent.parent
CLI_DIR = PROJECT_ROOT / "CLI" / "gemini_cli"
CORE_DIR = PROJECT_ROOT / "lib" / "Core"
AI_DIR = PROJECT_ROOT / "lib" / "AI"

for path in [str(PROJECT_ROOT), str(CLI_DIR), str(CORE_DIR), str(AI_DIR)]:
    if path not in sys.path:
        sys.path.insert(0, path)

from lib_bejson_Core_bejson_env import source_env
SECURE_ENV_PATH = "/storage/emulated/0/.env/secure/secureenv_file.py"
source_env(SECURE_ENV_PATH)

from lib_bejson_AI_bejson_interactions import get_standard_interactions_api
from lib_bejson_AI_ai_dispatch import ai_dispatch_call


class TestGeminiCLI(unittest.TestCase):

    def test_key_loading(self):
        api = get_standard_interactions_api()
        self.assertGreater(len(api.keys.keys), 0, "No Gemini API keys loaded into registry")

    def test_model_registry(self):
        api = get_standard_interactions_api()
        self.assertTrue(bool(api.models.active_model_id), "Active model ID is empty")
        self.assertGreater(len(api.models.models), 0, "No models found in Gemini model registry")

    def test_ai_dispatch_prompt(self):
        api = get_standard_interactions_api()
        active_model = api.models.active_model_id
        response = ai_dispatch_call(
            provider="gemini",
            user_input="Reply with only the word OK.",
            model_id=active_model
        )
        self.assertTrue(response.get("success"), f"Dispatch failed: {response.get('error')}")
        self.assertIn("OK", response.get("content", "").upper())


if __name__ == "__main__":
    unittest.main()
