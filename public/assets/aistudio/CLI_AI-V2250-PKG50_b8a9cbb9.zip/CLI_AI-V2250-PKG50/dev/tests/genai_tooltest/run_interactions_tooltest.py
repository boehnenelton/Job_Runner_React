#!/usr/bin/env python3
"""
Name:          run_interactions_tooltest.py
Description:   Live test suite for the Gemini Interactions API (client.interactions.create)
               covering basic generation, stateful turns, function calling (single, parallel,
               multi-round, forced/none tool choice, stateless replay), built-in tools
               (google_search, code_execution, url_context), structured output, streaming,
               and background mode. Results are exported as BEJSON 104a.
Version:       see VERSION
Date Created:  2026-10-23
Author:        Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID: bb96fdf8-b1b2-4eae-b514-a7e62e9150b5
"""
from __future__ import annotations

import argparse
import ast
import json
import logging
import operator
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

VERSION = "1.0.0"
RELATIONAL_ID = "bb96fdf8-b1b2-4eae-b514-a7e62e9150b5"
AUTHOR_CREDIT = "Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton"

EXIT_CODE_SUCCESS = 0
EXIT_CODE_TEST_FAILURES = 1
EXIT_CODE_ENV_FAILURE = 20
EXIT_CODE_SCHEMA_FAILURE = 30


def get_script_path() -> Path:
    return Path(__file__).resolve().parent


SCRIPT_PATH = get_script_path()
CONFIG_FILE_PATH = SCRIPT_PATH / "config" / "config.json"

logger = logging.getLogger("interactions_tooltest")


# ---------------------------------------------------------------------------
# BEJSON helpers (Field Map Cache, no positional indices)
# ---------------------------------------------------------------------------
def build_bejson_field_map(bejson_document: dict) -> dict[str, int]:
    return {field_definition["name"].strip(): field_index
            for field_index, field_definition in enumerate(bejson_document["Fields"])}


def load_script_config() -> dict[str, Any]:
    try:
        config_document = json.loads(CONFIG_FILE_PATH.read_text(encoding="utf-8"))
        config_field_map = build_bejson_field_map(config_document)
        return {config_row[config_field_map["setting_name"]].strip(): config_row[config_field_map["setting_value"]]
                for config_row in config_document["Values"]}
    except (OSError, KeyError, json.JSONDecodeError) as config_error:
        logger.error("Config load/schema failure: %s", config_error)
        sys.exit(EXIT_CODE_SCHEMA_FAILURE)


def load_gemini_api_keys(secure_env_path: str, api_key_prefix: str) -> list[str]:
    try:
        env_document = json.loads(Path(secure_env_path).read_text(encoding="utf-8"))
        env_field_map = build_bejson_field_map(env_document)
        api_key_list = [str(env_row[env_field_map["var_value"]]).strip()
                        for env_row in env_document["Values"]
                        if str(env_row[env_field_map["var_name"]]).strip().startswith(api_key_prefix)
                        and env_row[env_field_map["var_value"]]]
    except (OSError, KeyError, json.JSONDecodeError) as env_error:
        logger.error("Secure env sourcing failure: %s", env_error)
        sys.exit(EXIT_CODE_ENV_FAILURE)
    if not api_key_list:
        logger.error("No %s* keys found in secure env.", api_key_prefix)
        sys.exit(EXIT_CODE_ENV_FAILURE)
    return api_key_list


# ---------------------------------------------------------------------------
# Harness: client + key rotation
# ---------------------------------------------------------------------------
class InteractionsTestHarness:
    def __init__(self, api_key_list: list[str], model_name: str, retry_limit: int) -> None:
        from google import genai
        self.genai_module = genai
        self.api_key_list = api_key_list
        self.api_key_index = 0
        self.model_name = model_name
        self.retry_limit = int(retry_limit)
        self.client = genai.Client(api_key=self.api_key_list[self.api_key_index])

    def rotate_api_key(self) -> None:
        self.api_key_index = (self.api_key_index + 1) % len(self.api_key_list)
        self.client = self.genai_module.Client(api_key=self.api_key_list[self.api_key_index])
        logger.warning("Rotated to API key slot %d", self.api_key_index)

    def create_interaction(self, **create_kwargs: Any) -> Any:
        create_kwargs.setdefault("model", self.model_name)
        last_request_error: Exception | None = None
        for attempt_index in range(self.retry_limit):
            try:
                return self.client.interactions.create(**create_kwargs)
            except Exception as request_error:  # SDK raises typed HTTP errors
                status_code_value = getattr(request_error, "status_code", None)
                last_request_error = request_error
                if status_code_value in (429, 500, 502, 503, 504):
                    logger.warning("Attempt %d got HTTP %s; rotating.", attempt_index + 1, status_code_value)
                    self.rotate_api_key()
                    time.sleep(1.5 * (attempt_index + 1))
                    continue
                raise
        raise last_request_error  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Step inspection helpers
# ---------------------------------------------------------------------------
def list_step_types(interaction_result: Any) -> list[str]:
    return [getattr(step_entry, "type", "UNKNOWN") for step_entry in (interaction_result.steps or [])]


def filter_steps_by_type(interaction_result: Any, step_type_name: str) -> list[Any]:
    return [step_entry for step_entry in (interaction_result.steps or [])
            if getattr(step_entry, "type", None) == step_type_name]


def truncate_text(source_text: Any, max_length: int = 160) -> str:
    flattened_text = str(source_text or "").replace("\n", " ")
    return flattened_text if len(flattened_text) <= max_length else flattened_text[:max_length] + "…"


# ---------------------------------------------------------------------------
# Local function tools (deterministic so results are verifiable)
# ---------------------------------------------------------------------------
WEATHER_FIXTURE_TABLE = {
    "paris": {"temperature_celsius": 17, "condition": "light rain"},
    "tokyo": {"temperature_celsius": 23, "condition": "sunny"},
    "denver": {"temperature_celsius": -4, "condition": "snow"},
}
INVENTORY_FIXTURE_TABLE = {"SKU-123": {"unit_price_usd": 12.5, "stock_count": 40},
                           "SKU-777": {"unit_price_usd": 3.25, "stock_count": 0}}

SAFE_ARITHMETIC_OPERATORS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
                             ast.Div: operator.truediv, ast.Pow: operator.pow, ast.USub: operator.neg}


def evaluate_arithmetic_node(expression_node: ast.AST) -> float:
    if isinstance(expression_node, ast.Constant) and isinstance(expression_node.value, (int, float)):
        return expression_node.value
    if isinstance(expression_node, ast.BinOp) and type(expression_node.op) in SAFE_ARITHMETIC_OPERATORS:
        return SAFE_ARITHMETIC_OPERATORS[type(expression_node.op)](
            evaluate_arithmetic_node(expression_node.left), evaluate_arithmetic_node(expression_node.right))
    if isinstance(expression_node, ast.UnaryOp) and type(expression_node.op) in SAFE_ARITHMETIC_OPERATORS:
        return SAFE_ARITHMETIC_OPERATORS[type(expression_node.op)](evaluate_arithmetic_node(expression_node.operand))
    raise ValueError("Unsupported expression")


def tool_get_weather(city: str) -> dict:
    weather_record = WEATHER_FIXTURE_TABLE.get(str(city).strip().lower())
    return {"city": city, **weather_record} if weather_record else {"error": f"unknown city {city}"}


def tool_calculate(expression: str) -> dict:
    return {"expression": expression, "value": evaluate_arithmetic_node(ast.parse(expression, mode="eval").body)}


def tool_lookup_inventory(sku: str) -> dict:
    inventory_record = INVENTORY_FIXTURE_TABLE.get(str(sku).strip().upper())
    return {"sku": sku, **inventory_record} if inventory_record else {"error": f"unknown sku {sku}"}


LOCAL_TOOL_DISPATCH_TABLE: dict[str, Callable[..., dict]] = {
    "get_weather": tool_get_weather,
    "calculate": tool_calculate,
    "lookup_inventory": tool_lookup_inventory,
}

FUNCTION_DECLARATION_GET_WEATHER = {
    "type": "function", "name": "get_weather",
    "description": "Get the current weather for a city.",
    "parameters": {"type": "object", "properties": {"city": {"type": "string", "description": "City name"}},
                   "required": ["city"]},
}
FUNCTION_DECLARATION_CALCULATE = {
    "type": "function", "name": "calculate",
    "description": "Evaluate an arithmetic expression using + - * / ** and parentheses.",
    "parameters": {"type": "object", "properties": {"expression": {"type": "string"}}, "required": ["expression"]},
}
FUNCTION_DECLARATION_LOOKUP_INVENTORY = {
    "type": "function", "name": "lookup_inventory",
    "description": "Look up unit price (USD) and stock count for a product SKU.",
    "parameters": {"type": "object", "properties": {"sku": {"type": "string"}}, "required": ["sku"]},
}


def execute_function_call_steps(function_call_steps: list[Any]) -> list[dict]:
    function_result_payload_list = []
    for function_call_step in function_call_steps:
        dispatch_handler = LOCAL_TOOL_DISPATCH_TABLE.get(function_call_step.name)
        try:
            handler_output = dispatch_handler(**(function_call_step.arguments or {})) if dispatch_handler \
                else {"error": f"no such tool {function_call_step.name}"}
            is_error_flag = "error" in handler_output
        except Exception as handler_error:
            handler_output, is_error_flag = {"error": str(handler_error)}, True
        logger.info("    tool %s(%s) -> %s", function_call_step.name, function_call_step.arguments, handler_output)
        function_result_payload_list.append({
            "type": "function_result", "call_id": function_call_step.id, "name": function_call_step.name,
            "result": json.dumps(handler_output), "is_error": is_error_flag,
        })
    return function_result_payload_list


def run_stateful_function_loop(harness: InteractionsTestHarness, tool_declaration_list: list[dict],
                               first_turn_input: Any, max_round_count: int = 6,
                               **extra_create_kwargs: Any) -> tuple[Any, list[list[str]]]:
    """Runs create -> execute function calls -> function_result via previous_interaction_id."""
    round_call_name_log: list[list[str]] = []
    interaction_result = harness.create_interaction(input=first_turn_input, tools=tool_declaration_list,
                                                    **extra_create_kwargs)
    for _round_index in range(max_round_count):
        function_call_steps = filter_steps_by_type(interaction_result, "function_call")
        if not function_call_steps:
            break
        round_call_name_log.append([call_step.name for call_step in function_call_steps])
        interaction_result = harness.create_interaction(
            input=execute_function_call_steps(function_call_steps), tools=tool_declaration_list,
            previous_interaction_id=interaction_result.id, **extra_create_kwargs)
    return interaction_result, round_call_name_log


# ---------------------------------------------------------------------------
# Test cases: each returns (passed_flag, detail_text)
# ---------------------------------------------------------------------------
def test_basic_text(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(input="Reply with exactly: pong")
    return ("pong" in (interaction_result.output_text or "").lower(),
            f"status={interaction_result.status} steps={list_step_types(interaction_result)} "
            f"text={truncate_text(interaction_result.output_text)} tokens={interaction_result.usage.total_tokens}")


def test_system_instruction_and_generation_config(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(
        input="What is the capital of France?",
        system_instruction="You are a pirate. Always answer in ALL CAPS.",
        generation_config={"temperature": 0.2, "max_output_tokens": 200, "thinking_level": "low"})
    answer_text = interaction_result.output_text or ""
    letter_characters = [character for character in answer_text if character.isalpha()]
    uppercase_ratio = sum(character.isupper() for character in letter_characters) / max(1, len(letter_characters))
    return ("PARIS" in answer_text and uppercase_ratio > 0.8,
            f"upper_ratio={uppercase_ratio:.2f} text={truncate_text(answer_text)}")


def test_stateful_previous_interaction(harness: InteractionsTestHarness) -> tuple[bool, str]:
    first_interaction = harness.create_interaction(input="Remember the code word ZEBRA-42. Just say OK.")
    second_interaction = harness.create_interaction(input="What code word did I give you?",
                                                    previous_interaction_id=first_interaction.id)
    return ("ZEBRA-42" in (second_interaction.output_text or "").upper(),
            f"turn2={truncate_text(second_interaction.output_text)}")


def test_function_call_single(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result, round_call_name_log = run_stateful_function_loop(
        harness, [FUNCTION_DECLARATION_GET_WEATHER], "What's the weather in Tokyo right now?")
    final_text = interaction_result.output_text or ""
    return (bool(round_call_name_log) and "23" in final_text,
            f"rounds={round_call_name_log} final={truncate_text(final_text)}")


def test_function_call_parallel(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result, round_call_name_log = run_stateful_function_loop(
        harness, [FUNCTION_DECLARATION_GET_WEATHER],
        "Compare the current weather in Paris, Tokyo and Denver. Call the tool for all three at once.")
    final_text = interaction_result.output_text or ""
    first_round_size = len(round_call_name_log[0]) if round_call_name_log else 0
    all_values_present = all(token in final_text for token in ("17", "23", "-4"))
    return (first_round_size >= 2 and all_values_present,
            f"first_round_parallel={first_round_size} rounds={round_call_name_log} final={truncate_text(final_text)}")


def test_function_call_multi_round_chain(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result, round_call_name_log = run_stateful_function_loop(
        harness, [FUNCTION_DECLARATION_LOOKUP_INVENTORY, FUNCTION_DECLARATION_CALCULATE],
        "Look up SKU-123, then use the calculate tool to compute the total cost of 7 units. "
        "Do not do arithmetic yourself.")
    final_text = interaction_result.output_text or ""
    called_tool_names = {tool_name for round_names in round_call_name_log for tool_name in round_names}
    return ({"lookup_inventory", "calculate"} <= called_tool_names and "87.5" in final_text,
            f"rounds={round_call_name_log} final={truncate_text(final_text)}")


def test_tool_choice_any_forced(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(
        input="Say hello.", tools=[FUNCTION_DECLARATION_GET_WEATHER],
        generation_config={"tool_choice": "any"})
    function_call_steps = filter_steps_by_type(interaction_result, "function_call")
    return (bool(function_call_steps),
            f"steps={list_step_types(interaction_result)} calls="
            f"{[(call_step.name, call_step.arguments) for call_step in function_call_steps]}")


def test_tool_choice_none(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(
        input="What's the weather in Paris?", tools=[FUNCTION_DECLARATION_GET_WEATHER],
        generation_config={"tool_choice": "none"})
    function_call_steps = filter_steps_by_type(interaction_result, "function_call")
    return (not function_call_steps,
            f"steps={list_step_types(interaction_result)} text={truncate_text(interaction_result.output_text)}")


def test_tool_choice_allowed_tools(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(
        input="What's 19*23 and what's the weather in Paris?",
        tools=[FUNCTION_DECLARATION_GET_WEATHER, FUNCTION_DECLARATION_CALCULATE],
        generation_config={"tool_choice": {"allowed_tools": {"mode": "any", "tools": ["calculate"]}}})
    called_tool_names = [call_step.name for call_step in filter_steps_by_type(interaction_result, "function_call")]
    return (bool(called_tool_names) and set(called_tool_names) == {"calculate"}, f"calls={called_tool_names}")


def test_function_call_stateless_replay(harness: InteractionsTestHarness) -> tuple[bool, str]:
    """store=False: replay full step history client-side instead of previous_interaction_id."""
    user_turn_step = {"type": "user_input", "content": [{"type": "text", "text": "Weather in Denver?"}]}
    first_interaction = harness.create_interaction(input=[user_turn_step], tools=[FUNCTION_DECLARATION_GET_WEATHER],
                                                   store=False)
    function_call_steps = filter_steps_by_type(first_interaction, "function_call")
    if not function_call_steps:
        return False, f"no function_call; steps={list_step_types(first_interaction)}"
    replay_history_steps = [user_turn_step] + [
        step_entry.model_dump(mode="json", exclude_none=True, by_alias=True) for step_entry in first_interaction.steps
    ] + execute_function_call_steps(function_call_steps)
    second_interaction = harness.create_interaction(input=replay_history_steps,
                                                    tools=[FUNCTION_DECLARATION_GET_WEATHER], store=False)
    final_text = second_interaction.output_text or ""
    return ("-4" in final_text or "snow" in final_text.lower(),
            f"replayed_steps={[step_entry.get('type') for step_entry in replay_history_steps]} "
            f"final={truncate_text(final_text)}")


def test_builtin_google_search(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(
        input="Use Google Search: who won the most recent FIFA World Cup final and what was the score?",
        tools=[{"type": "google_search"}])
    step_type_list = list_step_types(interaction_result)
    return ("google_search_call" in step_type_list or "google_search_result" in step_type_list,
            f"steps={step_type_list} text={truncate_text(interaction_result.output_text)}")


def test_builtin_code_execution(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(
        input="Use code execution to compute the sum of the first 200 prime numbers. Report the number.",
        tools=[{"type": "code_execution"}])
    step_type_list = list_step_types(interaction_result)
    return ("code_execution_call" in step_type_list and "111587" in (interaction_result.output_text or "")
            .replace(",", ""), f"steps={step_type_list} text={truncate_text(interaction_result.output_text)}")


def test_builtin_url_context(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(
        input="Summarize in one sentence what https://example.com says.", tools=[{"type": "url_context"}])
    step_type_list = list_step_types(interaction_result)
    return ("url_context_call" in step_type_list or "url_context_result" in step_type_list,
            f"steps={step_type_list} text={truncate_text(interaction_result.output_text)}")


def test_builtin_plus_function_combo(harness: InteractionsTestHarness) -> tuple[bool, str]:
    interaction_result, round_call_name_log = run_stateful_function_loop(
        harness, [{"type": "google_search"}, FUNCTION_DECLARATION_CALCULATE],
        "Search for the population of Iceland, then use the calculate tool to divide it by 1000.")
    step_type_list = list_step_types(interaction_result)
    return (bool(round_call_name_log),
            f"fn_rounds={round_call_name_log} last_steps={step_type_list} "
            f"text={truncate_text(interaction_result.output_text)}")


def test_structured_output(harness: InteractionsTestHarness) -> tuple[bool, str]:
    response_json_schema = {
        "type": "object",
        "properties": {"city_name": {"type": "string"}, "country_name": {"type": "string"},
                       "population_estimate": {"type": "integer"}},
        "required": ["city_name", "country_name", "population_estimate"],
    }
    interaction_result = harness.create_interaction(
        input="Give facts about Osaka.", response_format=response_json_schema,
        response_mime_type="application/json")
    parsed_response_document = json.loads(interaction_result.output_text or "{}")
    return (set(response_json_schema["required"]) <= set(parsed_response_document)
            and isinstance(parsed_response_document.get("population_estimate"), int),
            f"json={truncate_text(json.dumps(parsed_response_document))}")


def test_streaming(harness: InteractionsTestHarness) -> tuple[bool, str]:
    stream_event_iterator = harness.create_interaction(input="Count from 1 to 5, one per line.", stream=True)
    stream_event_type_counts: dict[str, int] = {}
    for stream_event in stream_event_iterator:
        event_type_name = getattr(stream_event, "event_type", None) or type(stream_event).__name__
        stream_event_type_counts[event_type_name] = stream_event_type_counts.get(event_type_name, 0) + 1
    return (any("delta" in event_name for event_name in stream_event_type_counts),
            f"events={stream_event_type_counts}")


def test_background_mode(harness: InteractionsTestHarness, poll_limit: int = 30) -> tuple[bool, str]:
    interaction_result = harness.create_interaction(input="Write a haiku about cubes.", background=True,
                                                    store=True)
    status_history = [str(interaction_result.status)]
    for _poll_index in range(int(poll_limit)):
        if str(interaction_result.status) in ("completed", "failed", "cancelled", "incomplete"):
            break
        time.sleep(2)
        interaction_result = harness.client.interactions.get(interaction_result.id)
        status_history.append(str(interaction_result.status))
    return (str(interaction_result.status) == "completed",
            f"status_trail={status_history[:6]}…{status_history[-1]} text={truncate_text(interaction_result.output_text)}")


def test_get_and_delete_stored(harness: InteractionsTestHarness) -> tuple[bool, str]:
    created_interaction = harness.create_interaction(input="Say stored.", store=True)
    fetched_interaction = harness.client.interactions.get(created_interaction.id)
    harness.client.interactions.delete(created_interaction.id)
    deletion_confirmed_flag = False
    try:
        harness.client.interactions.get(created_interaction.id)
    except Exception as get_error:
        deletion_confirmed_flag = getattr(get_error, "status_code", None) == 404
    return (fetched_interaction.id == created_interaction.id and deletion_confirmed_flag,
            f"fetched_text={truncate_text(fetched_interaction.output_text)} deleted_404={deletion_confirmed_flag}")


TEST_CASE_REGISTRY: dict[str, Callable[..., tuple[bool, str]]] = {
    "basic_text": test_basic_text,
    "system_instruction_generation_config": test_system_instruction_and_generation_config,
    "stateful_previous_interaction": test_stateful_previous_interaction,
    "function_call_single": test_function_call_single,
    "function_call_parallel": test_function_call_parallel,
    "function_call_multi_round_chain": test_function_call_multi_round_chain,
    "tool_choice_any_forced": test_tool_choice_any_forced,
    "tool_choice_none": test_tool_choice_none,
    "tool_choice_allowed_tools": test_tool_choice_allowed_tools,
    "function_call_stateless_replay": test_function_call_stateless_replay,
    "builtin_google_search": test_builtin_google_search,
    "builtin_code_execution": test_builtin_code_execution,
    "builtin_url_context": test_builtin_url_context,
    "builtin_plus_function_combo": test_builtin_plus_function_combo,
    "structured_output": test_structured_output,
    "streaming": test_streaming,
    "background_mode": test_background_mode,
    "get_and_delete_stored": test_get_and_delete_stored,
}


# ---------------------------------------------------------------------------
# Results export (BEJSON 104a)
# ---------------------------------------------------------------------------
def export_results_bejson(result_row_list: list[list[Any]], export_directory_path: Path, model_name: str) -> Path:
    export_directory_path.mkdir(parents=True, exist_ok=True)
    run_timestamp_text = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    results_document = {
        "Format": "BEJSON", "Format_Version": "104a", "Format_Creator": "Elton Boehnen",
        "Records_Type": ["InteractionsToolTestResult"],
        "Suite_Version": VERSION, "Model_Name": model_name, "Run_Timestamp": run_timestamp_text,
        "Fields": [{"name": "test_name", "type": "string"}, {"name": "test_status", "type": "string"},
                   {"name": "duration_ms", "type": "integer"}, {"name": "detail_text", "type": "string"}],
        "Values": result_row_list,
    }
    export_file_path = export_directory_path / f"results-{run_timestamp_text}.104a.bejson"
    export_file_path.write_text(json.dumps(results_document, indent=2, ensure_ascii=False), encoding="utf-8")
    return export_file_path


def main() -> int:
    argument_parser = argparse.ArgumentParser(description="Gemini Interactions API tool test suite")
    argument_parser.add_argument("--version", action="store_true", help="Show version and exit")
    argument_parser.add_argument("--about", action="store_true", help="Show author/about info")
    argument_parser.add_argument("--list", action="store_true", help="List test names")
    argument_parser.add_argument("--only", nargs="*", default=None, help="Run only these tests")
    argument_parser.add_argument("--model", default=None, help="Override model name")
    parsed_arguments = argument_parser.parse_args()

    script_config = load_script_config()
    logging.basicConfig(level=getattr(logging, str(script_config.get("log_level", "INFO")).upper(), logging.INFO),
                        format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    logging.getLogger("httpx").setLevel(logging.WARNING)

    if parsed_arguments.version:
        logger.info("run_interactions_tooltest.py v%s (%s)", VERSION, RELATIONAL_ID)
        return EXIT_CODE_SUCCESS
    if parsed_arguments.about:
        logger.info("Gemini Interactions tool test suite v%s — %s", VERSION, AUTHOR_CREDIT)
        return EXIT_CODE_SUCCESS
    if parsed_arguments.list:
        for registered_test_name in TEST_CASE_REGISTRY:
            logger.info("  %s", registered_test_name)
        return EXIT_CODE_SUCCESS

    model_name = parsed_arguments.model or script_config["default_model_name"]
    harness = InteractionsTestHarness(
        load_gemini_api_keys(script_config["secure_env_path"], script_config["api_key_prefix"]),
        model_name, script_config.get("request_retry_limit", 3))
    selected_test_names = parsed_arguments.only or list(TEST_CASE_REGISTRY)

    result_row_list: list[list[Any]] = []
    for selected_test_name in selected_test_names:
        test_function = TEST_CASE_REGISTRY.get(selected_test_name)
        if test_function is None:
            logger.error("Unknown test: %s", selected_test_name)
            continue
        logger.info("▶ %s", selected_test_name)
        test_start_time = time.monotonic()
        try:
            if selected_test_name == "background_mode":
                passed_flag, detail_text = test_function(harness, script_config.get("background_poll_limit", 30))
            else:
                passed_flag, detail_text = test_function(harness)
            test_status_text = "PASS" if passed_flag else "FAIL"
        except Exception as test_error:
            test_status_text, detail_text = "ERROR", f"{type(test_error).__name__}: {truncate_text(test_error, 400)}"
        duration_ms_value = int((time.monotonic() - test_start_time) * 1000)
        log_method = logger.info if test_status_text == "PASS" else logger.warning
        log_method("  %s (%d ms) %s", test_status_text, duration_ms_value, detail_text)
        result_row_list.append([selected_test_name, test_status_text, duration_ms_value, detail_text])

    export_file_path = export_results_bejson(
        result_row_list, SCRIPT_PATH / script_config.get("results_export_dir", "exports/"), model_name)
    pass_count = sum(1 for result_row in result_row_list if result_row[1] == "PASS")
    logger.info("Summary: %d/%d passed — results: %s", pass_count, len(result_row_list), export_file_path)
    return EXIT_CODE_SUCCESS if pass_count == len(result_row_list) else EXIT_CODE_TEST_FAILURES


if __name__ == "__main__":
    sys.exit(main())
