"""
Test:           test_litertlm.py
Description:    End-to-end tests for the LiteRTLM provider and its chat-client
                integration, run against an in-process fake `litert-lm serve`
                (OpenAI-compatible /v1/models and /v1/chat/completions, SSE).
Version:        1.0.0
Date:           2026-10-20
Author:         Elton Boehnen
RELATIONAL_ID:  7e41b0a9-5c3d-4f82-b6a1-d09e82c4f713
Run:            python3 dev/tests/litertlm/test_litertlm.py
"""
import json
import os
import shutil
import socket
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
SEEN_REQUESTS = []


class FakeLiteRTLM(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/v1/models":
            return self._json({"object": "list", "data": [{"id": "gemma-4-e2b", "object": "model"}]})
        self._json({"error": {"message": "not found"}}, 404)

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path != "/v1/chat/completions":
            return self._json({"error": {"message": "not found"}}, 404)
        SEEN_REQUESTS.append(body)
        if body["model"] == "missing-model":
            return self._json({"error": {"message": "model 'missing-model' not found"}}, 404)
        last = body["messages"][-1]["content"]
        assert body["messages"][0]["role"] == "system"
        if not body.get("stream"):
            return self._json({"choices": [{"message": {"role": "assistant", "content": f" echo:{last} "}}]})
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        for tok in ("Here ", "is ", "code"):
            self.wfile.write(("data: " + json.dumps({"choices": [{"delta": {"content": tok}}]}) + "\n\n").encode())
            self.wfile.flush()
        self.wfile.write(b"data: " + json.dumps({"choices": [{"delta": {}, "finish_reason": "stop"}]}).encode() + b"\n\n")
        self.wfile.write(b"data: [DONE]\n\n")


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


PORT = free_port()
SERVER = ThreadingHTTPServer(("127.0.0.1", PORT), FakeLiteRTLM)
threading.Thread(target=SERVER.serve_forever, daemon=True).start()
os.environ["LITERTLM_URL"] = f"http://127.0.0.1:{PORT}"

SCRATCH = Path(tempfile.mkdtemp(prefix="cliai_lt_test_"))
shutil.copytree(PROJECT_ROOT, SCRATCH / "proj", ignore=shutil.ignore_patterns(".git", "__pycache__", "reports"))
ROOT = SCRATCH / "proj"
for sub in ("lib/AI", "lib/Core", "lib", "client"):
    sys.path.insert(0, str(ROOT / sub))

from lib_bejson_AI_ai_dispatch import ai_dispatch_call, PROVIDERS  # noqa: E402
from lib_bejson_AI_bejson_litertlm import (  # noqa: E402
    LiteRTLMServer, LiteRTLMError, get_standard_prompter)
from lib_ai_model_registry import AIModelRegistry  # noqa: E402


class ProviderTests(unittest.TestCase):
    def test_provider_registered(self):
        self.assertIn("litertlm", PROVIDERS)

    def test_server_probes(self):
        srv = LiteRTLMServer(base_url=os.environ["LITERTLM_URL"], log_dir=str(SCRATCH / "logs"))
        self.assertTrue(srv.is_ready())
        self.assertEqual(srv.installed_models(), ["gemma-4-e2b"])
        self.assertTrue(srv.has_model("gemma-4-e2b"))
        self.assertFalse(srv.has_model("nope"))

    def test_setup_async_ready_and_model_check(self):
        srv = LiteRTLMServer(base_url=os.environ["LITERTLM_URL"], log_dir=str(SCRATCH / "logs"))
        self.assertTrue(srv.setup_async("gemma-4-e2b"))
        for _ in range(50):
            if srv.state["phase"] in ("ready", "error"):
                break
            threading.Event().wait(0.1)
        self.assertEqual(srv.state["phase"], "ready", srv.state)
        with self.assertRaises(LiteRTLMError):
            srv.setup("not-served")
        self.assertEqual(srv.state["phase"], "error")

    def test_missing_binary_message(self):
        srv = LiteRTLMServer(base_url=f"http://127.0.0.1:{free_port()}", binary_name="definitely-not-litert-lm")
        with self.assertRaises(LiteRTLMError) as cm:
            srv.start()
        self.assertIn("not found on PATH", str(cm.exception))

    def test_dispatch_success_and_model_default(self):
        r = ai_dispatch_call("litertlm", "ping")
        self.assertTrue(r["success"], r)
        self.assertEqual(r["content"], "echo:ping")
        self.assertEqual(r["model_id"], "gemma-4-e2b")

    def test_dispatch_error_from_server(self):
        r = ai_dispatch_call("litertlm", "ping", model_id="missing-model")
        self.assertFalse(r["success"])
        self.assertIn("not found", r["error"])

    def test_dispatch_passes_params_and_reports_unsupported(self):
        r = ai_dispatch_call("litertlm", "ping", temperature=0.1, max_tokens=33, bogus=1)
        self.assertTrue(r["success"])
        self.assertTrue(any("bogus" in u for u in r["unsupported_params"]))
        self.assertEqual(SEEN_REQUESTS[-1]["max_tokens"], 33)
        self.assertEqual(SEEN_REQUESTS[-1]["temperature"], 0.1)

    def test_stream_yields_deltas(self):
        p = get_standard_prompter()
        self.assertEqual("".join(p.stream(p.build_messages("hi", None, []))), "Here is code")

    def test_stream_error_raises(self):
        p = get_standard_prompter()
        with self.assertRaises(LiteRTLMError):
            list(p.stream(p.build_messages("hi"), model_id="missing-model"))

    def test_not_running_message(self):
        srv = LiteRTLMServer(base_url=f"http://127.0.0.1:{free_port()}", log_dir=str(SCRATCH / "logs"))
        p = get_standard_prompter()
        original = p.server
        p.server = srv
        try:
            self.assertTrue(p.prompt("x").startswith("ERROR: LiteRT-LM server is not running"))
        finally:
            p.server = original


class RegistryTests(unittest.TestCase):
    def test_migration_adds_service_without_touching_existing(self):
        path = SCRATCH / "old_registry.bejson"
        path.write_text(json.dumps({
            "Format": "BEJSON", "Format_Version": "104", "Format_Creator": "Elton Boehnen",
            "Records_Type": ["ModelRecord"],
            "Fields": [{"name": "service", "type": "string"}, {"name": "model_id", "type": "string"},
                       {"name": "model_name", "type": "string"}, {"name": "flag", "type": "string"}],
            "Values": [["Groq", "custom-model", "Custom", None]]}))
        reg = AIModelRegistry(str(path), {}).load()
        self.assertEqual([m["id"] for m in reg.get_models("Groq")], ["custom-model"])
        self.assertEqual([m["id"] for m in reg.get_models("LiteRTLM")], ["gemma-4-e2b"])


class ClientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT / "client"))
        os.chdir(ROOT / "client")
        import importlib
        cls.app_mod = importlib.import_module("app")
        cls.client = cls.app_mod.app.test_client()
        cls.sid = "11111111-2222-4333-8444-666666666666"

    def test_1_stream_chat_and_log(self):
        r = self.client.post("/api/chat/stream", json={
            "message": "write code", "service": "LiteRTLM", "model": "gemma-4-e2b",
            "session_id": self.sid, "service_label": "LiteRT-LM Local"})
        self.assertEqual(r.status_code, 200)
        body = r.get_data(as_text=True)
        deltas = [json.loads(f[5:])["delta"] for f in body.split("\n\n") if f.startswith("data:") and "delta" in f]
        self.assertEqual("".join(deltas), "Here is code")
        self.assertIn('"done": true', body)
        msgs = self.client.get(f"/api/logs/{self.sid}").get_json()["messages"]
        self.assertEqual([m["role"] for m in msgs], ["user", "assistant"])
        self.assertEqual(msgs[1]["sender"], "LiteRT-LM Local")
        self.assertEqual(msgs[1]["content"], "Here is code")

    def test_2_second_turn_sends_history(self):
        self.client.post("/api/chat/stream", json={"message": "again", "service": "LiteRTLM", "session_id": self.sid})
        sent = SEEN_REQUESTS[-1]["messages"]
        self.assertEqual([m["role"] for m in sent], ["system", "user", "assistant", "user"])
        self.assertEqual(len(self.client.get(f"/api/logs/{self.sid}").get_json()["messages"]), 4)

    def test_3_server_not_running_is_503(self):
        original = self.app_mod.LOCAL_STREAM_SERVICES["LiteRTLM"]
        dead = LiteRTLMServer(base_url=f"http://127.0.0.1:{free_port()}")
        self.app_mod.LOCAL_STREAM_SERVICES["LiteRTLM"] = (dead,) + original[1:]
        try:
            r = self.client.post("/api/chat/stream", json={"message": "x", "service": "LiteRTLM"})
            self.assertEqual(r.status_code, 503)
            self.assertIn("LiteRT-LM server is not running", r.get_json()["response"])
        finally:
            self.app_mod.LOCAL_STREAM_SERVICES["LiteRTLM"] = original

    def test_4_wrong_service_and_ollama_still_streams_path(self):
        r = self.client.post("/api/chat/stream", json={"message": "x", "service": "Groq"})
        self.assertEqual(r.status_code, 400)
        self.assertIn("OllamaLocal", r.get_json()["response"])

    def test_5_nonstream_chat(self):
        sid = "aaaaaaaa-bbbb-4ccc-8ddd-ffffffffffff"
        r = self.client.post("/api/chat", json={
            "message": "ping", "service": "LiteRTLM", "session_id": sid, "service_label": "LiteRT-LM Local"})
        self.assertEqual(r.get_json()["status"], "success", r.get_json())
        reply = r.get_json()["response"]
        self.assertTrue(reply.startswith("echo:") and reply.endswith("ping"), reply)

    def test_6_server_endpoints(self):
        st = self.client.get("/api/litertlm/status").get_json()
        self.assertTrue(st["available"] and st["ready"])
        self.assertEqual(st["installed_models"], ["gemma-4-e2b"])
        self.assertTrue(self.client.post("/api/litertlm/setup", json={"model": "gemma-4-e2b"}).get_json()["started"])
        self.assertEqual(self.client.post("/api/litertlm/stop").get_json(), {"stopped": True})

    def test_7_models_endpoint(self):
        data = self.client.get("/api/models?service=LiteRTLM").get_json()
        self.assertEqual(data["source_type"], "hardcoded")
        self.assertEqual([m["id"] for m in data["models"]], ["gemma-4-e2b"])

    def test_8_ui_has_service_and_panel(self):
        html = self.client.get("/").get_data(as_text=True)
        self.assertIn('value="LiteRTLM"', html)
        self.assertIn('id="litertlmSetupBtn"', html)


if __name__ == "__main__":
    try:
        unittest.main(verbosity=2)
    finally:
        shutil.rmtree(SCRATCH, ignore_errors=True)
