"""
Test:           test_ollamalocal.py
Description:    End-to-end tests for the OllamaLocal provider and its chat-client
                integration, run against an in-process fake Ollama server
                (/api/version, /api/tags, /api/pull, /api/chat).
Version:        1.0.0
Date:           2026-10-12
Author:         Elton Boehnen
RELATIONAL_ID:  418bae67-46a4-463a-87d1-2e94e9000786
Run:            python3 dev/tests/ollamalocal/test_ollamalocal.py
"""
import json
import os
import shutil
import socket
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]

# ── fake Ollama ──────────────────────────────────────────────────────────
INSTALLED = ["llama3.2:3b"]


class FakeOllama(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/version":
            return self._json({"version": "0.0-test"})
        if self.path == "/api/tags":
            return self._json({"models": [{"name": n} for n in INSTALLED]})
        self._json({"error": "not found"}, 404)

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path == "/api/pull":
            self.send_response(200)
            self.end_headers()
            for done in (0, 50, 100):
                self.wfile.write((json.dumps({"status": "pulling x", "total": 100, "completed": done}) + "\n").encode())
                self.wfile.flush()
            INSTALLED.append(body["model"])
            self.wfile.write(b'{"status":"success"}\n')
            return
        if self.path == "/api/chat":
            if body["model"] == "missing:1b":
                return self._json({"error": "model 'missing:1b' not found"}, 404)
            last = body["messages"][-1]["content"]
            sys_msg = body["messages"][0]
            assert sys_msg["role"] == "system"
            if not body.get("stream"):
                return self._json({"message": {"role": "assistant", "content": f" echo:{last} "}, "done": True})
            self.send_response(200)
            self.end_headers()
            for tok in ("Here ", "is ", "code"):
                self.wfile.write((json.dumps({"message": {"content": tok}, "done": False}) + "\n").encode())
                self.wfile.flush()
            self.wfile.write((json.dumps({"message": {"content": ""}, "done": True}) + "\n").encode())
            return
        self._json({"error": "not found"}, 404)


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


PORT = free_port()
SERVER = ThreadingHTTPServer(("127.0.0.1", PORT), FakeOllama)
threading.Thread(target=SERVER.serve_forever, daemon=True).start()
os.environ["OLLAMA_LOCAL_URL"] = f"http://127.0.0.1:{PORT}"

# Work on a scratch copy so tests never touch real data/config.
SCRATCH = Path(tempfile.mkdtemp(prefix="cliai_test_"))
shutil.copytree(PROJECT_ROOT, SCRATCH / "proj", ignore=shutil.ignore_patterns(".git", "__pycache__", "reports"))
ROOT = SCRATCH / "proj"
for sub in ("lib/AI", "lib/Core", "lib", "client"):
    sys.path.insert(0, str(ROOT / sub))

from lib_bejson_AI_ai_dispatch import ai_dispatch_call, PROVIDERS  # noqa: E402
from lib_bejson_AI_bejson_ollamalocal import (  # noqa: E402
    OllamaLocalServer, OllamaLocalError, get_standard_prompter, get_standard_server)
from lib_ai_model_registry import AIModelRegistry  # noqa: E402
from lib_bejson_Core_bejson_core import bejson_core_load_file  # noqa: E402


class ProviderTests(unittest.TestCase):
    def test_provider_registered(self):
        self.assertIn("ollamalocal", PROVIDERS)

    def test_server_probes_and_pull(self):
        srv = OllamaLocalServer(base_url=os.environ["OLLAMA_LOCAL_URL"], log_dir=str(SCRATCH / "logs"))
        self.assertTrue(srv.is_ready())
        self.assertTrue(srv.has_model("llama3.2:3b"))
        self.assertFalse(srv.has_model("pull-test:1b"))
        seen = []
        srv.pull_model("pull-test:1b", lambda s, p: seen.append(p))
        self.assertIn(100, seen)
        self.assertTrue(srv.has_model("pull-test:1b"))

    def test_setup_async_reaches_ready(self):
        srv = OllamaLocalServer(base_url=os.environ["OLLAMA_LOCAL_URL"], log_dir=str(SCRATCH / "logs"))
        self.assertTrue(srv.setup_async("qwen2.5-coder:3b"))
        for _ in range(50):
            if srv.state["phase"] in ("ready", "error"):
                break
            threading.Event().wait(0.1)
        self.assertEqual(srv.state["phase"], "ready", srv.state)

    def test_dispatch_success_and_model_default(self):
        r = ai_dispatch_call("ollamalocal", "ping")
        self.assertTrue(r["success"], r)
        self.assertEqual(r["content"], "echo:ping")
        self.assertEqual(r["model_id"], "qwen2.5-coder:1.5b")

    def test_dispatch_error_from_server(self):
        r = ai_dispatch_call("ollamalocal", "ping", model_id="missing:1b")
        self.assertFalse(r["success"])
        self.assertIn("not found", r["error"])

    def test_dispatch_reports_unsupported_config(self):
        r = ai_dispatch_call("ollamalocal", "ping", temperature=0.1, bogus=1)
        self.assertTrue(r["success"])
        self.assertTrue(any("bogus" in u for u in r["unsupported_params"]))

    def test_stream_yields_deltas(self):
        p = get_standard_prompter()
        msgs = p.build_messages("hi", None, [])
        self.assertEqual("".join(p.stream(msgs)), "Here is code")

    def test_stream_error_raises(self):
        p = get_standard_prompter()
        with self.assertRaises(OllamaLocalError):
            list(p.stream(p.build_messages("hi"), model_id="missing:1b"))

    def test_not_running_message(self):
        srv = OllamaLocalServer(base_url=f"http://127.0.0.1:{free_port()}", log_dir=str(SCRATCH / "logs"))
        self.assertFalse(srv.is_ready())
        p = get_standard_prompter()
        original = p.server
        p.server = srv
        try:
            self.assertTrue(p.prompt("x").startswith("ERROR: Local Ollama server is not running"))
        finally:
            p.server = original


class RegistryTests(unittest.TestCase):
    def test_migration_adds_service_without_touching_existing(self):
        path = SCRATCH / "old_registry.bejson"
        path.write_text(json.dumps({
            "Format": "BEJSON", "Format_Version": "104", "Format_Creator": "Elton Boehnen",
            "Records_Type": ["ModelRecord"],
            "Fields": [{"name": "service", "type": "string"}, {"name": "model_id", "type": "string"},
                       {"name": "model_name", "type": "string"}, {"name": "flag", "type": "string"}],
            "Values": [["Groq", "custom-model", "Custom", None]]}))
        reg = AIModelRegistry(str(path), {}).load()
        self.assertEqual([m["id"] for m in reg.get_models("Groq")], ["custom-model"])
        self.assertEqual(len(reg.get_models("OllamaLocal")), 4)
        self.assertEqual(reg.get_model_source_type("OllamaLocal"), "hardcoded")


class ClientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT / "client"))
        os.chdir(ROOT / "client")
        import importlib
        cls.app_mod = importlib.import_module("app")
        cls.client = cls.app_mod.app.test_client()
        cls.sid = "11111111-2222-4333-8444-555555555555"

    def test_1_stream_chat_and_log(self):
        r = self.client.post("/api/chat/stream", json={
            "message": "write code", "service": "OllamaLocal", "model": "qwen2.5-coder:1.5b",
            "session_id": self.sid, "service_label": "Ollama Local"})
        self.assertEqual(r.status_code, 200)
        body = r.get_data(as_text=True)
        deltas = [json.loads(f[5:])["delta"] for f in body.split("\n\n") if f.startswith("data:") and "delta" in f]
        self.assertEqual("".join(deltas), "Here is code")
        self.assertIn('"done": true', body)
        msgs = self.client.get(f"/api/logs/{self.sid}").get_json()["messages"]
        self.assertEqual([m["role"] for m in msgs], ["user", "assistant"])
        self.assertEqual(msgs[1]["sender"], "Ollama Local")
        self.assertEqual(msgs[1]["content"], "Here is code")

    def test_2_second_turn_sends_history(self):
        self.client.post("/api/chat/stream", json={
            "message": "again", "service": "OllamaLocal", "session_id": self.sid})
        msgs = self.client.get(f"/api/logs/{self.sid}").get_json()["messages"]
        self.assertEqual(len(msgs), 4)

    def test_3_logs_list_download_delete(self):
        sessions = self.client.get("/api/logs").get_json()["sessions"]
        self.assertTrue(any(s["id"] == self.sid and s["count"] == 4 for s in sessions))
        dl = self.client.get(f"/api/logs/{self.sid}/download")
        self.assertEqual(dl.status_code, 200)
        doc = json.loads(dl.get_data(as_text=True))
        self.assertEqual((doc["Format"], doc["Format_Version"]), ("BEJSON", "104"))
        self.assertTrue(all(len(row) == len(doc["Fields"]) for row in doc["Values"]))
        self.assertEqual(self.client.delete(f"/api/logs/{self.sid}").get_json(), {"deleted": True})
        self.assertEqual(self.client.get(f"/api/logs/{self.sid}").get_json()["messages"], [])

    def test_4_bad_session_and_wrong_service(self):
        self.assertEqual(self.client.get("/api/logs/../x").status_code, 404)
        self.assertEqual(self.client.get("/api/logs/bad!id").status_code, 400)
        r = self.client.post("/api/chat/stream", json={"message": "x", "service": "Groq"})
        self.assertEqual(r.status_code, 400)

    def test_5_nonstream_chat_logs_too(self):
        sid = "aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee"
        r = self.client.post("/api/chat", json={
            "message": "ping", "service": "OllamaLocal", "session_id": sid, "service_label": "Ollama Local"})
        self.assertEqual(r.get_json()["status"], "success", r.get_json())
        reply = r.get_json()["response"]  # context bubble is prepended by the client
        self.assertTrue(reply.startswith("echo:") and reply.endswith("ping"), reply)
        self.assertEqual(len(self.client.get(f"/api/logs/{sid}").get_json()["messages"]), 2)

    def test_6_local_model_endpoints(self):
        st = self.client.get("/api/ollamalocal/status").get_json()
        self.assertTrue(st["available"] and st["ready"])
        self.assertIn("llama3.2:3b", st["installed_models"])
        self.assertTrue(self.client.post("/api/ollamalocal/setup", json={"model": "qwen2.5-coder:1.5b"}).get_json()["started"])

    def test_7_models_endpoint_lists_ollamalocal(self):
        data = self.client.get("/api/models?service=OllamaLocal").get_json()
        self.assertEqual(data["source_type"], "hardcoded")
        self.assertEqual({m["id"] for m in data["models"]},
                         {"qwen2.5-coder:0.5b", "qwen2.5-coder:1.5b", "qwen2.5-coder:3b", "qwen2.5-coder:7b"})


if __name__ == "__main__":
    try:
        unittest.main(verbosity=2)
    finally:
        shutil.rmtree(SCRATCH, ignore_errors=True)
