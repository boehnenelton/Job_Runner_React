"""
Tool:           test_cli_prompt_openrouter.py
Family:         CLI
Description:    Unit and integration tests for the OpenRouter CLI tool.
Version:        1.0.0
Date:           2026-08-14
Author:         Elton Boehnen
Contact:        eltonboehnen@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  9c2b3d4e-1f8a-4b9c-8e7d-6a5b4c3d2e1f
"""

import unittest
import sys
import os
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = TESTS_DIR.parent.parent
CLI_DIR = PROJECT_ROOT / "CLI" / "openrouter_cli"
CORE_DIR = PROJECT_ROOT / "lib" / "Core"
AI_DIR = PROJECT_ROOT / "lib" / "AI"

for path in [str(PROJECT_ROOT), str(CLI_DIR), str(CORE_DIR), str(AI_DIR)]:
    if path not in sys.path:
        sys.path.insert(0, path)

from lib_bejson_Core_bejson_env import source_env
SECURE_ENV_PATH = "/storage/emulated/0/.env/secure/secureenv_file.py"
source_env(SECURE_ENV_PATH)

from lib_bejson_AI_bejson_openrouter import get_standard_prompter
from lib_bejson_AI_ai_dispatch import ai_dispatch_call


class TestOpenRouterCLI(unittest.TestCase):

    def test_key_loading(self):
        prompter = get_standard_prompter()
        self.assertGreater(len(prompter.key_reg.keys), 0, "No API keys loaded into registry")

    def test_model_registry(self):
        prompter = get_standard_prompter()
        self.assertTrue(bool(prompter.model_reg.active_model_id), "Active model ID is empty")
        self.assertGreater(len(prompter.model_reg.models), 0, "No models found in model registry")

    def test_ai_dispatch_prompt(self):
        prompter = get_standard_prompter()
        active_model = prompter.model_reg.active_model_id
        response = ai_dispatch_call(
            provider="openrouter",
            user_input="Reply with only the word OK.",
            model_id=active_model
        )
        self.assertTrue(response.get("success"), f"Dispatch failed: {response.get('error')}")
        self.assertIn("OK", response.get("content", "").upper())


if __name__ == "__main__":
    unittest.main()