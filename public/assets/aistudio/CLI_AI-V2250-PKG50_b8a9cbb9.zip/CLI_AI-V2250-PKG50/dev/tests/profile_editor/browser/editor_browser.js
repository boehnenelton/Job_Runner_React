/*
 * Name:          editor_browser.js
 * Description:   Drives the profile editor's Edit dialog in Chromium: enter
 *                Embedded Code, see a rejected save explain itself (dialog stays
 *                open, nothing saved), fix it, save, reopen and find it intact,
 *                then clear it. Run against editor_server.py.
 * Version:       1.0.0
 * Date Created:  2026-10-18
 * Author:        Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
 * RELATIONAL_ID: 5d07a1f9-c3e2-4b64-8a10-9f4e6b2d7c83
 * Usage:         node editor_browser.js <base_url>   (needs the global playwright package)
 */
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const base = process.argv[2] || 'http://127.0.0.1:5096';
const failures = [];
const check = (label, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + label); if (!ok) failures.push(label); };
const PY = 'import re\n\ndef parse(raw_text):\n    return {"n": len(re.findall(r"\\w+", raw_text))}\n';
const RENDER = "function render(parsed, container) { container.textContent = 'n=' + parsed.n; }";

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await (await browser.newContext()).newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto(base);
  await page.waitForFunction(() => document.querySelectorAll('#profileSelect option').length >= 1);
  const status = () => page.textContent('#statusText');
  const openEdit = async () => { await page.click('#btnEdit'); await page.waitForSelector('#editModal.active'); };

  await openEdit();
  check('section is on the form, empty for a plain profile',
    (await page.inputValue('#edParserLang')) === '' && (await page.inputValue('#edParserCode')) === '' && (await page.inputValue('#edRendererCode')) === '');

  // rejected save: unsafe import
  await page.selectOption('#edParserLang', 'python');
  await page.fill('#edParserCode', 'import os\n\ndef parse(raw_text):\n    return os.listdir(".")\n');
  await page.click('#btnEditSave');
  await page.waitForFunction(() => /Parser rejected/.test(document.getElementById('statusText').textContent));
  check('rejected: reason is shown', /import not allowed: os/.test(await status()));
  check('rejected: dialog stays open', await page.$eval('#editModal', el => el.classList.contains('active')));
  const onDisk = await (await page.request.get(base + '/api/profiles/default')).json();
  check('rejected: nothing was saved', !('Parser' in onDisk) || !onDisk.Parser);

  // rejected save: JavaScript syntax error
  await page.selectOption('#edParserLang', 'javascript');
  await page.fill('#edParserCode', 'function parse(r { return 1; }');
  await page.click('#btnEditSave');
  await page.waitForFunction(() => /SyntaxError|syntax/i.test(document.getElementById('statusText').textContent));
  check('JS syntax error is reported', true);

  // fixed save
  await page.selectOption('#edParserLang', 'python');
  await page.fill('#edParserCode', PY);
  await page.fill('#edRendererCode', RENDER);
  await page.click('#btnEditSave');
  await page.waitForFunction(() => document.getElementById('statusText').textContent === 'Saved.');
  check('valid code saves; dialog closes', !(await page.$eval('#editModal', el => el.classList.contains('active'))));

  // persisted + reopened intact
  await openEdit();
  check('reopen: language kept', (await page.inputValue('#edParserLang')) === 'python');
  check('reopen: parser kept', (await page.inputValue('#edParserCode')) === PY);
  check('reopen: renderer kept', (await page.inputValue('#edRendererCode')) === RENDER);

  // unrelated edit keeps code
  await page.fill('#edPersona', 'edited persona');
  await page.click('#btnEditSave');
  await page.waitForFunction(() => document.getElementById('statusText').textContent === 'Saved.');
  const after = await (await page.request.get(base + '/api/profiles/default')).json();
  check('unrelated edit leaves code intact', after.Parser === PY && after.Renderer === RENDER && after.Persona === 'edited persona');

  // clear
  await openEdit();
  await page.selectOption('#edParserLang', '');
  await page.fill('#edParserCode', '');
  await page.fill('#edRendererCode', '');
  await page.click('#btnEditSave');
  await page.waitForFunction(() => document.getElementById('statusText').textContent === 'Saved.');
  const cleared = await (await page.request.get(base + '/api/profiles/default')).json();
  check('blank fields clear the code', !cleared.Parser && !cleared.Renderer && !cleared.Parser_Language);

  check('no uncaught page errors', errors.length === 0);
  if (errors.length) console.log(errors.join('\n'));
  await browser.close();
  console.log(failures.length ? '\nFAILED: ' + failures.length : '\nALL PASSED');
  process.exit(failures.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
