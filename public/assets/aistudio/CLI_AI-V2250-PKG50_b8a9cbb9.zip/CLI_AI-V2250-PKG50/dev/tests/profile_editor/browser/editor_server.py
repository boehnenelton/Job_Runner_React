"""
Name:           editor_server.py
Description:    Starts the real profile editor (profiles/app.py) on a scratch
                profiles directory for editor_browser.js. Optional test tooling.
Version:        1.0.0
Date Created:   2026-10-18
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  3b9e5d72-a0c4-4f18-96d3-e8f21c704ab5
Usage:          python3 editor_server.py <port>
"""
import importlib.util
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5096
spec = importlib.util.spec_from_file_location("profiles_editor_app", ROOT / "profiles" / "app.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

scratch = Path(tempfile.mkdtemp(prefix="editor_e2e_"))
mod.PROFILES_DIR = scratch / "profiles"
mod.CONFIG_DIR = scratch / "config"
mod.CONFIG_FILE = mod.CONFIG_DIR / "profile_config.104a.bejson"
mod.ensure_defaults()
try:
    mod.app.run(host="127.0.0.1", port=PORT, threaded=True, use_reloader=False)
finally:
    shutil.rmtree(scratch, ignore_errors=True)
