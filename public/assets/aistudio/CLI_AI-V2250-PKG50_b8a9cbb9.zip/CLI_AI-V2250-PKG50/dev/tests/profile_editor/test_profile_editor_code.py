"""
Name:           test_profile_editor_code.py
Description:    Profile editor (profiles/app.py 2.1.0) Embedded Code support:
                PUT validates Parser_Language / Parser / Renderer before any
                write (422 + file untouched on rejection), appends columns on
                first use, clears on blank, leaves code alone on unrelated
                edits, never writes the lib's field-map cache, and the result
                loads in the chat client's ProfileStore as unapproved code.
Version:        1.0.0
Date Created:   2026-10-18
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  f6a4c8e1-39b2-4d75-8e03-5b7a91d2c640
Run:            python3 dev/tests/profile_editor/test_profile_editor_code.py
"""
import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PY_OK = 'import re\n\ndef parse(raw_text):\n    return {"n": len(re.findall(r"\\w+", raw_text))}\n'
JS_OK = "function parse(raw) { return { n: raw.split(/\\s+/).filter(Boolean).length }; }\n"
RENDER_OK = "function render(parsed, container) { container.textContent = 'n=' + parsed.n; }\n"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class EditorCodeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("profiles_editor_app", ROOT / "profiles" / "app.py")
        cls.mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.mod)
        cls.tmp = Path(tempfile.mkdtemp(prefix="editor_code_"))
        cls.pdir = cls.tmp / "profiles"
        cls.pdir.mkdir()
        cls.mod.PROFILES_DIR = cls.pdir
        cls.client = cls.mod.app.test_client()
        import lib_bejson_AI_gemini_standard_profiles as P
        cls.P = P

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def fresh(self, name):
        shutil.copy(ROOT / "profiles" / "profiles" / "default.bejson", self.pdir / f"{name}.bejson")
        return self.pdir / f"{name}.bejson"

    def put(self, name, body):
        return self.client.put(f"/api/profiles/{name}", json=body)

    def test_01_add_code_to_a_plain_profile(self):
        path = self.fresh("t1")
        r = self.put("t1", {"Parser_Language": "python", "Parser": PY_OK, "Renderer": RENDER_OK})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        doc = json.loads(path.read_text())
        self.assertEqual([f["name"] for f in doc["Fields"]][-3:], ["Parser_Language", "Parser", "Renderer"])
        self.assertTrue(all(len(row) == len(doc["Fields"]) for row in doc["Values"]))
        self.assertNotIn("_bejson_field_map", doc)
        self.assertNotIn("_field_map", doc)
        self.assertTrue(self.P.gemini_profiles_validate(doc))
        got = self.client.get("/api/profiles/t1").get_json()
        self.assertEqual((got["Parser_Language"], got["Parser"], got["Renderer"]), ("python", PY_OK, RENDER_OK))

    def test_02_bad_parser_rejected_and_file_untouched(self):
        path = self.fresh("t2")
        before = sha(path)
        r = self.put("t2", {"Name": "should-not-stick", "Parser_Language": "python",
                            "Parser": "import os\n\ndef parse(raw_text):\n    return os.listdir('.')\n"})
        self.assertEqual(r.status_code, 422)
        self.assertIn("import not allowed", r.get_json()["error"])
        self.assertEqual(sha(path), before, "rejected save must not write anything, even other fields")

    def test_03_bad_renderer_and_bad_language(self):
        path = self.fresh("t3")
        before = sha(path)
        r = self.put("t3", {"Renderer": "function render(p,c){ fetch('http://x'); }"})
        self.assertEqual(r.status_code, 422)
        self.assertIn("Renderer rejected", r.get_json()["error"])
        r = self.put("t3", {"Parser_Language": "ruby", "Parser": "def parse(x); x; end"})
        self.assertEqual(r.status_code, 422)
        self.assertIn("Parser_Language", r.get_json()["error"])
        r = self.put("t3", {"Parser_Language": "", "Parser": PY_OK})   # code but no language
        self.assertEqual(r.status_code, 422)
        self.assertEqual(sha(path), before)

    def test_04_javascript_syntax_error_reported(self):
        import shutil as _sh
        if not _sh.which("node"):
            self.skipTest("node not installed")
        path = self.fresh("t4")
        before = sha(path)
        r = self.put("t4", {"Parser_Language": "javascript", "Parser": "function parse(r { return 1; }"})
        self.assertEqual(r.status_code, 422)
        self.assertIn("SyntaxError", r.get_json()["error"])
        self.assertEqual(sha(path), before)
        r = self.put("t4", {"Parser_Language": "javascript", "Parser": JS_OK, "Renderer": RENDER_OK})
        self.assertEqual(r.status_code, 200)

    def test_05_language_switch_must_match_code(self):
        path = self.fresh("t5")
        self.assertEqual(self.put("t5", {"Parser_Language": "python", "Parser": PY_OK}).status_code, 200)
        before = sha(path)
        r = self.put("t5", {"Parser_Language": "javascript"})      # python code, JS language
        self.assertEqual(r.status_code, 422)
        self.assertEqual(sha(path), before)

    def test_06_unrelated_edit_keeps_code(self):
        path = self.fresh("t6")
        self.put("t6", {"Parser_Language": "python", "Parser": PY_OK, "Renderer": RENDER_OK})
        r = self.put("t6", {"Persona": "changed persona"})
        self.assertEqual(r.status_code, 200)
        got = self.client.get("/api/profiles/t6").get_json()
        self.assertEqual((got["Persona"], got["Parser"], got["Renderer"]), ("changed persona", PY_OK, RENDER_OK))

    def test_07_blank_clears(self):
        path = self.fresh("t7")
        self.put("t7", {"Parser_Language": "python", "Parser": PY_OK, "Renderer": RENDER_OK})
        r = self.put("t7", {"Parser_Language": "", "Parser": "", "Renderer": ""})
        self.assertEqual(r.status_code, 200)
        doc = json.loads(path.read_text())
        self.assertTrue(self.P.gemini_profiles_validate(doc))
        self.assertIsNone(self.P.gemini_profiles_get_parser(doc))
        self.assertIsNone(self.P.gemini_profiles_get_renderer(doc))

    def test_08_blank_on_plain_profile_adds_no_columns(self):
        path = self.fresh("t8")
        r = self.put("t8", {"Persona": "p", "Parser_Language": "", "Parser": "", "Renderer": ""})
        self.assertEqual(r.status_code, 200)
        names = [f["name"] for f in json.loads(path.read_text())["Fields"]]
        self.assertNotIn("Parser", names)

    def test_09_fingerprint_changes_on_edit(self):
        path = self.fresh("t9")
        self.put("t9", {"Parser_Language": "python", "Parser": PY_OK, "Renderer": RENDER_OK})
        fp1 = self.P.gemini_profiles_embedded_fingerprint(json.loads(path.read_text()))
        self.put("t9", {"Renderer": RENDER_OK + "// v2\n"})
        fp2 = self.P.gemini_profiles_embedded_fingerprint(json.loads(path.read_text()))
        self.assertNotEqual(fp1, fp2)

    def test_10_chat_client_sees_editor_output_as_unapproved(self):
        self.fresh("t10")
        self.put("t10", {"Parser_Language": "python", "Parser": PY_OK, "Renderer": RENDER_OK})
        sys.path.insert(0, str(ROOT / "client"))
        from profile_support import ProfileStore
        store = ProfileStore(str(self.pdir), str(self.tmp / "approved.bejson"))
        d = store.detail("t10")
        self.assertTrue(d["has_embedded"])
        self.assertFalse(d["approved"])
        self.assertEqual(d["parser"], PY_OK)

    def test_11_page_has_the_form(self):
        html = self.client.get("/").get_data(as_text=True)
        for needle in ('id="edParserLang"', 'id="edParserCode"', 'id="edRendererCode"',
                       "Parser_Language:", "data['Renderer']"):
            self.assertIn(needle, html)


if __name__ == "__main__":
    sys.path.insert(0, str(ROOT / "lib" / "Core"))
    sys.path.insert(0, str(ROOT / "lib" / "AI"))
    unittest.main(verbosity=1)
