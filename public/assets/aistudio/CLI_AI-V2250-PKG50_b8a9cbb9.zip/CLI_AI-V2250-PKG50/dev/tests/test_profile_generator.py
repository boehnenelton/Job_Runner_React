import json
import subprocess
import sys
from pathlib import Path

# Paths
CLI_ROOT = Path(__file__).resolve().parent
PROFILE_PATH = CLI_ROOT / "profiles" / "profiles" / "profile_generator.bejson"
PROMPT_SCRIPT = CLI_ROOT / "CLI" / "gemini_cli" / "prompt_gemini.py"

def main():
    print("[*] Loading Profile Generator system instruction...")
    try:
        with open(PROFILE_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        # In the AI_Profile 104 schema, System_Instruction is at index 4
        sys_inst = data["Values"][0][4]
    except Exception as e:
        print(f"[!] Error loading profile generator: {e}")
        sys.exit(1)

    prompt_text = "Create a highly logical, stoic AI profile named 'Vulcan'. It must use the requested 104db structured chunk output format."

    cmd = [
        sys.executable,
        str(PROMPT_SCRIPT),
        prompt_text,
        "--system", sys_inst,
        "--once"
    ]

    print(f"[*] Running Gemini CLI test to generate the 'Vulcan' profile...")
    print(f"[*] Target Prompt: \"{prompt_text}\"\n")
    
    try:
        # Run the command interactively so the output streams directly to your console
        subprocess.run(cmd, check=True)
        print("\n[*] Test Complete! If successful, the profile was unpacked into data/structured_output/Vulcan/")
    except subprocess.CalledProcessError as e:
        print(f"\n[!] CLI execution failed with exit code {e.returncode}")
    except KeyboardInterrupt:
        print("\n[!] Test aborted by user.")

if __name__ == "__main__":
    main()
