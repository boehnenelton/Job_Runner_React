"""
Name:           test_profile_parser.py
Description:    Checks the embedded Parser_Language / Parser / Renderer profile
                columns (lib_bejson_AI_gemini_standard_profiles 4.0.0) and the
                runtime library (lib_bejson_AI_profile_parser_runtime 1.0.0):
                schema handling, static validation, fingerprint + approval
                gate, python/javascript parser execution, timeouts, and the
                browser-sandbox host (driven under node with a stub DOM).
                Replaces test_profile_mode.py (the Mode field was removed).
Version:        1.0.0
Date Created:   2026-10-18
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
RELATIONAL_ID:  20ad8a19-bed6-42fb-9bed-0ab51b77f061
Run:            python3 dev/tests/test_profile_parser.py
"""
import copy
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "lib" / "AI"))
sys.path.insert(0, str(ROOT / "lib" / "Core"))

import lib_bejson_AI_gemini_standard_profiles as P
import lib_bejson_AI_profile_parser_runtime as R

failures = []
HAVE_NODE = shutil.which("node") is not None


def check(label, cond):
    print(("PASS " if cond else "FAIL ") + label)
    if not cond:
        failures.append(label)


def names(doc):
    return [f["name"] for f in doc["Fields"]]


PY_OK = 'import re\n\ndef parse(raw_text):\n    return {"n": len(re.findall(r"\\w+", raw_text))}\n'
JS_OK = "function parse(raw) { return { n: raw.split(/\\s+/).filter(Boolean).length }; }\n"
RENDER_OK = "function render(parsed, container) { container.textContent = 'n=' + parsed.n; }\n"

canon_before = json.dumps(P.PROFILE_FIELDS)

# 1. Default profile has none of the new columns and is valid.
plain = P.gemini_profiles_create("a", "arch", "persona", "instr")
check("no optional columns by default", not any(n in names(plain) for n in ("Parser", "Parser_Language", "Renderer")))
check("plain profile validates", P.gemini_profiles_validate(plain))
check("plain: get_parser None / get_renderer None / fingerprint None",
      P.gemini_profiles_get_parser(plain) is None and P.gemini_profiles_get_renderer(plain) is None
      and P.gemini_profiles_embedded_fingerprint(plain) is None)
check("Mode API is gone", not any(hasattr(P, n) for n in ("gemini_profiles_get_mode", "gemini_profiles_set_mode", "PROFILE_MODE_FIELD")))

# 2. Create with embedded code: columns appended last, in order.
py = P.gemini_profiles_create("b", "arch", "persona", "instr",
                              Parser_Language="python", Parser=PY_OK, Renderer=RENDER_OK)
check("columns appended last in order", names(py)[-3:] == ["Parser_Language", "Parser", "Renderer"])
check("row length matches Fields", len(py["Values"][0]) == len(py["Fields"]))
check("optional columns declared string", all(f["type"] == "string" for f in py["Fields"][-3:]))
check("create+validate with embedded code", P.gemini_profiles_validate(py))
check("get_parser returns language+code", P.gemini_profiles_get_parser(py) == {"language": "python", "code": PY_OK})
check("get_renderer returns code", P.gemini_profiles_get_renderer(py) == RENDER_OK)
check("PROFILE_FIELDS not mutated", json.dumps(P.PROFILE_FIELDS) == canon_before)
check("later plain create still column-free", "Parser" not in names(P.gemini_profiles_create("c", "a", "p", "i")))

# 3. Aliases + rejection writes nothing.
alias = copy.deepcopy(plain)
check("language alias 'JS' accepted", P.gemini_profiles_set_parser(alias, "JS", JS_OK))
check("alias stored normalised", P.gemini_profiles_get_parser(alias)["language"] == "javascript")
bad_cases = {
    "python import os": ("python", "import os\n\ndef parse(raw_text):\n    return {}\n"),
    "python open()": ("python", "def parse(raw_text):\n    return open('x').read()\n"),
    "python dunder": ("python", "def parse(raw_text):\n    return ().__class__\n"),
    "python json.codecs": ("python", "import json\n\ndef parse(raw_text):\n    return json.codecs\n"),
    "python no parse": ("python", "def other(x):\n    return x\n"),
    "python syntax error": ("python", "def parse(raw_text:\n    return 1\n"),
    "python parse() no args": ("python", "def parse():\n    return 1\n"),
    "js fetch": ("javascript", "function parse(r){ fetch('http://x'); return {}; }"),
    "js eval": ("javascript", "function parse(r){ return eval(r); }"),
    "js no parse": ("javascript", "function other(r){ return r; }"),
    "js </script": ("javascript", "function parse(r){ return '</script>'; }"),
    "unsupported language": ("ruby", "def parse(x); x; end"),
    "too large": ("python", "def parse(raw_text):\n    return 1\n" + "#" * (R.MAX_CODE_CHARS + 1)),
}
for label, (lang, code) in bad_cases.items():
    victim = copy.deepcopy(plain)
    ok = P.gemini_profiles_set_parser(victim, lang, code)
    check(f"reject {label}", ok is False and "Parser" not in names(victim))
check("reject renderer without render()", P.gemini_profiles_set_renderer(copy.deepcopy(plain), "var x = 1;") is False)
check("reject renderer with fetch", P.gemini_profiles_set_renderer(copy.deepcopy(plain), "function render(p,c){ fetch('x'); }") is False)
try:
    P.gemini_profiles_create("d", "a", "p", "i", Parser_Language="python", Parser="import os")
    check("create with bad parser raises ValueError", False)
except ValueError:
    check("create with bad parser raises ValueError", True)

# 4. set on an existing doc: appended, padded, cache rebuilt; then clear.
doc = copy.deepcopy(plain)
doc["Values"].append(copy.deepcopy(doc["Values"][0]))
P.gemini_profiles_get_field_map(doc)  # prime the in-doc cache
check("set_parser on existing doc", P.gemini_profiles_set_parser(doc, "python", PY_OK))
check("second row null-padded", doc["Values"][1][-2:] == [None, None] or doc["Values"][1][-1] is None)
check("all rows match Fields", all(len(r) == len(doc["Fields"]) for r in doc["Values"]))
fm = P.gemini_profiles_get_field_map(doc)
check("field map sees Parser at its column", doc["Values"][0][fm["Parser"]] == PY_OK)
check("record 1 has no parser", P.gemini_profiles_get_parser(doc, 1) is None)
check("set_parser out-of-range record -> False", P.gemini_profiles_set_parser(doc, "python", PY_OK, 5) is False)
check("clear parser (None)", P.gemini_profiles_set_parser(doc, None, None) and P.gemini_profiles_get_parser(doc) is None)
check("cleared doc still validates", P.gemini_profiles_validate(doc))
fresh = copy.deepcopy(plain)
check("clearing on a column-free doc adds nothing",
      P.gemini_profiles_set_parser(fresh, None, "") and P.gemini_profiles_set_renderer(fresh, None) and "Parser" not in names(fresh))

# 5. validate(): wrong column type, legacy Mode, broken embedded code.
wrong = copy.deepcopy(py)
wrong["Fields"][-2]["type"] = "integer"
wrong["Values"][0][-2] = 3
wrong.pop("_bejson_field_map", None)
check("Parser declared integer -> invalid", P.gemini_profiles_validate(wrong) is False)

legacy = copy.deepcopy(plain)
legacy["Fields"].append({"name": "Mode", "type": "string"})
legacy["Values"][0].append("structured_output")
legacy.pop("_bejson_field_map", None)
check("legacy Mode column (string) still validates", P.gemini_profiles_validate(legacy))
check("legacy Mode is ignored by the new API", P.gemini_profiles_get_parser(legacy) is None)
legacy["Fields"][-1]["type"] = "integer"
legacy["Values"][0][-1] = 1
legacy.pop("_bejson_field_map", None)
check("legacy Mode declared integer -> invalid", P.gemini_profiles_validate(legacy) is False)

tampered = copy.deepcopy(py)
tampered["Values"][0][-2] = "import os\n\ndef parse(raw_text):\n    return {}\n"
tampered.pop("_bejson_field_map", None)
check("hand-edited bad code makes validate() fail", P.gemini_profiles_validate(tampered) is False)
check("validate_embedded lists the problem", any("import not allowed" in e for e in P.gemini_profiles_validate_embedded(tampered)))
orphan = copy.deepcopy(plain)
P.gemini_profiles_set_parser(orphan, "python", PY_OK)
orphan["Values"][0][P.gemini_profiles_get_field_map(orphan)["Parser"]] = None
check("Parser_Language without Parser is a problem", any("Parser is empty" in e for e in P.gemini_profiles_validate_embedded(orphan)))

# 6. Fingerprint + load + approval.
fp = P.gemini_profiles_embedded_fingerprint(py)
check("fingerprint is sha256 hex", bool(re.fullmatch(r"[0-9a-f]{64}", fp or "")))
check("fingerprint stable", fp == P.gemini_profiles_embedded_fingerprint(copy.deepcopy(py)))
edited = copy.deepcopy(py)
P.gemini_profiles_set_renderer(edited, RENDER_OK + "// edit\n")
check("editing the renderer changes the fingerprint", P.gemini_profiles_embedded_fingerprint(edited) != fp)
ld = P.gemini_profiles_load_embedded(py)
check("load: valid + has_embedded + not approved", ld["success"] and ld["has_embedded"] and not ld["approved"] and ld["fingerprint"] == fp)
check("load: approved when fingerprint pinned", P.gemini_profiles_load_embedded(py, [fp])["approved"] is True)
check("load: other fingerprint is not approval", P.gemini_profiles_load_embedded(py, ["0" * 64])["approved"] is False)
check("load: plain profile has_embedded False", P.gemini_profiles_load_embedded(plain)["has_embedded"] is False)
check("load: tampered profile reports errors", P.gemini_profiles_load_embedded(tampered)["success"] is False)

# 7. Approval gate + execution.
r = P.gemini_profiles_run_parser(py, "one two three", [])
check("run refused when unapproved", r["success"] is False and "not approved" in r["reason"] and r["fingerprint"] == fp)
r = P.gemini_profiles_run_parser(py, "one two three", [fp])
check("python parser runs when approved", r["success"] and r["result"] == {"n": 3})
check("run refused for tampered code even if 'approved'",
      P.gemini_profiles_run_parser(tampered, "x", [P.gemini_profiles_embedded_fingerprint(tampered)])["success"] is False)
check("run refused on a profile with no code", P.gemini_profiles_run_parser(plain, "x", [])["success"] is False)

loop = R.runtime_run_python_parser("def parse(raw_text):\n    while True:\n        pass\n", "x", timeout=1.0)
check("python infinite loop times out", loop["success"] is False and ("timed out" in loop["reason"] or "CPU" in loop["reason"] or "no result" in loop["reason"]))
boom = R.runtime_run_python_parser("def parse(raw_text):\n    return 1 / 0\n", "x")
check("python exception reported", boom["success"] is False and "ZeroDivisionError" in boom["reason"])
nonjson = R.runtime_run_python_parser("def parse(raw_text):\n    return {1, 2}\n", "x")
check("python non-JSON result rejected", nonjson["success"] is False)
cls = R.runtime_run_python_parser("class A:\n    pass\n\ndef parse(raw_text):\n    return {'ok': isinstance(A(), A)}\n", "x")
check("python class definitions work", cls["success"] and cls["result"] == {"ok": True})
check("python input cap enforced", R.runtime_run_python_parser(PY_OK, "x" * (R.MAX_INPUT_CHARS + 1))["success"] is False)

if HAVE_NODE:
    js = P.gemini_profiles_create("e", "a", "p", "i", Parser_Language="javascript", Parser=JS_OK, Renderer=RENDER_OK)
    jfp = P.gemini_profiles_embedded_fingerprint(js)
    jr = P.gemini_profiles_run_parser(js, "one two three four", [jfp])
    check("javascript parser runs under node vm", jr["success"] and jr["result"] == {"n": 4})
    check("javascript parser refused when unapproved", P.gemini_profiles_run_parser(js, "x", [])["success"] is False)
    jloop = R.runtime_run_javascript_parser("function parse(r){ while(true){} }", "x", timeout=1.0)
    check("javascript infinite loop times out", jloop["success"] is False)
    jboom = R.runtime_run_javascript_parser("function parse(r){ throw new Error('nope'); }", "x")
    check("javascript exception reported", jboom["success"] is False and "nope" in jboom["reason"])
    jglobals = R.runtime_run_javascript_parser("function parse(r){ return typeof process + typeof require; }", "x")
    check("vm context has no process/require", jglobals["success"] and jglobals["result"] == "undefinedundefined")
    check("syntax check catches a JS syntax error", R.runtime_javascript_syntax_error("function parse(r { return 1; }") is not None)
    check("syntax check passes good JS", R.runtime_javascript_syntax_error(JS_OK) is None)
    bad_syntax = copy.deepcopy(plain)
    bad_syntax["Fields"] += [{"name": "Parser_Language", "type": "string"}, {"name": "Parser", "type": "string"}]
    bad_syntax["Values"][0] += ["javascript", "function parse(r { return 1; }"]
    bad_syntax.pop("_bejson_field_map", None)
    check("load_embedded flags JS syntax error", P.gemini_profiles_load_embedded(bad_syntax)["success"] is False)
else:
    print("SKIP javascript execution tests (node not installed)")

# 8. Browser sandbox host.
sb = P.gemini_profiles_build_sandbox(py, [])
check("sandbox refused when unapproved", sb["success"] is False and sb["srcdoc"] == "")
sb = P.gemini_profiles_build_sandbox(py, [fp])
doc_html = sb["srcdoc"]
check("sandbox builds when approved", sb["success"] and sb["iframe_attributes"] == 'sandbox="allow-scripts"')
check("srcdoc carries a no-network CSP", "default-src 'none'" in doc_html and "connect-src" not in doc_html)
check("python parser source is NOT placed in the browser", "findall" not in doc_html and RENDER_OK.strip() in doc_html)
check("srcdoc only has inline script blocks", len(re.findall(r"<script>", doc_html)) == 3 and "src=" not in doc_html)
try:
    R.sandbox_build_srcdoc("javascript", "function parse(r){ return '</script><b>'; }", None)
    check("srcdoc builder rejects </script injection", False)
except ValueError:
    check("srcdoc builder rejects </script injection", True)


def drive_sandbox(srcdoc, events):
    """Runs the srcdoc's three script blocks in node with a stub DOM, delivers
    *events* and returns what the iframe posted to its parent + the root node."""
    scripts = re.findall(r"<script>(.*?)</script>", srcdoc, re.S)
    harness = r"""
const vm = require('vm'); const fs = require('fs');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const sent = []; const handlers = [];
function mk(tag) { return { tag: tag, textContent: '', children: [], style: {},
  appendChild(c) { this.children.push(c); return c; } }; }
const root = mk('div');
const parentWin = { postMessage: (m) => sent.push(m) };
const win = { parent: parentWin, addEventListener: (t, f) => handlers.push(f) };
const doc = { getElementById: () => root, createElement: mk, documentElement: { scrollHeight: 42 } };
const ctx = vm.createContext({ window: win, document: doc, JSON, String });
input.scripts.forEach(s => { try { vm.runInContext(s, ctx); } catch (e) { sent.push({ type: 'load-error', message: String(e) }); } });
input.events.forEach(e => handlers.forEach(h => h({ source: e.foreign ? {} : parentWin, data: e.data })));
const strip = n => ({ tag: n.tag, text: n.textContent, children: n.children.map(strip) });
process.stdout.write(JSON.stringify({ sent: sent, root: strip(root) }));
"""
    out = subprocess.run(["node", "-e", harness], input=json.dumps({"scripts": scripts, "events": events}),
                         capture_output=True, text=True, timeout=20)
    return json.loads(out.stdout)


if HAVE_NODE:
    # python parser: parent parses, iframe renders.
    res = drive_sandbox(doc_html, [{"data": {"type": "render", "parsed": {"n": 7}}}])
    check("sandbox: ready is announced", res["sent"][0] == {"type": "ready"})
    check("sandbox: renderer draws a parsed value", res["root"]["text"] == "n=7")
    check("sandbox: rendered message carries height", {"type": "rendered", "height": 42} in res["sent"])
    res = drive_sandbox(doc_html, [{"data": {"type": "run", "raw": "x"}}])
    check("sandbox: 'run' without a JS parser is an error", any(m.get("type") == "error" and m.get("stage") == "parse" for m in res["sent"]))
    res = drive_sandbox(doc_html, [{"foreign": True, "data": {"type": "render", "parsed": {"n": 1}}}])
    check("sandbox: messages from another window are ignored", res["root"]["text"] == "" and len(res["sent"]) == 1)

    # javascript parser: iframe parses and renders.
    jsb = P.gemini_profiles_build_sandbox(js, [jfp])
    res = drive_sandbox(jsb["srcdoc"], [{"data": {"type": "run", "raw": "a b c"}}])
    check("sandbox: JS parser + renderer end to end", res["root"]["text"] == "n=3")
    thrower = R.sandbox_build_srcdoc("javascript", "function parse(r){ throw new Error('bad'); }", RENDER_OK)
    res = drive_sandbox(thrower, [{"data": {"type": "run", "raw": "x"}}])
    check("sandbox: parser exception is reported, not thrown",
          any(m.get("type") == "error" and m.get("stage") == "parse" and "bad" in m["message"] for m in res["sent"]))
    noview = R.sandbox_build_srcdoc("javascript", JS_OK, None)
    res = drive_sandbox(noview, [{"data": {"type": "run", "raw": "a b"}}])
    check("sandbox: no Renderer falls back to JSON text", '"n": 2' in res["root"]["text"])

# 9. Save / reload round trip.
with tempfile.TemporaryDirectory() as d:
    path = str(Path(d) / "p.bejson")
    P.gemini_profiles_save(py, path)
    back = json.loads(Path(path).read_text())
    check("round trip validates", P.gemini_profiles_validate(back))
    check("round trip keeps parser + renderer + fingerprint",
          P.gemini_profiles_get_parser(back) == P.gemini_profiles_get_parser(py)
          and P.gemini_profiles_get_renderer(back) == RENDER_OK
          and P.gemini_profiles_embedded_fingerprint(back) == fp)

# 10. Every shipped profile validates; the two examples run end to end.
SAMPLE = "- Alpha | first\n- Beta\nnot a list line\n- Gamma | third"
EXPECT = {"items": [{"title": "Alpha", "detail": "first"}, {"title": "Beta", "detail": ""}, {"title": "Gamma", "detail": "third"}]}
for f in sorted((ROOT / "profiles").rglob("*.bejson")):
    try:
        d = json.loads(f.read_text())
    except Exception:
        continue
    if d.get("Records_Type") == ["AI_Profile"] and any(x["name"] == "System_Instruction" for x in d["Fields"]):
        check(f"shipped profile validates: {f.relative_to(ROOT)}", P.gemini_profiles_validate(d))
for stem in ("example_parser_python", "example_parser_javascript"):
    d = json.loads((ROOT / "profiles" / "profiles" / f"{stem}.bejson").read_text())
    pfp = P.gemini_profiles_embedded_fingerprint(d)
    if stem.endswith("javascript") and not HAVE_NODE:
        continue
    out = P.gemini_profiles_run_parser(d, SAMPLE, [pfp])
    check(f"{stem}: parses the sample list", out["success"] and out["result"] == EXPECT)

# 11. The editor's PUT path (iterates the file's own field map) must not drop the new columns.
d = json.loads((ROOT / "profiles" / "profiles" / "example_parser_python.bejson").read_text())
fmap = {f["name"]: i for i, f in enumerate(d["Fields"])}
row = d["Values"][0]
for k in ("Persona", "Verbosity"):
    row[fmap[k]] = "edited"
check("editing other columns leaves embedded code intact", P.gemini_profiles_get_parser(d) is not None and P.gemini_profiles_validate(d))

print("\nFAILED: %d" % len(failures) if failures else "\nALL PASSED")
sys.exit(1 if failures else 0)
