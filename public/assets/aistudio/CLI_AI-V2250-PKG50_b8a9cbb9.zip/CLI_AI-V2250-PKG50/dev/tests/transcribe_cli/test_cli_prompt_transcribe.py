"""
Tool:           test_cli_prompt_transcribe.py
Family:         CLI
Description:    Unit and integration tests for the Gemini transcription
                 library and CLI tool.
Version:        1.0.0
Date:           2026-09-03
Author:         Elton Boehnen
Contact:        boehnenelton2024@gmail.com
Format_Creator: Elton Boehnen
"""

import shutil
import subprocess
import unittest
import sys
import os
from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = TESTS_DIR.parent.parent
CLI_DIR = PROJECT_ROOT / "CLI" / "transcribe_cli"
CORE_DIR = PROJECT_ROOT / "lib" / "Core"
AI_DIR = PROJECT_ROOT / "lib" / "AI"

for path in [str(PROJECT_ROOT), str(CLI_DIR), str(CORE_DIR), str(AI_DIR)]:
    if path not in sys.path:
        sys.path.insert(0, path)

from lib_bejson_Core_bejson_env import source_env
SECURE_ENV_PATH = "/storage/emulated/0/.env/secure/secureenv_file.py"
source_env(SECURE_ENV_PATH)

from lib_bejson_AI_bejson_gemini_transcribe import (
    clean_domain_terminology,
    detect_media_mime_type,
    get_standard_transcribe_api,
)
from lib_bejson_AI_bejson_errors import TranscribeUnsupportedMediaError
from lib_bejson_AI_ai_transcribe_dispatch import ai_transcribe_dispatch


class TestDomainCleanup(unittest.TestCase):
    """Pure-function tests -- no API keys or network required."""

    def test_bejson_misspellings_corrected(self):
        self.assertEqual(clean_domain_terminology("we use BJSON for config"), "we use BEJSON for config")
        self.assertEqual(clean_domain_terminology("the B JAON format"), "the BEJSON format")

    def test_behtml_misspellings_corrected(self):
        self.assertEqual(clean_domain_terminology("rendered with beHTML"), "rendered with BEHTML")

    def test_mfdb_misspelling_corrected(self):
        self.assertEqual(clean_domain_terminology("stored in MDFB"), "stored in MFDB")

    def test_format_misspellings_corrected(self):
        self.assertEqual(clean_domain_terminology("exported as 140B"), "exported as 104db")

    def test_author_name_corrected(self):
        self.assertEqual(clean_domain_terminology("built by Elton Bonin"), "built by Elton Boehnen")

    def test_clean_text_passes_through_unchanged(self):
        text = "This transcript already uses BEJSON and BEHTML correctly."
        self.assertEqual(clean_domain_terminology(text), text)

    def test_empty_string(self):
        self.assertEqual(clean_domain_terminology(""), "")


class TestMediaTypeDetection(unittest.TestCase):

    def test_known_audio_extension(self):
        self.assertEqual(detect_media_mime_type("clip.mp3"), "audio/mpeg")
        self.assertEqual(detect_media_mime_type("clip.wav"), "audio/wav")

    def test_known_video_extension(self):
        self.assertEqual(detect_media_mime_type("clip.mp4"), "video/mp4")
        self.assertEqual(detect_media_mime_type("clip.mkv"), "video/x-matroska")

    def test_unknown_extension_raises(self):
        with self.assertRaises(TranscribeUnsupportedMediaError):
            detect_media_mime_type("clip.xyz")

    def test_case_insensitive(self):
        self.assertEqual(detect_media_mime_type("CLIP.MP3"), "audio/mpeg")


class TestRegistryLoading(unittest.TestCase):
    """Reuses gemini.py's own key/model registries -- confirms the
    transcription API shares that same live configuration."""

    def test_key_loading(self):
        api = get_standard_transcribe_api()
        self.assertGreater(len(api.keys.keys), 0, "No Gemini API keys loaded into registry")

    def test_model_registry(self):
        api = get_standard_transcribe_api()
        self.assertTrue(bool(api.models.active_model_id), "Active model ID is empty")


class TestDispatchInputValidation(unittest.TestCase):
    """Confirms bad input comes back as AIResponse(success=False, ...)
    rather than raising, per ai_transcribe_dispatch()'s contract."""

    def test_missing_file_is_reported_not_raised(self):
        response = ai_transcribe_dispatch("gemini", "/tmp/does_not_exist_1234.mp3")
        self.assertFalse(response.get("success"))
        self.assertIn("not found", response.get("error", "").lower())

    def test_unknown_provider_raises_value_error(self):
        with self.assertRaises(ValueError):
            ai_transcribe_dispatch("not_a_real_provider", "/tmp/whatever.mp3")


class TestGeminiRestProvider(unittest.TestCase):
    """gemini_rest provider against a local mock endpoint (no keys, no network, no SDK)."""

    @classmethod
    def setUpClass(cls):
        import json, threading, http.server
        import lib_bejson_AI_bejson_gemini_rest_transcribe as rest

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                part = body["contents"][0]["parts"][0]["inline_data"]
                ok = self.headers.get("x-goog-api-key") == "fake-key" and part["mime_type"] == "audio/wav"
                out = json.dumps({"candidates": [{"content": {"parts": [{"text": "hello BJSON"}]}}]}
                                 if ok else {"error": "bad"}).encode()
                self.send_response(200 if ok else 403)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(out)

            def log_message(self, *a):
                pass

        class FakeKeys:
            keys = ["fake-key"]

        class FakeModels:
            active_model_id = "test-model"

        cls.rest = rest
        cls.server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls._old_url, cls._old_single = rest.REST_BASE_URL, rest._rest_singleton
        rest.REST_BASE_URL = f"http://127.0.0.1:{cls.server.server_port}/v1beta/models"
        rest._rest_singleton = rest.GeminiRestTranscribeAPI(FakeKeys(), FakeModels())
        cls.wav = TESTS_DIR / "transcribe_cli" / "_rest_test.wav"
        cls.wav.write_bytes(b"RIFF....WAVEfake")

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.rest.REST_BASE_URL, cls.rest._rest_singleton = cls._old_url, cls._old_single
        cls.wav.unlink(missing_ok=True)

    def test_provider_registered(self):
        from lib_bejson_AI_ai_transcribe_dispatch import PROVIDERS
        self.assertIn("gemini_rest", PROVIDERS)

    def test_rest_transcription_and_domain_cleanup(self):
        response = ai_transcribe_dispatch("gemini_rest", self.wav)
        self.assertTrue(response.get("success"), response.get("error"))
        self.assertEqual(response["content"], "hello BEJSON")
        self.assertEqual(response["provider"], "gemini_rest")

    def test_rest_http_error_is_reported_not_raised(self):
        self.rest._rest_singleton.keys.keys[:] = ["wrong-key"]
        try:
            response = ai_transcribe_dispatch("gemini_rest", self.wav)
        finally:
            self.rest._rest_singleton.keys.keys[:] = ["fake-key"]
        self.assertFalse(response.get("success"))
        self.assertIn("403", response.get("error", ""))

    def test_rest_missing_file_reported(self):
        response = ai_transcribe_dispatch("gemini_rest", "/tmp/does_not_exist_1234.wav")
        self.assertFalse(response.get("success"))
        self.assertIn("not found", response.get("error", "").lower())


@unittest.skipUnless(shutil.which("ffmpeg"), "ffmpeg not installed -- skipping live transcription test")
class TestLiveTranscription(unittest.TestCase):
    """Generates a short silent WAV via ffmpeg and sends it through a real
    transcription call. Skipped automatically if ffmpeg isn't on PATH."""

    @classmethod
    def setUpClass(cls):
        cls.tmp_wav = TESTS_DIR / "transcribe_cli" / "_silence_test.wav"
        subprocess.run(
            ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
             "-f", "lavfi", "-i", "anullsrc=r=16000:cl=mono", "-t", "2", str(cls.tmp_wav)],
            check=True,
        )

    @classmethod
    def tearDownClass(cls):
        if cls.tmp_wav.exists():
            cls.tmp_wav.unlink()

    def test_transcribe_silence_does_not_error(self):
        response = ai_transcribe_dispatch("gemini", self.tmp_wav, mode="verbatim")
        self.assertTrue(response.get("success"), f"Dispatch failed: {response.get('error')}")


if __name__ == "__main__":
    unittest.main()
