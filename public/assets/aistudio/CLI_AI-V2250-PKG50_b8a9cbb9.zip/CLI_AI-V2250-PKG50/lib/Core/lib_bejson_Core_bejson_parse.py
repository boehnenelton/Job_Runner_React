"""
Library:         lib_bejson_Core_bejson_parse.py
Family:          Core
Module Purpose:  Tolerant JSON extraction from raw text and project-file extraction/saving from a parsed BEJSON document.
Architecture:    Format-level BEJSON layer that works on any BEJSON document (104, 104a, 104db) through positional Fields/Values and the field-map cache. It does not orchestrate MFDB and is not specific to 104db.
Format_Scope:    104 | 104a | 104db (generic)
Glossary:        BEJSON 104, 104a and 104db are the three file formats (Format_Version). 104db = ONE file holding 2+ entity types
                 (Record_Type_Parent discriminator, null-padding). MFDB is NOT a format and NOT 104db: it is a layer made of one 104a manifest
                 (104a.mfdb.bejson) plus dense 104 entity files linked by Parent_Hierarchy. MFDB-132 = an MFDB packed into one Chunked-104a document.
Version:         2.1.4
Release_Version: 300
Date:            2026-10-02
Author:          Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
Format_Creator:  Elton Boehnen
RELATIONAL_ID:   97a21bc4-8933-4d94-92b0-9bf36d2aeb94
"""

import datetime
import json
import os
import shutil
import tempfile
import zipfile
from pathlib import Path

# ------------------------------------------------------------------
# BEJSON ecosystem — core + validator sourced here
# ------------------------------------------------------------------
from lib_bejson_Core_bejson_core import (
    BEJSONCoreError,
    bejson_core_is_valid,
    bejson_core_get_version,
    bejson_core_get_stats,
)
from lib_bejson_Core_bejson_validator import (
    BEJSONValidationError,
    bejson_validator_validate_string,
    bejson_validator_get_report,
)

# Default output dir
_SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT  = os.path.join(_SCRIPT_DIR, "output")

# ------------------------------------------------------------------
# ATOMIC WRITE HELPER
# ------------------------------------------------------------------

# Writes text to a file atomically (temp file + fsync + rename).
def _atomic_write_text(file_path: str, content: str) -> None:
    """Write text to file_path atomically with fsync."""
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    temp_dir = str(path.parent)
    fd, tmp_path = tempfile.mkstemp(dir=temp_dir, suffix=".tmp", prefix=".parse_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as tmp:
            tmp.write(content)
            tmp.flush()
            os.fsync(tmp.fileno())
        os.rename(tmp_path, file_path)
        # fsync the directory
        dir_fd = os.open(str(path.parent), os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    except Exception:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise

# ------------------------------------------------------------------
# PARSER CORE (Best Practices - No Regex)
# ------------------------------------------------------------------

# Extracts and parses a JSON object from raw text using string methods and json; returns None if no JSON can be recovered.
def parse_json(text):
    """Extract and parse JSON using strictly string methods and json module."""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            return json.loads(text[start:end+1])
        raise

# Reads a project-style BEJSON document (Fields/Values) and returns the project metadata plus the file rows as dicts.
def extract_data(data):
    fields = data.get("Fields", [])
    values = data.get("Values", [])
    if not values:
        return "My_Project", []

    f_map = {}
    for i, f in enumerate(fields):
        # Non-regex sanitization: alphanumeric only
        name = f["name"].lower()
        key = "".join([c for c in name if c.isalnum()])
        f_map[key] = i

    # Nested helper: value of one named field in a row via the field map (None when absent).
    def get_val(row, key):
        idx = f_map.get(key)
        if idx is not None and idx < len(row):
            v = row[idx]
            if v is not None:
                return str(v).strip()
        return None

    project_name = "My_Project"
    for row in values:
        for key in ("projectname", "zipfilename", "containername"):
            v = get_val(row, key)
            if v:
                project_name = v
                break
        if project_name != "My_Project":
            break

    # Non-regex sanitization for filesystem safety
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        project_name = project_name.replace(char, '_')

    files = []
    for row in values:
        for i in range(1, 51):
            fname = get_val(row, "file" + str(i) + "name")
            fcont = get_val(row, "file" + str(i) + "content")
            if fname and fcont:
                files.append({"name": fname, "content": fcont})

    return project_name, files

from lib_bejson_Core_bejson_path_guard import bejson_safe_join

# Writes the extracted project files under the configured output path, with a boundary check on every relative path.
def save_files(proj, files, cfg):
    base_dir = cfg.get("output_path") or DEFAULT_OUT
    if not os.path.isdir(base_dir):
        try:
            os.makedirs(base_dir, exist_ok=True)
        except Exception as e:
            return {"success": False, "message": "Cannot create output dir: " + str(e)}

    overwrite = cfg.get("overwrite_enabled", False)

    if overwrite:
        target     = os.path.join(base_dir, proj)
        bak_target = os.path.join(base_dir, proj + "_BACKUP")
        if os.path.exists(target):
            if os.path.exists(bak_target):
                shutil.rmtree(bak_target, ignore_errors=True)
            try:
                shutil.copytree(target, bak_target)
            except Exception as e:
                print("Backup warning: " + str(e))
    else:
        ts     = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        target = os.path.join(base_dir, ts + "_" + proj)

    try:
        # Resolve and guard target path
        target = os.path.abspath(target)
        os.makedirs(target, exist_ok=True)

        for f in files:
            # Assert boundary prefixes via safe_join
            fpath = bejson_safe_join(target, f["name"])
            _atomic_write_text(fpath, f["content"])

        # Build report
        ts_now   = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        mode_str = "Merge/Update (overwrite)" if overwrite else "Timestamped (new folder)"
        lines    = []
        lines.append("=" * 52)
        lines.append("  STRUCTURED PARSER — BUILD REPORT")
        lines.append("=" * 52)
        lines.append("Project    : " + proj)
        lines.append("Generated  : " + ts_now)
        lines.append("Mode       : " + mode_str)
        lines.append("Output Dir : " + target)
        lines.append("Files      : " + str(len(files)))
        lines.append("-" * 52)
        lines.append("FILE LIST")
        lines.append("-" * 52)
        for idx, f in enumerate(files):
            size_b = len(f["content"].encode("utf-8"))
            if size_b >= 1024:
                size_s = str(round(size_b / 1024.0, 1)) + " KB"
            else:
                size_s = str(size_b) + " B"
            lines.append("  [" + str(idx + 1).zfill(2) + "] " + f["name"] + "  (" + size_s + ")")
        lines.append("-" * 52)
        lines.append("Zip        : " + proj + "_update.zip")
        lines.append("=" * 52)
        report_text = "\n".join(lines) + "\n"

        # Write report to disk atomically
        report_path = os.path.join(target, "_REPORT.txt")
        _atomic_write_text(report_path, report_text)

        # Build zip
        zip_path = os.path.join(target, proj + "_update.zip")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in files:
                zf.writestr(f["name"], f["content"])
            zf.writestr("_REPORT.txt", report_text)

        return {
            "success":    True,
            "message":    "Saved " + str(len(files)) + " file(s)",
            "path":       target,
            "file_count": len(files),
        }

    except Exception as e:
        return {"success": False, "message": str(e)}