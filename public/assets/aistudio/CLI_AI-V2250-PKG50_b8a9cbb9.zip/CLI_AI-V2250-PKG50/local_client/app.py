"""
Module:         app.py
Component of:   CLI_AI Local Chat Client (local_client/)
Description:    Dedicated on-device local LLM client for Ollama Local and LiteRT-LM Local
                with Hamburger Sidebar navigation and SSE token streaming.
Version:        1.0.0
Date:           2026-11-02
Author:         Elton Boehnen
Contact:        boehnenelton2024@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
"""

import os
import sys
import json
import time
import threading
import subprocess
import logging
from flask import Flask, render_template, request, jsonify, Response, send_file

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_DIR = os.path.join(BASE_DIR, 'static')
DATA_DIR = os.path.join(BASE_DIR, 'data')
CONFIG_DIR = os.path.join(BASE_DIR, 'config')

os.makedirs(os.path.join(DATA_DIR, 'chat_logs'), exist_ok=True)
os.makedirs(os.path.join(DATA_DIR, 'logs'), exist_ok=True)

def load_bejson_config(config_path):
    if not os.path.exists(config_path):
        return {}
    with open(config_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if "Values" not in data or not data["Values"]:
        return {}
    config = {}
    fields = [f["name"] for f in data.get("Fields", [])]
    for row in data["Values"]:
        setting_name = None
        setting_val = None
        for i, field_name in enumerate(fields):
            if i < len(row):
                if field_name == "setting_name":
                    setting_name = row[i]
                elif field_name == "setting_value":
                    setting_val = row[i]
        if setting_name:
            config[setting_name] = setting_val
    return config

from client_constants import load_client_constants
CLIENT_CONSTANTS = load_client_constants(CONFIG_DIR)

CONFIG_PATH = os.path.join(CONFIG_DIR, 'config.json')
APP_CONFIG = load_bejson_config(CONFIG_PATH)

lib_path = APP_CONFIG.get("library_path", "../lib/")
if lib_path:
    if not os.path.isabs(lib_path):
        lib_path = os.path.abspath(os.path.join(BASE_DIR, lib_path))
    if os.path.exists(lib_path) and lib_path not in sys.path:
        sys.path.insert(0, lib_path)
    for _sub in ("AI", "Core"):
        _sub_path = os.path.join(lib_path, _sub)
        if os.path.exists(_sub_path) and _sub_path not in sys.path:
            sys.path.insert(0, _sub_path)

_client_logger = logging.getLogger("cli_ai.local_client")
logging.basicConfig(level=logging.INFO)

# AI Model Registry for local models
REGISTRY_PATH = os.path.abspath(os.path.join(BASE_DIR, '..', 'lib', 'ai_model_registry.bejson'))
try:
    from lib_ai_model_registry import AIModelRegistry
    MODEL_REGISTRY = AIModelRegistry(REGISTRY_PATH, {})
    MODEL_REGISTRY.load()
except Exception as _re:
    MODEL_REGISTRY = None
    _client_logger.warning("AIModelRegistry load failed (%s) - using static model list.", _re)

# Chat Log Store
from chat_logs import ChatLogStore, valid_session_id
CHAT_LOGS = ChatLogStore(os.path.join(DATA_DIR, 'chat_logs'))

# Local Server: Ollama Local (integrated directly in local_client with library fallback)
try:
    from ollama_local import (
        get_standard_server as _get_ollamalocal_server,
        get_standard_prompter as _get_ollamalocal_prompter,
    )
    OLLAMA_LOCAL_SERVER = _get_ollamalocal_server(log_dir=os.path.join(DATA_DIR, 'logs'))
except Exception as _oe:
    try:
        from lib_bejson_AI_bejson_ollamalocal import (
            get_standard_server as _get_ollamalocal_server,
            get_standard_prompter as _get_ollamalocal_prompter,
        )
        OLLAMA_LOCAL_SERVER = _get_ollamalocal_server(log_dir=os.path.join(DATA_DIR, 'logs'))
    except ImportError as _ie:
        OLLAMA_LOCAL_SERVER = None
        _get_ollamalocal_prompter = None
        _client_logger.warning("Ollama local integration failed (%s, %s) - OllamaLocal disabled.", _oe, _ie)

# Local Server: LiteRT-LM Local
try:
    from lib_bejson_AI_bejson_litertlm import (
        get_standard_server as _get_litertlm_server,
        get_standard_prompter as _get_litertlm_prompter,
    )
    LITERTLM_SERVER = _get_litertlm_server(log_dir=os.path.join(DATA_DIR, 'logs'))
except ImportError as _e:
    LITERTLM_SERVER = None
    _get_litertlm_prompter = None
    _client_logger.warning("lib_bejson_AI_bejson_litertlm not found (%s) - LiteRTLM disabled.", _e)

LOCAL_STREAM_SERVICES = {
    "OllamaLocal": (OLLAMA_LOCAL_SERVER, _get_ollamalocal_prompter, "ollamalocal_history_messages",
                    "Local Ollama server is not running. Open Services and press Start Server."),
    "LiteRTLM": (LITERTLM_SERVER, _get_litertlm_prompter, "litertlm_history_messages",
                 "LiteRT-LM server is not running. Open Services and press Start Server."),
}

# Gateway Tool Engine
GATEWAY_DIR = os.path.join(BASE_DIR, 'gateway')
if os.path.exists(GATEWAY_DIR) and GATEWAY_DIR not in sys.path:
    sys.path.insert(0, GATEWAY_DIR)
try:
    from tool_gateway import ToolGateway
    TOOL_GATEWAY = ToolGateway(GATEWAY_DIR)
except Exception as _tge:
    TOOL_GATEWAY = None
    _client_logger.warning("ToolGateway load failed (%s) - Tooling disabled.", _tge)


def _log_message(session_id, role, sender, service, model, content):
    if not session_id:
        return
    try:
        CHAT_LOGS.append(session_id, role, sender, service, model, content)
    except Exception as e:
        _client_logger.error("Chat log write failed: %s", e)

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)

@app.route('/')
def index():
    return render_template('chat.html', constants=CLIENT_CONSTANTS)

@app.route('/api/models', methods=['GET'])
def api_models():
    service = request.args.get('service', 'OllamaLocal')
    models = []
    if service == 'OllamaLocal':
        # Check live installed models on the local Ollama server
        try:
            if OLLAMA_LOCAL_SERVER and OLLAMA_LOCAL_SERVER.is_ready():
                live_models = OLLAMA_LOCAL_SERVER.installed_models()
                for lm in live_models:
                    models.append({"id": lm, "name": f"{lm} (Installed)"})
        except Exception as _me:
            _client_logger.debug("Live Ollama model query error: %s", _me)

    if MODEL_REGISTRY:
        try:
            reg_models = MODEL_REGISTRY.get_models(service)
            existing_ids = {m["id"] for m in models}
            for rm in reg_models:
                if rm["id"] not in existing_ids:
                    models.append(rm)
        except Exception:
            pass

    if not models:
        if service == 'OllamaLocal':
            models = [
                {"id": "qwen2.5-coder:1.5b", "name": "Qwen2.5-Coder 1.5B"},
                {"id": "qwen2.5-coder:0.5b", "name": "Qwen2.5-Coder 0.5B"},
                {"id": "qwen2.5-coder:3b", "name": "Qwen2.5-Coder 3B"},
                {"id": "qwen2.5-coder:7b", "name": "Qwen2.5-Coder 7B"},
            ]
        elif service == 'LiteRTLM':
            models = [
                {"id": "gemma-4-e2b", "name": "Gemma 4 E2B"},
            ]
    return jsonify({"models": models, "service": service})

def _sse(obj):
    return "data: " + json.dumps(obj, ensure_ascii=False) + "\n\n"

@app.route('/api/chat/stream', methods=['POST'])
def api_chat_stream():
    """SSE streaming chat for OllamaLocal and LiteRTLM."""
    data = request.json or {}
    service = data.get('service') or 'OllamaLocal'
    model = data.get('model') or None
    message = (data.get('message') or '').strip()
    session_id = valid_session_id(data.get('session_id'))
    service_label = data.get('service_label') or ("Ollama Local" if service == "OllamaLocal" else "LiteRT-LM Local")

    if service not in LOCAL_STREAM_SERVICES:
        return jsonify({"status": "error", "response": f"Unsupported local service: {service}"}), 400
    if not message:
        return jsonify({"status": "error", "response": "Message cannot be empty."}), 400

    local_server, local_prompter_factory, history_constant, not_running_msg = LOCAL_STREAM_SERVICES[service]
    if local_server is None:
        return jsonify({"status": "error", "response": f"{service} library is unavailable - check server logs."}), 503
    if not local_server.is_ready():
        return jsonify({"status": "error", "response": not_running_msg}), 503

    prompter = local_prompter_factory()
    keep = int(CLIENT_CONSTANTS.get(history_constant, 20))
    history = [{"role": m["role"], "content": m["content"]}
               for m in (CHAT_LOGS.load(session_id) if session_id else [])
               if m["role"] in ("user", "assistant")][-keep:]
    while history and history[0]["role"] != "user":
        history.pop(0)

    messages = prompter.build_messages(message, None, history)

    def generate():
        acc = []
        try:
            _log_message(session_id, "user", "User", service, model, message)
            for delta in prompter.stream(messages, model_id=model):
                acc.append(delta)
                yield _sse({"delta": delta})
            yield _sse({"done": True})
        except Exception as e:
            _client_logger.error("%s stream error: %s", service, e)
            yield _sse({"error": str(e)})
        finally:
            text = "".join(acc)
            if text.strip():
                _log_message(session_id, "assistant", service_label, service, model, text)

    return Response(generate(), mimetype='text/event-stream',
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

@app.route('/api/chat', methods=['POST'])
def api_chat():
    """Non-streaming fallback for local chat."""
    data = request.json or {}
    service = data.get('service') or 'OllamaLocal'
    model = data.get('model') or None
    message = (data.get('message') or '').strip()
    session_id = valid_session_id(data.get('session_id'))
    service_label = data.get('service_label') or ("Ollama Local" if service == "OllamaLocal" else "LiteRT-LM Local")

    if service not in LOCAL_STREAM_SERVICES:
        return jsonify({"status": "error", "response": f"Unsupported local service: {service}"}), 400
    if not message:
        return jsonify({"status": "error", "response": "Message cannot be empty."}), 400

    local_server, local_prompter_factory, history_constant, not_running_msg = LOCAL_STREAM_SERVICES[service]
    if local_server is None:
        return jsonify({"status": "error", "response": f"{service} library is unavailable."}), 503
    if not local_server.is_ready():
        return jsonify({"status": "error", "response": not_running_msg}), 503

    try:
        prompter = local_prompter_factory()
        reply_text = prompter.prompt(message, model_id=model)
        if isinstance(reply_text, str) and reply_text.startswith("ERROR:"):
            return jsonify({"status": "error", "response": reply_text})
        _log_message(session_id, "user", "User", service, model, message)
        _log_message(session_id, "assistant", service_label, service, model, reply_text)
        return jsonify({"status": "success", "response": reply_text})
    except Exception as e:
        return jsonify({"status": "error", "response": str(e)})

# ── Local Ollama Server Control ───────────────────────────────────────
@app.route('/api/ollamalocal/status', methods=['GET'])
def api_ollamalocal_status():
    if OLLAMA_LOCAL_SERVER is None:
        return jsonify({"available": False, "error": "OllamaLocal library is unavailable."})
    status = OLLAMA_LOCAL_SERVER.status()
    status["available"] = True
    return jsonify(status)

@app.route('/api/ollamalocal/setup', methods=['POST'])
def api_ollamalocal_setup():
    if OLLAMA_LOCAL_SERVER is None:
        return jsonify({"started": False, "error": "OllamaLocal library is unavailable."}), 503
    tag = ((request.json or {}).get('model') or '').strip() or None
    return jsonify({"started": OLLAMA_LOCAL_SERVER.setup_async(tag)})

@app.route('/api/ollamalocal/stop', methods=['POST'])
def api_ollamalocal_stop():
    if OLLAMA_LOCAL_SERVER is None:
        return jsonify({"stopped": False}), 503
    OLLAMA_LOCAL_SERVER.stop()
    return jsonify({"stopped": True})

# ── LiteRT-LM Server Control ──────────────────────────────────────────
@app.route('/api/litertlm/status', methods=['GET'])
def api_litertlm_status():
    if LITERTLM_SERVER is None:
        return jsonify({"available": False, "error": "LiteRTLM library is unavailable."})
    status = LITERTLM_SERVER.status()
    status["available"] = True
    return jsonify(status)

@app.route('/api/litertlm/setup', methods=['POST'])
def api_litertlm_setup():
    if LITERTLM_SERVER is None:
        return jsonify({"started": False, "error": "LiteRTLM library is unavailable."}), 503
    model_id = ((request.json or {}).get('model') or '').strip() or None
    return jsonify({"started": LITERTLM_SERVER.setup_async(model_id)})

@app.route('/api/litertlm/stop', methods=['POST'])
def api_litertlm_stop():
    if LITERTLM_SERVER is None:
        return jsonify({"stopped": False}), 503
    LITERTLM_SERVER.stop()
    return jsonify({"stopped": True})

# ── Tooling Gateway ───────────────────────────────────────────────────
@app.route('/api/tools', methods=['GET'])
def api_tools():
    if TOOL_GATEWAY is None:
        return jsonify({"available": False, "mode": 0, "tools": []})
    service = request.args.get('service', 'OllamaLocal')
    model = request.args.get('model', '')
    mode = TOOL_GATEWAY.get_mode()
    state = TOOL_GATEWAY.get_state()
    tools = TOOL_GATEWAY.list_available_tools(service, model)
    return jsonify({
        "available": True,
        "mode": mode,
        "state": state,
        "service": service,
        "model": model,
        "tools": tools,
        "route_directory": TOOL_GATEWAY.resolve_model_tool_dir(service, model) if mode == 1 else None
    })

@app.route('/api/tools/mode', methods=['POST'])
def api_tools_mode():
    if TOOL_GATEWAY is None:
        return jsonify({"success": False, "error": "ToolGateway is unavailable"}), 503
    data = request.json or {}
    new_mode = int(data.get('mode', 0))
    success = TOOL_GATEWAY.set_mode(new_mode)
    return jsonify({"success": success, "mode": TOOL_GATEWAY.get_mode()})

@app.route('/api/tools/execute', methods=['POST'])
def api_tools_execute():
    if TOOL_GATEWAY is None:
        return jsonify({"status": "error", "error": "ToolGateway is unavailable"}), 503
    data = request.json or {}
    tool_name = (data.get('tool') or '').strip()
    tool_args = data.get('args') or {}
    service = data.get('service') or 'OllamaLocal'
    model = data.get('model') or ''

    if not tool_name:
        return jsonify({"status": "error", "error": "Tool name is required"}), 400

    result = TOOL_GATEWAY.execute_tool(tool_name, tool_args, service, model)
    return jsonify(result)

# ── Chat Logs ─────────────────────────────────────────────────────────
@app.route('/api/logs', methods=['GET'])
def api_logs_list():
    return jsonify({"sessions": CHAT_LOGS.list_sessions()})

@app.route('/api/logs/<sid>', methods=['GET'])
def api_logs_get(sid):
    if not valid_session_id(sid):
        return jsonify({"error": "Invalid session id"}), 400
    return jsonify({"messages": CHAT_LOGS.load(sid)})

@app.route('/api/logs/<sid>', methods=['DELETE'])
def api_logs_delete(sid):
    if not valid_session_id(sid):
        return jsonify({"error": "Invalid session id"}), 400
    return jsonify({"deleted": CHAT_LOGS.delete(sid)})

@app.route('/api/logs/<sid>/download', methods=['GET'])
def api_logs_download(sid):
    if not valid_session_id(sid) or not CHAT_LOGS.exists(sid):
        return jsonify({"error": "Not found"}), 404
    return send_file(CHAT_LOGS.path_of(sid), as_attachment=True, download_name=f"local-chat-{sid}.bejson")

def launch_browser():
    time.sleep(1.2)
    try:
        subprocess.run(['termux-clipboard-set'], input=SERVER_URL.encode(), check=False)
        subprocess.run(['termux-open', SERVER_URL], check=False)
    except Exception as e:
        print(f"Browser launch note: {e}")

if __name__ == '__main__':
    PORT = int(CLIENT_CONSTANTS.get('port', 5005))
    HOST = str(CLIENT_CONSTANTS.get('host', '127.0.0.1'))
    SERVER_URL = f"http://{HOST}:{PORT}"

    print("=" * 60)
    print(f" CLI AI Local Client - On-Device LLM Chat")
    print(f" Server running at: {SERVER_URL}")
    print(f" Local Services: Ollama Local & LiteRT-LM Local")
    print("=" * 60)

    threading.Thread(target=launch_browser, daemon=True).start()
    app.run(host=HOST, port=PORT, debug=False)
