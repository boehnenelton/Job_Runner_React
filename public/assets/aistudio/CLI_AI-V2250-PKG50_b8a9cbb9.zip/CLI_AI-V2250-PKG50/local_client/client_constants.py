"""
Module:         client_constants.py
Component of:   CLI_AI Local chat client (local_client/)
Description:    Self-healing configuration and constants loader for Local Client.
Version:        1.0.0
Date:           2026-11-02
Author:         Elton Boehnen
Contact:        boehnenelton2024@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
RELATIONAL_ID:  a1b2c3d4-e5f6-7890-abcd-ef1234567890
"""

import os
import sys
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_CORE_DIR = os.path.abspath(os.path.join(BASE_DIR, '..', 'lib', 'Core'))
if _CORE_DIR not in sys.path:
    sys.path.insert(0, _CORE_DIR)

try:
    from lib_bejson_Core_bejson_core import (
        bejson_core_create_104a,
        bejson_core_atomic_write,
        bejson_core_load_file,
        bejson_core_get_field_map,
    )
except ImportError:
    bejson_core_create_104a = None
    bejson_core_atomic_write = None
    bejson_core_load_file = None
    bejson_core_get_field_map = None

VERSION = "1.0.0"

_CONSTANT_FIELDS = [
    {"name": "constant_name",  "type": "string"},
    {"name": "defined_value",  "type": "string"},
    {"name": "default_value",  "type": "string"},
    {"name": "description",    "type": "string"},
]

_DEFAULT_CONSTANTS = [
    ("port", 5005, "Port for the Local Client Flask server"),
    ("host", "127.0.0.1", "Host binding for the Local Client Flask server"),
    ("send_timeout_ms", 120000, "Timeout in milliseconds for the local chat JS client"),
    ("ollamalocal_history_messages", 20, "Most recent chat-log messages sent as context to OllamaLocal"),
    ("litertlm_history_messages", 20, "Most recent chat-log messages sent as context to LiteRTLM"),
]

_CONSTANTS_FILENAME = "client_constants.bejson"

def _to_str(value: Any) -> Any:
    if value is None: return None
    return str(value)

def _from_str(raw: Any, template: Any) -> Any:
    if raw is None: return None
    try:
        t = type(template)
        if t is bool:
            return str(raw).lower() in ("true", "1", "yes")
        return t(raw)
    except Exception:
        return raw

def _generate_default_file(path: Path):
    if not bejson_core_create_104a: return
    bejson = bejson_core_create_104a("ScriptConfig", _CONSTANT_FIELDS, [], Format_Creator="Elton Boehnen")
    for name, dval, desc in _DEFAULT_CONSTANTS:
        bejson["Values"].append([name, None, _to_str(dval), desc])
    bejson_core_atomic_write(str(path), bejson)

def load_client_constants(config_dir: str) -> dict:
    cdir = Path(config_dir)
    cdir.mkdir(parents=True, exist_ok=True)
    cpath = cdir / _CONSTANTS_FILENAME

    if not cpath.exists():
        _generate_default_file(cpath)

    if not bejson_core_load_file:
        return {name: dval for name, dval, _ in _DEFAULT_CONSTANTS}

    raw = bejson_core_load_file(str(cpath))
    if not raw or "Values" not in raw:
        _generate_default_file(cpath)
        raw = bejson_core_load_file(str(cpath)) or {}

    fmap = bejson_core_get_field_map(raw)
    name_idx = fmap.get("constant_name")
    def_idx = fmap.get("defined_value")
    dval_idx = fmap.get("default_value")

    if None in (name_idx, def_idx, dval_idx):
        return {name: dval for name, dval, _ in _DEFAULT_CONSTANTS}

    disk_map = {}
    for row in raw.get("Values", []):
        if len(row) > max(name_idx, def_idx, dval_idx):
            disk_map[row[name_idx]] = (row[def_idx], row[dval_idx])

    effective = {}
    for name, baseline_dval, _ in _DEFAULT_CONSTANTS:
        if name in disk_map:
            def_str, dval_str = disk_map[name]
            if def_str is not None:
                effective[name] = _from_str(def_str, baseline_dval)
            else:
                effective[name] = _from_str(dval_str, baseline_dval)
        else:
            effective[name] = baseline_dval

    return effective
