"""
Gateway Tool Engine for CLI_AI Local Client
Manages tool modes (0=Disabled, 1=Standard, 2=MCP, 3=Experimental),
dynamic model-based routing, schema translation (OpenAI & Gemini),
access gate enforcement, and tool execution.
"""

import os
import json
import importlib.util
import time
from typing import Dict, List, Any, Optional

GATEWAY_DIR = os.path.dirname(os.path.abspath(__file__))
TOOLS_DIR = os.path.join(GATEWAY_DIR, "tools")
GLOBAL_DIR = os.path.join(GATEWAY_DIR, "global")


class ToolGateway:
    def __init__(self, gateway_dir: str = GATEWAY_DIR):
        self.gateway_dir = gateway_dir
        self.tools_dir = os.path.join(gateway_dir, "tools")
        self.global_dir = os.path.join(gateway_dir, "global")
        self.standard_dir = os.path.join(self.tools_dir, "standard")

    # -------------------------------------------------------------
    # Configuration & State Management
    # -------------------------------------------------------------
    def get_mode(self) -> int:
        mode_file = os.path.join(self.tools_dir, "mode.json")
        try:
            if os.path.exists(mode_file):
                with open(mode_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return int(data.get("mode", 0))
        except Exception:
            pass
        return 0

    def set_mode(self, mode: int) -> bool:
        mode_file = os.path.join(self.tools_dir, "mode.json")
        state_file = os.path.join(self.tools_dir, "state.json")
        try:
            data = {
                "mode": mode,
                "description": "0=Disabled, 1=Standard (local service active), 2=MCP, 3=Experimental",
                "available_modes": [0, 1, 2, 3],
                "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            }
            with open(mode_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            # Update state file
            state = self.get_state()
            state["active_mode"] = mode
            state["last_check"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            with open(state_file, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
            return True
        except Exception:
            return False

    def get_state(self) -> Dict[str, Any]:
        state_file = os.path.join(self.tools_dir, "state.json")
        try:
            if os.path.exists(state_file):
                with open(state_file, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {
            "active_mode": self.get_mode(),
            "active_service": "OllamaLocal",
            "active_model": "",
            "loaded_tools": [],
            "status": "idle"
        }

    def update_state(self, updates: Dict[str, Any]) -> None:
        state_file = os.path.join(self.tools_dir, "state.json")
        state = self.get_state()
        state.update(updates)
        state["last_check"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        try:
            with open(state_file, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception:
            pass

    def get_access_gate(self) -> Dict[str, Any]:
        gate_file = os.path.join(self.global_dir, "access_gate.json")
        try:
            if os.path.exists(gate_file):
                with open(gate_file, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {
            "gate_enabled": True,
            "execution_policy": "permissive",
            "require_confirmation": False,
            "max_execution_time_seconds": 15,
            "allowed_tools": ["*"],
            "blocked_tools": []
        }

    # -------------------------------------------------------------
    # Routing & Discovery
    # -------------------------------------------------------------
    def resolve_model_tool_dir(self, service: str, model: str) -> Optional[str]:
        """
        Determines the appropriate tool directory based on active local service and model.
        """
        service_lower = (service or "").lower()
        model_lower = (model or "").lower()

        if "ollama" in service_lower:
            ollama_dir = os.path.join(self.standard_dir, "ollama")
            if not os.path.exists(ollama_dir):
                return None
            for item in os.listdir(ollama_dir):
                candidate_dir = os.path.join(ollama_dir, item)
                if os.path.isdir(candidate_dir):
                    cfg_file = os.path.join(candidate_dir, "config.json")
                    if os.path.exists(cfg_file):
                        try:
                            with open(cfg_file, "r", encoding="utf-8") as f:
                                cfg = json.load(f)
                            patterns = cfg.get("model_patterns", [])
                            if any(p.lower() in model_lower for p in patterns) or not model:
                                return os.path.join(candidate_dir, cfg.get("tools_directory", "tools"))
                        except Exception:
                            pass
            # Fallback to qwen25coder if present
            default_qwen = os.path.join(ollama_dir, "qwen25coder", "tools")
            if os.path.exists(default_qwen):
                return default_qwen

        elif "litert" in service_lower:
            litert_dir = os.path.join(self.standard_dir, "litertlm")
            if not os.path.exists(litert_dir):
                return None
            for item in os.listdir(litert_dir):
                candidate_dir = os.path.join(litert_dir, item)
                if os.path.isdir(candidate_dir):
                    cfg_file = os.path.join(candidate_dir, "config.json")
                    if os.path.exists(cfg_file):
                        try:
                            with open(cfg_file, "r", encoding="utf-8") as f:
                                cfg = json.load(f)
                            patterns = cfg.get("model_patterns", [])
                            if any(p.lower() in model_lower for p in patterns) or not model:
                                return os.path.join(candidate_dir, cfg.get("tools_directory", "tools"))
                        except Exception:
                            pass
            # Fallback to gemma if present
            default_gemma = os.path.join(litert_dir, "gemma", "tools")
            if os.path.exists(default_gemma):
                return default_gemma

        return None

    def list_available_tools(self, service: str = "OllamaLocal", model: str = "") -> List[Dict[str, Any]]:
        mode = self.get_mode()
        if mode == 0:
            return []

        if mode == 1:
            tools_dir = self.resolve_model_tool_dir(service, model)
            if not tools_dir or not os.path.exists(tools_dir):
                return []

            tools = []
            for item in sorted(os.listdir(tools_dir)):
                tdir = os.path.join(tools_dir, item)
                if os.path.isdir(tdir):
                    def_file = os.path.join(tdir, "tool_def.json")
                    if os.path.exists(def_file):
                        try:
                            with open(def_file, "r", encoding="utf-8") as f:
                                tdef = json.load(f)
                            
                            # Read system instruction if present
                            inst_file = os.path.join(tdir, "system_instruction.md")
                            instruction = ""
                            if os.path.exists(inst_file):
                                with open(inst_file, "r", encoding="utf-8") as f:
                                    instruction = f.read().strip()

                            tools.append({
                                "name": tdef.get("name", item),
                                "description": tdef.get("description", ""),
                                "parameters": tdef.get("parameters", {"type": "object", "properties": {}}),
                                "instruction": instruction,
                                "path": tdir
                            })
                        except Exception:
                            pass
            return tools

        elif mode == 2:
            # Mode 2: MCP (placeholder / future extension)
            return []

        elif mode == 3:
            # Mode 3: Experimental
            return []

        return []

    # -------------------------------------------------------------
    # Schema Formatters
    # -------------------------------------------------------------
    def get_openai_tools(self, service: str = "OllamaLocal", model: str = "") -> List[Dict[str, Any]]:
        """
        Formats tools for Ollama / OpenAI-compatible /v1/chat/completions:
        [{"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}]
        """
        tools = self.list_available_tools(service, model)
        formatted = []
        for t in tools:
            formatted.append({
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t["description"],
                    "parameters": t["parameters"]
                }
            })
        return formatted

    def get_gemini_tools(self, service: str = "LiteRTLM", model: str = "") -> List[Dict[str, Any]]:
        """
        Formats tools for Google Gemini / LiteRT-LM /v1beta/models/{model}:generateContent:
        [{"functionDeclarations": [{"name": ..., "description": ..., "parameters": ...}]}]
        """
        tools = self.list_available_tools(service, model)
        if not tools:
            return []
        declarations = []
        for t in tools:
            declarations.append({
                "name": t["name"],
                "description": t["description"],
                "parameters": t["parameters"]
            })
        return [{"functionDeclarations": declarations}]

    # -------------------------------------------------------------
    # Tool Execution
    # -------------------------------------------------------------
    def execute_tool(self, name: str, args: Dict[str, Any] = None, service: str = "OllamaLocal", model: str = "") -> Dict[str, Any]:
        """
        Executes a registered tool by invoking its handler.py.
        Enforces access_gate policies.
        """
        mode = self.get_mode()
        if mode == 0:
            return {"status": "error", "error": "Tooling is disabled (Mode 0)"}

        # Access gate check
        gate = self.get_access_gate()
        if gate.get("gate_enabled", True):
            blocked = gate.get("blocked_tools", [])
            allowed = gate.get("allowed_tools", ["*"])
            if name in blocked:
                return {"status": "blocked", "error": f"Tool '{name}' is explicitly blocked by access gate."}
            if "*" not in allowed and name not in allowed:
                return {"status": "blocked", "error": f"Tool '{name}' is not in allowed tools list."}

        tools_dir = self.resolve_model_tool_dir(service, model)
        if not tools_dir or not os.path.exists(tools_dir):
            return {"status": "error", "error": f"Tool directory not found for service '{service}' and model '{model}'"}

        tool_path = os.path.join(tools_dir, name)
        handler_file = os.path.join(tool_path, "handler.py")

        if not os.path.exists(handler_file):
            return {"status": "error", "error": f"Tool '{name}' handler.py not found at {handler_file}"}

        try:
            # Dynamically import handler
            spec = importlib.util.spec_from_file_location(f"tool_{name}", handler_file)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)

            if not hasattr(mod, "execute"):
                return {"status": "error", "error": f"Handler for '{name}' does not implement execute(args)"}

            # Execute
            result = mod.execute(args or {})
            return {
                "status": "success",
                "tool": name,
                "output": result
            }
        except Exception as e:
            return {
                "status": "error",
                "tool": name,
                "error": str(e)
            }


gateway_engine = ToolGateway()
