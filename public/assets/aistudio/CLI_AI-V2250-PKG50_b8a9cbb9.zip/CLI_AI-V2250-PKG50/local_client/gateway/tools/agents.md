# Tooling Gateway
Client should support multiple tooling systems eventually, mode.json dictates which tooling system is available.

For now we have no tooling system so leave it at 0 until integrated, just prepare the architectural gates  

[ Mode: 0 ] - Tools are disabled.

[ Mode: 1 ] - Standard tooling based on local service active.

[ Mode: 2 ] - MCP 

[ Mode: 3 ] - Experimental custom tooling system.

/storage/emulated/0/Download/CLI_AI-V2250-PKG49/local_client/gateway/tools