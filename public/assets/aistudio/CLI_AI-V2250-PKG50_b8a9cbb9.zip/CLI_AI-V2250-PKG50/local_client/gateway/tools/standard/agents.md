# Standard Tooling Mode

Will be dynamic based on local model. Will detect if running Qwen on Ollama and route to a Ollama/Qwen/Tools subfolder and enable the standard tool system for LiteRT with a recognizable Gemma model and route to that tool system.