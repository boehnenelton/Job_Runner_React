Use calculator when performing mathematical or arithmetic calculations to guarantee accuracy.
