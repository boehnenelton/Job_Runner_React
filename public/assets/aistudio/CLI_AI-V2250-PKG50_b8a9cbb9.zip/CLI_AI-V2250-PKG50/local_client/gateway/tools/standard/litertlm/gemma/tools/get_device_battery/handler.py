import json
import subprocess

def execute(args: dict = None) -> dict:
    try:
        proc = subprocess.run(
            ["termux-battery-status"],
            capture_output=True,
            text=True,
            timeout=3
        )
        if proc.returncode == 0 and proc.stdout.strip():
            data = json.loads(proc.stdout)
            return {"status": "success", "battery": data}
    except Exception:
        pass

    try:
        import os
        base = "/sys/class/power_supply"
        if os.path.exists(base):
            for entry in os.listdir(base):
                cap_file = os.path.join(base, entry, "capacity")
                stat_file = os.path.join(base, entry, "status")
                if os.path.exists(cap_file):
                    with open(cap_file, "r") as f:
                        cap = f.read().strip()
                    status = "unknown"
                    if os.path.exists(stat_file):
                        with open(stat_file, "r") as f:
                            status = f.read().strip()
                    return {"status": "success", "battery": {"percentage": int(cap), "status": status, "source": entry}}
    except Exception:
        pass

    return {"status": "info", "battery": {"percentage": None, "status": "unavailable"}}
