Use get_device_battery when the user asks about battery level, charging state, or device power.
