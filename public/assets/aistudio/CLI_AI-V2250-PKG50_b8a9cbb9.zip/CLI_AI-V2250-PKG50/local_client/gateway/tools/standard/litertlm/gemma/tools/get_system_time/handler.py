import datetime
import time

def execute(args: dict = None) -> dict:
    now_local = datetime.datetime.now()
    now_utc = datetime.datetime.now(datetime.timezone.utc)
    return {
        "status": "success",
        "iso_local": now_local.isoformat(),
        "iso_utc": now_utc.isoformat(),
        "day_of_week": now_local.strftime("%A"),
        "timezone": time.tzname[0] if time.tzname else "UTC",
        "timestamp": int(time.time())
    }
