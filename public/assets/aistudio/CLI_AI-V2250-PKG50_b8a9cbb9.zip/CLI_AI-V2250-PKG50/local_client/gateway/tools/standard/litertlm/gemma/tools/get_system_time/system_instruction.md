Use get_system_time whenever the user asks for the current date, time, day of the week, or timezone.
