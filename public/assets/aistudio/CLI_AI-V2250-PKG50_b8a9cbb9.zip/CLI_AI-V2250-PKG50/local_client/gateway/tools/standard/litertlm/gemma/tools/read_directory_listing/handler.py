import os

def execute(args: dict = None) -> dict:
    target_path = (args or {}).get("path", "").strip() or os.getcwd()
    target_path = os.path.expanduser(target_path)
    if not os.path.exists(target_path):
        return {"status": "error", "error": f"Path does not exist: {target_path}"}
    if not os.path.isdir(target_path):
        return {"status": "error", "error": f"Path is not a directory: {target_path}"}
    
    try:
        items = []
        for name in sorted(os.listdir(target_path)):
            full_path = os.path.join(target_path, name)
            is_dir = os.path.isdir(full_path)
            size = os.path.getsize(full_path) if not is_dir else None
            items.append({
                "name": name,
                "is_dir": is_dir,
                "size_bytes": size
            })
        return {
            "status": "success",
            "path": target_path,
            "total_items": len(items),
            "items": items[:50]
        }
    except Exception as e:
        return {"status": "error", "path": target_path, "error": str(e)}
