Use read_directory_listing to view files and folders located inside a directory.
