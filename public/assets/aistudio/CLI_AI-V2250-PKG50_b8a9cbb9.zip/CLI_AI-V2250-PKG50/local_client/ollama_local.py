"""
Ollama Local Integration Module for CLI_AI Local Client
Self-contained Ollama client, process supervisor, and chat prompter.
"""

import json
import logging
import os
import shutil
import subprocess
import threading
import time
from typing import Any, Dict, Generator, List, Optional

logger = logging.getLogger("cli_ai.local_client.ollama")

DEFAULT_BASE_URL = "http://127.0.0.1:11434"
DEFAULT_MODEL = "qwen2.5-coder:1.5b"


class OllamaLocalServer:
    """Manages the lifecycle and state of the local Ollama server process."""

    def __init__(self, base_url: str = DEFAULT_BASE_URL, log_dir: Optional[str] = None):
        self.base_url = base_url.rstrip("/")
        self.log_dir = log_dir or os.path.expanduser("~/.ollama/logs")
        os.makedirs(self.log_dir, exist_ok=True)
        self.server_log = os.path.join(self.log_dir, "ollama_server.log")
        self._proc: Optional[subprocess.Popen] = None
        self._lock = threading.Lock()
        self.state: Dict[str, Any] = {
            "phase": "idle",
            "message": "",
            "percent": None,
            "error": None,
        }

    def _find_binary(self) -> Optional[str]:
        # Check standard PATH first, then common Termux paths
        binary = shutil.which("ollama")
        if binary and os.path.isfile(binary):
            return binary
        termux_bin = "/data/data/com.termux/files/usr/bin/ollama"
        if os.path.isfile(termux_bin):
            return termux_bin
        return None

    def is_ready(self) -> bool:
        """Returns True if the Ollama HTTP server is responsive."""
        try:
            import requests
            resp = requests.get(f"{self.base_url}/api/version", timeout=1.5)
            return resp.status_code == 200
        except Exception:
            try:
                import urllib.request
                req = urllib.request.Request(f"{self.base_url}/api/version")
                with urllib.request.urlopen(req, timeout=1.5) as r:
                    return r.status == 200
            except Exception:
                return False

    def installed_models(self) -> List[str]:
        """Queries the Ollama server for currently installed local models."""
        if not self.is_ready():
            return []
        try:
            import requests
            resp = requests.get(f"{self.base_url}/api/tags", timeout=3.0)
            if resp.status_code == 200:
                data = resp.json()
                return [m.get("name", "") for m in data.get("models", []) if m.get("name")]
        except Exception as e:
            logger.debug("Failed to list installed models: %s", e)
        return []

    def status(self) -> Dict[str, Any]:
        """Returns standard server status dictionary."""
        ready = self.is_ready()
        pid = None
        if self._proc and self._proc.poll() is None:
            pid = self._proc.pid
        with self._lock:
            state_copy = dict(self.state)
        return {
            "ready": ready,
            "base_url": self.base_url,
            "binary": self._find_binary(),
            "managed_pid": pid,
            "installed_models": self.installed_models() if ready else [],
            "state": state_copy,
        }

    def setup_async(self, model_tag: Optional[str] = None) -> bool:
        """Starts server if stopped, and optionally verifies/pulls model asynchronously."""
        tag = (model_tag or "").strip() or DEFAULT_MODEL

        def _worker():
            with self._lock:
                self.state = {"phase": "starting", "message": "Starting Ollama server...", "percent": None, "error": None}

            # 1. Start server if not ready
            if not self.is_ready():
                binary = self._find_binary()
                if not binary:
                    with self._lock:
                        self.state = {"phase": "error", "message": "Ollama executable not found in PATH or Termux bin.", "percent": None, "error": "binary_not_found"}
                    return

                env = dict(os.environ)
                env.setdefault("OLLAMA_HOST", "127.0.0.1:11434")
                env.setdefault("OLLAMA_MODELS", os.path.expanduser("~/.ollama/models"))
                env.setdefault("OLLAMA_KEEP_ALIVE", "15m")

                try:
                    log_f = open(self.server_log, "a", encoding="utf-8")
                    self._proc = subprocess.Popen(
                        [binary, "serve"],
                        env=env,
                        stdout=log_f,
                        stderr=subprocess.STDOUT,
                        preexec_fn=os.setsid if hasattr(os, "setsid") else None,
                    )
                except Exception as e:
                    with self._lock:
                        self.state = {"phase": "error", "message": f"Failed to spawn Ollama: {e}", "percent": None, "error": str(e)}
                    return

                # Wait for server to become ready
                online = False
                for _ in range(20):
                    time.sleep(0.5)
                    if self.is_ready():
                        online = True
                        break
                if not online:
                    with self._lock:
                        self.state = {"phase": "error", "message": "Ollama server started but did not respond on HTTP port.", "percent": None, "error": "startup_timeout"}
                    return

            # 2. Check if requested model is present
            models = self.installed_models()
            matched = any(tag == m or tag.split(":")[0] == m.split(":")[0] for m in models)
            if not matched and tag:
                # Pull model via Ollama API
                with self._lock:
                    self.state = {"phase": "downloading", "message": f"Pulling model {tag}...", "percent": None, "error": None}
                try:
                    import requests
                    resp = requests.post(f"{self.base_url}/api/pull", json={"name": tag}, stream=True, timeout=300)
                    for line in resp.iter_lines():
                        if line:
                            data = json.loads(line)
                            status_msg = data.get("status", "")
                            completed = data.get("completed", 0)
                            total = data.get("total", 0)
                            pct = round((completed / total * 100), 1) if total > 0 else None
                            with self._lock:
                                self.state = {"phase": "downloading", "message": status_msg, "percent": pct, "error": None}
                except Exception as pe:
                    logger.warning("Error during model pull %s: %s", tag, pe)

            with self._lock:
                self.state = {"phase": "ready", "message": f"Ollama is ready with {tag}", "percent": 100, "error": None}

        threading.Thread(target=_worker, daemon=True).start()
        return True

    def stop(self) -> bool:
        """Stops the Ollama server process."""
        with self._lock:
            self.state = {"phase": "stopped", "message": "Server stopped", "percent": None, "error": None}

        # 1. Terminate managed process
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.terminate()
                self._proc.wait(timeout=3)
            except Exception:
                try:
                    self._proc.kill()
                except Exception:
                    pass
            self._proc = None

        # 2. Kill orphan ollama serve processes if needed
        try:
            subprocess.run(["pkill", "-f", "ollama serve"], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

        return True


class OllamaLocalPrompter:
    """Handles chat completions and SSE streaming directly to local Ollama."""

    def __init__(self, base_url: str = DEFAULT_BASE_URL, default_model: str = DEFAULT_MODEL):
        self.base_url = base_url.rstrip("/")
        self.default_model = default_model

    def build_messages(self, message: str, system: Optional[str] = None, history: Optional[List[Dict[str, str]]] = None) -> List[Dict[str, str]]:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        if history:
            for item in history:
                role = item.get("role", "user")
                content = item.get("content", "")
                if role in ("user", "assistant", "system") and content:
                    messages.append({"role": role, "content": content})
        if message:
            messages.append({"role": "user", "content": message})
        return messages

    def prompt(self, message: str, model_id: Optional[str] = None, history: Optional[List[Dict[str, str]]] = None) -> str:
        """Synchronous chat completion."""
        model = model_id or self.default_model
        messages = self.build_messages(message, history=history)
        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
        }
        try:
            import requests
            resp = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=180)
            resp.raise_for_status()
            data = resp.json()
            return data.get("message", {}).get("content", "")
        except Exception as e:
            logger.error("Ollama prompt failed: %s", e)
            return f"ERROR: Ollama request failed ({e})"

    def stream(self, messages: List[Dict[str, str]], model_id: Optional[str] = None) -> Generator[str, None, None]:
        """Streams chat completion tokens line by line."""
        model = model_id or self.default_model
        payload = {
            "model": model,
            "messages": messages,
            "stream": True,
        }
        import requests
        resp = requests.post(f"{self.base_url}/api/chat", json=payload, stream=True, timeout=120)
        resp.raise_for_status()

        for line in resp.iter_lines():
            if line:
                try:
                    data = json.loads(line)
                    delta = data.get("message", {}).get("content", "")
                    if delta:
                        yield delta
                    if data.get("done", False):
                        break
                except Exception:
                    continue


def get_standard_server(log_dir: Optional[str] = None) -> OllamaLocalServer:
    return OllamaLocalServer(log_dir=log_dir)


def get_standard_prompter(default_model: str = DEFAULT_MODEL) -> OllamaLocalPrompter:
    return OllamaLocalPrompter(default_model=default_model)
