/**
 * Module:         chat.js
 * Component of:   CLI_AI Local Chat Client (local_client/)
 * Description:    Client controller for local on-device AI (Ollama Local & LiteRT-LM Local)
 *                 featuring Hamburger Sidebar navigation and SSE token streaming.
 * Version:        1.0.0
 * Date:           2026-11-02
 * Author:         Elton Boehnen
 */

document.addEventListener('DOMContentLoaded', () => {
    // ── Elements ─────────────────────────────────────────────────────────
    const statusHeader = document.getElementById('statusHeader');
    const statusText = document.getElementById('statusText');
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const sidebar = document.getElementById('sidebar');
    const sidebarBackdrop = document.getElementById('sidebarBackdrop');
    const closeSidebarBtn = document.getElementById('closeSidebarBtn');
    const headerServiceBadge = document.getElementById('headerServiceBadge');
    const headerServiceText = document.getElementById('headerServiceText');
    const serviceStatusDot = document.getElementById('serviceStatusDot');

    // Sidebar Nav
    const navChatBtn = document.getElementById('navChatBtn');
    const navServicesBtn = document.getElementById('navServicesBtn');
    const navLogsBtn = document.getElementById('navLogsBtn');
    const navSettingsBtn = document.getElementById('navSettingsBtn');
    const headerSettingsBtn = document.getElementById('headerSettingsBtn');
    const sidebarActiveService = document.getElementById('sidebarActiveService');
    const sidebarActiveModel = document.getElementById('sidebarActiveModel');

    // Settings Overlay
    const settingsOverlay = document.getElementById('settingsOverlay');
    const closeSettingsBtn = document.getElementById('closeSettingsBtn');
    const subtabToolingBtn = document.getElementById('subtabToolingBtn');
    const subtabServicesBtn = document.getElementById('subtabServicesBtn');
    const subtabSystemBtn = document.getElementById('subtabSystemBtn');
    const panelTooling = document.getElementById('panelTooling');
    const panelServices = document.getElementById('panelServices');
    const panelSystem = document.getElementById('panelSystem');

    // Tooling Subtab Elements
    const toolServiceOllamaBtn = document.getElementById('toolServiceOllamaBtn');
    const toolServiceLiteRTBtn = document.getElementById('toolServiceLiteRTBtn');
    const toolRoutingTitle = document.getElementById('toolRoutingTitle');
    const toolFormatBadge = document.getElementById('toolFormatBadge');
    const toolRouteDir = document.getElementById('toolRouteDir');
    const toolModelPatterns = document.getElementById('toolModelPatterns');
    const toolApiFormat = document.getElementById('toolApiFormat');
    const toolModeButtons = document.querySelectorAll('.becss-tool-mode-btn');
    const toolModeDesc = document.getElementById('toolModeDesc');
    const toolCountBadge = document.getElementById('toolCountBadge');
    const toolCardsContainer = document.getElementById('toolCardsContainer');
    const toolConsoleOutput = document.getElementById('toolConsoleOutput');

    // Views
    const viewChat = document.getElementById('viewChat');
    const viewServices = document.getElementById('viewServices');
    const viewLogs = document.getElementById('viewLogs');

    // Chat Elements
    const chatHistory = document.getElementById('chatHistory');
    const chatBar = document.getElementById('chatBar');
    const chatWho = document.getElementById('chatWho');
    const chatBarActions = document.getElementById('chatBarActions');
    const chatInput = document.getElementById('chatInput');
    const sendBtn = document.getElementById('sendBtn');
    const sendIcon = sendBtn.querySelector('.becss-send-btn__send-icon');
    const stopIcon = sendBtn.querySelector('.becss-send-btn__stop-icon');
    const toastEl = document.getElementById('toast');

    // Services Elements: Tabs & Cards
    const tabSwitchOllama = document.getElementById('tabSwitchOllama');
    const tabSwitchLiteRT = document.getElementById('tabSwitchLiteRT');
    const cardOllama = document.getElementById('cardOllama');
    const cardLiteRT = document.getElementById('cardLiteRT');
    const switchIndicatorOllama = document.getElementById('switchIndicatorOllama');
    const switchIndicatorLiteRT = document.getElementById('switchIndicatorLiteRT');

    // Ollama Card
    const ollamaStatusEl = document.getElementById('ollamaLocalStatus');
    const ollamaModelSel = document.getElementById('ollamaLocalModel');
    const ollamaSetupBtn = document.getElementById('ollamaLocalSetupBtn');
    const ollamaStopBtn = document.getElementById('ollamaLocalStopBtn');
    const ollamaActivateBtn = document.getElementById('ollamaActivateBtn');
    const ollamaProgressEl = document.getElementById('ollamaLocalProgress');
    const ollamaInstalledEl = document.getElementById('ollamaLocalInstalled');

    // LiteRT Card
    const litertStatusEl = document.getElementById('litertlmStatus');
    const litertModelSel = document.getElementById('litertlmModel');
    const litertSetupBtn = document.getElementById('litertlmSetupBtn');
    const litertStopBtn = document.getElementById('litertlmStopBtn');
    const litertActivateBtn = document.getElementById('litertActivateBtn');
    const litertProgressEl = document.getElementById('litertlmProgress');
    const litertInstalledEl = document.getElementById('litertlmInstalled');

    // Logs Elements
    const logsList = document.getElementById('logsList');
    const newChatBtn = document.getElementById('newChatBtn');
    const refreshLogsBtn = document.getElementById('refreshLogsBtn');
    const clearAllLogsBtn = document.getElementById('clearAllLogsBtn');

    // ── Application State ────────────────────────────────────────────────
    let currentView = 'chat';
    let activeService = localStorage.getItem('cliai_local_service') || 'OllamaLocal';
    let activeModel = localStorage.getItem('cliai_local_model') || '';
    let activeController = null;
    let pollInterval = null;
    let toastTimer = null;

    const SEND_TIMEOUT_MS = parseInt((window.CLIENT_CONSTANTS && window.CLIENT_CONSTANTS.send_timeout_ms) || 120000, 10);

    let serverStates = {
        OllamaLocal: { ready: false, busy: false, available: false, base_url: '', phase: '' },
        LiteRTLM: { ready: false, busy: false, available: false, base_url: '', phase: '' }
    };

    // ── Session UUID Management ──────────────────────────────────────────
    function generateUUID() {
        if (crypto && crypto.randomUUID) return crypto.randomUUID();
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            const r = Math.random() * 16 | 0;
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    }

    let sessionId = localStorage.getItem('cliai_local_session') || generateUUID();
    localStorage.setItem('cliai_local_session', sessionId);

    // ── Toast System ─────────────────────────────────────────────────────
    function toast(message) {
        if (!toastEl) return;
        toastEl.textContent = message;
        toastEl.classList.add('becss-toast--active');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => toastEl.classList.remove('becss-toast--active'), 2500);
    }

    // ── Header Status Indicators ─────────────────────────────────────────
    function setStatus(state) {
        if (!statusHeader) return;
        statusHeader.setAttribute('data-state', state);
        const labels = {
            idle: 'Idle',
            sending: 'Sending',
            waiting: 'Waiting',
            receiving: 'Receiving',
            timeout: 'Timeout'
        };
        statusText.textContent = labels[state] || state;
    }

    function setSending(isSending) {
        if (isSending) {
            sendIcon.style.display = 'none';
            stopIcon.style.display = 'block';
        } else {
            sendIcon.style.display = 'block';
            stopIcon.style.display = 'none';
        }
    }

    // ── Sidebar Navigation ───────────────────────────────────────────────
    function openSidebar() {
        sidebar.classList.add('becss-sidebar--open');
        sidebarBackdrop.classList.add('becss-sidebar-backdrop--active');
    }

    function closeSidebar() {
        sidebar.classList.remove('becss-sidebar--open');
        sidebarBackdrop.classList.remove('becss-sidebar-backdrop--active');
    }

    hamburgerBtn.addEventListener('click', openSidebar);
    closeSidebarBtn.addEventListener('click', closeSidebar);
    sidebarBackdrop.addEventListener('click', closeSidebar);

    function switchView(viewName) {
        currentView = viewName;
        [viewChat, viewServices, viewLogs].forEach(v => v.classList.remove('becss-view--active'));
        [navChatBtn, navServicesBtn, navLogsBtn].forEach(b => b.classList.remove('becss-sidebar__nav-item--active'));

        if (viewName === 'chat') {
            viewChat.classList.add('becss-view--active');
            navChatBtn.classList.add('becss-sidebar__nav-item--active');
            updateChatBar();
        } else if (viewName === 'services') {
            viewServices.classList.add('becss-view--active');
            navServicesBtn.classList.add('becss-sidebar__nav-item--active');
            refreshAllServerStatuses();
        } else if (viewName === 'logs') {
            viewLogs.classList.add('becss-view--active');
            navLogsBtn.classList.add('becss-sidebar__nav-item--active');
            loadLogsList();
        }
        closeSidebar();
    }

    navChatBtn.addEventListener('click', () => switchView('chat'));
    navServicesBtn.addEventListener('click', () => switchView('services'));
    navLogsBtn.addEventListener('click', () => switchView('logs'));
    headerServiceBadge.addEventListener('click', () => switchView('services'));

    // ── Local Service Tab Switching (Ollama vs LiteRT) ───────────────────
    tabSwitchOllama.addEventListener('click', () => {
        tabSwitchOllama.classList.add('becss-service-switch-tab--active');
        tabSwitchLiteRT.classList.remove('becss-service-switch-tab--active');
        cardOllama.style.display = 'flex';
        cardLiteRT.style.display = 'none';
    });

    tabSwitchLiteRT.addEventListener('click', () => {
        tabSwitchLiteRT.classList.add('becss-service-switch-tab--active');
        tabSwitchOllama.classList.remove('becss-service-switch-tab--active');
        cardLiteRT.style.display = 'flex';
        cardOllama.style.display = 'none';
    });

    // ── Fullscreen Settings & Tooling Overlay Controller ─────────────────
    let toolTargetService = activeService;
    let currentToolingMode = 0;

    const MODE_DESCRIPTIONS = {
        0: 'Mode 0: Tools are currently disabled (Default). Switch to Mode 1 to enable dynamic local tools.',
        1: 'Mode 1: Standard tooling based on active local service (Qwen on Ollama vs Gemma on LiteRT-LM).',
        2: 'Mode 2: Model Context Protocol (MCP) tooling ecosystem.',
        3: 'Mode 3: Experimental custom local tooling system.'
    };

    function openSettings(defaultSubtab = 'tooling') {
        settingsOverlay.style.display = 'flex';
        switchSettingsSubtab(defaultSubtab);
        toolTargetService = activeService;
        updateToolingServiceUI();
        refreshToolingView();
        closeSidebar();
    }

    function closeSettings() {
        settingsOverlay.style.display = 'none';
    }

    function switchSettingsSubtab(subtabName) {
        [subtabToolingBtn, subtabServicesBtn, subtabSystemBtn].forEach(b => b.classList.remove('becss-settings-subtab--active'));
        [panelTooling, panelServices, panelSystem].forEach(p => { p.style.display = 'none'; p.classList.remove('becss-subtab-panel--active'); });

        if (subtabName === 'tooling') {
            subtabToolingBtn.classList.add('becss-settings-subtab--active');
            panelTooling.style.display = 'flex';
            panelTooling.classList.add('becss-subtab-panel--active');
            refreshToolingView();
        } else if (subtabName === 'services') {
            subtabServicesBtn.classList.add('becss-settings-subtab--active');
            panelServices.style.display = 'flex';
            panelServices.classList.add('becss-subtab-panel--active');
        } else if (subtabName === 'system') {
            subtabSystemBtn.classList.add('becss-settings-subtab--active');
            panelSystem.style.display = 'flex';
            panelSystem.classList.add('becss-subtab-panel--active');
        }
    }

    function updateToolingServiceUI() {
        if (toolTargetService === 'OllamaLocal') {
            toolServiceOllamaBtn.classList.add('becss-tool-service-btn--active');
            toolServiceLiteRTBtn.classList.remove('becss-tool-service-btn--active');
            toolRoutingTitle.textContent = 'Ollama Tooling (Qwen Engine)';
            toolFormatBadge.textContent = 'OpenAI Format';
            toolRouteDir.textContent = 'gateway/tools/standard/ollama/qwen25coder/tools';
            toolModelPatterns.textContent = 'qwen, qwen2.5, qwen2.5-coder';
            toolApiFormat.textContent = 'OpenAI /v1/chat/completions (tools: [{type: "function"}])';
        } else {
            toolServiceLiteRTBtn.classList.add('becss-tool-service-btn--active');
            toolServiceOllamaBtn.classList.remove('becss-tool-service-btn--active');
            toolRoutingTitle.textContent = 'LiteRT-LM Tooling (Gemma Engine)';
            toolFormatBadge.textContent = 'Gemini Format';
            toolRouteDir.textContent = 'gateway/tools/standard/litertlm/gemma/tools';
            toolModelPatterns.textContent = 'gemma, gemma-2, gemma-4-e2b';
            toolApiFormat.textContent = 'Google Gemini /v1beta/models/{model}:generateContent (functionDeclarations)';
        }
    }

    async function refreshToolingView() {
        try {
            const resp = await fetch(`/api/tools?service=${encodeURIComponent(toolTargetService)}&model=${encodeURIComponent(activeModel || '')}`);
            const data = await resp.json();
            currentToolingMode = data.mode !== undefined ? data.mode : 0;

            toolModeButtons.forEach(btn => {
                const m = parseInt(btn.getAttribute('data-mode'), 10);
                if (m === currentToolingMode) {
                    btn.classList.add('becss-tool-mode-btn--active');
                } else {
                    btn.classList.remove('becss-tool-mode-btn--active');
                }
            });

            toolModeDesc.textContent = MODE_DESCRIPTIONS[currentToolingMode] || '';
            renderToolCards(data.tools || [], currentToolingMode);
        } catch (e) {
            console.error('Error fetching tools:', e);
            toast('Failed to load tooling data');
        }
    }

    async function setToolingMode(mode) {
        try {
            const resp = await fetch('/api/tools/mode', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mode })
            });
            const data = await resp.json();
            if (data.success) {
                toast(`Tooling Mode set to ${mode}`);
                refreshToolingView();
            } else {
                toast('Failed to change tooling mode');
            }
        } catch (e) {
            toast('Error updating tooling mode');
        }
    }

    function renderToolCards(tools, mode) {
        toolCardsContainer.innerHTML = '';
        toolCountBadge.textContent = `${tools.length} Tools`;

        if (tools.length === 0) {
            const emptyEl = document.createElement('div');
            emptyEl.className = 'becss-env-status';
            if (mode === 0) {
                emptyEl.innerHTML = `Mode 0 is active (Tools Disabled). Click <strong>Mode 1 (Standard)</strong> above to enable dynamic local tools for <code>${escapeHtml(toolTargetService)}</code>.`;
            } else {
                emptyEl.textContent = `No tools currently registered for ${toolTargetService}.`;
            }
            toolCardsContainer.appendChild(emptyEl);
            return;
        }

        const defaultArgsMap = {
            'calculator': '{"expression": "45 * 12 + 10"}',
            'get_system_time': '{}',
            'get_device_battery': '{}',
            'read_directory_listing': '{"path": "."}'
        };

        tools.forEach(tool => {
            const card = document.createElement('div');
            card.className = 'becss-tool-item-card';

            const defaultArgVal = defaultArgsMap[tool.name] || '{}';

            card.innerHTML = `
                <div class="becss-tool-item-top">
                    <span class="becss-tool-item-name">${escapeHtml(tool.name)}</span>
                    <span class="becss-badge becss-badge--idle">Ready</span>
                </div>
                <div class="becss-tool-item-desc">${escapeHtml(tool.description || 'No description provided.')}</div>
                <div class="becss-tool-item-test-row">
                    <input type="text" class="becss-tool-test-input" value='${defaultArgVal}' placeholder='JSON arguments'>
                    <button class="becss-tool-test-btn" data-tool="${escapeHtml(tool.name)}">Run Test</button>
                </div>
            `;

            const btn = card.querySelector('.becss-tool-test-btn');
            const input = card.querySelector('.becss-tool-test-input');

            btn.addEventListener('click', async () => {
                let parsedArgs = {};
                try {
                    const raw = input.value.trim();
                    if (raw) parsedArgs = JSON.parse(raw);
                } catch (pe) {
                    toast('Invalid JSON arguments syntax');
                    return;
                }

                btn.disabled = true;
                btn.textContent = 'Running...';
                toolConsoleOutput.textContent = `Executing tool "${tool.name}" on ${toolTargetService}...\nArguments: ${JSON.stringify(parsedArgs, null, 2)}`;

                try {
                    const execResp = await fetch('/api/tools/execute', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            tool: tool.name,
                            args: parsedArgs,
                            service: toolTargetService,
                            model: activeModel || ''
                        })
                    });
                    const execData = await execResp.json();
                    toolConsoleOutput.textContent = JSON.stringify(execData, null, 2);
                    toast(`Tool ${tool.name} finished: ${execData.status}`);
                } catch (ee) {
                    toolConsoleOutput.textContent = `Error executing tool: ${ee.message}`;
                    toast('Tool execution failed');
                } finally {
                    btn.disabled = false;
                    btn.textContent = 'Run Test';
                }
            });

            toolCardsContainer.appendChild(card);
        });
    }

    if (headerSettingsBtn) headerSettingsBtn.addEventListener('click', () => openSettings('tooling'));
    if (navSettingsBtn) navSettingsBtn.addEventListener('click', () => openSettings('tooling'));
    if (closeSettingsBtn) closeSettingsBtn.addEventListener('click', closeSettings);

    if (subtabToolingBtn) subtabToolingBtn.addEventListener('click', () => switchSettingsSubtab('tooling'));
    if (subtabServicesBtn) subtabServicesBtn.addEventListener('click', () => switchSettingsSubtab('services'));
    if (subtabSystemBtn) subtabSystemBtn.addEventListener('click', () => switchSettingsSubtab('system'));

    if (toolServiceOllamaBtn) {
        toolServiceOllamaBtn.addEventListener('click', () => {
            toolTargetService = 'OllamaLocal';
            updateToolingServiceUI();
            refreshToolingView();
        });
    }

    if (toolServiceLiteRTBtn) {
        toolServiceLiteRTBtn.addEventListener('click', () => {
            toolTargetService = 'LiteRTLM';
            updateToolingServiceUI();
            refreshToolingView();
        });
    }

    toolModeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const m = parseInt(btn.getAttribute('data-mode'), 10);
            setToolingMode(m);
        });
    });


    // ── Helper: Format Utilities ─────────────────────────────────────────
    function escapeHtml(text) {
        if (!text) return '';
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return String(text).replace(/[&<>"']/g, m => map[m]);
    }

    function mdToHtml(md) {
        if (!md) return '';
        let s = escapeHtml(md);

        // Fenced code blocks
        s = s.replace(/```([a-zA-Z0-9_\-\+]*)\n([\s\S]*?)```/g, (_, lang, code) => {
            return `<pre><code class="language-${lang}">${code.trim()}</code></pre>`;
        });

        // Inline code
        s = s.replace(/`([^`]+)`/g, '<code>$1</code>');

        // Headers
        s = s.replace(/^### (.*$)/gim, '<h3>$1</h3>');
        s = s.replace(/^## (.*$)/gim, '<h2>$1</h2>');
        s = s.replace(/^# (.*$)/gim, '<h1>$1</h1>');

        // Bold & Italic
        s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        s = s.replace(/\*([^*]+)\*/g, '<em>$1</em>');

        // Blockquotes
        s = s.replace(/^\> (.*$)/gim, '<blockquote>$1</blockquote>');

        // Unordered lists
        s = s.replace(/^\s*-\s+(.*$)/gim, '<li>$1</li>');
        s = s.replace(/(<li>.*<\/li>)/gim, '<ul>$1</ul>');

        // Paragraphs
        const paras = s.split(/\n{2,}/).map(p => {
            p = p.trim();
            if (!p) return '';
            if (/^<(h[1-6]|pre|ul|ol|blockquote)/.test(p)) return p;
            return `<p>${p.replace(/\n/g, '<br>')}</p>`;
        });
        return paras.join('');
    }

    // ── Model Choices Loading ────────────────────────────────────────────
    async function loadModels(service, selectEl) {
        try {
            const resp = await fetch(`/api/models?service=${service}`);
            const data = await resp.json();
            const models = data.models || [];
            selectEl.innerHTML = models.map(m => `<option value="${escapeHtml(m.id)}">${escapeHtml(m.name)}</option>`).join('');
            if (activeService === service && (!activeModel || !models.some(m => m.id === activeModel)) && models.length) {
                const preferred = models.find(m => m.id.includes('1.5b')) || models[0];
                activeModel = preferred ? preferred.id : models[0].id;
                localStorage.setItem('cliai_local_model', activeModel);
            }
            if (activeService === service && activeModel) {
                selectEl.value = activeModel;
            }
            updateChatBar();
        } catch (e) {
            selectEl.innerHTML = `<option value="">Default model</option>`;
        }
    }

    // ── Local Server Control & Status Polling ────────────────────────────
    async function pollOllamaStatus() {
        try {
            const resp = await fetch('/api/ollamalocal/status');
            const st = await resp.json();
            serverStates.OllamaLocal.available = !!st.available;
            serverStates.OllamaLocal.ready = !!st.ready;
            serverStates.OllamaLocal.base_url = st.base_url || 'http://127.0.0.1:11434';
            const phase = (st.state && st.state.phase) || 'idle';
            serverStates.OllamaLocal.phase = phase;
            serverStates.OllamaLocal.busy = ['installing', 'starting', 'pulling'].includes(phase);

            if (st.ready) {
                ollamaStatusEl.textContent = 'Running';
                ollamaStatusEl.className = 'becss-env-status becss-env-status--ok';
                switchIndicatorOllama.textContent = 'Running';
                switchIndicatorOllama.className = 'becss-switch-indicator becss-switch-indicator--running';
            } else if (serverStates.OllamaLocal.busy) {
                ollamaStatusEl.textContent = `Busy: ${phase}`;
                ollamaStatusEl.className = 'becss-env-status becss-env-status--busy';
                switchIndicatorOllama.textContent = phase;
                switchIndicatorOllama.className = 'becss-switch-indicator becss-switch-indicator--busy';
            } else {
                ollamaStatusEl.textContent = st.binary ? 'Installed (Stopped)' : 'Not Installed';
                ollamaStatusEl.className = 'becss-env-status becss-env-status--error';
                switchIndicatorOllama.textContent = 'Stopped';
                switchIndicatorOllama.className = 'becss-switch-indicator';
            }

            const pct = st.state && st.state.percent != null ? ` (${st.state.percent}%)` : '';
            ollamaProgressEl.textContent = (st.state && st.state.message) ? `${phase}: ${st.state.message}${pct}` : '';
            ollamaInstalledEl.textContent = st.installed_models && st.installed_models.length
                ? 'Installed models: ' + st.installed_models.join(', ') : '';
            ollamaSetupBtn.disabled = serverStates.OllamaLocal.busy;
        } catch (e) {
            ollamaStatusEl.textContent = 'Error querying status';
            ollamaStatusEl.className = 'becss-env-status becss-env-status--error';
        }
    }

    async function pollLiteRTStatus() {
        try {
            const resp = await fetch('/api/litertlm/status');
            const st = await resp.json();
            serverStates.LiteRTLM.available = !!st.available;
            serverStates.LiteRTLM.ready = !!st.ready;
            serverStates.LiteRTLM.base_url = st.base_url || 'http://127.0.0.1:9379';
            const phase = (st.state && st.state.phase) || 'idle';
            serverStates.LiteRTLM.phase = phase;
            serverStates.LiteRTLM.busy = ['starting'].includes(phase);

            if (st.ready) {
                litertStatusEl.textContent = 'Running';
                litertStatusEl.className = 'becss-env-status becss-env-status--ok';
                switchIndicatorLiteRT.textContent = 'Running';
                switchIndicatorLiteRT.className = 'becss-switch-indicator becss-switch-indicator--running';
            } else if (serverStates.LiteRTLM.busy) {
                litertStatusEl.textContent = `Busy: ${phase}`;
                litertStatusEl.className = 'becss-env-status becss-env-status--busy';
                switchIndicatorLiteRT.textContent = phase;
                switchIndicatorLiteRT.className = 'becss-switch-indicator becss-switch-indicator--busy';
            } else {
                litertStatusEl.textContent = st.binary ? 'Installed (Stopped)' : 'Not Installed';
                litertStatusEl.className = 'becss-env-status becss-env-status--error';
                switchIndicatorLiteRT.textContent = 'Stopped';
                switchIndicatorLiteRT.className = 'becss-switch-indicator';
            }

            litertProgressEl.textContent = (st.state && st.state.message) ? `${phase}: ${st.state.message}` : '';
            litertInstalledEl.textContent = st.installed_models && st.installed_models.length
                ? 'Served models: ' + st.installed_models.join(', ') : '';
            litertSetupBtn.disabled = serverStates.LiteRTLM.busy;
        } catch (e) {
            litertStatusEl.textContent = 'Error querying status';
            litertStatusEl.className = 'becss-env-status becss-env-status--error';
        }
    }

    async function refreshAllServerStatuses() {
        await Promise.all([pollOllamaStatus(), pollLiteRTStatus()]);
        updateHeaderAndSidebarBadges();
        updateChatBar();
    }

    function updateHeaderAndSidebarBadges() {
        const sName = activeService === 'OllamaLocal' ? 'Ollama' : 'LiteRT-LM';
        headerServiceText.textContent = sName;
        sidebarActiveService.textContent = activeService === 'OllamaLocal' ? 'Ollama Local' : 'LiteRT-LM Local';
        sidebarActiveModel.textContent = activeModel || 'Default Model';

        const curr = serverStates[activeService];
        serviceStatusDot.className = 'becss-service-badge__dot';
        if (curr && curr.ready) {
            serviceStatusDot.classList.add('becss-service-badge__dot--ok');
        } else if (curr && curr.busy) {
            serviceStatusDot.classList.add('becss-service-badge__dot--busy');
        } else {
            serviceStatusDot.classList.add('becss-service-badge__dot--error');
        }
    }

    // Server Action Handlers
    ollamaSetupBtn.addEventListener('click', async () => {
        try {
            ollamaSetupBtn.disabled = true;
            toast('Starting Ollama server...');
            await fetch('/api/ollamalocal/setup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: ollamaModelSel.value })
            });
            refreshAllServerStatuses();
        } catch (e) { toast('Failed to start Ollama'); }
    });

    ollamaStopBtn.addEventListener('click', async () => {
        try {
            await fetch('/api/ollamalocal/stop', { method: 'POST' });
            toast('Ollama server stopped');
            refreshAllServerStatuses();
        } catch (e) { toast('Failed to stop Ollama'); }
    });

    litertSetupBtn.addEventListener('click', async () => {
        try {
            litertSetupBtn.disabled = true;
            toast('Starting LiteRT-LM server...');
            await fetch('/api/litertlm/setup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ model: litertModelSel.value })
            });
            refreshAllServerStatuses();
        } catch (e) { toast('Failed to start LiteRT-LM'); }
    });

    litertStopBtn.addEventListener('click', async () => {
        try {
            await fetch('/api/litertlm/stop', { method: 'POST' });
            toast('LiteRT-LM server stopped');
            refreshAllServerStatuses();
        } catch (e) { toast('Failed to stop LiteRT-LM'); }
    });

    // Service Activation Buttons
    ollamaActivateBtn.addEventListener('click', () => {
        activeService = 'OllamaLocal';
        activeModel = ollamaModelSel.value;
        localStorage.setItem('cliai_local_service', activeService);
        localStorage.setItem('cliai_local_model', activeModel);
        updateHeaderAndSidebarBadges();
        toast('Active service set to Ollama Local');
        switchView('chat');
    });

    litertActivateBtn.addEventListener('click', () => {
        activeService = 'LiteRTLM';
        activeModel = litertModelSel.value;
        localStorage.setItem('cliai_local_service', activeService);
        localStorage.setItem('cliai_local_model', activeModel);
        updateHeaderAndSidebarBadges();
        toast('Active service set to LiteRT-LM Local');
        switchView('chat');
    });

    // ── Chat Strip & Message Management ──────────────────────────────────
    function chatBarButton(label, handler, extraClass, disabled) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'becss-chatbar__btn' + (extraClass ? ' ' + extraClass : '');
        b.textContent = label;
        if (disabled) b.disabled = true;
        b.addEventListener('click', handler);
        return b;
    }

    function selectedMessage() {
        return chatHistory.querySelector('.becss-message--selected');
    }

    function clearSelection() {
        const sel = selectedMessage();
        if (sel) sel.classList.remove('becss-message--selected');
        updateChatBar();
    }

    function clearChatHistory() {
        if (!confirm('Clear message history from view? (Chat log remains in History tab)')) return;
        chatHistory.innerHTML = '';
        updateChatBar();
        toast('Chat cleared');
    }

    function resetChat() {
        if (chatHistory.querySelector('.becss-message') && !confirm('Start a new chat session?')) return;
        if (activeController) activeController.abort();
        sessionId = generateUUID();
        localStorage.setItem('cliai_local_session', sessionId);
        chatHistory.innerHTML = '';
        updateChatBar();
        toast('New session started');
    }

    function updateChatBar() {
        const sLabel = activeService === 'OllamaLocal' ? 'Ollama Local' : 'LiteRT-LM Local';
        chatWho.innerHTML = `Chatting with <b>${escapeHtml(sLabel)}</b>${activeModel ? ' &middot; ' + escapeHtml(activeModel) : ''}`;
        chatBarActions.innerHTML = '';

        const sel = selectedMessage();
        chatBar.classList.toggle('becss-chatbar--selecting', !!sel);

        if (sel) {
            chatBarActions.appendChild(chatBarButton('Copy', async () => {
                if (navigator.clipboard) await navigator.clipboard.writeText(sel._rawText || '');
                toast('Copied to clipboard');
            }));
            chatBarActions.appendChild(chatBarButton('✕', clearSelection));
            return;
        }

        // Server control directly on chat strip
        const curr = serverStates[activeService];
        if (curr) {
            if (curr.busy) {
                chatBarActions.appendChild(chatBarButton('Starting...', () => {}, '', true));
            } else if (curr.ready) {
                chatBarActions.appendChild(chatBarButton('Stop Server', async () => {
                    const endpoint = activeService === 'OllamaLocal' ? '/api/ollamalocal/stop' : '/api/litertlm/stop';
                    await fetch(endpoint, { method: 'POST' });
                    toast('Server stopped');
                    refreshAllServerStatuses();
                }, 'becss-chatbar__btn--accent'));
            } else {
                chatBarActions.appendChild(chatBarButton('Start Server', async () => {
                    const endpoint = activeService === 'OllamaLocal' ? '/api/ollamalocal/setup' : '/api/litertlm/setup';
                    toast('Starting server...');
                    await fetch(endpoint, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ model: activeModel })
                    });
                    refreshAllServerStatuses();
                }, 'becss-chatbar__btn--accent'));
            }
        }

        const hasMessages = !!chatHistory.querySelector('.becss-message');
        chatBarActions.appendChild(chatBarButton('Clear', clearChatHistory, '', !hasMessages));
        chatBarActions.appendChild(chatBarButton('New Chat', resetChat));
    }

    // ── Build Message Element ────────────────────────────────────────────
    function buildMessage(role, sender, text, streaming = false) {
        const msg = document.createElement('div');
        msg.className = `becss-message becss-message--${role}`;
        msg._rawText = text;

        const header = document.createElement('div');
        header.className = 'becss-message__header';

        const senderSpan = document.createElement('span');
        senderSpan.className = 'becss-message__sender';
        senderSpan.textContent = sender;

        const timeSpan = document.createElement('span');
        timeSpan.className = 'becss-message__time';
        timeSpan.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        header.appendChild(senderSpan);
        header.appendChild(timeSpan);

        const body = document.createElement('div');
        body.className = 'becss-message__text';
        body.innerHTML = mdToHtml(text);

        const copyBtn = document.createElement('button');
        copyBtn.className = 'becss-message__copy-btn';
        copyBtn.textContent = 'Copy';
        copyBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            if (navigator.clipboard) await navigator.clipboard.writeText(msg._rawText || '');
            toast('Copied');
        });

        msg.appendChild(header);
        msg.appendChild(body);
        msg.appendChild(copyBtn);

        msg.addEventListener('click', () => {
            const isSel = msg.classList.contains('becss-message--selected');
            document.querySelectorAll('.becss-message--selected').forEach(el => el.classList.remove('becss-message--selected'));
            if (!isSel) msg.classList.add('becss-message--selected');
            updateChatBar();
        });

        return msg;
    }

    // ── Send Message with SSE Token Streaming ────────────────────────────
    async function sendMessage() {
        const text = chatInput.value.trim();
        if (!text || activeController) return;

        chatInput.value = '';
        chatInput.style.height = 'auto';

        // Append user message
        const userMsg = buildMessage('user', 'User', text);
        chatHistory.appendChild(userMsg);
        chatHistory.scrollTop = chatHistory.scrollHeight;

        setStatus('sending');
        setSending(true);

        const serviceLabel = activeService === 'OllamaLocal' ? 'Ollama Local' : 'LiteRT-LM Local';
        const aiMsg = buildMessage('ai', serviceLabel, '', true);
        const aiTextEl = aiMsg.querySelector('.becss-message__text');

        let accumulated = '';
        let renderQueued = false;
        const renderDelta = () => {
            renderQueued = false;
            aiMsg._rawText = accumulated;
            aiTextEl.innerHTML = mdToHtml(accumulated);
            chatHistory.scrollTop = chatHistory.scrollHeight;
        };

        activeController = new AbortController();
        const timeoutTimer = setTimeout(() => {
            if (activeController) activeController.abort();
        }, SEND_TIMEOUT_MS);

        try {
            const resp = await fetch('/api/chat/stream', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: text,
                    service: activeService,
                    model: activeModel,
                    session_id: sessionId,
                    service_label: serviceLabel
                }),
                signal: activeController.signal
            });

            if (!resp.ok) {
                const err = await resp.json().catch(() => ({}));
                throw new Error(err.response || `HTTP ${resp.status}`);
            }

            chatHistory.appendChild(aiMsg);
            setStatus('waiting');

            const reader = resp.body.getReader();
            const decoder = new TextDecoder();
            let buf = '';

            while (true) {
                const { value, done } = await reader.read();
                if (done) break;
                buf += decoder.decode(value, { stream: true });
                let idx;
                while ((idx = buf.indexOf('\n\n')) >= 0) {
                    const frame = buf.slice(0, idx);
                    buf = buf.slice(idx + 2);
                    if (!frame.startsWith('data:')) continue;
                    const ev = JSON.parse(frame.slice(5));
                    if (ev.error) throw new Error(ev.error);
                    if (ev.delta) {
                        if (!accumulated) setStatus('receiving');
                        accumulated += ev.delta;
                        if (!renderQueued) {
                            renderQueued = true;
                            requestAnimationFrame(renderDelta);
                        }
                    }
                }
            }
            renderDelta();
        } catch (error) {
            if (error.name === 'AbortError') {
                chatHistory.appendChild(buildMessage('ai', 'System', 'Request stopped or timed out.'));
                setStatus('timeout');
            } else {
                if (accumulated) renderDelta();
                chatHistory.appendChild(buildMessage('ai', 'System', `Error: ${error.message}`));
            }
        } finally {
            clearTimeout(timeoutTimer);
            if (!accumulated && aiMsg.parentNode) aiMsg.remove();
            activeController = null;
            setSending(false);
            chatHistory.scrollTop = chatHistory.scrollHeight;
            if (statusHeader.getAttribute('data-state') === 'timeout') {
                setTimeout(() => setStatus('idle'), 3000);
            } else {
                setStatus('idle');
            }
        }
    }

    sendBtn.addEventListener('click', () => {
        if (activeController) {
            activeController.abort();
            toast('Stopped generation');
        } else {
            sendMessage();
        }
    });

    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    chatInput.addEventListener('input', () => {
        chatInput.style.height = 'auto';
        chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    });

    // ── Chat History / Logs List ─────────────────────────────────────────
    async function loadLogsList() {
        logsList.innerHTML = '<li class="becss-env-status">Loading chat history...</li>';
        try {
            const resp = await fetch('/api/logs');
            const data = await resp.json();
            const sessions = data.sessions || [];
            if (!sessions.length) {
                logsList.innerHTML = '<li class="becss-env-status">No saved chat sessions yet.</li>';
                return;
            }
            logsList.innerHTML = '';
            sessions.forEach(sess => {
                const li = document.createElement('li');
                li.className = 'becss-logs__item';

                const meta = document.createElement('div');
                meta.className = 'becss-logs__meta';

                const title = document.createElement('div');
                title.className = 'becss-logs__title';
                title.textContent = sess.title || sess.session_id;

                const sub = document.createElement('div');
                sub.className = 'becss-logs__sub';
                sub.textContent = `${sess.message_count || 0} messages &middot; ${sess.updated_at || ''}`;

                meta.appendChild(title);
                meta.appendChild(sub);

                const actions = document.createElement('div');
                actions.className = 'becss-logs__actions';

                const openBtn = document.createElement('button');
                openBtn.className = 'becss-logs__action-btn';
                openBtn.textContent = 'Load';
                openBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    await loadSessionMessages(sess.session_id);
                });

                const dlBtn = document.createElement('button');
                dlBtn.className = 'becss-logs__action-btn';
                dlBtn.textContent = 'Download';
                dlBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    window.location.href = `/api/logs/${sess.session_id}/download`;
                });

                const delBtn = document.createElement('button');
                delBtn.className = 'becss-logs__action-btn';
                delBtn.textContent = 'Delete';
                delBtn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    if (!confirm('Delete this session log?')) return;
                    await fetch(`/api/logs/${sess.session_id}`, { method: 'DELETE' });
                    toast('Session deleted');
                    loadLogsList();
                });

                actions.appendChild(openBtn);
                actions.appendChild(dlBtn);
                actions.appendChild(delBtn);

                li.appendChild(meta);
                li.appendChild(actions);
                logsList.appendChild(li);
            });
        } catch (e) {
            logsList.innerHTML = '<li class="becss-env-status becss-env-status--error">Failed to load chat history.</li>';
        }
    }

    async function loadSessionMessages(sid) {
        try {
            const resp = await fetch(`/api/logs/${sid}`);
            const data = await resp.json();
            const messages = data.messages || [];
            sessionId = sid;
            localStorage.setItem('cliai_local_session', sid);
            chatHistory.innerHTML = '';
            messages.forEach(m => {
                chatHistory.appendChild(buildMessage(m.role || 'user', m.sender || m.role, m.content || ''));
            });
            chatHistory.scrollTop = chatHistory.scrollHeight;
            toast('Chat session loaded');
            switchView('chat');
        } catch (e) {
            toast('Failed to load session');
        }
    }

    newChatBtn.addEventListener('click', () => {
        resetChat();
        switchView('chat');
    });

    refreshLogsBtn.addEventListener('click', loadLogsList);

    clearAllLogsBtn.addEventListener('click', async () => {
        if (!confirm('Clear all chat sessions? This cannot be undone.')) return;
        try {
            const resp = await fetch('/api/logs');
            const data = await resp.json();
            for (const s of (data.sessions || [])) {
                await fetch(`/api/logs/${s.session_id}`, { method: 'DELETE' });
            }
            toast('All history cleared');
            loadLogsList();
        } catch (e) { toast('Error clearing history'); }
    });

    // ── Initial Bootstrapping ────────────────────────────────────────────
    (async () => {
        await loadModels('OllamaLocal', ollamaModelSel);
        await loadModels('LiteRTLM', litertModelSel);

        // Pre-select active model in select elements
        if (activeService === 'OllamaLocal' && activeModel) ollamaModelSel.value = activeModel;
        if (activeService === 'LiteRTLM' && activeModel) litertModelSel.value = activeModel;

        refreshAllServerStatuses();
        updateHeaderAndSidebarBadges();

        // Load active session messages if exists
        try {
            const resp = await fetch(`/api/logs/${sessionId}`);
            const data = await resp.json();
            (data.messages || []).forEach(m => {
                chatHistory.appendChild(buildMessage(m.role || 'user', m.sender || m.role, m.content || ''));
            });
            chatHistory.scrollTop = chatHistory.scrollHeight;
        } catch (e) { /* fresh session */ }

        // Start background status poll every 4 seconds
        pollInterval = setInterval(() => {
            if (!document.hidden) refreshAllServerStatuses();
        }, 4000);
    })();
});
