#!/usr/bin/env python3
# ─────────────────────────────────────────────────────────────
# Name:         PROFILES - AI Profile Selector & Editor
# Description:  Single-file Flask app for managing AI profiles
#               with BEJSON 104a persistent storage. Full 24-field
#               AI_Profile schema editor (This_Case_Fields) with
#               sectioned UI. Uses the shared project lib/ folder
#               (lib/AI/lib_bejson_AI_gemini_standard_profiles.py
#               and lib/Core/) — no standalone copies.
# Version:      2.1.0 (see VERSION below)
# Date:         2026-10-18
# Author:       Elton Boehnen
#               boehnenelton2024@gmail.com
#               boehnenelton2024.pages.dev
#               github.com/boehnenelton
# RELATIONAL_ID: 4f2b9d6e-71a3-4c08-b5e9-c0a1d38f7264
# ─────────────────────────────────────────────────────────────
# Changelog:
#   2.1.0 (2026-10-18) -- Edit dialog gains an "Embedded Code" section
#           (Parser_Language / Parser / Renderer). PUT /api/profiles/<name>
#           validates the code with lib_bejson_AI_gemini_standard_profiles
#           (static checks + `node --check` for JavaScript) BEFORE anything is
#           written and returns 422 with the problems; columns are appended on
#           first use, blank clears. write_bejson also strips the Core
#           _bejson_field_map cache. Changing code changes its fingerprint, so
#           any approval in the chat client no longer applies.
#   2.0.0 (2026-09-04) -- Migrated all field names to This_Case convention
#           (System_Instruction, Forbidden_Topics, Avatar_Source_Url,
#           Max_Response_Tokens, etc.). Switched from standalone BEJSON
#           helpers to the shared project lib/ (lib_bejson_AI_gemini_standard_profiles
#           + lib_bejson_Core_bejson_core). Profile_Config now holds both
#           Selected_Profile and Profiles_Enabled (This_Case keys).
#   1.0.0 (2026-08-21) -- Initial creation.
# ─────────────────────────────────────────────────────────────

VERSION = "2.1.0"
Release_Version = 300
PORT = 5098

import json
import copy
import logging
import sys
from pathlib import Path
from datetime import datetime, timezone

from flask import Flask, request, jsonify, render_template_string

# ── Self-Locating ────────────────────────────────────────────
def get_script_path() -> Path:
    return Path(__file__).resolve().parent

SCRIPT_PATH = get_script_path()
PROJECT_ROOT = SCRIPT_PATH.parent          # CLI_AI-V12-PKG12/
LIB_CORE = PROJECT_ROOT / "lib" / "Core"
LIB_AI   = PROJECT_ROOT / "lib" / "AI"

for _p in (LIB_CORE, LIB_AI):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

# ── Shared library imports ───────────────────────────────────
from lib_bejson_Core_bejson_core import (
    bejson_core_get_field_map,
    bejson_core_atomic_write,
)
from lib_bejson_AI_gemini_standard_profiles import (
    gemini_profiles_validate,
    gemini_profiles_create,
    gemini_profiles_get_value,
    gemini_profiles_update_value,
    gemini_profiles_get_field_map,
    gemini_profiles_get_parser,
    gemini_profiles_set_parser,
    gemini_profiles_set_renderer,
    gemini_profiles_validate_embedded,
    PROFILE_FIELDS,
)
import lib_bejson_AI_profile_parser_runtime as _parser_runtime

# ── Logging ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("PROFILES")

# ── Paths ────────────────────────────────────────────────────
PROFILES_DIR   = SCRIPT_PATH / "profiles"
CONFIG_DIR     = SCRIPT_PATH / "config"
CONFIG_FILE    = CONFIG_DIR / "profile_config.104a.bejson"
TEMPLATE_FILE  = SCRIPT_PATH / "profile_template.bejson"

# ── BEJSON helpers (wrap shared Core) ───────────────────────
def build_field_map(data: dict) -> dict:
    """Build name→index map from a BEJSON Fields array."""
    return bejson_core_get_field_map(data)


def read_bejson(filepath: Path) -> dict:
    """Read and return parsed BEJSON with attached _field_map."""
    with open(filepath, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    data["_field_map"] = build_field_map(data)
    return data


def write_bejson(filepath: Path, data: dict) -> None:
    """Atomically write BEJSON, stripping the internal field-map caches
    (_field_map here, _bejson_field_map from the shared lib) before save."""
    out = {k: v for k, v in data.items() if k not in ("_field_map", "_bejson_field_map")}
    if not bejson_core_atomic_write(str(filepath), out):
        raise IOError(f"Atomic write failed: {filepath}")


def get_field(data: dict, row: list, field_name: str):
    """Get a value from a BEJSON row by field name via field map cache."""
    fm = data["_field_map"]
    return row[fm[field_name]]


def set_field(data: dict, row: list, field_name: str, value) -> None:
    """Set a value in a BEJSON row by field name via field map cache."""
    fm = data["_field_map"]
    row[fm[field_name]] = value


# ── Profile Config helpers ───────────────────────────────────
def _cfg_get(config: dict, key: str) -> str | None:
    """Read Config_Value for a given Config_Key from the Profile_Config doc."""
    fm = config["_field_map"]
    k_idx = fm.get("Config_Key", -1)
    v_idx = fm.get("Config_Value", -1)
    if k_idx == -1 or v_idx == -1:
        return None
    for row in config.get("Values", []):
        if len(row) > max(k_idx, v_idx) and row[k_idx] == key:
            return row[v_idx]
    return None


def _cfg_set(config: dict, key: str, value: str) -> bool:
    """Update Config_Value for a given Config_Key. Returns True if found."""
    fm = config["_field_map"]
    k_idx = fm.get("Config_Key", -1)
    v_idx = fm.get("Config_Value", -1)
    if k_idx == -1 or v_idx == -1:
        return False
    for row in config.get("Values", []):
        if len(row) > max(k_idx, v_idx) and row[k_idx] == key:
            row[v_idx] = value
            return True
    return False


# ── Bootstrap ────────────────────────────────────────────────
def ensure_defaults():
    """Create profiles/ and config/ dirs + default files if missing."""
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    if not CONFIG_FILE.exists():
        default_config = {
            "Format": "BEJSON",
            "Format_Version": "104a",
            "Format_Creator": "Elton Boehnen",
            "Records_Type": ["Profile_Config"],
            "Fields": [
                {"name": "Config_Key",         "type": "string"},
                {"name": "Config_Value",        "type": "string"},
                {"name": "Config_Description",  "type": "string"},
            ],
            "Values": [
                ["Selected_Profile", "default",  "Currently selected profile name"],
                ["Profiles_Enabled", "false",    "Whether AI profile injection is active for CLI calls"],
            ]
        }
        write_bejson(CONFIG_FILE, default_config)
        logger.info("Created default profile config file.")

    default_profile = PROFILES_DIR / "default.bejson"
    if not default_profile.exists():
        if TEMPLATE_FILE.exists():
            tmpl = read_bejson(TEMPLATE_FILE)
            profile_data = {k: v for k, v in tmpl.items() if k != "_field_map"}
            row = copy.deepcopy(tmpl["Values"][0])
            profile_data["_field_map"] = build_field_map(profile_data)
            set_field(profile_data, row, "Name", "default")
            profile_data["Values"] = [row]
            write_bejson(default_profile, profile_data)
        else:
            profile_data = gemini_profiles_create(
                "default", "General Assistant",
                "A helpful AI assistant",
                "You are a helpful AI assistant ready to assist with a wide range of tasks."
            )
            # gemini_profiles_create returns Format_Version "104" (array fields
            # require 104; 104a is primitives-only per spec)
            write_bejson(default_profile, profile_data)
        logger.info("Created default profile.")


# ── Flask App ────────────────────────────────────────────────
app = Flask(__name__)


def list_profile_names() -> list[str]:
    """Scan profiles/ for .bejson files, return sorted profile names."""
    names = [f.stem for f in PROFILES_DIR.glob("*.bejson")]
    names.sort(key=lambda n: (n != "default", n))
    return names


def profile_to_dict(data: dict, row: list) -> dict:
    """Convert a BEJSON profile row to a plain dict via field map cache."""
    fm = data["_field_map"]
    return {field_name: row[idx] for field_name, idx in fm.items()}


EMBEDDED_CODE_KEYS = ("Parser_Language", "Parser", "Renderer")


def apply_embedded_code(data: dict, body: dict) -> str | None:
    """
    Applies Parser_Language / Parser / Renderer from *body* to record 0 of
    *data* through the shared lib (columns are appended on first use, blank
    clears). Returns a problem string when the code is rejected, else None.
    Keys absent from *body* keep their current value.
    """
    if "Parser" in body or "Parser_Language" in body:
        current = gemini_profiles_get_parser(data)
        language = body["Parser_Language"] if "Parser_Language" in body else (current or {}).get("language")
        code = body["Parser"] if "Parser" in body else (current or {}).get("code")
        if not gemini_profiles_set_parser(data, language, code):
            problems = _parser_runtime.runtime_validate_parser(language, code)
            return "Parser rejected: " + ("; ".join(problems) or "invalid")
    if "Renderer" in body:
        if not gemini_profiles_set_renderer(data, body["Renderer"]):
            problems = _parser_runtime.runtime_validate_renderer(body["Renderer"])
            return "Renderer rejected: " + ("; ".join(problems) or "invalid")
    problems = gemini_profiles_validate_embedded(data, 0, syntax_check_js=True)
    if problems:
        return "; ".join(problems)
    return None


# ── API Routes ───────────────────────────────────────────────

@app.route("/api/profiles", methods=["GET"])
def api_list_profiles():
    return jsonify({"profiles": list_profile_names()})


@app.route("/api/profiles/<name>", methods=["GET"])
def api_get_profile(name: str):
    filepath = PROFILES_DIR / f"{name}.bejson"
    if not filepath.exists():
        return jsonify({"error": f"Profile '{name}' not found."}), 404
    data = read_bejson(filepath)
    row = data["Values"][0]
    return jsonify(profile_to_dict(data, row))


@app.route("/api/profiles", methods=["POST"])
def api_create_profile():
    body = request.get_json(silent=True) or {}
    profile_name = body.get("profile_name", "").strip()
    if not profile_name:
        return jsonify({"error": "profile_name is required."}), 400
    safe_name = "".join(c for c in profile_name if c.isalnum() or c in "_-").lower()
    if not safe_name:
        return jsonify({"error": "Invalid profile name."}), 400
    filepath = PROFILES_DIR / f"{safe_name}.bejson"
    if filepath.exists():
        return jsonify({"error": f"Profile '{safe_name}' already exists."}), 409

    if TEMPLATE_FILE.exists():
        tmpl = read_bejson(TEMPLATE_FILE)
        profile_data = {k: v for k, v in tmpl.items() if k != "_field_map"}
        row = copy.deepcopy(tmpl["Values"][0])
        profile_data["_field_map"] = build_field_map(profile_data)
        set_field(profile_data, row, "Name", safe_name)
        profile_data["Values"] = [row]
    else:
        profile_data = gemini_profiles_create(safe_name, "General Assistant",
                                              "A helpful AI assistant",
                                              "You are a helpful AI assistant.")

    write_bejson(filepath, profile_data)
    logger.info("Created profile: %s", safe_name)
    return jsonify({"message": f"Profile '{safe_name}' created.",
                    "profile_name": safe_name}), 201


@app.route("/api/profiles/<name>", methods=["PUT"])
def api_update_profile(name: str):
    filepath = PROFILES_DIR / f"{name}.bejson"
    if not filepath.exists():
        return jsonify({"error": f"Profile '{name}' not found."}), 404
    body = request.get_json(silent=True) or {}

    data = read_bejson(filepath)
    row = data["Values"][0]
    fm = data["_field_map"]

    for field_name in fm:
        if field_name in body and field_name != "Record_Type_Parent" \
                and field_name not in EMBEDDED_CODE_KEYS:
            set_field(data, row, field_name, body[field_name])

    if any(k in body for k in EMBEDDED_CODE_KEYS):
        problem = apply_embedded_code(data, body)
        if problem:
            # Nothing has been written yet: the file on disk is untouched.
            return jsonify({"error": problem}), 422
        data["_field_map"] = build_field_map(data)

    write_bejson(filepath, data)
    logger.info("Updated profile: %s", name)
    return jsonify({"message": f"Profile '{name}' updated."})


@app.route("/api/profiles/<name>", methods=["DELETE"])
def api_delete_profile(name: str):
    if name == "default":
        return jsonify({"error": "Cannot delete the default profile."}), 403
    filepath = PROFILES_DIR / f"{name}.bejson"
    if not filepath.exists():
        return jsonify({"error": f"Profile '{name}' not found."}), 404
    filepath.unlink()
    config = read_bejson(CONFIG_FILE)
    if _cfg_get(config, "Selected_Profile") == name:
        _cfg_set(config, "Selected_Profile", "default")
        write_bejson(CONFIG_FILE, config)
    logger.info("Deleted profile: %s", name)
    return jsonify({"message": f"Profile '{name}' deleted."})


@app.route("/api/config", methods=["GET"])
def api_get_config():
    config = read_bejson(CONFIG_FILE)
    return jsonify({
        "selected_profile": _cfg_get(config, "Selected_Profile") or "default",
        "profiles_enabled": (_cfg_get(config, "Profiles_Enabled") or "false").lower() == "true",
    })


@app.route("/api/config", methods=["PUT"])
def api_update_config():
    body = request.get_json(silent=True) or {}
    config = read_bejson(CONFIG_FILE)
    changed = False

    if "selected_profile" in body:
        selected = body["selected_profile"].strip()
        if not selected:
            return jsonify({"error": "selected_profile cannot be empty."}), 400
        if not (PROFILES_DIR / f"{selected}.bejson").exists():
            return jsonify({"error": f"Profile '{selected}' not found."}), 404
        _cfg_set(config, "Selected_Profile", selected)
        logger.info("Config: Selected_Profile = %s", selected)
        changed = True

    if "profiles_enabled" in body:
        enabled_val = "true" if body["profiles_enabled"] else "false"
        _cfg_set(config, "Profiles_Enabled", enabled_val)
        logger.info("Config: Profiles_Enabled = %s", enabled_val)
        changed = True

    if changed:
        write_bejson(CONFIG_FILE, config)
    return jsonify({"message": "Config updated."})


# ── Main Page ────────────────────────────────────────────────

HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="PROFILES - AI Profile Selector & Editor with BEJSON 104a storage">
<title>PROFILES v{{ version }}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
/* ─── Reset & Base ────────────────────────────── */
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
:root {
  --bg: #000000;
  --bg-surface: #0a0a0a;
  --bg-elevated: #141414;
  --bg-card: #1a1a1a;
  --bg-section: #111111;
  --text: #ffffff;
  --text-dim: #999999;
  --text-muted: #666666;
  --accent: #DE2626;
  --accent-glow: rgba(222,38,38,0.35);
  --accent-dim: rgba(222,38,38,0.15);
  --border: #2a2a2a;
  --border-focus: #DE2626;
  --radius: 8px;
  --radius-lg: 12px;
  --transition: 0.2s cubic-bezier(0.4,0,0.2,1);
  --font: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}
html { font-size: 15px; }
body {
  font-family: var(--font);
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0;
  overflow-x: hidden;
}

/* ─── Header ──────────────────────────────────── */
.prof-header {
  width: 100%;
  max-width: 700px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px 16px;
}
.prof-header h1 {
  font-size: 1.6rem;
  font-weight: 800;
  letter-spacing: 0.08em;
  color: var(--text);
  user-select: none;
}
.prof-header h1 span { color: var(--accent); }

/* ─── Enable Toggle Banner ────────────────────── */
.enable-banner {
  width: 100%;
  max-width: 700px;
  margin: 0 16px 12px;
  padding: 12px 20px;
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}
.enable-banner-label {
  font-size: 0.82rem;
  font-weight: 600;
  color: var(--text-dim);
  letter-spacing: 0.03em;
}
.enable-banner-label span {
  display: block;
  font-size: 0.72rem;
  font-weight: 400;
  color: var(--text-muted);
  margin-top: 2px;
}

/* ─── Main Card ───────────────────────────────── */
.prof-card {
  width: 100%;
  max-width: 700px;
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 24px;
  margin: 0 16px;
}

/* Selector Row */
.selector-row {
  display: flex;
  gap: 10px;
  align-items: stretch;
  flex-wrap: nowrap;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: thin;
}
.prof-select-wrapper {
  flex: 1;
  position: relative;
}
.prof-select {
  width: 100%;
  height: 44px;
  padding: 0 36px 0 14px;
  background: var(--bg-surface);
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  font-family: var(--font);
  font-size: 0.93rem;
  font-weight: 500;
  appearance: none;
  cursor: pointer;
  transition: all var(--transition);
  outline: none;
}
.prof-select:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-dim);
}
.prof-select option {
  background: var(--bg-card);
  color: var(--text);
}
.prof-select-wrapper::after {
  content: '';
  position: absolute;
  right: 14px;
  top: 50%;
  transform: translateY(-50%);
  width: 0; height: 0;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 6px solid var(--text-dim);
  pointer-events: none;
  transition: border-color var(--transition);
}
.prof-select-wrapper:focus-within::after {
  border-top-color: var(--accent);
}

/* Action Buttons */
.btn {
  height: 44px;
  padding: 0 18px;
  font-family: var(--font);
  font-size: 0.82rem;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  border: 1px solid var(--border);
  border-radius: var(--radius);
  background: var(--bg-elevated);
  color: var(--text);
  cursor: pointer;
  transition: all var(--transition);
  white-space: nowrap;
  user-select: none;
}
.btn:hover {
  border-color: var(--accent);
  color: var(--accent);
  box-shadow: 0 0 12px var(--accent-glow);
}
.btn:active { transform: scale(0.96); }
.btn--danger:hover {
  background: rgba(222,38,38,0.12);
}
.btn--primary {
  background: var(--accent);
  border-color: var(--accent);
  color: #fff;
}
.btn--primary:hover {
  background: #c42020;
  box-shadow: 0 0 20px var(--accent-glow);
  color: #fff;
}

/* Preview area */
.prof-preview {
  margin-top: 20px;
  padding: 16px;
  background: var(--bg-surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  min-height: 80px;
  transition: border-color var(--transition);
}
.prof-preview-label {
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--text-muted);
  margin-bottom: 8px;
}
.prof-preview-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px 20px;
}
.prof-preview-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.prof-preview-item .pv-label {
  font-size: 0.68rem;
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.04em;
}
.prof-preview-item .pv-val {
  font-size: 0.88rem;
  color: var(--text-dim);
  word-break: break-word;
}
.prof-preview-item.wide {
  grid-column: 1 / -1;
}

/* ─── New Profile Inline Input ────────────────── */
.new-prof-row {
  display: none;
  gap: 10px;
  align-items: stretch;
  margin-top: 14px;
  flex-wrap: nowrap;
  overflow-x: auto;
}
.new-prof-row.active { display: flex; }
.new-prof-input {
  flex: 1;
  height: 40px;
  padding: 0 14px;
  background: var(--bg-surface);
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  font-family: var(--font);
  font-size: 0.88rem;
  outline: none;
  transition: border-color var(--transition), box-shadow var(--transition);
}
.new-prof-input:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-dim);
}
.new-prof-input::placeholder { color: var(--text-muted); }

/* ─── Status Bar ──────────────────────────────── */
.status-bar {
  width: 100%;
  max-width: 700px;
  margin-top: 12px;
  padding: 0 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.status-text {
  font-size: 0.72rem;
  font-weight: 500;
  color: var(--text-muted);
  letter-spacing: 0.03em;
  transition: color var(--transition);
}
.status-text.status--error { color: var(--accent); }
.status-text.status--ok { color: #2ecc71; }
.version-text {
  font-size: 0.68rem;
  color: var(--text-muted);
  font-weight: 500;
  letter-spacing: 0.04em;
}

/* ─── Modal Overlay ───────────────────────────── */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.8);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  display: flex;
  align-items: flex-start;
  justify-content: center;
  z-index: 1000;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.25s ease;
  padding: 16px;
  overflow-y: auto;
}
.modal-overlay.active {
  opacity: 1;
  pointer-events: auto;
}

.modal {
  width: 100%;
  max-width: 600px;
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 28px;
  margin: 40px 0;
  transform: translateY(20px) scale(0.97);
  transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1);
}
.modal-overlay.active .modal {
  transform: translateY(0) scale(1);
}
.modal-title {
  font-size: 1.05rem;
  font-weight: 700;
  margin-bottom: 20px;
  color: var(--text);
}
.modal-title span { color: var(--accent); }

/* ─── Editor Sections ─────────────────────────── */
.ed-section {
  margin-bottom: 20px;
}
.ed-section-title {
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--accent);
  margin-bottom: 12px;
  padding-bottom: 6px;
  border-bottom: 1px solid var(--border);
}
.ed-row {
  display: flex;
  gap: 12px;
  margin-bottom: 10px;
  align-items: flex-start;
}
.ed-row.col { flex-direction: column; gap: 4px; }
.ed-field {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.ed-label {
  font-size: 0.72rem;
  font-weight: 600;
  color: var(--text-dim);
  letter-spacing: 0.03em;
}
.ed-input, .ed-select {
  width: 100%;
  height: 38px;
  padding: 0 12px;
  background: var(--bg-surface);
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  font-family: var(--font);
  font-size: 0.85rem;
  outline: none;
  transition: border-color var(--transition), box-shadow var(--transition);
}
.ed-input:focus, .ed-select:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-dim);
}
.ed-textarea {
  width: 100%;
  min-height: 100px;
  padding: 12px;
  background: var(--bg-surface);
  color: var(--text);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  font-family: var(--font);
  font-size: 0.85rem;
  line-height: 1.5;
  resize: vertical;
  outline: none;
  transition: border-color var(--transition), box-shadow var(--transition);
}
.ed-code {
  font-family: ui-monospace, Menlo, Consolas, monospace;
  font-size: 0.8rem;
  min-height: 140px;
  white-space: pre;
  tab-size: 2;
}
.ed-hint {
  font-size: 0.8rem;
  margin-bottom: 8px;
}
.ed-textarea:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-dim);
}

/* Slider */
.ed-slider-wrap {
  display: flex;
  align-items: center;
  gap: 10px;
}
.ed-slider {
  flex: 1;
  -webkit-appearance: none;
  appearance: none;
  height: 6px;
  background: var(--border);
  border-radius: 3px;
  outline: none;
}
.ed-slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--accent);
  cursor: pointer;
  border: 2px solid var(--bg-card);
  box-shadow: 0 0 8px var(--accent-glow);
  transition: transform var(--transition);
}
.ed-slider::-webkit-slider-thumb:hover { transform: scale(1.15); }
.ed-slider-val {
  font-size: 0.8rem;
  font-weight: 600;
  color: var(--accent);
  min-width: 36px;
  text-align: right;
}

/* Toggle Switch */
.ed-toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 0;
}
.ed-toggle-label {
  font-size: 0.82rem;
  color: var(--text-dim);
}
.toggle-switch {
  position: relative;
  width: 44px;
  height: 24px;
  flex-shrink: 0;
}
.toggle-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
.toggle-slider {
  position: absolute;
  inset: 0;
  background: var(--border);
  border-radius: 12px;
  cursor: pointer;
  transition: background var(--transition);
}
.toggle-slider::before {
  content: '';
  position: absolute;
  width: 18px;
  height: 18px;
  left: 3px;
  top: 3px;
  background: var(--text-dim);
  border-radius: 50%;
  transition: all var(--transition);
}
.toggle-switch input:checked + .toggle-slider {
  background: var(--accent);
}
.toggle-switch input:checked + .toggle-slider::before {
  background: #fff;
  transform: translateX(20px);
  box-shadow: 0 0 8px var(--accent-glow);
}

/* Tag Input */
.tag-container {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 8px;
  background: var(--bg-surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  min-height: 38px;
  transition: border-color var(--transition);
  cursor: text;
}
.tag-container:focus-within {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-dim);
}
.tag-item {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: 4px;
  font-size: 0.78rem;
  color: var(--text);
  animation: tagIn 0.2s ease;
}
@keyframes tagIn {
  from { opacity: 0; transform: scale(0.85); }
  to { opacity: 1; transform: scale(1); }
}
.tag-remove {
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
  font-size: 0.9rem;
  line-height: 1;
  padding: 0 2px;
  transition: color var(--transition);
}
.tag-remove:hover { color: var(--accent); }
.tag-input-field {
  border: none;
  background: transparent;
  color: var(--text);
  font-family: var(--font);
  font-size: 0.82rem;
  outline: none;
  min-width: 80px;
  flex: 1;
}
.tag-input-field::placeholder { color: var(--text-muted); }

.modal-actions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  margin-top: 24px;
  padding-top: 16px;
  border-top: 1px solid var(--border);
}

/* ─── Cube Decorative Grid ────────────────────── */
.cube-grid {
  width: 100%;
  max-width: 700px;
  display: flex;
  gap: 6px;
  padding: 20px 24px 0;
  opacity: 0.15;
}
.cube-cell {
  width: 8px; height: 8px;
  background: var(--text);
  border-radius: 1px;
}
.cube-cell:nth-child(even) { background: var(--accent); }

/* ─── Footer ──────────────────────────────────── */
.prof-footer {
  width: 100%;
  max-width: 700px;
  padding: 24px;
  margin-top: auto;
  text-align: center;
}
.prof-footer p {
  font-size: 0.68rem;
  color: var(--text-muted);
  line-height: 1.7;
}
.prof-footer a {
  color: var(--text-dim);
  text-decoration: none;
  transition: color var(--transition);
}
.prof-footer a:hover { color: var(--accent); }

/* ─── Scrollbar ───────────────────────────────── */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: var(--accent); }

/* ─── Responsive ──────────────────────────────── */
@media (max-width: 480px) {
  .prof-select-wrapper { min-width: 140px; }
  .btn { flex-shrink: 0; }
  .ed-row { flex-direction: column; }
  .prof-preview-grid { grid-template-columns: 1fr; }
}

/* ─── Pulse animation ─────────────────────────── */
@keyframes pulse-accent {
  0%, 100% { box-shadow: 0 0 0 0 var(--accent-glow); }
  50% { box-shadow: 0 0 16px 4px var(--accent-glow); }
}
.pulse { animation: pulse-accent 1.5s ease infinite; }
</style>
</head>
<body>

<!-- ── Decorative Cube Grid ──────────────────── -->
<div class="cube-grid" aria-hidden="true">
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
  <div class="cube-cell"></div><div class="cube-cell"></div>
</div>

<!-- ── Header ────────────────────────────────── -->
<header class="prof-header">
  <h1>PRO<span>F</span>ILES</h1>
</header>

<!-- ── Profile Enable Banner ─────────────────── -->
<div class="enable-banner">
  <div class="enable-banner-label">
    Profile Injection
    <span>Applies selected profile's system instruction to all CLI calls</span>
  </div>
  <label class="toggle-switch" title="Enable / disable profile injection">
    <input type="checkbox" id="profilesEnabled">
    <span class="toggle-slider"></span>
  </label>
</div>

<!-- ── Main Card ─────────────────────────────── -->
<main class="prof-card">
  <!-- Selector Row -->
  <div class="selector-row">
    <div class="prof-select-wrapper">
      <select class="prof-select" id="profileSelect">
        <option value="">Loading...</option>
      </select>
    </div>
    <button class="btn" id="btnNew">New</button>
    <button class="btn" id="btnEdit">Edit</button>
    <button class="btn btn--danger" id="btnDelete">Delete</button>
  </div>

  <!-- New Profile Inline Row -->
  <div class="new-prof-row" id="newProfRow">
    <input type="text" class="new-prof-input" id="newProfInput"
           placeholder="Profile name..." maxlength="40">
    <button class="btn btn--primary" id="btnCreateConfirm">Create</button>
    <button class="btn" id="btnCreateCancel">Cancel</button>
  </div>

  <!-- Preview -->
  <div class="prof-preview">
    <div class="prof-preview-label">Profile Summary</div>
    <div class="prof-preview-grid" id="previewGrid">
      <div class="prof-preview-item"><span class="pv-label">Name</span><span class="pv-val" id="pvName">—</span></div>
      <div class="prof-preview-item"><span class="pv-label">Archetype</span><span class="pv-val" id="pvArchetype">—</span></div>
      <div class="prof-preview-item"><span class="pv-label">Persona</span><span class="pv-val" id="pvPersona">—</span></div>
      <div class="prof-preview-item"><span class="pv-label">Avatar</span><span class="pv-val" id="pvAvatar">—</span></div>
      <div class="prof-preview-item"><span class="pv-label">Creativity</span><span class="pv-val" id="pvCreativity">—</span></div>
      <div class="prof-preview-item"><span class="pv-label">Formality</span><span class="pv-val" id="pvFormality">—</span></div>
      <div class="prof-preview-item"><span class="pv-label">Verbosity</span><span class="pv-val" id="pvVerbosity">—</span></div>
      <div class="prof-preview-item"><span class="pv-label">Tokens</span><span class="pv-val" id="pvTokens">—</span></div>
      <div class="prof-preview-item wide"><span class="pv-label">System Instruction</span><span class="pv-val" id="pvInstruction">—</span></div>
    </div>
  </div>
</main>

<!-- ── Status Bar ────────────────────────────── -->
<div class="status-bar">
  <span class="status-text" id="statusText">Idle</span>
  <span class="version-text">v{{ version }}</span>
</div>

<!-- ── Edit Dialog Modal ─────────────────────── -->
<div class="modal-overlay" id="editModal">
  <div class="modal">
    <div class="modal-title">Edit Profile: <span id="editProfileName"></span></div>

    <!-- Identity Section -->
    <div class="ed-section">
      <div class="ed-section-title">Identity</div>
      <div class="ed-row">
        <div class="ed-field"><label class="ed-label">Name</label><input class="ed-input" id="edName" type="text"></div>
        <div class="ed-field"><label class="ed-label">Archetype</label><input class="ed-input" id="edArchetype" type="text"></div>
      </div>
      <div class="ed-row col">
        <label class="ed-label">Persona</label>
        <input class="ed-input" id="edPersona" type="text">
      </div>
      <div class="ed-row">
        <div class="ed-field">
          <label class="ed-label">Avatar Type</label>
          <select class="ed-select" id="edAvatarType">
            <option value="Emoji">Emoji</option>
            <option value="URL">URL</option>
            <option value="Base64">Base64</option>
          </select>
        </div>
        <div class="ed-field"><label class="ed-label">Avatar Data</label><input class="ed-input" id="edAvatarData" type="text" placeholder="🤖"></div>
      </div>
    </div>

    <!-- Instructions Section -->
    <div class="ed-section">
      <div class="ed-section-title">Instructions</div>
      <div class="ed-row col">
        <label class="ed-label">System Instruction</label>
        <textarea class="ed-textarea" id="edInstruction" placeholder="Enter system instructions..."></textarea>
      </div>
    </div>

    <!-- Behavior Section -->
    <div class="ed-section">
      <div class="ed-section-title">Behavior</div>
      <div class="ed-row">
        <div class="ed-field">
          <label class="ed-label">Max Response Tokens</label>
          <input class="ed-input" id="edMaxTokens" type="number" min="1" max="65536">
        </div>
        <div class="ed-field">
          <label class="ed-label">Formality</label>
          <select class="ed-select" id="edFormality">
            <option value="Formal">Formal</option>
            <option value="Neutral">Neutral</option>
            <option value="Casual">Casual</option>
          </select>
        </div>
      </div>
      <div class="ed-row">
        <div class="ed-field">
          <label class="ed-label">Verbosity</label>
          <select class="ed-select" id="edVerbosity">
            <option value="Minimal">Minimal</option>
            <option value="Normal">Normal</option>
            <option value="Verbose">Verbose</option>
          </select>
        </div>
      </div>
      <div class="ed-row col">
        <label class="ed-label">Creativity</label>
        <div class="ed-slider-wrap">
          <input class="ed-slider" id="edCreativity" type="range" min="0" max="2" step="0.05">
          <span class="ed-slider-val" id="edCreativityVal">0.7</span>
        </div>
      </div>
      <div class="ed-row col">
        <label class="ed-label">Tone</label>
        <div class="tag-container" id="edTone">
          <input class="tag-input-field" data-tag="tone" placeholder="Add tone...">
        </div>
      </div>
    </div>

    <!-- Expression Section -->
    <div class="ed-section">
      <div class="ed-section-title">Expression</div>
      <div class="ed-toggle-row">
        <span class="ed-toggle-label">Emotional Expression</span>
        <label class="toggle-switch"><input type="checkbox" id="edEmotional"><span class="toggle-slider"></span></label>
      </div>
      <div class="ed-row col">
        <label class="ed-label">Emotional Intensity</label>
        <div class="ed-slider-wrap">
          <input class="ed-slider" id="edEmotionalIntensity" type="range" min="0" max="1" step="0.05">
          <span class="ed-slider-val" id="edEmotionalIntensityVal">0.0</span>
        </div>
      </div>
    </div>

    <!-- Tools Section -->
    <div class="ed-section">
      <div class="ed-section-title">Tools</div>
      <div class="ed-toggle-row">
        <span class="ed-toggle-label">Google Search</span>
        <label class="toggle-switch"><input type="checkbox" id="edGoogleSearch"><span class="toggle-slider"></span></label>
      </div>
      <div class="ed-toggle-row">
        <span class="ed-toggle-label">Code Interpreter</span>
        <label class="toggle-switch"><input type="checkbox" id="edCodeInterpreter"><span class="toggle-slider"></span></label>
      </div>
      <div class="ed-toggle-row">
        <span class="ed-toggle-label">Ephemeral Memory</span>
        <label class="toggle-switch"><input type="checkbox" id="edEphemeralMemory"><span class="toggle-slider"></span></label>
      </div>
      <div class="ed-toggle-row">
        <span class="ed-toggle-label">Thinking Supported</span>
        <label class="toggle-switch"><input type="checkbox" id="edThinking"><span class="toggle-slider"></span></label>
      </div>
    </div>

    <!-- Code Parsing Section -->
    <div class="ed-section">
      <div class="ed-section-title">Code Parsing</div>
      <div class="ed-row">
        <div class="ed-field">
          <label class="ed-label">Mode</label>
          <select class="ed-select" id="edCodeMode">
            <option value="complete">Complete</option>
            <option value="partial">Partial</option>
            <option value="disabled">Disabled</option>
          </select>
        </div>
      </div>
      <div class="ed-row col">
        <label class="ed-label">Languages</label>
        <div class="tag-container" id="edCodeLangs">
          <input class="tag-input-field" data-tag="codeLangs" placeholder="Add language...">
        </div>
      </div>
      <div class="ed-toggle-row">
        <span class="ed-toggle-label">Structure Validation</span>
        <label class="toggle-switch"><input type="checkbox" id="edStructureValidation"><span class="toggle-slider"></span></label>
      </div>
      <div class="ed-toggle-row">
        <span class="ed-toggle-label">Version Control</span>
        <label class="toggle-switch"><input type="checkbox" id="edVersionControl"><span class="toggle-slider"></span></label>
      </div>
    </div>

    <!-- Embedded Code Section -->
    <div class="ed-section">
      <div class="ed-section-title">Embedded Code</div>
      <div class="ed-hint">Optional. The Parser turns the model&rsquo;s raw reply into a value: <code>parse(raw_text)</code>. The Renderer draws it: <code>render(parsed, container)</code> (vanilla JavaScript, shown in a sandboxed frame). Saving changed code withdraws any approval in the chat client &mdash; review and approve it there again. Leave both blank for none.</div>
      <div class="ed-row">
        <div class="ed-field">
          <label class="ed-label">Parser language</label>
          <select class="ed-select" id="edParserLang">
            <option value="">None</option>
            <option value="python">Python</option>
            <option value="javascript">JavaScript</option>
          </select>
        </div>
      </div>
      <div class="ed-row col">
        <label class="ed-label">Parser</label>
        <textarea class="ed-textarea ed-code" id="edParserCode" spellcheck="false" placeholder="def parse(raw_text):&#10;    return {...}"></textarea>
      </div>
      <div class="ed-row col">
        <label class="ed-label">Renderer (JavaScript)</label>
        <textarea class="ed-textarea ed-code" id="edRendererCode" spellcheck="false" placeholder="function render(parsed, container) {&#10;  container.textContent = JSON.stringify(parsed);&#10;}"></textarea>
      </div>
    </div>

    <!-- Restrictions Section -->
    <div class="ed-section">
      <div class="ed-section-title">Restrictions</div>
      <div class="ed-row col">
        <label class="ed-label">Forbidden Topics</label>
        <div class="tag-container" id="edForbidden">
          <input class="tag-input-field" data-tag="forbidden" placeholder="Add topic...">
        </div>
      </div>
    </div>

    <div class="modal-actions">
      <button class="btn" id="btnEditCancel">Cancel</button>
      <button class="btn btn--primary" id="btnEditSave">Save</button>
    </div>
  </div>
</div>

<!-- ── Footer ────────────────────────────────── -->
<footer class="prof-footer">
  <p>
    Elton Boehnen &middot;
    <a href="mailto:boehnenelton2024@gmail.com">boehnenelton2024@gmail.com</a> &middot;
    <a href="https://boehnenelton2024.pages.dev" target="_blank">boehnenelton2024.pages.dev</a> &middot;
    <a href="https://github.com/boehnenelton" target="_blank">github.com/boehnenelton</a>
  </p>
</footer>

<script>
/* ─────────────────────────────────────────────────────────────
 * PROFILES - Client Logic  v{{ version }}
 * Fields use This_Case (Name, System_Instruction, etc.) as
 * returned by the API (mapped from BEJSON Field Map Cache).
 * ───────────────────────────────────────────────────────────── */
(function() {
  'use strict';

  // ── DOM refs ──────────────────────────────────────────────
  const profileSelect    = document.getElementById('profileSelect');
  const profilesEnabled  = document.getElementById('profilesEnabled');
  const btnNew           = document.getElementById('btnNew');
  const btnEdit          = document.getElementById('btnEdit');
  const btnDelete        = document.getElementById('btnDelete');
  const newProfRow       = document.getElementById('newProfRow');
  const newProfInput     = document.getElementById('newProfInput');
  const btnCreateConfirm = document.getElementById('btnCreateConfirm');
  const btnCreateCancel  = document.getElementById('btnCreateCancel');
  const statusText       = document.getElementById('statusText');

  // Preview
  const pvName        = document.getElementById('pvName');
  const pvArchetype   = document.getElementById('pvArchetype');
  const pvPersona     = document.getElementById('pvPersona');
  const pvAvatar      = document.getElementById('pvAvatar');
  const pvCreativity  = document.getElementById('pvCreativity');
  const pvFormality   = document.getElementById('pvFormality');
  const pvVerbosity   = document.getElementById('pvVerbosity');
  const pvTokens      = document.getElementById('pvTokens');
  const pvInstruction = document.getElementById('pvInstruction');

  // Edit modal
  const editModal       = document.getElementById('editModal');
  const editProfileName = document.getElementById('editProfileName');
  const btnEditSave     = document.getElementById('btnEditSave');
  const btnEditCancel   = document.getElementById('btnEditCancel');

  // Editor fields — This_Case API keys
  const edName          = document.getElementById('edName');
  const edArchetype     = document.getElementById('edArchetype');
  const edPersona       = document.getElementById('edPersona');
  const edAvatarType    = document.getElementById('edAvatarType');
  const edAvatarData    = document.getElementById('edAvatarData');
  const edInstruction   = document.getElementById('edInstruction');
  const edMaxTokens     = document.getElementById('edMaxTokens');
  const edFormality     = document.getElementById('edFormality');
  const edVerbosity     = document.getElementById('edVerbosity');
  const edCreativity    = document.getElementById('edCreativity');
  const edCreativityVal = document.getElementById('edCreativityVal');
  const edEmotional     = document.getElementById('edEmotional');
  const edEmotionalIntensity    = document.getElementById('edEmotionalIntensity');
  const edEmotionalIntensityVal = document.getElementById('edEmotionalIntensityVal');
  const edGoogleSearch        = document.getElementById('edGoogleSearch');
  const edCodeInterpreter     = document.getElementById('edCodeInterpreter');
  const edEphemeralMemory     = document.getElementById('edEphemeralMemory');
  const edThinking            = document.getElementById('edThinking');
  const edCodeMode            = document.getElementById('edCodeMode');
  const edParserLang          = document.getElementById('edParserLang');
  const edParserCode          = document.getElementById('edParserCode');
  const edRendererCode        = document.getElementById('edRendererCode');
  const edStructureValidation = document.getElementById('edStructureValidation');
  const edVersionControl      = document.getElementById('edVersionControl');
  const edTone      = document.getElementById('edTone');
  const edCodeLangs = document.getElementById('edCodeLangs');
  const edForbidden = document.getElementById('edForbidden');

  // ── State ─────────────────────────────────────────────────
  let currentProfiles = [];
  let selectedProfile = 'default';
  let currentProfileData = null;
  const tagData = { tone: [], codeLangs: [], forbidden: [] };

  // ── Status helpers ────────────────────────────────────────
  function setStatus(msg, type) {
    statusText.textContent = msg;
    statusText.className = 'status-text';
    if (type === 'error') statusText.classList.add('status--error');
    else if (type === 'ok') statusText.classList.add('status--ok');
  }

  // ── API helpers ───────────────────────────────────────────
  async function apiFetch(url, opts) {
    try {
      const res = await fetch(url, opts);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      return data;
    } catch (err) {
      setStatus(err.message, 'error');
      throw err;
    }
  }

  // ── Tag Input System ──────────────────────────────────────
  function renderTags(container, key) {
    const input = container.querySelector('.tag-input-field');
    container.querySelectorAll('.tag-item').forEach(t => t.remove());
    tagData[key].forEach((tag, idx) => {
      const el = document.createElement('span');
      el.className = 'tag-item';
      el.innerHTML = `${tag}<button class="tag-remove" data-key="${key}" data-idx="${idx}">&times;</button>`;
      container.insertBefore(el, input);
    });
  }

  function initTagInput(container, key) {
    const input = container.querySelector('.tag-input-field');
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && input.value.trim()) {
        e.preventDefault();
        tagData[key].push(input.value.trim());
        input.value = '';
        renderTags(container, key);
      }
      if (e.key === 'Backspace' && !input.value && tagData[key].length) {
        tagData[key].pop();
        renderTags(container, key);
      }
    });
    container.addEventListener('click', (e) => {
      if (e.target.classList.contains('tag-remove')) {
        const k = e.target.dataset.key;
        const i = parseInt(e.target.dataset.idx);
        tagData[k].splice(i, 1);
        renderTags(container, k);
      }
      input.focus();
    });
  }

  initTagInput(edTone, 'tone');
  initTagInput(edCodeLangs, 'codeLangs');
  initTagInput(edForbidden, 'forbidden');

  // ── Slider Bindings ───────────────────────────────────────
  edCreativity.addEventListener('input', () => {
    edCreativityVal.textContent = parseFloat(edCreativity.value).toFixed(2);
  });
  edEmotionalIntensity.addEventListener('input', () => {
    edEmotionalIntensityVal.textContent = parseFloat(edEmotionalIntensity.value).toFixed(2);
  });

  // ── Profiles Enabled toggle ───────────────────────────────
  profilesEnabled.addEventListener('change', async () => {
    setStatus('Saving...', '');
    try {
      await apiFetch('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profiles_enabled: profilesEnabled.checked })
      });
      setStatus(profilesEnabled.checked ? 'Profile injection enabled.' : 'Profile injection disabled.', 'ok');
    } catch { /* status set by apiFetch */ }
  });

  // ── Load profiles list ────────────────────────────────────
  async function loadProfiles() {
    setStatus('Loading...', '');
    const data = await apiFetch('/api/profiles');
    currentProfiles = data.profiles;
    profileSelect.innerHTML = '';
    currentProfiles.forEach(name => {
      const opt = document.createElement('option');
      opt.value = name;
      opt.textContent = name;
      profileSelect.appendChild(opt);
    });
    const cfg = await apiFetch('/api/config');
    selectedProfile = cfg.selected_profile;
    profilesEnabled.checked = !!cfg.profiles_enabled;
    if (currentProfiles.includes(selectedProfile)) {
      profileSelect.value = selectedProfile;
    }
    await loadProfilePreview(selectedProfile);
    setStatus('Idle', '');
  }

  // ── Load preview ──────────────────────────────────────────
  async function loadProfilePreview(name) {
    if (!name) return;
    try {
      const data = await apiFetch(`/api/profiles/${name}`);
      currentProfileData = data;
      // API returns This_Case keys via Field Map Cache
      pvName.textContent        = data['Name'] || '—';
      pvArchetype.textContent   = data['Archetype'] || '—';
      pvPersona.textContent     = data['Persona'] || '—';
      pvAvatar.textContent      = (data['Avatar_Data'] || '—') + (data['Avatar_Type'] ? ` (${data['Avatar_Type']})` : '');
      pvCreativity.textContent  = data['Creativity'] !== undefined ? data['Creativity'] : '—';
      pvFormality.textContent   = data['Formality'] || '—';
      pvVerbosity.textContent   = data['Verbosity'] || '—';
      pvTokens.textContent      = data['Max_Response_Tokens'] !== undefined ? data['Max_Response_Tokens'] : '—';
      const instr = data['System_Instruction'] || '';
      pvInstruction.textContent = instr.length > 200 ? instr.substring(0, 200) + '...' : (instr || '—');
    } catch {
      currentProfileData = null;
    }
  }

  // ── Profile select change ─────────────────────────────────
  profileSelect.addEventListener('change', async () => {
    selectedProfile = profileSelect.value;
    await apiFetch('/api/config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ selected_profile: selectedProfile })
    });
    await loadProfilePreview(selectedProfile);
    setStatus('Idle', '');
  });

  // ── New Profile ───────────────────────────────────────────
  btnNew.addEventListener('click', () => {
    newProfRow.classList.add('active');
    newProfInput.value = '';
    newProfInput.focus();
  });
  btnCreateCancel.addEventListener('click', () => {
    newProfRow.classList.remove('active');
  });
  btnCreateConfirm.addEventListener('click', async () => {
    const name = newProfInput.value.trim();
    if (!name) { setStatus('Name cannot be empty.', 'error'); return; }
    setStatus('Creating...', '');
    try {
      const data = await apiFetch('/api/profiles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile_name: name })
      });
      newProfRow.classList.remove('active');
      await loadProfiles();
      profileSelect.value = data.profile_name;
      profileSelect.dispatchEvent(new Event('change'));
      setStatus(`Created '${data.profile_name}'.`, 'ok');
    } catch { /* status set by apiFetch */ }
  });
  newProfInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') btnCreateConfirm.click();
    if (e.key === 'Escape') btnCreateCancel.click();
  });

  // ── Edit Profile ──────────────────────────────────────────
  btnEdit.addEventListener('click', async () => {
    const name = profileSelect.value;
    if (!name) { setStatus('No profile selected.', 'error'); return; }
    try {
      const data = await apiFetch(`/api/profiles/${name}`);
      editProfileName.textContent = name;

      edName.value          = data['Name'] || '';
      edArchetype.value     = data['Archetype'] || '';
      edPersona.value       = data['Persona'] || '';
      edAvatarType.value    = data['Avatar_Type'] || 'Emoji';
      edAvatarData.value    = data['Avatar_Data'] || '';
      edInstruction.value   = data['System_Instruction'] || '';
      edMaxTokens.value     = data['Max_Response_Tokens'] || 8192;
      edFormality.value     = data['Formality'] || 'Neutral';
      edVerbosity.value     = data['Verbosity'] || 'Normal';
      edCreativity.value    = data['Creativity'] !== undefined ? data['Creativity'] : 0.7;
      edCreativityVal.textContent = parseFloat(edCreativity.value).toFixed(2);

      tagData.tone = Array.isArray(data['Tone']) ? [...data['Tone']] : [];
      renderTags(edTone, 'tone');

      edEmotional.checked = !!data['Emotional_Expression_Enabled'];
      edEmotionalIntensity.value = data['Emotional_Expression_Intensity'] || 0;
      edEmotionalIntensityVal.textContent = parseFloat(edEmotionalIntensity.value).toFixed(2);

      edGoogleSearch.checked    = !!data['Google_Search_Enabled'];
      edCodeInterpreter.checked = !!data['Code_Interpreter_Enabled'];
      edEphemeralMemory.checked = !!data['Ephemeral_Memory'];
      edThinking.checked        = !!data['Thinking_Supported'];

      edCodeMode.value = data['Code_Parsing_Mode'] || 'complete';
      edParserLang.value     = data['Parser_Language'] || '';
      edParserCode.value     = data['Parser'] || '';
      edRendererCode.value   = data['Renderer'] || '';
      tagData.codeLangs = Array.isArray(data['Code_Parsing_Languages']) ? [...data['Code_Parsing_Languages']] : [];
      renderTags(edCodeLangs, 'codeLangs');
      edStructureValidation.checked = !!data['Code_Parsing_Structure_Validation'];
      edVersionControl.checked      = !!data['Code_Parsing_Version_Control'];

      tagData.forbidden = Array.isArray(data['Forbidden_Topics']) ? [...data['Forbidden_Topics']] : [];
      renderTags(edForbidden, 'forbidden');

      editModal.classList.add('active');
      edName.focus();
    } catch { /* status set */ }
  });

  btnEditCancel.addEventListener('click', () => {
    editModal.classList.remove('active');
  });

  btnEditSave.addEventListener('click', async () => {
    const origName = editProfileName.textContent;
    setStatus('Saving...', '');
    const payload = {
      Name:                           edName.value,
      Archetype:                      edArchetype.value,
      Persona:                        edPersona.value,
      Avatar_Type:                    edAvatarType.value,
      Avatar_Source_Url:              '',
      Avatar_Data:                    edAvatarData.value,
      System_Instruction:             edInstruction.value,
      Max_Response_Tokens:            parseInt(edMaxTokens.value) || 8192,
      Creativity:                     parseFloat(edCreativity.value) || 0.7,
      Formality:                      edFormality.value,
      Verbosity:                      edVerbosity.value,
      Tone:                           tagData.tone,
      Emotional_Expression_Enabled:   edEmotional.checked,
      Emotional_Expression_Intensity: parseFloat(edEmotionalIntensity.value) || 0,
      Google_Search_Enabled:          edGoogleSearch.checked,
      Code_Interpreter_Enabled:       edCodeInterpreter.checked,
      Ephemeral_Memory:               edEphemeralMemory.checked,
      Thinking_Supported:             edThinking.checked,
      Code_Parsing_Mode:              edCodeMode.value,
      Code_Parsing_Languages:         tagData.codeLangs,
      Code_Parsing_Structure_Validation: edStructureValidation.checked,
      Code_Parsing_Version_Control:   edVersionControl.checked,
      Parser_Language:                edParserLang.value,
      Parser:                         edParserCode.value,
      Renderer:                       edRendererCode.value,
      Forbidden_Topics:               tagData.forbidden,
    };
    try {
      await apiFetch(`/api/profiles/${origName}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      editModal.classList.remove('active');
      await loadProfilePreview(origName);
      setStatus('Saved.', 'ok');
    } catch { /* status set */ }
  });

  editModal.addEventListener('click', (e) => {
    if (e.target === editModal) editModal.classList.remove('active');
  });

  // ── Delete Profile ────────────────────────────────────────
  btnDelete.addEventListener('click', async () => {
    const name = profileSelect.value;
    if (!name) { setStatus('No profile selected.', 'error'); return; }
    if (name === 'default') { setStatus('Cannot delete the default profile.', 'error'); return; }
    if (!confirm(`Delete profile "${name}"?`)) return;
    setStatus('Deleting...', '');
    try {
      await apiFetch(`/api/profiles/${name}`, { method: 'DELETE' });
      await loadProfiles();
      setStatus(`Deleted '${name}'.`, 'ok');
    } catch { /* status set */ }
  });

  // ── Keyboard shortcuts ────────────────────────────────────
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      editModal.classList.remove('active');
      newProfRow.classList.remove('active');
    }
  });

  // ── Init ──────────────────────────────────────────────────
  loadProfiles();
})();
</script>

</body>
</html>"""


@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE, version=VERSION)


# ── Entry Point ──────────────────────────────────────────────
if __name__ == "__main__":
    ensure_defaults()
    logger.info("PROFILES v%s starting on port %d", VERSION, PORT)
    app.run(host="0.0.0.0", port=PORT, debug=False)
