# AI Library Modularity Report — Services & Extensions

**Date:** 2026-09-18
**Author:** Claude, for Elton Boehnen
**Scope:** `CLI_AI-V15-PKG17` (the library source project) and, for
comparison, the working prototype already shipped in `Cognitive_Core`
**Companion doc:** `dev/docs/Instructions3.md` — the stated intent this
report assesses the codebase against

---

## 1. Executive Summary

The goal, in Elton's words: classify every AI library file as either a
**Service** (talks to one provider) or an **Extension** (adds a capability
to any call, regardless of provider), and make the two compose like Lego
bricks — any Extension attachable to any Service, seamlessly, with no code
changes on either side.

Today's codebase is **partway there**. The `ai_dispatch_call()` unified
interface already gives six of seven Services a common bus. But three
concrete problems block real Lego composability:

1. **Gemini isn't on the bus.** `prompt_gemini.py` bypasses
   `ai_dispatch_call()` entirely and talks straight to
   `lib_bejson_AI_bejson_interactions.GeminiInteractionsAPI`. Whatever
   Extension mechanism gets built, Gemini won't benefit from it until this
   changes.
2. **The two Extensions actually in use (call logging, console output) are
   hand-wired into every CLI script individually**, not attached through
   any shared mechanism. The same three lines are duplicated across all
   seven `prompt_<service>.py` files. Turning logging off for one service
   means editing that service's file, not flipping a switch.
3. **The two most capable Extensions (context bubble, keyword triggers)
   have zero attachment points anywhere.** They're fully built, fully
   working in isolation, and completely disconnected from every Service.

Section 4 below shows exactly where a working solution to this already
exists — I built one, and shipped it, in `Cognitive_Core`'s copy of
`ai_dispatch.py`. It isn't fully general yet (context_bubble's state
handling has a documented scope limitation), but it proves the pattern.
This report's core recommendation is to **port that pattern upstream, into
this library source project itself**, generalize it, and then use it to
fix all three problems above at the root — rather than every downstream
consumer (Cognitive_Core, the CLI_AI `client/` app, future projects)
re-solving the same problem independently.

---

## 2. Method

This assessment is based on reading the actual source in
`CLI_AI-V15-PKG17`, not on the package's own documentation claims. Where a
claim below is about behavior, it's backed by a specific file and line
reference, and in most cases a command that reproduces the finding.
Where I'm proposing something new, it's marked as a recommendation, not a
finding.

---

## 3. Current State: The Inventory

### 3.1 Services (talk to one provider)

| Service | File | On `ai_dispatch_call`? |
|---|---|---|
| Gemini | `lib_bejson_AI_bejson_gemini.py` | **No** — `prompt_gemini.py` uses `lib_bejson_AI_bejson_interactions.GeminiInteractionsAPI` directly |
| Grok | `lib_bejson_AI_bejson_grok.py` | Yes |
| Groq | `lib_bejson_AI_bejson_groq.py` | Yes |
| HuggingFace | `lib_bejson_AI_bejson_huggingface.py` | Yes |
| OpenRouter | `lib_bejson_AI_bejson_openrouter.py` | Yes |
| TokenRouter | `lib_bejson_AI_bejson_tokenrouter.py` | Yes |
| Ollama | `lib_bejson_AI_bejson_ollama.py` | Yes |
| GenAI | `lib_bejson_AI_bejson_genai.py` | Yes |

Every Service that's on the bus follows the same shape: a key registry, a
model registry, a profile class, and a `get_standard_prompter()` factory
returning an object with a `.prompt(user_input, model_id, system_instruction=...)`
method. This consistency is exactly what makes the bus possible — it's
the reason six Services can share one dispatch function at all. Gemini
being the odd one out isn't a minor inconsistency; it's the single
biggest blocker to "any Extension, any Service," because Gemini is
arguably the most-used Service in the project.

### 3.2 Extensions (add a capability to any call)

| Extension | File | Currently attached to |
|---|---|---|
| Call logging | `lib_bejson_AI_ai_call_log.py` | Every CLI script, hand-wired individually (see 4.2) |
| Console output | `lib_bejson_AI_ai_console_log.py` | Every CLI script, hand-wired individually |
| Context bubble | `lib_bejson_AI_ai_context_bubble.py` | **Nothing.** Zero callers anywhere in this package. |
| Keyword triggers | `lib_bejson_AI_ai_keywords.py` | Only as an internal dependency of context bubble — not independently attachable |
| Command system | `lib_bejson_AI_ai_command_system.py` | Not wired into any CLI script's input loop |
| Workspace Brain helper | `lib_bejson_AI_brain_helper.py` | Standalone; nothing calls it from a dispatch path |
| Structured-output auto-parse | Built into `lib_bejson_AI_ai_response.py`'s `ai_response_ok()` | Every Service, but **unconditionally** — not a switch, just always-on |

Context bubble is worth dwelling on: it's not a stub. It's a complete,
18-function/class module (`ai_bubble_assemble()` at line 412 of
`lib_bejson_AI_ai_context_bubble.py`) that assembles policy, cwd, task,
environment, and knowledge context into a budgeted string, with keyword
cooldown tracking via its dependency on `ai_keywords.py`. It's the most
sophisticated Extension in the library, and it is attached to *nothing*.
That's not a small gap — it's the exact gap that motivated this report's
existence.

### 3.3 Infrastructure (neither — foundational plumbing)

`ai_dispatch.py`, `ai_transcribe_dispatch.py`, `ai_registry_base.py`,
`ai_openai_compatible_base.py`, `ai_response.py`, `ai_constants.py`,
`bejson_errors.py`, `gemini_standard_profiles.py`. These aren't Services
or Extensions — they're what Services and Extensions are both built out
of, or the bus they communicate over. Not part of the classification, but
worth naming so the classification doesn't feel incomplete.

---

## 4. Current State: The Coupling Problems, With Evidence

### 4.1 Gemini bypasses the bus

```
$ grep -n "ai_dispatch_call\|GeminiInteractionsAPI" CLI/gemini_cli/prompt_gemini.py
84:from lib_bejson_AI_bejson_interactions import get_standard_interactions_api, GeminiInteractionsAPI
```

No `ai_dispatch_call` import at all. Every other provider's CLI script
imports it. This means any Extension attached at the `ai_dispatch_call`
level — which is the natural, lowest-effort attachment point, since it's
already the one place every other Service passes through — simply never
runs for Gemini calls. Whatever gets built for Extensions, Gemini needs a
path onto the same bus, or it'll permanently be the one Service Lego
bricks don't fit.

### 4.2 Logging is copy-pasted, not attached

```
$ grep -n "console_log.setup_logging\|log_ai_call(" CLI/*/prompt_*.py | wc -l
32
```

Thirty-two call sites, across seven files, doing the same two things:
importing `ai_call_log`/`ai_console_log` and invoking them directly. This
is the textbook shape of a feature that was built once and then
copy-pasted into every consumer instead of being built as something
consumers *attach*. It works, today. It's also the reason "turn off
logging for just Groq" or "swap in a different log destination for just
one Service" both currently require editing that Service's own CLI
script — the opposite of a configuration switch.

### 4.3 Context bubble and keywords have no attachment point

```
$ grep -rln "ai_context_bubble\|ai_bubble_assemble" CLI/ lib/AI/*.py
lib/AI/lib_bejson_AI_ai_context_bubble.py
```

Only the file itself. No CLI script, no Service file, nothing in
`ai_dispatch.py`, references it. `ai_keywords.py` is referenced from
exactly one place — inside `ai_context_bubble.py` itself, as an internal
dependency, not as an independently attachable Extension in its own
right.

### 4.4 Auto-parse is always-on, not switchable

`ai_response_ok()` calls `auto_parse_bejson_104db()` unconditionally for
every successful response, from every Service. It's cheap (an early-exit
check for 104db-shaped content), so this hasn't caused a visible problem,
but it's still an Extension with no off switch — which matters the moment
someone wants a Service that should never attempt structured-output
parsing (a raw-text-only chatbot, say), and currently can't say so.

---

## 5. Prior Art: What Already Works (Cognitive_Core)

Cognitive_Core (a downstream project consuming these libraries) already
had to solve a version of this exact problem, and the solution is worth
treating as a first draft rather than reinventing from scratch. Summary
of what's there today, in `Cognitive_Core/lib/AI/lib_bejson_AI_ai_dispatch.py`:

- `_load_client_features(provider)` loads
  `config/<provider>_features.104a.bejson` — **one config file per
  Service**, not a single global switch, so each Service's Extensions
  toggle independently.
- `_apply_features_pre(provider, features, system_instruction)` runs
  before the adapter call — currently just context bubble, which gets
  prepended to `system_instruction` if enabled.
- `_apply_features_post(provider, features, user_input, response)` runs
  after — currently gates auto-parse (strips the result post-hoc if
  disabled) and fires call logging if enabled.
- Every Service's adapter function is unchanged. The attachment logic
  lives entirely in `ai_dispatch_call()`, once, and applies uniformly.

This is a genuinely working instance of "any Extension, any Service" —
for the two Extensions it covers. Its known limitations, which any
upstream port needs to solve for real rather than inherit:

- **Context bubble's state is process-global**, not per-conversation. It
  needs a turn counter and a keyword-cooldown dict that persist across
  calls, and `ai_dispatch_call` — being a stateless per-request function
  with no session concept — currently owns that state at module scope.
  Fine for a single-session CLI process; wrong the moment two independent
  conversations run in the same process (a multi-user server, say).
- **Only two Extensions are wired this way.** Console logging, keyword
  triggers standalone, the command system, and the Workspace Brain helper
  aren't part of this mechanism at all yet — they're either still
  hand-wired (console logging) or still fully disconnected (the rest).
- **It's per-project, not per-library.** This exists in Cognitive_Core's
  *copy* of `ai_dispatch.py`, not in this source library. Every other
  consumer of this library starts from zero on this problem.

---

## 6. Proposed Target Architecture

### 6.1 The Service Contract

Formalize, in a docstring at the top of `ai_registry_base.py`, what
already exists as convention: every Service's `get_standard_prompter()`
must return an object exposing exactly:

```python
class ServicePrompter(Protocol):
    def prompt(self, user_input: str, model_id: Optional[str] = None,
               system_instruction: Optional[str] = None) -> str: ...
    model_reg: ModelRegistryBase  # for .active_model_id
```

This is already true of every Service on the bus today — writing it down
as a contract (and adding the conformance test in Section 8) turns an
implicit convention into an enforced one, which matters once there are
more than seven Services and more than one person adding them.

### 6.2 The Extension Contract

This doesn't exist yet in any form and is the actual gap. Propose:

```python
class Extension(Protocol):
    name: str  # matches the feature_name key in *_features.104a.bejson

    def pre_call(self, provider: str, system_instruction: Optional[str],
                 options: dict, state: dict) -> Optional[str]:
        """Return the (possibly modified) system_instruction to actually
        send. `state` is a dict this Extension owns and that persists
        across calls for as long as the caller keeps passing the same
        state object back in - see 6.3."""
        ...

    def post_call(self, provider: str, user_input: str,
                  response: AIResponse, options: dict, state: dict) -> AIResponse:
        """Return the (possibly modified) response."""
        ...
```

An Extension that doesn't need one of the two hooks just doesn't
implement it (call logging only needs `post_call`; context bubble only
needs `pre_call`). The key property: **nothing in this interface
mentions a Service by name.** An Extension written against this contract
cannot special-case Gemini vs. Grok even if it wanted to — the contract
doesn't give it a way to know which Service it's attached to, beyond the
`provider` string, which it can log but shouldn't branch on.

### 6.3 Solving statefulness properly

Cognitive_Core's module-global state is a real limitation, not just a
style nit — it's the difference between "works for one CLI session" and
"works as a real library." Recommend: `ai_dispatch_call()` gains an
optional `session_state: Optional[dict] = None` parameter. When provided,
it's threaded into `pre_call`/`post_call` as the `state` dict above, and
the caller owns its lifetime (a CLI script creates one dict at startup
and reuses it; a server creates one per active conversation). When
omitted, dispatch falls back to a module-level dict — preserving today's
behavior for simple callers, while giving multi-conversation callers a
real, correct way to keep their bubbles independent. This is additive: no
existing caller breaks.

### 6.4 The attachment mechanism

Keep Cognitive_Core's per-Service config file pattern — it's the right
call for exactly the reason Elton specified when this was discussed
before ("configuration should be held by the client... that way we don't
have one configuration for every client"). Move it here, upstream:

- `lib/AI/config/<service>_features.104a.bejson` per Service — same
  schema already in production: `feature_name` / `enabled` / `description`
  / `options`.
- `_EXTENSIONS` registry dict in `ai_dispatch.py`, mapping `feature_name`
  to an `Extension` instance — the Extension-side equivalent of
  `_ADAPTERS`.
- `ai_dispatch_call()` loads the calling Service's feature config, and
  for each enabled entry whose name is in `_EXTENSIONS`, calls
  `pre_call`/`post_call` in registration order.

Adding a new Extension becomes: write one file implementing the
contract, register it in one dict, and every Service can opt in via its
own config — no Service file touched, no CLI script touched. Adding a new
Service becomes: write one adapter, register it in `_ADAPTERS`, add its
`_features.104a.bejson` (can start with everything `enabled: false`) —
every existing Extension is already available to it for free.

### 6.5 What happens to the CLI scripts

Once `ai_dispatch_call()` owns Extension application, every
`prompt_<service>.py`'s hand-wired `log_ai_call`/`console_log` calls
become redundant — they'd fire twice (once from the script, once from
dispatch) if left in place. Migration needs to actually delete the
hand-wired calls from all seven scripts, not just add the new mechanism
alongside them, or the "32 call sites" problem in Section 4.2 becomes 64.

---

## 7. Migration Plan

Ordered by what unblocks the most value soonest, and by risk (lowest-risk,
most-isolated changes first).

**Phase 1 — Formalize the contracts (no behavior change).**
Write the Service and Extension protocol docstrings from 6.1/6.2 into
`ai_registry_base.py`. Add the conformance test from Section 8. This is
pure documentation-as-code; nothing runtime changes, and it gives every
later phase something concrete to check itself against.

**Phase 2 — Port the Extension mechanism upstream.**
Bring `_load_client_features`, `_apply_features_pre`/`_post`, and the
per-Service config file convention from Cognitive_Core into this
project's own `ai_dispatch.py`, generalized into the `_EXTENSIONS`
registry shape from 6.4. Add the `session_state` parameter from 6.3.
Register the two Extensions already in the mechanism (call log,
auto-parse gating) plus console logging (a genuinely new port — it isn't
in Cognitive_Core's version at all). At the end of this phase, six
Services (everything except Gemini) have real, config-gated, attachable
Extensions, and the CLI scripts' hand-wired logging can be deleted per
6.5.

**Phase 3 — Bring Gemini onto the bus.**
This is the highest-value, highest-effort item. `prompt_gemini.py`'s use
of `GeminiInteractionsAPI` instead of a standard `get_standard_prompter()`
suggests Gemini's Interactions API has capabilities (live tool-calling,
attachments, multi-turn state) the simple `.prompt()` contract doesn't
express. Two honest options, not a false choice to paper over:
(a) write a `_adapt_gemini_interactions` adapter that maps the simple
contract onto the Interactions API for the common case, accepting that
advanced features stay Gemini-specific and unavailable through
`ai_dispatch_call`; or (b) extend the Service contract itself with
optional capabilities (`supports_tools`, `supports_attachments`) that any
Service can declare, and let Extensions check for them rather than assume
every Service is a bare prompt-in/text-out box. (b) is more work and more
correct long-term, if other Services eventually grow similar advanced
modes. This needs a decision, not an assumption — flagging it rather than
picking one silently.

**Phase 4 — Attach context bubble and keywords for real.**
With the mechanism from Phase 2 in place, implement the `Extension`
contract for context bubble (wrapping `ai_bubble_assemble` per 6.2) and
for keyword triggers as an *independent* Extension, not just an internal
dependency of context bubble. Enable both, off by default, in every
Service's features config (matching Cognitive_Core's precedent of
"present but inert until `context_dir`/`config_dir` are configured").

**Phase 5 — Command system and Workspace Brain.**
These two don't fit the `pre_call`/`post_call` shape (Section headers in
`docs/ai-library-classification.md`'s "Input-layer utilities" category
already explain why — they operate on the conversation *around* a call,
before dispatch is even reached, not on the call itself). Recommend a
separate, smaller `InputExtension` contract (`intercept(user_input) ->
Optional[str]`, returning a response to short-circuit dispatch entirely
for a recognized slash-command) rather than forcing them into the
call-wrapping shape. Lower priority than Phases 1-4; these two aren't
blocking the core Lego-composability goal, since they were never
meant to attach to a single call the way context bubble does.

---

## 8. Testing Strategy

- **Contract conformance test.** For every entry in `PROVIDERS`, assert
  its adapter's `get_standard_prompter()` return value has `.prompt` and
  `.model_reg.active_model_id`. For every entry in `_EXTENSIONS`, assert
  it implements at least one of `pre_call`/`post_call`. This is the
  automated version of "does this actually fit the Lego brick shape,"
  and should fail loudly the moment someone adds a Service or Extension
  that doesn't.
- **Cross-attachment test.** The literal test of the stated goal: for at
  least two different Services, enable the same Extension via its config
  file, and assert the Extension's effect shows up in both — proving the
  same Extension code ran against two different Services with zero
  Service-specific branching. This is the test that would have caught
  "context bubble only works from inside `bejson_gemini.py`" before it
  shipped as a permanent gap.
- **Regression test per phase**, same discipline already established in
  Cognitive_Core: reproduce the bug/gap first (show the test failing
  against current code), fix it, confirm the test passes, keep the test
  in the suite. Every claim in Section 4 above is written so it can be
  turned directly into a failing test before any of Section 7's phases
  start.

---

## 9. Risks and Open Questions

- **Gemini's Interactions API gap (Phase 3) is a real design fork, not an
  implementation detail** — see 7's Phase 3 discussion. Needs an explicit
  decision before that phase starts.
- **Backward compatibility for existing callers of `ai_dispatch_call`
  without `session_state`.** The fallback-to-module-global behavior in
  6.3 needs to be genuinely transparent, not just "probably fine" —
  worth a test that calls dispatch from two threads/contexts without
  `session_state` and confirms today's exact (imperfect but documented)
  behavior is preserved, not silently changed.
- **Extension ordering.** If two enabled Extensions both modify
  `system_instruction` in `pre_call` (context bubble now; something else
  later), the order they run in matters and currently has no defined
  rule. Recommend: registration order in `_EXTENSIONS`, documented
  explicitly, with a test pinning the order for any Service that has two
  or more `pre_call` Extensions enabled at once.
- **Config file proliferation.** Eight Services × one features file each
  is manageable; Elton should decide whether a future Service count in
  the dozens still wants one-file-per-Service, or whether a single
  multi-row registry (Service as a field, not a filename) becomes
  preferable at some threshold. Not urgent now — flagging so it isn't a
  surprise later.

---

## 10. Summary Recommendation

Do Phases 1 and 2 first — they're low-risk, high-leverage, and turn the
one working prototype (Cognitive_Core) into the library's own standard
rather than a downstream workaround. Phase 3 (Gemini) is the one that
actually closes the biggest gap against the stated goal, but needs an
explicit decision on the Interactions-API question before it starts.
Phases 4 and 5 are genuinely valuable but lower-risk to defer — nothing
about them gets harder by doing Phases 1-3 first, and doing them first
would mean building the attachment mechanism against Extensions that
don't yet have real consumers to validate it against.
