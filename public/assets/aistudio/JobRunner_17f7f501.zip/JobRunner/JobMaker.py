"""
Name:           JobMaker.py
Family:         JobMaker
Description:    Standalone job creation system, spun out of NewAgent's Job
                Creation System into its own project. Single, isolated Flask
                file. Tab 1 (Hub) lets you pick "Job Schema" or "Template"
                with a radio box, then load an existing entry of that kind
                from a combo box. Tab 2 (Job Editor) names a job, sets a
                goal, sets Job Type / Job Subtype, toggles Contextualize
                Plan / Contextualize Last, and adds/removes tasks in a
                scrollable list -- each task row carries its own "+ Ref"
                (path-only) and "+ Attach" (read + Doc_Chunker-chunked)
                buttons, opening a real navigable file-browser dialog
                (directories to click into, checkboxes on files, modeled on
                the Queue Template's /api/browse) instead of a typed path.
                Tab 3 (Schema) shows a live JSON view of the current
                in-editor job doc with a red Copy to Clipboard button.
                Saving opens a dialog to name the entry and classify it as a
                Job Schema or a Template. A registry.bejson (104db) file
                tracks every saved entry -- name, type, and storage location
                -- separately from the job/template payload files
                themselves. Job Schema files continue to land in jobs/
                under their old slug-based filenames so external consumers
                (e.g. NewAgent's agent.py/webagent.py via
                lib_bejson_newagent_jobs.scan_jobs) keep working unchanged.
                Templates land in templates/. The Hub can delete an entry
                outright; the Job Editor renames an already-loaded entry in
                place (moves/reclassifies the file instead of forking a
                duplicate); and a "Save As Job Schema" action instantiates a
                loaded Template into a brand-new Job Schema with fresh task
                IDs and cleared completion state.
Version:        2.8.0
Date:           2026-10-11
Author:         Elton Boehnen — eltonboehnen@gmail.com
Contact:        eltonboehnen@gmail.com | boehnenelton2024.pages.dev | github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  6e91d4a7-3f28-4c65-b8a0-9d2e1c7f4b56
Changelog:
  2.8.0 (2026-10-11) - Added the Run tab and JobRunner.py: JobMaker can now
    execute a Job Schema, not just author it. Tasks run in order through the
    AI-family dispatch library (vendored under lib/: ai_dispatch, ai_response,
    ai_registry_base, bejson_errors and the genai/gemini/groq/openrouter/grok/
    huggingface/ollama/tokenrouter providers; none edited). Every run applies
    the job header flags -- Contextualize_Plan injects the full plan with
    done/pending/active markers, Contextualize_Last injects the previous
    completed task's saved output -- then the task's own context chunks and
    reference paths. Per-task audit_enabled runs a PASS/FAIL review call with
    a retry carrying the reviewer's feedback. task_mandatory now has runner
    meaning: a failed mandatory task HALTS the run, a failed optional task is
    skipped. Outputs land in runs/<job_slug>/<task_id>.md and a combined
    final.md is written when every task is done; task_completed/audit_* are
    written back to the job file through the Field Map Cache. Run controls:
    provider, model, retries, system instruction, Preview Prompt, Run Next,
    Run All, Stop, Reset. A "dryrun" provider returns the assembled prompt
    without any network call. The schema itself is unchanged.
  2.7.1 (2026-08-25) - Fixed a 500 on every GET / (crashed on Android/Pydroid3
    with UnicodeEncodeError: 'utf-8' codec can't encode ... surrogates not
    allowed). Cause: the browse-dialog folder icon was written as two
    separate short Python unicode escapes forming a UTF-16 surrogate pair
    meant to become the folder emoji -- Python doesn't combine a pair of
    those into one codepoint the way JS does, so this produced two lone,
    unencodable surrogate characters baked into the page HTML. Replaced with
    the correct single 8-digit astral-plane escape. Whole-file UTF-8
    encodability now checked as part of the test pass before every
    delivery, not just the JSON API responses, so this class of bug can't
    slip through unnoticed again.
  2.7.0 (2026-08-25) - Added a per-task Mandatory checkbox (task_mandatory).
    A Template built for a given Job_Type/Job_Subtype can now mark a task as
    required for that type -- e.g. a "document" template's final task,
    "Combine all chapters," gets checked Mandatory so it's flagged as a
    built-in step of that type rather than an optional one. Purely a label
    at this stage: JobMaker doesn't enforce it (won't block deleting a
    mandatory task or auto-insert one into a new job) -- it just records the
    flag on the task row for whatever runs the job to read and act on.
    Rendered as a checkbox next to each task's Ref/Attach buttons.
  2.6.0 (2026-08-25) - Added four job-header fields so JobMaker's schema can
    stand in for Bookmaker's own scheme: Job_Type (string, e.g. "writing"),
    Job_Subtype (string, e.g. "book"), Contextualize_Plan (boolean -- when
    on, every task is injected with the full plan scope, or at minimum every
    task title), and Contextualize_Last (boolean -- when on, every task
    receives the prior task's output as context). All four live at the job
    header level (alongside Job_Goal), not per-task. Job Editor gained a
    Job Type / Job Subtype field pair and two checkboxes for the
    contextualize flags. Threaded through _build_job_doc/_doc_to_job_dict,
    all three save endpoints, and the Schema tab preview.
  2.5.0 (2026-08-22) - Context moved from job-level to per-task, per spec:
    each task now carries its own task_context (embedded, chunked files) and
    task_reference (path-only refs) list, aligned to that task -- add task 3
    and it gets its own context/reference cells, not a shared job-wide list.
    "+ Ref" and "+ Attach" buttons sit on each task row and open a real
    navigable file-browser dialog (directory listing + checkboxes,
    modeled on the Queue Template's /api/browse) instead of a typed path.
    Chunking now always runs for anything added via Attach -- no
    extension/text-type gate -- and uses the exact Doc_Chunker segmentation
    algorithm (cmd_doc_import_file: strip + split on blank-line-separated
    blocks, sequential chunk_id/chunk_label/chunk_content/chunk_index_pos/
    chunk_status), placing the resulting chunks straight into that task's
    context cell. Reference stays path-only, never chunked. Job_Context/
    Job_Reference top-level doc fields are gone; Fields gained task_context
    and task_reference (BEJSON positional-integrity: appended at the end,
    old rows read back with empty lists). Added a Schema tab: a live JSON
    view of the current in-editor job doc via new POST /api/schema/preview,
    with a red "Copy to Clipboard" button.
  2.3.0 (2026-08-22) - Context refs now embed content for text-based files,
    Doc_Chunker-style: on "+ Attach Ref", the server reads the file at that
    path (within SAFE_ROOTS) and, if it's text, splits it into verbatim
    paragraph-block chunks (chunk_id/chunk_label/chunk_content/chunk_index_pos/
    chunk_status, mirroring the Doc_Chunker chunk shape) embedded straight in
    the job's Job_Context entry. The ref field itself remains just the file
    path -- only the embedded chunk payload is new. Non-text/binary files
    keep a ref-only entry with no embedded content. New POST
    /api/context/preview route does the read+chunk server-side (browser JS
    can't read the filesystem). Job_Context entries are now objects
    ({ref, text_based, chunks}) instead of plain path strings; old
    string-only entries from PKG102 load-migrate transparently. Attached-tab
    rows show an "Embedded: N chunks" / "Not embedded (binary/unknown)" badge.
  2.2.0 (2026-08-22) - Added Context attachments: a job-level Job_Context
    list of file-path refs (no content, just the path string). New "Context"
    tab (path input + red "Attach Ref" button, modeled on the Queue Template's
    add pattern) and new "Attached" tab (list of attached refs with a red ×
    remove button per row and a count, modeled on the Queue Template's Active
    Queue list) -- split across two tabs per spec instead of one combined
    view. Save paths (POST /api/entry, PUT /api/entry/<id>, legacy POST
    /api/jobs) now read/write the context list alongside goal/tasks.
  2.1.0 (2026-08-16) - Added DELETE /api/entry/<id> (Hub "Delete" button,
    removes both the payload file and its registry row). Added PUT
    /api/entry/<id> for true rename-in-place: updates the SAME registry row
    (entry_id preserved) and moves/renames the underlying file instead of
    forking a new entry when the name or type changes; returns 409 on a
    name/type collision with a different existing entry. Editor now tracks
    the currently loaded entry_id/entry_type so a plain Save updates in
    place. Added a "Save As Job Schema" button: forces entry_type=schema,
    always creates a new entry (never overwrites the currently loaded one),
    and clears task_id/task_completed/audit_passed on each task so a
    Template instantiates as a fresh, unstarted Job Schema.
  2.0.0 (2026-08-16) - Extracted into its own standalone project. Added Hub
    tab (radio: Job Schema / Template + combo load), horizontal scrollable
    tab switcher, Save-As dialog (name + type), and a new JobRegistryEntry
    104db registry.bejson schema that classifies every saved entry as
    "schema" or "template". Legacy jobs/*.bejson files are auto-migrated
    into the registry as "schema" entries on first read. Old /api/jobs
    endpoints kept intact for backward compatibility.
  1.0.0 (2026-08-08) - Initial release (single job-list combo, no templates,
    no registry).
"""

import logging
import os
import re
import sys
import uuid
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, request, Response

VERSION = "2.8.0"

def get_script_path() -> Path:
    return Path(__file__).resolve().parent

SCRIPT_PATH = get_script_path()
BASE_DIR = SCRIPT_PATH
JOBS_DIR = BASE_DIR / "jobs"
TEMPLATES_DIR = BASE_DIR / "templates"
REGISTRY_PATH = BASE_DIR / "registry.bejson"

# Reuse the same Core BEJSON library the rest of the ecosystem uses -- no
# second read/write/field-map implementation. This is a Core family library;
# per Library Immutability policy it is never edited from this project.
sys.path.insert(0, str(BASE_DIR / "lib"))
from lib_bejson_Core_bejson_core import (
    bejson_core_load_file,
    bejson_core_atomic_write,
    bejson_core_get_field_map,
)

app = Flask(__name__)

ENTRY_TYPES = ("schema", "template")

_JOB_FIELDS = [
    {"name": "task_id", "type": "string"},
    {"name": "task_order", "type": "integer"},
    {"name": "task_name", "type": "string"},
    {"name": "task_description", "type": "string"},
    {"name": "task_completed", "type": "boolean"},
    {"name": "audit_enabled", "type": "boolean"},
    {"name": "audit_passed", "type": "boolean"},
    {"name": "audit_fail_reason", "type": "string"},
    {"name": "task_context", "type": "array"},
    {"name": "task_reference", "type": "array"},
    {"name": "task_mandatory", "type": "boolean"},
]

_REGISTRY_FIELDS = [
    {"name": "entry_id", "type": "string"},
    {"name": "entry_name", "type": "string"},
    {"name": "entry_slug", "type": "string"},
    {"name": "entry_type", "type": "string"},
    {"name": "file_path", "type": "string"},
    {"name": "created_date", "type": "string"},
    {"name": "modified_date", "type": "string"},
]

# ── Context ref reading / chunking (Doc_Chunker cmd_doc_import_file logic,
#    ported 1:1 from libraries_104/Lib_PY/Core/cli/CLI_Doc_Chunker/Doc_Chunker.py) ─

CONTEXT_SAFE_ROOTS = [
    os.path.realpath(str(BASE_DIR)),
    "/storage/emulated/0",
    "/storage/7B30-0E0B",   # Ulefone Armor 24 SD
    "/storage/FE5F-F510",   # Samsung Galaxy A16 SD
]
BROWSE_SAFE_ROOTS = CONTEXT_SAFE_ROOTS  # shared by /api/browse and /api/context/preview

CONTEXT_MAX_READ_BYTES = 2 * 1024 * 1024  # 2 MB cap on embedded reads


def _context_path_safe(path: str) -> bool:
    try:
        resolved = os.path.realpath(path)
        return any(resolved.startswith(root) for root in CONTEXT_SAFE_ROOTS)
    except Exception:
        return False


def _chunk_text(content: str) -> list[dict]:
    """Doc_Chunker's cmd_doc_import_file segmentation, ported exactly:
    strip + split on blank-line-separated blocks, sequential chunk_id/
    chunk_label/chunk_content/chunk_index_pos/chunk_status, content kept
    verbatim, no summarization."""
    blocks = [b.strip() for b in content.split("\n\n") if b.strip()]
    chunks = []
    for i, block in enumerate(blocks, 1):
        chunks.append({
            "chunk_id": uuid.uuid4().hex[:8],
            "chunk_label": f"Chunk_{i}",
            "chunk_content": block,
            "chunk_index_pos": i,
            "chunk_status": "draft",
        })
    return chunks


def _read_and_chunk_ref(raw_path: str) -> dict:
    """Read a ref path (server-side; the browser can't read the filesystem)
    and chunk it Doc_Chunker-style. Every imported file is attempted --
    no extension/text-type gate -- the only thing that can stop a chunk is
    the content not decoding as UTF-8. Returns
    {"ok": True, "ref": ..., "text_based": bool, "chunks": [...]} or
    {"ok": False, "error": ..., "status": ...}."""
    if not _context_path_safe(raw_path):
        return {"ok": False, "error": "Path is outside allowed storage roots.", "status": 400}
    p = Path(raw_path)
    if not p.is_file():
        return {"ok": False, "error": f"No file at '{raw_path}'.", "status": 404}
    try:
        size = p.stat().st_size
        with open(p, "rb") as f:
            raw = f.read(CONTEXT_MAX_READ_BYTES)
    except OSError as exc:
        return {"ok": False, "error": f"Could not read file: {exc}", "status": 500}

    try:
        content = raw.decode("utf-8")
    except UnicodeDecodeError:
        return {"ok": True, "ref": raw_path, "text_based": False, "chunks": []}
    if size > CONTEXT_MAX_READ_BYTES:
        content += "\n\n[...truncated -- file exceeds 2 MB embed cap...]"
    return {"ok": True, "ref": raw_path, "text_based": True, "chunks": _chunk_text(content)}


def _normalize_context_entry(item) -> dict:
    """Accept either a plain path string (legacy shape) or the current
    {ref, text_based, chunks} object shape."""
    if isinstance(item, str):
        return {"ref": item, "text_based": False, "chunks": []}
    if isinstance(item, dict):
        return {
            "ref": str(item.get("ref", "")),
            "text_based": bool(item.get("text_based", False)),
            "chunks": item.get("chunks", []) if isinstance(item.get("chunks"), list) else [],
        }
    return {"ref": str(item), "text_based": False, "chunks": []}


def _normalize_reference_entry(item) -> str:
    if isinstance(item, dict):
        return str(item.get("ref", "")).strip()
    return str(item).strip()


def _browse_dir(path: str) -> dict:
    """Navigable directory listing for the per-task Reference/Attach picker
    dialogs -- dirs to click into, files to checkbox-select. Modeled
    directly on the Queue Template's browse_dir()."""
    if not path:
        path = BROWSE_SAFE_ROOTS[1] if len(BROWSE_SAFE_ROOTS) > 1 else BROWSE_SAFE_ROOTS[0]
    if not os.path.isdir(path):
        return {"ok": False, "error": "Not a valid directory.", "status": 400}
    if not _context_path_safe(path):
        return {"ok": False, "error": "Access denied: path is outside allowed roots.", "status": 400}
    entries = []
    parent = str(Path(path).parent)
    if parent != path:
        entries.append({"name": "..", "path": parent, "type": "dir"})
    try:
        for item in sorted(os.listdir(path)):
            ipath = os.path.join(path, item)
            try:
                if os.path.isdir(ipath):
                    entries.append({"name": item, "path": ipath, "type": "dir"})
                elif os.path.isfile(ipath):
                    size_kb = round(os.path.getsize(ipath) / 1024, 2)
                    entries.append({"name": item, "path": ipath, "type": "file", "size_kb": size_kb})
            except PermissionError:
                continue
    except Exception as exc:
        return {"ok": False, "error": str(exc), "status": 500}
    return {"ok": True, "path": path, "entries": entries}


def _slugify(title: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", title.strip()).strip("_").lower()
    return slug or "untitled_job"


def _job_path(name: str) -> Path:
    return JOBS_DIR / f"{_slugify(name)}.bejson"


def _list_job_names() -> list[str]:
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    return sorted(f.stem for f in JOBS_DIR.glob("*.bejson") if f.is_file())


def _doc_to_job_dict(doc: dict) -> dict:
    """Convert a loaded BEJSON 104a job doc into the flat shape the UI/JS uses,
    resolving every column strictly through the Field Map Cache -- no
    positional/index-based access, per the BEJSON Core Mandate."""
    fmap = bejson_core_get_field_map(doc)
    tasks = []
    for row in doc.get("Values", []):
        def get(field, default="", _row=row):
            idx = fmap.get(field)
            return _row[idx] if idx is not None and len(_row) > idx else default
        raw_context = get("task_context", [])
        raw_reference = get("task_reference", [])
        tasks.append({
            "task_id": get("task_id", ""),
            "task_order": get("task_order", 0),
            "task_name": get("task_name", ""),
            "task_description": get("task_description", ""),
            "task_completed": bool(get("task_completed", False)),
            "audit_enabled": bool(get("audit_enabled", False)),
            "audit_passed": bool(get("audit_passed", False)),
            "audit_fail_reason": get("audit_fail_reason", ""),
            "context": [_normalize_context_entry(c) for c in (raw_context if isinstance(raw_context, list) else [])],
            "reference": [_normalize_reference_entry(r) for r in (raw_reference if isinstance(raw_reference, list) else [])
                          if _normalize_reference_entry(r)],
            "mandatory": bool(get("task_mandatory", False)),
        })
    tasks.sort(key=lambda t: t["task_order"])
    return {
        "goal": doc.get("Job_Goal", ""),
        "complete": bool(doc.get("Job_Complete", False)),
        "creation_date": doc.get("Creation_Date", ""),
        "completion_date": doc.get("Completion_Date", ""),
        "job_type": doc.get("Job_Type", ""),
        "job_subtype": doc.get("Job_Subtype", ""),
        "contextualize_plan": bool(doc.get("Contextualize_Plan", False)),
        "contextualize_last": bool(doc.get("Contextualize_Last", False)),
        "tasks": tasks,
    }


def _build_job_doc(name: str, goal: str, tasks: list[dict], existing: dict | None,
                    job_type: str = "", job_subtype: str = "",
                    contextualize_plan: bool = False, contextualize_last: bool = False) -> dict:
    """Each task dict carries its own context/reference lists -- Context 3
    lives on task 3's row, not in any job-wide list. job_type/job_subtype/
    contextualize_plan/contextualize_last are job-header fields (alongside
    Job_Goal), letting this schema stand in for Bookmaker's own job scheme."""
    now = datetime.now().strftime("%Y-%m-%d")
    creation_date = (existing or {}).get("Creation_Date") or now
    values = []
    for i, t in enumerate(tasks):
        tid = (t.get("task_id") or "").strip() or str(uuid.uuid4())
        task_context = [
            _normalize_context_entry(c) for c in (t.get("context") or [])
            if (c.get("ref") if isinstance(c, dict) else c)
        ]
        task_reference = [
            _normalize_reference_entry(r) for r in (t.get("reference") or []) if _normalize_reference_entry(r)
        ]
        values.append([
            tid,
            int(t.get("task_order", i + 1)),
            str(t.get("task_name", "")),
            str(t.get("task_description", "")),
            bool(t.get("task_completed", False)),
            bool(t.get("audit_enabled", False)),
            bool(t.get("audit_passed", False)),
            str(t.get("audit_fail_reason", "")),
            task_context,
            task_reference,
            bool(t.get("mandatory", False)),
        ])
    all_done = bool(values) and all(v[4] is True for v in values)
    return {
        "Format": "BEJSON",
        "Format_Version": "104a",
        "Format_Creator": "Elton Boehnen",
        "Schema_Name": "Job Schema",
        "Schema_Version": "1.0",
        "Schema_Description": "Custom job schema for the NewAgent task creation and tracking system, managing individual task states and optional auditing. Each task carries its own task_context (embedded, chunked files), task_reference (path-only refs), and task_mandatory (marks a task as a required, built-in step for the job's Job_Type/Job_Subtype). Job_Type/Job_Subtype classify the job; Contextualize_Plan/Contextualize_Last control what each task is injected with at run time. Also reused unmodified as the Template payload shape.",
        "Job_Goal": goal,
        "Job_Type": str(job_type or ""),
        "Job_Subtype": str(job_subtype or ""),
        "Contextualize_Plan": bool(contextualize_plan),
        "Contextualize_Last": bool(contextualize_last),
        "Job_Complete": all_done,
        "Creation_Date": creation_date,
        "Completion_Date": (datetime.now().strftime("%Y-%m-%d") if all_done else ""),
        "Records_Type": ["JobTask"],
        "Fields": _JOB_FIELDS,
        "Values": values,
    }


# ── Registry (jobs vs. templates classification) ───────────────────────────

def _default_registry_doc() -> dict:
    return {
        "Format": "BEJSON",
        "Format_Version": "104db",
        "Format_Creator": "Elton Boehnen",
        "Schema_Name": "Job Registry Schema",
        "Schema_Version": "1.0",
        "Schema_Description": "Tracks every entry saved by JobMaker and classifies it as a Job Schema or a Template, independent of the payload files themselves.",
        "Records_Type": ["JobRegistryEntry"],
        "Fields": _REGISTRY_FIELDS,
        "Values": [],
    }


def _load_registry() -> dict:
    if REGISTRY_PATH.is_file():
        doc = bejson_core_load_file(str(REGISTRY_PATH))
        if isinstance(doc, dict) and doc.get("Fields"):
            return doc
    return _default_registry_doc()


def _save_registry(doc: dict) -> bool:
    return bejson_core_atomic_write(str(REGISTRY_PATH), doc)


def _registry_rows(doc: dict):
    """Yield (row, get) pairs resolved through the Field Map Cache -- never
    positional access, per the BEJSON Core Mandate."""
    fmap = bejson_core_get_field_map(doc)
    for row in doc.get("Values", []):
        def get(field, default="", _row=row):
            idx = fmap.get(field)
            return _row[idx] if idx is not None and len(_row) > idx else default
        yield row, get


def _registry_migrate_legacy(doc: dict) -> bool:
    """Auto-register any jobs/*.bejson files that predate the registry (e.g.
    hand-placed, or saved by the old pre-Hub JobMaker / the legacy /api/jobs
    route) as "schema" entries, so nothing already on disk goes missing from
    the Hub."""
    changed = False
    known_paths = {get("file_path", "") for _row, get in _registry_rows(doc)}
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    now = datetime.now().strftime("%Y-%m-%d")
    for f in sorted(JOBS_DIR.glob("*.bejson")):
        rel = str(f.relative_to(BASE_DIR))
        if rel in known_paths:
            continue
        display = f.stem.replace("_", " ").strip().title() or f.stem
        doc.setdefault("Values", []).append([
            str(uuid.uuid4()), display, f.stem, "schema", rel, now, now,
        ])
        changed = True
    return changed


def _registry_list(entry_type: str) -> list:
    doc = _load_registry()
    if _registry_migrate_legacy(doc):
        _save_registry(doc)
    out = [
        {"entry_id": get("entry_id", ""), "entry_name": get("entry_name", "")}
        for _row, get in _registry_rows(doc)
        if get("entry_type", "") == entry_type
    ]
    out.sort(key=lambda e: e["entry_name"].lower())
    return out


def _registry_find(entry_id: str) -> dict | None:
    doc = _load_registry()
    for _row, get in _registry_rows(doc):
        if get("entry_id", "") == entry_id:
            return {
                "entry_id": get("entry_id", ""),
                "entry_name": get("entry_name", ""),
                "entry_slug": get("entry_slug", ""),
                "entry_type": get("entry_type", ""),
                "file_path": get("file_path", ""),
            }
    return None


def _registry_find_by_slug_type(doc: dict, slug: str, entry_type: str, exclude_entry_id: str = None) -> dict | None:
    """Look up a registry row by its (slug, type) identity, optionally
    excluding one entry_id (used for collision checks during rename)."""
    for _row, get in _registry_rows(doc):
        if get("entry_slug", "") == slug and get("entry_type", "") == entry_type:
            if exclude_entry_id and get("entry_id", "") == exclude_entry_id:
                continue
            return {
                "entry_id": get("entry_id", ""),
                "entry_name": get("entry_name", ""),
            }
    return None


def _registry_delete(entry_id: str) -> bool:
    """Remove a registry row and its payload file. Returns True if a row
    was found and removed (file removal is best-effort)."""
    doc = _load_registry()
    fmap = bejson_core_get_field_map(doc)
    values = doc.get("Values", [])
    for i, row in enumerate(values):
        if row[fmap["entry_id"]] == entry_id:
            rel_path = row[fmap["file_path"]]
            full_path = BASE_DIR / rel_path
            try:
                if full_path.is_file():
                    full_path.unlink()
            except OSError:
                pass
            values.pop(i)
            _save_registry(doc)
            return True
    return False


def _registry_rename(entry_id: str, name: str, entry_type: str, goal: str, tasks: list,
                      job_type: str = "", job_subtype: str = "",
                      contextualize_plan: bool = False, contextualize_last: bool = False) -> dict:
    """Update the entry identified by entry_id IN PLACE: same entry_id and
    created_date, but the payload is rewritten and, if the name or type
    changed, the underlying file is moved/reclassified rather than forking
    a new entry. Returns {"ok": True, ...} or {"ok": False, "error": ..., "status": ...}."""
    doc = _load_registry()
    fmap = bejson_core_get_field_map(doc)
    target_row = None
    for row, get in _registry_rows(doc):
        if get("entry_id", "") == entry_id:
            target_row = row
            break
    if target_row is None:
        return {"ok": False, "error": f"No entry '{entry_id}'.", "status": 404}

    old_rel_path = target_row[fmap["file_path"]]
    old_full_path = BASE_DIR / old_rel_path

    new_slug = _slugify(name)
    collision = _registry_find_by_slug_type(doc, new_slug, entry_type, exclude_entry_id=entry_id)
    if collision:
        return {
            "ok": False,
            "error": f"Another {entry_type} named \"{collision['entry_name']}\" already exists.",
            "status": 409,
        }

    new_folder = JOBS_DIR if entry_type == "schema" else TEMPLATES_DIR
    new_folder.mkdir(parents=True, exist_ok=True)
    new_full_path = new_folder / f"{new_slug}.bejson"

    existing_doc = bejson_core_load_file(str(old_full_path)) if old_full_path.is_file() else None
    job_doc = _build_job_doc(name, goal, tasks, existing_doc, job_type, job_subtype,
                              contextualize_plan, contextualize_last)
    if not bejson_core_atomic_write(str(new_full_path), job_doc):
        return {"ok": False, "error": f"Failed to write {new_full_path.name}.", "status": 500}

    if new_full_path != old_full_path and old_full_path.is_file():
        try:
            old_full_path.unlink()
        except OSError:
            pass

    now = datetime.now().strftime("%Y-%m-%d")
    new_rel_path = str(new_full_path.relative_to(BASE_DIR))
    target_row[fmap["entry_name"]] = name
    target_row[fmap["entry_slug"]] = new_slug
    target_row[fmap["entry_type"]] = entry_type
    target_row[fmap["file_path"]] = new_rel_path
    target_row[fmap["modified_date"]] = now
    _save_registry(doc)

    return {"ok": True, "entry_id": entry_id, "entry_type": entry_type, "job": _doc_to_job_dict(job_doc)}


def _registry_upsert(name: str, entry_type: str, rel_path: str) -> str:
    """Create or update the registry row keyed by (slug, entry_type).
    Returns the entry_id."""
    slug = _slugify(name)
    doc = _load_registry()
    now = datetime.now().strftime("%Y-%m-%d")
    fmap = bejson_core_get_field_map(doc)
    for row, get in _registry_rows(doc):
        if get("entry_slug", "") == slug and get("entry_type", "") == entry_type:
            row[fmap["entry_name"]] = name
            row[fmap["file_path"]] = rel_path
            row[fmap["modified_date"]] = now
            _save_registry(doc)
            return get("entry_id", "")
    entry_id = str(uuid.uuid4())
    doc.setdefault("Values", []).append([
        entry_id, name, slug, entry_type, rel_path, now, now,
    ])
    _save_registry(doc)
    return entry_id


# ── API -- Hub / registry-aware routes ──────────────────────────────────────

@app.route("/api/registry", methods=["GET"])
def api_registry_list():
    entry_type = request.args.get("type", "schema")
    if entry_type not in ENTRY_TYPES:
        return jsonify({"error": "type must be 'schema' or 'template'."}), 400
    return jsonify({"entries": _registry_list(entry_type)})


@app.route("/api/entry/<entry_id>", methods=["GET"])
def api_get_entry(entry_id):
    meta = _registry_find(entry_id)
    if not meta:
        return jsonify({"error": f"No entry '{entry_id}'."}), 404
    full_path = BASE_DIR / meta["file_path"]
    if not full_path.is_file():
        return jsonify({"error": f"Entry file missing on disk: {meta['file_path']}"}), 500
    doc = bejson_core_load_file(str(full_path))
    if not isinstance(doc, dict):
        return jsonify({"error": f"Could not load {full_path.name} as BEJSON."}), 500
    payload = _doc_to_job_dict(doc)
    payload.update({
        "entry_id": meta["entry_id"],
        "entry_name": meta["entry_name"],
        "entry_type": meta["entry_type"],
    })
    return jsonify(payload)


def _job_meta_from_body(body: dict) -> dict:
    return {
        "job_type": str(body.get("job_type", "") or ""),
        "job_subtype": str(body.get("job_subtype", "") or ""),
        "contextualize_plan": bool(body.get("contextualize_plan", False)),
        "contextualize_last": bool(body.get("contextualize_last", False)),
    }


@app.route("/api/entry", methods=["POST"])
def api_save_entry():
    body = request.get_json(force=True, silent=True) or {}
    name = (body.get("name") or "").strip()
    entry_type = body.get("entry_type", "schema")
    if not name:
        return jsonify({"error": "Name is required."}), 400
    if entry_type not in ENTRY_TYPES:
        return jsonify({"error": "entry_type must be 'schema' or 'template'."}), 400
    goal = body.get("goal", "")
    tasks = body.get("tasks", [])
    if not isinstance(tasks, list):
        return jsonify({"error": "tasks must be a list."}), 400
    meta = _job_meta_from_body(body)

    slug = _slugify(name)
    folder = JOBS_DIR if entry_type == "schema" else TEMPLATES_DIR
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{slug}.bejson"
    existing = bejson_core_load_file(str(path)) if path.is_file() else None
    doc = _build_job_doc(name, goal, tasks, existing, **meta)

    if not bejson_core_atomic_write(str(path), doc):
        return jsonify({"error": f"Failed to save {path.name}."}), 500

    rel_path = str(path.relative_to(BASE_DIR))
    entry_id = _registry_upsert(name, entry_type, rel_path)
    return jsonify({
        "ok": True,
        "entry_id": entry_id,
        "entry_type": entry_type,
        "name": slug,
        "display_name": name,
        "job": _doc_to_job_dict(doc),
    })


@app.route("/api/entry/<entry_id>", methods=["PUT"])
def api_rename_entry(entry_id):
    """Update the entry identified by entry_id in place -- true rename,
    not a new registry row. Moves/reclassifies the underlying file if the
    name or type changed."""
    body = request.get_json(force=True, silent=True) or {}
    name = (body.get("name") or "").strip()
    entry_type = body.get("entry_type", "schema")
    if not name:
        return jsonify({"error": "Name is required."}), 400
    if entry_type not in ENTRY_TYPES:
        return jsonify({"error": "entry_type must be 'schema' or 'template'."}), 400
    goal = body.get("goal", "")
    tasks = body.get("tasks", [])
    if not isinstance(tasks, list):
        return jsonify({"error": "tasks must be a list."}), 400
    meta = _job_meta_from_body(body)

    result = _registry_rename(entry_id, name, entry_type, goal, tasks, **meta)
    if not result["ok"]:
        return jsonify({"error": result["error"]}), result["status"]
    return jsonify({
        "ok": True,
        "entry_id": result["entry_id"],
        "entry_type": result["entry_type"],
        "display_name": name,
        "job": result["job"],
    })


@app.route("/api/entry/<entry_id>", methods=["DELETE"])
def api_delete_entry(entry_id):
    if not _registry_delete(entry_id):
        return jsonify({"error": f"No entry '{entry_id}'."}), 404
    return jsonify({"ok": True, "entry_id": entry_id})


@app.route("/api/context/preview", methods=["POST"])
def api_context_preview():
    """Reads a ref path server-side and chunks it Doc_Chunker-style for
    embedding (every file is attempted; only a non-UTF-8 decode stops it).
    Does not persist anything -- the Job Editor holds the result in memory,
    scoped to the task that requested it, until the job itself is saved."""
    body = request.get_json(force=True, silent=True) or {}
    raw_path = (body.get("path") or "").strip()
    if not raw_path:
        return jsonify({"error": "path is required."}), 400
    result = _read_and_chunk_ref(raw_path)
    if not result["ok"]:
        return jsonify({"error": result["error"]}), result["status"]
    return jsonify(result)


@app.route("/api/browse", methods=["POST"])
def api_browse():
    """Navigable directory listing for the per-task Reference/Attach picker
    dialogs. Modeled on the Queue Template's /api/browse."""
    body = request.get_json(force=True, silent=True) or {}
    result = _browse_dir(body.get("path", ""))
    if not result["ok"]:
        return jsonify({"error": result["error"]}), result["status"]
    return jsonify(result)


@app.route("/api/schema/preview", methods=["POST"])
def api_schema_preview():
    """Builds the exact BEJSON job doc for the current in-editor state
    (name/goal/tasks, each task carrying its own context/reference) without
    saving it -- backs the Schema tab's live view + Copy to Clipboard."""
    body = request.get_json(force=True, silent=True) or {}
    name = (body.get("name") or "Untitled Job").strip()
    goal = body.get("goal", "")
    tasks = body.get("tasks", [])
    if not isinstance(tasks, list):
        return jsonify({"error": "tasks must be a list."}), 400

    existing = None
    entry_id = body.get("entry_id")
    if entry_id:
        entry = _registry_find(entry_id)
        if entry:
            full_path = BASE_DIR / entry["file_path"]
            if full_path.is_file():
                existing = bejson_core_load_file(str(full_path))

    doc = _build_job_doc(name, goal, tasks, existing, **_job_meta_from_body(body))
    return jsonify({"ok": True, "schema": doc})


# ── API -- legacy routes (pre-Hub JobMaker v1.0.0), kept for compatibility ─
# Anything saved through here lands in jobs/ and is picked up automatically
# by _registry_migrate_legacy() as a "schema" entry the next time the Hub's
# registry list is requested.

@app.route("/api/jobs", methods=["GET"])
def api_list_jobs():
    return jsonify({"jobs": _list_job_names()})


@app.route("/api/jobs/<name>", methods=["GET"])
def api_get_job(name):
    path = _job_path(name)
    if not path.is_file():
        return jsonify({"error": f"No job named '{name}'."}), 404
    doc = bejson_core_load_file(str(path))
    if not isinstance(doc, dict):
        return jsonify({"error": f"Could not load {path.name} as BEJSON."}), 500
    return jsonify(_doc_to_job_dict(doc))


@app.route("/api/jobs", methods=["POST"])
def api_save_job():
    body = request.get_json(force=True, silent=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return jsonify({"error": "Job name is required."}), 400
    goal = body.get("goal", "")
    tasks = body.get("tasks", [])
    if not isinstance(tasks, list):
        return jsonify({"error": "tasks must be a list."}), 400

    path = _job_path(name)
    existing = bejson_core_load_file(str(path)) if path.is_file() else None
    doc = _build_job_doc(name, goal, tasks, existing, **_job_meta_from_body(body))

    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    if not bejson_core_atomic_write(str(path), doc):
        return jsonify({"error": f"Failed to save {path.name}."}), 500
    return jsonify({"ok": True, "name": _slugify(name), "job": _doc_to_job_dict(doc)})


# ── UI ────────────────────────────────────────────────────────────────────

_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>JobMaker</title>
<style>
  @font-face {{ font-family: 'Inter'; src: local('Inter'); }}
  :root {{
    --bg: #FFFFFF;
    --fg: #000000;
    --red: #DE2626;
    --border: #000000;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0; background: var(--bg); color: var(--fg);
    font-family: 'Inter', system-ui, sans-serif;
    min-height: 100vh;
  }}
  header.becss-header {{
    background: #000000; color: #FFFFFF;
    padding: 16px 20px;
    display: flex; align-items: center; justify-content: space-between;
    flex-wrap: wrap; gap: 10px;
  }}
  .becss-header__title {{ font-size: 1.1rem; margin: 0; letter-spacing: 0.02em; }}
  .becss-header__sub {{ color: #CCCCCC; font-size: 0.8rem; }}

  /* Horizontal, scroll-on-overflow tab switcher */
  .becss-tabbar {{
    display: flex; overflow-x: auto; white-space: nowrap;
    background: #FFFFFF; border-bottom: 2px solid var(--border);
    -webkit-overflow-scrolling: touch;
  }}
  .becss-tabbar__tab {{
    flex: 0 0 auto;
    background: #FFFFFF; color: #000000; border: none;
    border-right: 1px solid #DDDDDD;
    padding: 14px 20px; font-family: inherit; font-size: 0.95rem; font-weight: 600;
    cursor: pointer;
  }}
  .becss-tabbar__tab:hover {{ background: #F2F2F2; }}
  .becss-tabbar__tab--active {{
    background: var(--red); color: #FFFFFF; border-color: var(--red);
  }}

  main {{ max-width: 720px; margin: 0 auto; padding: 20px 16px 60px; }}
  .becss-panel {{ display: none; }}
  .becss-panel--active {{ display: block; }}

  label {{ display: block; font-weight: 600; margin: 18px 0 6px; }}
  input[type=text], textarea, select {{
    width: 100%; background: #FFFFFF; color: #000000;
    border: 1px solid var(--border); border-radius: 4px;
    padding: 10px; font-family: inherit; font-size: 1rem;
  }}
  textarea {{ resize: vertical; min-height: 60px; }}

  .becss-radio-group {{ display: flex; gap: 20px; margin-top: 8px; flex-wrap: wrap; }}
  .becss-radio-group__option {{
    display: flex; align-items: center; gap: 6px; font-weight: 500; cursor: pointer;
  }}
  .becss-radio-group__option input {{ width: 16px; height: 16px; }}

  .becss-picker {{ display: flex; gap: 8px; align-items: center; margin-top: 8px; }}
  .becss-picker__select {{ flex: 1; }}

  .becss-task-list {{
    max-height: 360px; overflow-y: auto;
    border: 1px solid var(--border); border-radius: 6px;
    padding: 8px; margin-top: 8px; background: #FFFFFF;
  }}
  .becss-task-row {{
    display: flex; gap: 8px; align-items: flex-start;
    padding: 8px; border-bottom: 1px solid #DDDDDD;
  }}
  .becss-task-row:last-child {{ border-bottom: none; }}
  .becss-task-row__fields {{ flex: 1; display: flex; flex-direction: column; gap: 6px; min-width: 0; }}
  .becss-task-row input[type=checkbox] {{ margin-top: 12px; width: 18px; height: 18px; }}

  .becss-task-context {{
    margin-top: 6px; padding-top: 6px; border-top: 1px dashed #DDDDDD;
  }}
  .becss-task-context__row {{
    display: flex; gap: 6px; align-items: center;
    padding: 4px 0; font-size: 0.78rem;
  }}
  .becss-task-context__tag {{
    font-weight: 700; flex-shrink: 0; color: #FFFFFF; background: var(--red);
    border-radius: 3px; padding: 1px 5px; font-size: 0.68rem;
  }}
  .becss-task-context__ref {{
    flex: 1; font-family: 'Source Code Pro', monospace; word-break: break-all;
  }}
  .becss-task-context__badge {{ color: #777777; flex-shrink: 0; }}
  .becss-task-context__rm {{
    background: none; border: none; color: var(--red); cursor: pointer;
    font-size: 1rem; line-height: 1; flex-shrink: 0; padding: 2px 4px;
  }}
  .becss-task-row__pickbtns {{ display: flex; gap: 6px; margin-top: 4px; flex-wrap: wrap; }}
  .becss-task-row__pickbtns .becss-btn {{
    padding: 5px 10px; font-size: 0.75rem;
  }}

  .becss-btn {{
    background: #FFFFFF; color: #000000; border: 1px solid var(--border);
    border-radius: 4px; padding: 10px 16px; font-weight: 600;
    cursor: pointer; font-family: inherit;
  }}
  .becss-btn:hover {{ background: var(--red); color: #FFFFFF; border-color: var(--red); }}
  .becss-btn--del {{
    width: 32px; height: 32px; padding: 0; flex-shrink: 0;
  }}
  .becss-btn--red {{
    background: var(--red); color: #FFFFFF; border-color: var(--red);
  }}
  .becss-btn--red:hover {{ background: #FFFFFF; color: var(--red); }}

  .becss-context-list {{
    max-height: 360px; overflow-y: auto;
    border: 1px solid var(--border); border-radius: 6px;
    padding: 8px; margin-top: 8px; background: #FFFFFF;
  }}
  .becss-context-row {{
    display: flex; gap: 8px; align-items: center;
    padding: 8px; border-bottom: 1px solid #DDDDDD;
  }}
  .becss-context-row:last-child {{ border-bottom: none; }}
  .becss-context-row__label {{ font-weight: 600; flex-shrink: 0; color: #555555; font-size: 0.85rem; }}
  .becss-context-row__ref {{
    flex: 1; font-family: 'Source Code Pro', monospace; font-size: 0.85rem;
    word-break: break-all;
  }}
  .becss-context-row__badge {{
    font-family: 'Inter', system-ui, sans-serif; font-size: 0.75rem;
    color: #555555; margin-top: 2px;
  }}
  .becss-context-empty {{ padding: 10px; color: #777777; }}

  .becss-row {{ display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }}
  .becss-status {{ margin-top: 10px; font-size: 0.9rem; min-height: 1.2em; }}
  .becss-status--ok {{ color: #0a7a0a; }}
  .becss-status--err {{ color: var(--red); }}

  /* Save-As modal */
  .becss-modal {{
    position: fixed; inset: 0; background: rgba(0,0,0,0.55);
    display: flex; align-items: center; justify-content: center;
    padding: 16px; z-index: 100;
  }}
  .becss-modal[hidden] {{ display: none; }}
  .becss-modal__box {{
    background: #FFFFFF; border: 1px solid var(--border); border-radius: 8px;
    padding: 20px; width: 100%; max-width: 420px;
  }}
  .becss-modal__title {{ margin: 0 0 4px; font-size: 1.05rem; }}

  /* Browse dialog (per-task Reference / Attach picker) */
  .becss-browse__box {{
    max-width: 480px; display: flex; flex-direction: column;
    max-height: 88dvh; padding: 0;
  }}
  .becss-browse__head {{
    padding: 14px 16px; border-bottom: 1px solid var(--border);
    display: flex; align-items: center; justify-content: space-between;
  }}
  .becss-browse__head h2 {{ margin: 0; font-size: 1.05rem; }}
  .becss-browse__path {{
    padding: 8px 16px; background: #F2F2F2; font-family: 'Source Code Pro', monospace;
    font-size: 0.78rem; word-break: break-all; border-bottom: 1px solid var(--border);
  }}
  .becss-browse__entries {{ height: 320px; overflow-y: auto; }}
  .becss-browse__entry {{
    padding: 10px 16px; border-bottom: 1px solid #F0F0F0;
    display: flex; align-items: center; gap: 10px; font-size: 0.88rem; cursor: pointer;
  }}
  .becss-browse__entry:hover {{ background: #F8F8F8; }}
  .becss-browse__entry--file {{ cursor: default; }}
  .becss-browse__entry__name {{ flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }}
  .becss-browse__entry__meta {{ font-size: 0.75rem; color: #777777; flex-shrink: 0; }}
  .becss-browse__foot {{
    padding: 12px 16px; border-top: 1px solid var(--border);
    display: flex; gap: 8px; justify-content: flex-end; align-items: center;
  }}

  /* Schema tab */
  .becss-schema-view {{
    max-height: 480px; overflow: auto; background: #000000; color: #FFFFFF;
    border-radius: 6px; padding: 12px; font-family: 'Source Code Pro', monospace;
    font-size: 0.78rem; white-space: pre-wrap; word-break: break-all; margin-top: 8px;
  }}

  footer.becss-footer {{
    text-align: center; font-size: 0.75rem; color: #555555;
    padding: 20px 16px 30px;
  }}
  code {{ font-family: 'Source Code Pro', monospace; }}
</style>
</head>
<body>
<header class="becss-header">
  <h1 class="becss-header__title">JobMaker</h1>
  <span class="becss-header__sub">Job Creation System · v{version}</span>
</header>

<nav class="becss-tabbar" id="tabBar">
  <button class="becss-tabbar__tab becss-tabbar__tab--active" data-tab="hub" type="button">Hub</button>
  <button class="becss-tabbar__tab" data-tab="editor" type="button">Job Editor</button>
  <button class="becss-tabbar__tab" data-tab="schema" type="button">Schema</button>
  <button class="becss-tabbar__tab" data-tab="run" type="button">Run</button>
</nav>

<main>
  <!-- ── Tab 1: Hub ─────────────────────────────────────────────────── -->
  <section class="becss-panel becss-panel--active" id="panel-hub">
    <label>Load From</label>
    <div class="becss-radio-group" id="hubSourceGroup">
      <label class="becss-radio-group__option">
        <input type="radio" name="hubSource" value="schema" checked> Job Schema
      </label>
      <label class="becss-radio-group__option">
        <input type="radio" name="hubSource" value="template"> Template
      </label>
    </div>

    <label for="hubPicker">Select Entry</label>
    <div class="becss-picker">
      <select id="hubPicker" class="becss-picker__select"><option value="">-- none --</option></select>
      <button class="becss-btn" id="hubLoadBtn" type="button">Load</button>
      <button class="becss-btn" id="hubDeleteBtn" type="button">Delete</button>
    </div>
    <div class="becss-status" id="hubStatus"></div>
  </section>

  <!-- ── Tab 2: Job Editor ──────────────────────────────────────────── -->
  <section class="becss-panel" id="panel-editor">
    <label for="jobName">Job Name</label>
    <input type="text" id="jobName" placeholder="e.g. Refactor Chunker CLI">

    <label for="jobGoal">Goal</label>
    <textarea id="jobGoal" placeholder="What should the agent accomplish?"></textarea>

    <label>Job Type / Subtype</label>
    <div class="becss-row" style="margin-top:0;">
      <input type="text" id="jobType" placeholder="e.g. writing" style="flex:1;">
      <input type="text" id="jobSubtype" placeholder="e.g. book" style="flex:1;">
    </div>

    <label>Contextualize</label>
    <label class="becss-radio-group__option" style="display:flex; align-items:center; gap:8px; margin-top:6px;">
      <input type="checkbox" id="contextualizePlan"> Contextualize Plan -- inject each task with the full plan (or at least every task title)
    </label>
    <label class="becss-radio-group__option" style="display:flex; align-items:center; gap:8px; margin-top:6px;">
      <input type="checkbox" id="contextualizeLast"> Contextualize Last -- inject each task with the prior task's output
    </label>

    <label>Tasks</label>
    <div class="becss-task-list" id="taskList"></div>

    <div class="becss-row">
      <button class="becss-btn" id="addTaskBtn" type="button">+ Add Task</button>
      <button class="becss-btn" id="saveBtn" type="button">Save</button>
      <button class="becss-btn" id="saveAsSchemaBtn" type="button">Save As Job Schema</button>
    </div>
    <div class="becss-status" id="statusLine"></div>
  </section>

  <!-- ── Tab 3: Schema ──────────────────────────────────────────────── -->
  <section class="becss-panel" id="panel-schema">
    <label>Current Job Schema (live)</label>
    <div class="becss-row">
      <button class="becss-btn becss-btn--red" id="copySchemaBtn" type="button">Copy to Clipboard</button>
    </div>
    <div class="becss-status" id="schemaStatus"></div>
    <pre class="becss-schema-view" id="schemaView">{{}}</pre>
  </section>

  <!-- ── Tab 4: Run ─────────────────────────────────────────────────── -->
  <section class="becss-panel" id="panel-run">
    <label>Loaded Job</label>
    <div class="becss-status" id="runJobLine">No Job Schema loaded. Load one from the Hub.</div>

    <label for="runProvider">Provider</label>
    <select id="runProvider"></select>
    <div class="becss-status" id="runProviderNote"></div>

    <label for="runModel">Model (blank = provider default)</label>
    <input type="text" id="runModel" placeholder="e.g. gemini-3-flash-preview">

    <label for="runRetries">Retries per task</label>
    <select id="runRetries"><option>0</option><option selected>1</option><option>2</option><option>3</option></select>

    <label for="runSystem">System instruction (blank = default)</label>
    <textarea id="runSystem" rows="2" placeholder="Default: execute one task, return only the deliverable."></textarea>

    <div class="becss-row">
      <button class="becss-btn" id="runPreviewBtn" type="button">Preview Prompt</button>
      <button class="becss-btn becss-btn--red" id="runNextBtn" type="button">Run Next</button>
      <button class="becss-btn becss-btn--red" id="runAllBtn" type="button">Run All</button>
      <button class="becss-btn" id="runStopBtn" type="button">Stop</button>
      <button class="becss-btn" id="runResetBtn" type="button">Reset</button>
    </div>
    <div class="becss-status" id="runStatusLine"></div>

    <label>Tasks</label>
    <div class="becss-task-list" id="runTaskList"></div>

    <label>Log</label>
    <pre class="becss-schema-view" id="runLog"></pre>

    <label>Viewer <span id="runViewerTitle"></span></label>
    <pre class="becss-schema-view" id="runViewer"></pre>
  </section>
</main>

<!-- ── Browse dialog (per-task Reference / Attach picker) ─────────────── -->
<div class="becss-modal" id="browseModal" hidden>
  <div class="becss-modal__box becss-browse__box">
    <div class="becss-browse__head">
      <h2 id="browseTitle">Add Reference</h2>
      <button class="becss-btn becss-btn--del" id="browseCloseBtn" type="button">×</button>
    </div>
    <div class="becss-browse__path" id="browsePath"></div>
    <div class="becss-browse__entries" id="browseEntries"></div>
    <div class="becss-browse__foot">
      <span class="becss-status" id="browseStatus" style="margin:0; flex:1;"></span>
      <button class="becss-btn" id="browseCancelBtn" type="button">Cancel</button>
      <button class="becss-btn becss-btn--red" id="browseAddBtn" type="button">Add Selected (0)</button>
    </div>
  </div>
</div>

<!-- ── Save-As modal ────────────────────────────────────────────────── -->
<div class="becss-modal" id="saveModal" hidden>
  <div class="becss-modal__box">
    <h2 class="becss-modal__title">Save As</h2>
    <label for="saveNameInput">Name</label>
    <input type="text" id="saveNameInput" placeholder="Entry name">

    <label>Save As Type</label>
    <div class="becss-radio-group" id="saveTypeGroup">
      <label class="becss-radio-group__option">
        <input type="radio" name="saveType" value="schema" checked> Job Schema
      </label>
      <label class="becss-radio-group__option">
        <input type="radio" name="saveType" value="template"> Template
      </label>
    </div>

    <div class="becss-row">
      <button class="becss-btn" id="saveConfirmBtn" type="button">Save</button>
      <button class="becss-btn" id="saveCancelBtn" type="button">Cancel</button>
    </div>
    <div class="becss-status" id="saveModalStatus"></div>
  </div>
</div>

<footer class="becss-footer">
  Elton Boehnen · eltonboehnen@gmail.com · boehnenelton2024.pages.dev ·
  github.com/boehnenelton · JobMaker v{version}
</footer>

<script>
let tasks = [];
let currentEntryId = null;    // entry_id of the loaded Hub entry, or null for an unsaved/new job
let currentEntryType = null;  // 'schema' | 'template' | null
let saveMode = 'save';        // 'save' (update in place / create) | 'saveAsSchema' (always a new copy)

// ── Tab switching ──────────────────────────────────────────────────────
function activateTab(name) {{
  document.querySelectorAll('.becss-tabbar__tab').forEach(t => {{
    t.classList.toggle('becss-tabbar__tab--active', t.dataset.tab === name);
  }});
  document.querySelectorAll('.becss-panel').forEach(p => {{
    p.classList.toggle('becss-panel--active', p.id === 'panel-' + name);
  }});
  if (name === 'schema') refreshSchemaView();
  if (name === 'run') {{ runRefreshHeader(); runLoadProviders(); runRenderTasks(); }}
}}
document.querySelectorAll('.becss-tabbar__tab').forEach(t => {{
  t.addEventListener('click', () => activateTab(t.dataset.tab));
}});


// ── Run tab ─────────────────────────────────────────────────────────────
let runPoll = null;
let runProvidersLoaded = false;

function runLoadedOk() {{
  return currentEntryId && currentEntryType === 'schema';
}}

function runRefreshHeader() {{
  const line = document.getElementById('runJobLine');
  if (runLoadedOk()) {{
    line.textContent = 'Running: ' + (document.getElementById('jobName') ? document.getElementById('jobName').value : currentEntryId);
  }} else if (currentEntryId && currentEntryType === 'template') {{
    line.textContent = 'A Template is loaded. Use Save As Job Schema first; only Job Schemas can run.';
  }} else {{
    line.textContent = 'No Job Schema loaded. Load one from the Hub (saved, not just edited).';
  }}
}}

async function runLoadProviders() {{
  if (runProvidersLoaded) return;
  const sel = document.getElementById('runProvider');
  try {{
    const r = await fetch('/api/run/providers');
    const d = await r.json();
    sel.innerHTML = '';
    (d.providers || []).filter(p => p.id).forEach(p => {{
      const o = document.createElement('option');
      o.value = p.id;
      o.textContent = p.id + (p.available ? '' : '  (unavailable)');
      o.dataset.note = p.note || '';
      sel.appendChild(o);
    }});
    runProvidersLoaded = true;
    runShowProviderNote();
  }} catch (e) {{
    document.getElementById('runProviderNote').textContent = 'Could not load providers: ' + e;
  }}
}}

function runShowProviderNote() {{
  const sel = document.getElementById('runProvider');
  const o = sel.options[sel.selectedIndex];
  document.getElementById('runProviderNote').textContent = o ? (o.dataset.note || '') : '';
}}
document.getElementById('runProvider').addEventListener('change', runShowProviderNote);

async function runRenderTasks() {{
  const box = document.getElementById('runTaskList');
  if (!runLoadedOk()) {{ box.innerHTML = ''; return; }}
  const r = await fetch('/api/entry/' + encodeURIComponent(currentEntryId));
  if (!r.ok) {{ box.textContent = 'Could not load the saved job.'; return; }}
  const d = await r.json();
  const rows = (d.tasks || []).map(t => {{
    const st = t.task_completed ? 'DONE' : (t.audit_fail_reason ? 'FAILED' : 'pending');
    return '<div class="becss-task-row" style="cursor:pointer" data-tid="' + esc(t.task_id) + '">' +
      '<span style="min-width:2.2em">' + esc(t.task_order) + '.</span>' +
      '<span style="flex:1">' + esc(t.task_name) + (t.mandatory ? ' [mandatory]' : '') +
      (t.audit_fail_reason ? '<br><small>' + esc(t.audit_fail_reason) + '</small>' : '') + '</span>' +
      '<span>' + st + '</span></div>';
  }}).join('');
  box.innerHTML = rows + '<div class="becss-task-row" style="cursor:pointer" data-tid="final"><span style="flex:1">View combined final.md</span></div>';
  box.querySelectorAll('[data-tid]').forEach(el => el.addEventListener('click', () => runViewOutput(el.dataset.tid)));
}}

async function runViewOutput(tid) {{
  const r = await fetch('/api/run/output?entry_id=' + encodeURIComponent(currentEntryId) + '&task_id=' + encodeURIComponent(tid));
  const d = await r.json();
  document.getElementById('runViewerTitle').textContent = '(' + (tid === 'final' ? 'final.md' : tid) + ')';
  document.getElementById('runViewer').textContent = r.ok ? d.content : (d.error || 'No output.');
}}

function runBody(mode) {{
  return {{
    entry_id: currentEntryId,
    provider: document.getElementById('runProvider').value,
    model: document.getElementById('runModel').value.trim(),
    max_retries: parseInt(document.getElementById('runRetries').value, 10),
    system: document.getElementById('runSystem').value.trim(),
    mode: mode,
  }};
}}

async function runStart(mode) {{
  const st = document.getElementById('runStatusLine');
  if (!runLoadedOk()) {{ st.textContent = 'Load a saved Job Schema from the Hub first.'; return; }}
  const r = await fetch('/api/run/start', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify(runBody(mode))}});
  const d = await r.json();
  if (!r.ok) {{ st.textContent = d.error || 'Could not start.'; return; }}
  st.textContent = 'Running...';
  runStartPolling();
}}

function runStartPolling() {{
  if (runPoll) clearInterval(runPoll);
  runPoll = setInterval(runPollOnce, 1500);
  runPollOnce();
}}

async function runPollOnce() {{
  try {{
    const d = await (await fetch('/api/run/status')).json();
    document.getElementById('runLog').textContent = (d.log || []).map(l => l.t + '  ' + l.msg).join('\\n');
    const st = document.getElementById('runStatusLine');
    if (d.running) {{
      st.textContent = 'Running task ' + d.current_task + ' via ' + d.provider + '...';
    }} else {{
      st.textContent = d.halted_reason ? ('Stopped: ' + d.halted_reason) : (d.finished ? 'Run finished.' : '');
      if (runPoll) {{ clearInterval(runPoll); runPoll = null; }}
    }}
    await runRenderTasks();
  }} catch (e) {{
    document.getElementById('runStatusLine').textContent = 'Status error: ' + e;
  }}
}}

document.getElementById('runNextBtn').addEventListener('click', () => runStart('next'));
document.getElementById('runAllBtn').addEventListener('click', () => runStart('all'));
document.getElementById('runStopBtn').addEventListener('click', () => fetch('/api/run/stop', {{method:'POST'}}));
document.getElementById('runPreviewBtn').addEventListener('click', async () => {{
  const st = document.getElementById('runStatusLine');
  if (!runLoadedOk()) {{ st.textContent = 'Load a saved Job Schema from the Hub first.'; return; }}
  const r = await fetch('/api/run/preview', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify({{entry_id: currentEntryId}})}});
  const d = await r.json();
  document.getElementById('runViewerTitle').textContent = r.ok ? '(prompt for task ' + d.task_order + ', ' + d.chars + ' chars)' : '';
  document.getElementById('runViewer').textContent = r.ok ? d.prompt : (d.error || 'No preview.');
}});
document.getElementById('runResetBtn').addEventListener('click', async () => {{
  const st = document.getElementById('runStatusLine');
  if (!runLoadedOk()) {{ st.textContent = 'Load a saved Job Schema from the Hub first.'; return; }}
  if (!confirm('Mark every task as not completed so the job can run again? Saved outputs are kept.')) return;
  const r = await fetch('/api/run/reset', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify({{entry_id: currentEntryId}})}});
  const d = await r.json();
  st.textContent = r.ok ? ('Reset ' + d.tasks_reset + ' tasks. Reload the job in the Job Editor to see them.') : (d.error || 'Reset failed.');
  runRenderTasks();
}});

// ── Job Editor: task list rendering ─────────────────────────────────────
function esc(s) {{
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}}

// ── Job Editor: task list rendering (each task owns its own context/reference) ─
function renderTasks() {{
  const el = document.getElementById('taskList');
  el.innerHTML = '';
  if (tasks.length === 0) {{
    el.innerHTML = '<div style="padding:10px;color:#777;">No tasks yet -- click "+ Add Task".</div>';
    return;
  }}
  tasks.forEach((t, i) => {{
    t.context = t.context || [];
    t.reference = t.reference || [];
    t.mandatory = !!t.mandatory;
    const row = document.createElement('div');
    row.className = 'becss-task-row';
    row.innerHTML = `
      <input type="checkbox" data-i="${{i}}" class="becss-task-row__done-cb" ${{t.task_completed ? 'checked' : ''}} title="task_completed">
      <div class="becss-task-row__fields">
        <input type="text" class="becss-task-row__name" data-i="${{i}}" placeholder="Task name" value="${{esc(t.task_name).replace(/"/g,'&quot;')}}">
        <textarea class="becss-task-row__desc" data-i="${{i}}" placeholder="Task description">${{esc(t.task_description)}}</textarea>
        <div class="becss-task-row__pickbtns">
          <button class="becss-btn becss-btn--red" data-i="${{i}}" data-mode="reference" type="button">+ Ref</button>
          <button class="becss-btn becss-btn--red" data-i="${{i}}" data-mode="context" type="button">+ Attach</button>
          <label style="display:flex; align-items:center; gap:4px; font-size:0.8rem; margin-left:4px;">
            <input type="checkbox" class="becss-task-row__mandatory-cb" data-i="${{i}}" ${{t.mandatory ? 'checked' : ''}}> Mandatory
          </label>
        </div>
        <div class="becss-task-context" id="taskCtx-${{i}}"></div>
      </div>
      <button class="becss-btn becss-btn--del" data-i="${{i}}" type="button" title="Delete task">×</button>
    `;
    el.appendChild(row);
  }});
  el.querySelectorAll('.becss-btn--del').forEach(b => b.addEventListener('click', e => {{
    tasks.splice(parseInt(e.target.dataset.i), 1);
    renderTasks();
  }}));
  el.querySelectorAll('.becss-task-row__name').forEach(inp => inp.addEventListener('input', e => {{
    tasks[parseInt(e.target.dataset.i)].task_name = e.target.value;
  }}));
  el.querySelectorAll('.becss-task-row__desc').forEach(inp => inp.addEventListener('input', e => {{
    tasks[parseInt(e.target.dataset.i)].task_description = e.target.value;
  }}));
  el.querySelectorAll('.becss-task-row__done-cb').forEach(cb => cb.addEventListener('change', e => {{
    tasks[parseInt(e.target.dataset.i)].task_completed = e.target.checked;
  }}));
  el.querySelectorAll('.becss-task-row__mandatory-cb').forEach(cb => cb.addEventListener('change', e => {{
    tasks[parseInt(e.target.dataset.i)].mandatory = e.target.checked;
  }}));
  el.querySelectorAll('.becss-task-row__pickbtns .becss-btn').forEach(b => b.addEventListener('click', e => {{
    openBrowseDialog(parseInt(e.currentTarget.dataset.i), e.currentTarget.dataset.mode);
  }}));
  tasks.forEach((t, i) => renderTaskContext(i));
}}

function renderTaskContext(i) {{
  const t = tasks[i];
  const el = document.getElementById('taskCtx-' + i);
  if (!el) return;
  let html = '';
  (t.reference || []).forEach((ref, j) => {{
    html += `
      <div class="becss-task-context__row">
        <span class="becss-task-context__tag">Ref ${{j + 1}}</span>
        <span class="becss-task-context__ref">${{esc(ref)}}</span>
        <button class="becss-task-context__rm" data-i="${{i}}" data-kind="reference" data-j="${{j}}" type="button" title="Remove">×</button>
      </div>`;
  }});
  (t.context || []).forEach((c, j) => {{
    const badge = c.text_based
      ? 'Chunked: ' + c.chunks.length + ' chunk' + (c.chunks.length === 1 ? '' : 's')
      : 'Not chunked (could not decode as text)';
    html += `
      <div class="becss-task-context__row">
        <span class="becss-task-context__tag">Context ${{j + 1}}</span>
        <span class="becss-task-context__ref">${{esc(c.ref)}}</span>
        <span class="becss-task-context__badge">${{badge}}</span>
        <button class="becss-task-context__rm" data-i="${{i}}" data-kind="context" data-j="${{j}}" type="button" title="Remove">×</button>
      </div>`;
  }});
  el.innerHTML = html;
  el.querySelectorAll('.becss-task-context__rm').forEach(b => b.addEventListener('click', e => {{
    const ti = parseInt(e.currentTarget.dataset.i);
    const kind = e.currentTarget.dataset.kind;
    const j = parseInt(e.currentTarget.dataset.j);
    tasks[ti][kind].splice(j, 1);
    renderTaskContext(ti);
  }}));
}}

function addTask() {{
  tasks.push({{
    task_id: '', task_order: tasks.length + 1, task_name: '', task_description: '',
    task_completed: false, audit_enabled: false, audit_passed: false, audit_fail_reason: '',
    context: [], reference: [], mandatory: false
  }});
  renderTasks();
}}

// ── Browse dialog: real navigable file browser + checkboxes, per task ──────
let browseTaskIndex = null;
let browseMode = 'reference';   // 'reference' (path-only) | 'context' (chunked)
let browsePath = '';
let browseSelected = new Set();

function openBrowseDialog(taskIndex, mode) {{
  browseTaskIndex = taskIndex;
  browseMode = mode;
  browseSelected = new Set();
  document.getElementById('browseTitle').textContent = mode === 'context' ? 'Add Attachment' : 'Add Reference';
  document.getElementById('browseStatus').textContent = '';
  document.getElementById('browseModal').hidden = false;
  loadBrowseDir('');
}}

function closeBrowseDialog() {{
  document.getElementById('browseModal').hidden = true;
}}

async function loadBrowseDir(path) {{
  const entriesEl = document.getElementById('browseEntries');
  entriesEl.innerHTML = '<div style="padding:14px;color:#777;">Loading...</div>';
  const res = await fetch('/api/browse', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{path: path}})
  }});
  const data = await res.json();
  if (!res.ok) {{ entriesEl.innerHTML = '<div style="padding:14px;color:#777;">' + esc(data.error || 'Could not browse.') + '</div>'; return; }}
  browsePath = data.path;
  document.getElementById('browsePath').textContent = data.path;
  if (!data.entries.length) {{
    entriesEl.innerHTML = '<div style="padding:14px;color:#777;">Empty directory.</div>';
    return;
  }}
  entriesEl.innerHTML = data.entries.map((e, idx) => {{
    if (e.type === 'dir') {{
      const icon = e.name === '..' ? '⬆' : '📁';
      return `<div class="becss-browse__entry" data-path="${{esc(e.path)}}" data-type="dir">
        <span>${{icon}}</span><span class="becss-browse__entry__name">${{esc(e.name)}}</span>
      </div>`;
    }}
    const checked = browseSelected.has(e.path) ? 'checked' : '';
    return `<div class="becss-browse__entry becss-browse__entry--file">
      <input type="checkbox" data-path="${{esc(e.path)}}" ${{checked}}>
      <span class="becss-browse__entry__name">${{esc(e.name)}}</span>
      <span class="becss-browse__entry__meta">${{esc(String(e.size_kb))}} KB</span>
    </div>`;
  }}).join('');
  entriesEl.querySelectorAll('.becss-browse__entry[data-type="dir"]').forEach(row => {{
    row.addEventListener('click', () => loadBrowseDir(row.dataset.path));
  }});
  entriesEl.querySelectorAll('input[type=checkbox]').forEach(cb => {{
    cb.addEventListener('change', () => {{
      if (cb.checked) browseSelected.add(cb.dataset.path); else browseSelected.delete(cb.dataset.path);
      document.getElementById('browseAddBtn').textContent = 'Add Selected (' + browseSelected.size + ')';
    }});
  }});
}}

async function confirmBrowseAdd() {{
  if (!browseSelected.size) {{ closeBrowseDialog(); return; }}
  const t = tasks[browseTaskIndex];
  const paths = Array.from(browseSelected);
  if (browseMode === 'reference') {{
    paths.forEach(p => {{ if (!t.reference.includes(p)) t.reference.push(p); }});
    renderTaskContext(browseTaskIndex);
    closeBrowseDialog();
    return;
  }}
  // context mode: read + chunk each selected file server-side
  document.getElementById('browseStatus').textContent = 'Reading & chunking ' + paths.length + ' file(s)...';
  for (const p of paths) {{
    if (t.context.some(c => c.ref === p)) continue;
    try {{
      const res = await fetch('/api/context/preview', {{
        method: 'POST', headers: {{'Content-Type': 'application/json'}},
        body: JSON.stringify({{path: p}})
      }});
      const data = await res.json();
      if (res.ok) t.context.push(data);
    }} catch (e) {{ /* skip failed file, continue with the rest */ }}
  }}
  renderTaskContext(browseTaskIndex);
  closeBrowseDialog();
}}

document.getElementById('browseCloseBtn').addEventListener('click', closeBrowseDialog);
document.getElementById('browseCancelBtn').addEventListener('click', closeBrowseDialog);
document.getElementById('browseAddBtn').addEventListener('click', confirmBrowseAdd);
document.getElementById('browseModal').addEventListener('click', e => {{
  if (e.target.id === 'browseModal') closeBrowseDialog();
}});

function setStatus(elId, msg, ok) {{
  const s = document.getElementById(elId);
  s.textContent = msg;
  s.className = 'becss-status ' + (ok ? 'becss-status--ok' : 'becss-status--err');
}}

// ── Schema tab: live JSON view + copy ───────────────────────────────────
function jobMetaPayload() {{
  return {{
    job_type: document.getElementById('jobType').value.trim(),
    job_subtype: document.getElementById('jobSubtype').value.trim(),
    contextualize_plan: document.getElementById('contextualizePlan').checked,
    contextualize_last: document.getElementById('contextualizeLast').checked,
  }};
}}

async function refreshSchemaView() {{
  const payload = Object.assign({{
    name: document.getElementById('jobName').value.trim() || 'Untitled Job',
    goal: document.getElementById('jobGoal').value,
    tasks: tasks,
    entry_id: currentEntryId
  }}, jobMetaPayload());
  const res = await fetch('/api/schema/preview', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify(payload)
  }});
  const data = await res.json();
  document.getElementById('schemaView').textContent = res.ok ? JSON.stringify(data.schema, null, 2) : (data.error || 'Could not build schema.');
}}

async function copySchema() {{
  const text = document.getElementById('schemaView').textContent;
  try {{
    await navigator.clipboard.writeText(text);
    setStatus('schemaStatus', 'Copied to clipboard.', true);
  }} catch (e) {{
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    try {{ document.execCommand('copy'); setStatus('schemaStatus', 'Copied to clipboard.', true); }}
    catch (e2) {{ setStatus('schemaStatus', 'Could not copy -- select and copy manually.', false); }}
    document.body.removeChild(ta);
  }}
}}

document.getElementById('copySchemaBtn').addEventListener('click', copySchema);

function loadJobIntoEditor(name, data, entryId, entryType) {{
  document.getElementById('jobName').value = name || '';
  document.getElementById('jobGoal').value = data.goal || '';
  document.getElementById('jobType').value = data.job_type || '';
  document.getElementById('jobSubtype').value = data.job_subtype || '';
  document.getElementById('contextualizePlan').checked = !!data.contextualize_plan;
  document.getElementById('contextualizeLast').checked = !!data.contextualize_last;
  tasks = data.tasks || [];
  currentEntryId = entryId || null;
  currentEntryType = entryType || null;
  renderTasks();
}}

// ── Hub tab: type-aware entry picker ────────────────────────────────────
function currentHubSource() {{
  return document.querySelector('input[name="hubSource"]:checked').value;
}}

async function refreshHubList() {{
  const type = currentHubSource();
  const res = await fetch('/api/registry?type=' + encodeURIComponent(type));
  const data = await res.json();
  const picker = document.getElementById('hubPicker');
  picker.innerHTML = '<option value="">-- none --</option>';
  (data.entries || []).forEach(entry => {{
    const opt = document.createElement('option');
    opt.value = entry.entry_id; opt.textContent = entry.entry_name;
    picker.appendChild(opt);
  }});
}}

async function loadSelectedHubEntry() {{
  const entryId = document.getElementById('hubPicker').value;
  if (!entryId) {{ setStatus('hubStatus', 'Select an entry to load.', false); return; }}
  const res = await fetch('/api/entry/' + encodeURIComponent(entryId));
  if (!res.ok) {{ setStatus('hubStatus', 'Could not load entry.', false); return; }}
  const data = await res.json();
  loadJobIntoEditor(data.entry_name, data, data.entry_id, data.entry_type);
  setStatus('hubStatus', 'Loaded "' + data.entry_name + '".', true);
  activateTab('editor');
}}

async function deleteSelectedHubEntry() {{
  const entryId = document.getElementById('hubPicker').value;
  const entryName = document.getElementById('hubPicker').selectedOptions[0]?.textContent || '';
  if (!entryId) {{ setStatus('hubStatus', 'Select an entry to delete.', false); return; }}
  if (!window.confirm('Delete "' + entryName + '" permanently? This cannot be undone.')) return;
  const res = await fetch('/api/entry/' + encodeURIComponent(entryId), {{ method: 'DELETE' }});
  const data = await res.json();
  if (!res.ok) {{ setStatus('hubStatus', data.error || 'Delete failed.', false); return; }}
  if (currentEntryId === entryId) {{
    currentEntryId = null;
    currentEntryType = null;
  }}
  setStatus('hubStatus', 'Deleted "' + entryName + '".', true);
  refreshHubList();
}}

document.querySelectorAll('input[name="hubSource"]').forEach(r => {{
  r.addEventListener('change', refreshHubList);
}});
document.getElementById('hubLoadBtn').addEventListener('click', loadSelectedHubEntry);
document.getElementById('hubDeleteBtn').addEventListener('click', deleteSelectedHubEntry);

// ── Save-As modal ────────────────────────────────────────────────────────
function openSaveModal(mode) {{
  saveMode = mode;
  document.getElementById('saveNameInput').value = document.getElementById('jobName').value.trim();
  document.getElementById('saveModalStatus').textContent = '';

  const templateRadio = document.querySelector('input[name="saveType"][value="template"]');
  const schemaRadio = document.querySelector('input[name="saveType"][value="schema"]');
  const title = document.querySelector('.becss-modal__title');
  if (mode === 'saveAsSchema') {{
    schemaRadio.checked = true;
    templateRadio.disabled = true;
    title.textContent = 'Save As New Job Schema';
  }} else {{
    templateRadio.disabled = false;
    (currentEntryType === 'template' ? templateRadio : schemaRadio).checked = true;
    title.textContent = (currentEntryId ? 'Save (renames "' + document.getElementById('jobName').value.trim() + '" in place)' : 'Save As');
  }}

  document.getElementById('saveModal').hidden = false;
  document.getElementById('saveNameInput').focus();
}}

function closeSaveModal() {{
  document.getElementById('saveModal').hidden = true;
}}

async function confirmSaveEntry() {{
  const name = document.getElementById('saveNameInput').value.trim();
  if (!name) {{ setStatus('saveModalStatus', 'Name is required.', false); return; }}
  const entryType = saveMode === 'saveAsSchema' ? 'schema' : document.querySelector('input[name="saveType"]:checked').value;

  tasks.forEach((t, i) => {{
    t.task_order = i + 1;
    if (saveMode === 'saveAsSchema') {{
      // Instantiating a Template into a fresh Job Schema: don't carry over
      // the template's task identity or in-progress/completion state.
      // Its context/reference attachments are still relevant material for
      // the fresh job, so those carry over untouched.
      t.task_id = '';
      t.task_completed = false;
      t.audit_passed = false;
    }}
  }});

  const payload = Object.assign({{
    name: name, entry_type: entryType,
    goal: document.getElementById('jobGoal').value, tasks: tasks
  }}, jobMetaPayload());

  const useRename = (saveMode === 'save' && currentEntryId);
  const url = useRename ? ('/api/entry/' + encodeURIComponent(currentEntryId)) : '/api/entry';
  const method = useRename ? 'PUT' : 'POST';

  const res = await fetch(url, {{
    method: method, headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify(payload)
  }});
  const data = await res.json();
  if (!res.ok) {{ setStatus('saveModalStatus', data.error || 'Save failed.', false); return; }}

  currentEntryId = data.entry_id;
  currentEntryType = data.entry_type;
  document.getElementById('jobName').value = data.display_name;
  tasks = data.job.tasks;
  renderTasks();
  closeSaveModal();
  const kindLabel = entryType === 'template' ? 'Template' : 'Job Schema';
  const verb = saveMode === 'saveAsSchema' ? 'Saved a new Job Schema: ' : (useRename ? 'Updated ' : 'Saved ');
  setStatus('statusLine', verb + '"' + data.display_name + '" (' + kindLabel + ').', true);
  refreshHubList();
}}

document.getElementById('saveBtn').addEventListener('click', () => openSaveModal('save'));
document.getElementById('saveAsSchemaBtn').addEventListener('click', () => openSaveModal('saveAsSchema'));
document.getElementById('saveCancelBtn').addEventListener('click', closeSaveModal);
document.getElementById('saveConfirmBtn').addEventListener('click', confirmSaveEntry);
document.getElementById('saveModal').addEventListener('click', e => {{
  if (e.target.id === 'saveModal') closeSaveModal();
}});

document.getElementById('addTaskBtn').addEventListener('click', addTask);

renderTasks();
refreshHubList();
</script>
</body>
</html>
"""


@app.route("/", methods=["GET"])
def index():
    return Response(_PAGE.format(version=VERSION), mimetype="text/html")


import JobRunner
JobRunner.register_routes(app, base_dir=BASE_DIR, lib_dir=BASE_DIR / "lib",
                          registry_find=_registry_find)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    TEMPLATES_DIR.mkdir(parents=True, exist_ok=True)
    logging.getLogger("JobMaker").info("JobMaker v%s serving jobs/ + templates/ at %s", VERSION, BASE_DIR)
    app.run(host="0.0.0.0", port=5055, debug=False)
