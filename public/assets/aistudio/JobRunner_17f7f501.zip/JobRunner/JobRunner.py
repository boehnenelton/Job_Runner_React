"""
Name:           JobRunner.py
Relative Path:  JobRunner.py
Family:         JobMaker
Description:    Job execution engine for JobMaker. Runs a BEJSON 104a Job
                Schema task by task through the AI-family dispatch library
                (lib_bejson_AI_ai_dispatch). Every run applies the job's
                Contextualize_Plan / Contextualize_Last header flags, the
                per-task context (embedded chunks) and reference (paths)
                cells, the per-task audit gate and the per-task mandatory
                flag. Pure engine plus a Flask route registrar -- it does not
                own the UI. Task outputs are written to runs/<job_slug>/ and
                task_completed / audit_* are written back to the job file
                through the Field Map Cache (no positional access).
Version:        1.0.0
Date:           2026-10-11
Author:         Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
Format_Creator: Elton Boehnen
RELATIONAL_ID:  b2f7c5a1-84d3-4e6a-9c10-5d3e7a9f2b48

Prompt order per task (matches the Bookmaker-as-job-runner spec):
    1. Job_Goal
    2. Plan scope            (only if Contextualize_Plan)
    3. Previous task output  (only if Contextualize_Last)
    4. Active task name + description
    5. Task context chunks   (embedded files)
    6. Task references       (paths only, never read)
    7. Closing instruction

Failure policy (what Mandatory means to the runner):
    A task that fails (provider error, or audit FAIL after retries) is left
    incomplete. If it is Mandatory the run HALTS there. If it is not
    mandatory the run records it as skipped and continues; the skipped task's
    output is not fed forward as "previous output". The job is only marked
    complete when every task, mandatory or not, is completed.

Dependencies: Core libs under lib/ (field map, atomic write) and the AI
dispatch libs under lib/ (loaded lazily, so JobMaker still starts when a
provider SDK is missing).
"""

import json
import logging
import re
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

VERSION = "1.0.0"

logger = logging.getLogger("JobRunner")

DRYRUN_PROVIDER = "dryrun"

# Providers whose adapter cannot take a per-call system instruction
# (see ai_dispatch.py). For these the system text is folded into the prompt.
_NO_SYSTEM_INSTRUCTION = {"groq", "openrouter"}

DEFAULT_SYSTEM = (
    "You are executing one task of a multi-task job. Follow the job goal and "
    "the active task exactly. Return only the deliverable for the active "
    "task, with no preamble and no commentary about the process."
)

AUDIT_SYSTEM = (
    "You are a strict reviewer. You are given a task and the output produced "
    "for it. Reply with PASS or FAIL as the first word, then one short "
    "sentence explaining why."
)

MAX_CONTEXT_CHARS = 200_000   # hard cap on embedded context per task


# ── Run state (single active run at a time) ─────────────────────────────────

_state_lock = threading.Lock()
_stop_flag = threading.Event()
_state: dict = {
    "running": False, "entry_id": "", "job_name": "", "provider": "",
    "model": "", "mode": "", "current_task": 0, "started": "", "finished": "",
    "halted_reason": "", "log": [], "results": [],
}


def _log(msg: str, level: str = "info") -> None:
    getattr(logger, level, logger.info)(msg)
    with _state_lock:
        _state["log"].append({"t": datetime.now().strftime("%H:%M:%S"), "msg": msg})
        if len(_state["log"]) > 300:
            del _state["log"][:-300]


def get_status() -> dict:
    with _state_lock:
        return json.loads(json.dumps(_state))


def request_stop() -> None:
    _stop_flag.set()


# ── Provider access ──────────────────────────────────────────────────────────

def list_providers(lib_dir: Path) -> list[dict]:
    """Providers the dispatch library knows, plus a no-network dry run.
    Each carries whether its module imports right now and why not."""
    out = [{"id": DRYRUN_PROVIDER, "available": True,
            "note": "No AI call: returns the assembled prompt as the output."}]
    _ensure_path(lib_dir)
    try:
        from lib_bejson_AI_ai_dispatch import PROVIDERS
    except Exception as e:  # dispatch lib missing or broken
        logger.error("AI dispatch library unavailable: %s", e)
        return out + [{"id": "", "available": False, "note": f"dispatch library unavailable: {e}"}]
    import importlib
    for p in PROVIDERS:
        mod = {"genai": "lib_bejson_AI_bejson_genai"}.get(p, f"lib_bejson_AI_bejson_{p}")
        try:
            importlib.import_module(mod)
            out.append({"id": p, "available": True, "note": ""})
        except BaseException as e:  # missing sibling lib / SDK
            out.append({"id": p, "available": False, "note": f"{type(e).__name__}: {e}"})
    return out


def _ensure_path(lib_dir: Path) -> None:
    s = str(lib_dir)
    if s not in sys.path:
        sys.path.insert(0, s)


def call_ai(lib_dir: Path, provider: str, prompt: str, model: Optional[str],
            system: str) -> dict:
    """One normalized call. Returns {success, content, error, model_id}.
    Never raises for provider-side failures."""
    if provider == DRYRUN_PROVIDER:
        return {"success": True, "content": f"[DRY RUN]\n\n{prompt}", "error": None, "model_id": "dryrun"}
    _ensure_path(lib_dir)
    try:
        from lib_bejson_AI_ai_dispatch import ai_dispatch_call
    except Exception as e:
        return {"success": False, "content": "", "error": f"AI dispatch library unavailable: {e}", "model_id": model}
    sys_arg = system
    user_input = prompt
    if provider in _NO_SYSTEM_INSTRUCTION:
        sys_arg = None
        user_input = f"{system}\n\n{prompt}"
    try:
        resp = ai_dispatch_call(provider, user_input, model_id=model or None,
                                system_instruction=sys_arg)
    except Exception as e:
        return {"success": False, "content": "", "error": f"dispatch error: {e}", "model_id": model}
    ok = bool(resp.get("success")) and bool((resp.get("content") or "").strip())
    err = resp.get("error")
    if resp.get("success") and not ok:
        err = "Provider returned an empty reply."
    return {"success": ok, "content": resp.get("content") or "", "error": err,
            "model_id": resp.get("model_id") or model}


# ── Job doc access (Field Map Cache only) ────────────────────────────────────

def _tasks_from_doc(doc: dict) -> list[dict]:
    from lib_bejson_Core_bejson_core import bejson_core_get_field_map
    fmap = bejson_core_get_field_map(doc)
    tasks = []
    for ri, row in enumerate(doc.get("Values", [])):
        def get(field, default=None, _row=row):
            idx = fmap.get(field)
            return _row[idx] if idx is not None and len(_row) > idx else default
        ctx = get("task_context", [])
        ref = get("task_reference", [])
        tasks.append({
            "row": ri,
            "task_id": str(get("task_id", "")),
            "order": int(get("task_order", ri + 1) or ri + 1),
            "name": str(get("task_name", "")),
            "description": str(get("task_description", "")),
            "completed": bool(get("task_completed", False)),
            "audit_enabled": bool(get("audit_enabled", False)),
            "mandatory": bool(get("task_mandatory", False)),
            "context": ctx if isinstance(ctx, list) else [],
            "reference": ref if isinstance(ref, list) else [],
        })
    tasks.sort(key=lambda t: t["order"])
    return tasks


def _set_row(doc: dict, row_index: int, **fields) -> None:
    from lib_bejson_Core_bejson_core import bejson_core_get_field_map
    fmap = bejson_core_get_field_map(doc)
    row = doc["Values"][row_index]
    for name, val in fields.items():
        idx = fmap.get(name)
        if idx is not None and len(row) > idx:
            row[idx] = val


def _slug(name: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", name.strip()).strip("_").lower() or "job"


# ── Prompt assembly ──────────────────────────────────────────────────────────

def _context_block(task: dict) -> str:
    parts = []
    used = 0
    for entry in task["context"]:
        if not isinstance(entry, dict):
            continue
        ref = str(entry.get("ref", ""))
        chunks = entry.get("chunks") or []
        if not entry.get("text_based") or not chunks:
            continue
        parts.append(f"#### [Context file: {Path(ref).name} | {ref}]")
        for ch in chunks:
            body = str(ch.get("chunk_content", ""))
            if used + len(body) > MAX_CONTEXT_CHARS:
                parts.append("[...context truncated at size cap...]")
                return "\n".join(parts)
            used += len(body)
            parts.append(body)
    return "\n\n".join(parts)


def assemble_prompt(doc: dict, tasks: list[dict], task: dict,
                    last_output: str = "") -> str:
    """Build the user prompt for one task, in the spec'd order."""
    out = [f"### JOB GOAL\n{doc.get('Job_Goal', '')}".rstrip()]
    jt, jst = doc.get("Job_Type", ""), doc.get("Job_Subtype", "")
    if jt or jst:
        out.append(f"### JOB TYPE\n{jt}{' / ' + jst if jst else ''}")
    if doc.get("Contextualize_Plan"):
        lines = []
        for t in tasks:
            mark = "  <-- ACTIVE" if t["task_id"] == task["task_id"] else ""
            state = "done" if t["completed"] else "pending"
            lines.append(f"{t['order']}. {t['name']} [{state}]{mark}")
            if t["description"] and t["task_id"] != task["task_id"]:
                lines.append(f"   {t['description']}")
        out.append("### FULL PLAN\n" + "\n".join(lines))
    if doc.get("Contextualize_Last") and last_output.strip():
        out.append("### PREVIOUS TASK OUTPUT\n" + last_output.strip())
    out.append(f"### ACTIVE TASK {task['order']}: {task['name']}\n{task['description']}".rstrip())
    ctx = _context_block(task)
    if ctx:
        out.append("### TASK CONTEXT (study material; do not repeat it back)\n" + ctx)
    refs = [str(r.get("ref") if isinstance(r, dict) else r) for r in task["reference"]]
    refs = [r for r in refs if r and r != "None"]
    if refs:
        out.append("### TASK REFERENCES (paths only)\n" + "\n".join(f"- {r}" for r in refs))
    out.append("### INSTRUCTION\nComplete the active task now and return only its deliverable.")
    return "\n\n".join(out)


# ── Output storage ───────────────────────────────────────────────────────────

def _run_dir(base_dir: Path, job_name: str) -> Path:
    d = base_dir / "runs" / _slug(job_name)
    d.mkdir(parents=True, exist_ok=True)
    return d


def _out_path(run_dir: Path, task_id: str) -> Path:
    return run_dir / f"{_slug(task_id)}.md"


def read_task_output(base_dir: Path, job_name: str, task_id: str) -> str:
    p = _out_path(_run_dir(base_dir, job_name), task_id)
    return p.read_text(encoding="utf-8") if p.is_file() else ""


def _last_output(run_dir: Path, tasks: list[dict], upto_order: int) -> str:
    """Output of the nearest earlier completed task that has a saved file."""
    for t in reversed([t for t in tasks if t["order"] < upto_order]):
        if t["completed"]:
            p = _out_path(run_dir, t["task_id"])
            if p.is_file():
                return p.read_text(encoding="utf-8")
    return ""


def _write_final(run_dir: Path, doc: dict, tasks: list[dict]) -> Optional[Path]:
    parts = []
    for t in tasks:
        p = _out_path(run_dir, t["task_id"])
        if p.is_file():
            parts.append(p.read_text(encoding="utf-8").rstrip())
    if not parts:
        return None
    final = run_dir / "final.md"
    final.write_text("\n\n".join(parts) + "\n", encoding="utf-8")
    return final


# ── Core: run one task ───────────────────────────────────────────────────────

def _parse_audit(text: str) -> tuple[bool, str]:
    m = re.match(r"\W*(PASS|FAIL)\b[\W]*(.*)", text.strip(), re.IGNORECASE | re.DOTALL)
    if not m:
        return False, "Reviewer reply did not start with PASS or FAIL."
    return m.group(1).upper() == "PASS", m.group(2).strip()[:500]


def run_one_task(*, base_dir: Path, lib_dir: Path, job_path: Path, provider: str,
                 model: str, system: str, max_retries: int = 1) -> dict:
    """Run the first pending task of the job file. Returns a result dict:
    {status: 'completed'|'failed'|'none_pending', task_order, task_name,
     mandatory, error, output_chars}. Persists state to disk either way."""
    from lib_bejson_Core_bejson_core import bejson_core_load_file, bejson_core_atomic_write
    doc = bejson_core_load_file(str(job_path))
    if not isinstance(doc, dict):
        return {"status": "failed", "error": f"Could not load {job_path.name}.", "mandatory": True,
                "task_order": 0, "task_name": ""}
    tasks = _tasks_from_doc(doc)
    pending = [t for t in tasks if not t["completed"]]
    if not pending:
        return {"status": "none_pending", "task_order": 0, "task_name": "", "mandatory": False}
    return _execute(base_dir, lib_dir, job_path, doc, tasks, pending[0], provider, model,
                    system, max_retries, bejson_core_atomic_write)


def _execute(base_dir, lib_dir, job_path, doc, tasks, task, provider, model, system,
             max_retries, atomic_write) -> dict:
    run_dir = _run_dir(base_dir, job_path.stem)
    res = {"status": "failed", "task_order": task["order"], "task_name": task["name"],
           "mandatory": task["mandatory"], "error": "", "output_chars": 0}
    last = _last_output(run_dir, tasks, task["order"])
    prompt = assemble_prompt(doc, tasks, task, last)
    attempt, fail_reason, output = 0, "", ""
    while attempt <= max_retries:
        attempt += 1
        p = prompt if not fail_reason else (
            prompt + f"\n\n### REVIEWER FEEDBACK ON YOUR PREVIOUS ATTEMPT\n{fail_reason}\nFix this in your new answer.")
        r = call_ai(lib_dir, provider, p, model, system)
        if not r["success"]:
            fail_reason = r["error"] or "Provider call failed."
            _log(f"Task {task['order']} attempt {attempt}: provider error: {fail_reason}", "warning")
            if attempt > max_retries:
                break
            continue
        output = r["content"]
        if not task["audit_enabled"] or provider == DRYRUN_PROVIDER:
            # dry run makes no AI calls, so there is no reviewer to ask
            fail_reason = ""
            break
        a = call_ai(lib_dir, provider,
                    f"TASK: {task['name']}\n{task['description']}\n\nOUTPUT:\n{output}",
                    model, AUDIT_SYSTEM)
        if not a["success"]:
            fail_reason = f"Audit call failed: {a['error']}"
            if attempt > max_retries:
                break
            continue
        passed, why = _parse_audit(a["content"])
        if passed:
            fail_reason = ""
            break
        fail_reason = why or "Audit failed."
        _log(f"Task {task['order']} attempt {attempt}: audit FAIL: {fail_reason}", "warning")
    if fail_reason:
        _set_row(doc, task["row"], task_completed=False,
                 audit_passed=False,
                 audit_fail_reason=fail_reason[:500])
        atomic_write(str(job_path), doc)
        res["error"] = fail_reason
        return res
    _out_path(run_dir, task["task_id"]).write_text(output.rstrip() + "\n", encoding="utf-8")
    _set_row(doc, task["row"], task_completed=True, audit_passed=bool(task["audit_enabled"]),
             audit_fail_reason="")
    all_done = all(
        (i == task["row"]) or bool(_tasks_row_completed(doc, i)) for i in range(len(doc["Values"])))
    if all_done:
        doc["Job_Complete"] = True
        doc["Completion_Date"] = datetime.now().strftime("%Y-%m-%d")
    atomic_write(str(job_path), doc)
    res.update(status="completed", output_chars=len(output))
    if all_done:
        final = _write_final(run_dir, doc, _tasks_from_doc(doc))
        res["final"] = str(final.relative_to(base_dir)) if final else ""
    return res


def _tasks_row_completed(doc: dict, row_index: int) -> bool:
    from lib_bejson_Core_bejson_core import bejson_core_get_field_map
    fmap = bejson_core_get_field_map(doc)
    idx = fmap.get("task_completed")
    row = doc["Values"][row_index]
    return bool(idx is not None and len(row) > idx and row[idx])


# ── Run loop (background thread) ─────────────────────────────────────────────

def _run_thread(*, base_dir, lib_dir, job_path, entry_id, provider, model, system,
                mode, max_retries):
    try:
        skipped: set = set()
        while not _stop_flag.is_set():
            from lib_bejson_Core_bejson_core import bejson_core_load_file, bejson_core_atomic_write
            doc = bejson_core_load_file(str(job_path))
            tasks = _tasks_from_doc(doc)
            pending = [t for t in tasks if not t["completed"] and t["task_id"] not in skipped]
            if not pending:
                break
            task = pending[0]
            with _state_lock:
                _state["current_task"] = task["order"]
            _log(f"Running task {task['order']}: {task['name']}"
                 f"{' (mandatory)' if task['mandatory'] else ''}")
            res = _execute(base_dir, lib_dir, job_path, doc, tasks, task, provider, model,
                           system, max_retries, bejson_core_atomic_write)
            with _state_lock:
                _state["results"].append(res)
            if res["status"] == "completed":
                _log(f"Task {res['task_order']} completed ({res['output_chars']} chars).")
            else:
                if task["mandatory"]:
                    with _state_lock:
                        _state["halted_reason"] = (
                            f"Mandatory task {task['order']} failed: {res['error']}")
                    _log(_state["halted_reason"], "error")
                    break
                skipped.add(task["task_id"])
                _log(f"Task {task['order']} failed and is not mandatory; skipped: {res['error']}", "warning")
            if mode == "next":
                break
        if _stop_flag.is_set():
            with _state_lock:
                _state["halted_reason"] = "Stopped by user."
    except Exception as e:  # keep the thread's failure visible, never silent
        logger.exception("Run thread crashed")
        with _state_lock:
            _state["halted_reason"] = f"Runner crashed: {e}"
    finally:
        with _state_lock:
            _state["running"] = False
            _state["finished"] = datetime.now().isoformat(timespec="seconds")
        _log("Run finished.")


def start_run(*, base_dir: Path, lib_dir: Path, job_path: Path, entry_id: str,
              job_name: str, provider: str, model: str, system: str, mode: str,
              max_retries: int) -> tuple[bool, str]:
    with _state_lock:
        if _state["running"]:
            return False, "A run is already in progress."
        _state.update(running=True, entry_id=entry_id, job_name=job_name, provider=provider,
                      model=model, mode=mode, current_task=0, halted_reason="",
                      started=datetime.now().isoformat(timespec="seconds"), finished="",
                      log=[], results=[])
    _stop_flag.clear()
    threading.Thread(
        target=_run_thread, daemon=True,
        kwargs=dict(base_dir=base_dir, lib_dir=lib_dir, job_path=job_path, entry_id=entry_id,
                    provider=provider, model=model, system=system, mode=mode,
                    max_retries=max_retries)).start()
    return True, "started"


def reset_job(job_path: Path) -> int:
    """Clear completion/audit state on every task so the job can run again.
    Returns the number of tasks reset. Saved outputs on disk are kept."""
    from lib_bejson_Core_bejson_core import bejson_core_load_file, bejson_core_atomic_write
    doc = bejson_core_load_file(str(job_path))
    n = len(doc.get("Values", []))
    for i in range(n):
        _set_row(doc, i, task_completed=False, audit_passed=False, audit_fail_reason="")
    doc["Job_Complete"] = False
    doc["Completion_Date"] = ""
    bejson_core_atomic_write(str(job_path), doc)
    return n


# ── Flask registration ───────────────────────────────────────────────────────

def register_routes(app, *, base_dir: Path, lib_dir: Path,
                    registry_find: Callable[[str], Optional[dict]]) -> None:
    from flask import jsonify, request

    def _resolve(entry_id: str):
        meta = registry_find(entry_id or "")
        if not meta:
            return None, None, (jsonify({"error": f"No entry '{entry_id}'."}), 404)
        if meta["entry_type"] != "schema":
            return None, None, (jsonify({"error": "Only Job Schema entries can be run, not templates. "
                                                  "Use Save As Job Schema first."}), 400)
        p = (base_dir / meta["file_path"]).resolve()
        if base_dir.resolve() not in p.parents or not p.is_file():
            return None, None, (jsonify({"error": "Job file missing or outside the project."}), 404)
        return meta, p, None

    @app.route("/api/run/providers", methods=["GET"])
    def api_run_providers():
        return jsonify({"providers": list_providers(lib_dir)})

    @app.route("/api/run/preview", methods=["POST"])
    def api_run_preview():
        body = request.get_json(silent=True) or {}
        meta, p, err = _resolve(body.get("entry_id"))
        if err:
            return err
        from lib_bejson_Core_bejson_core import bejson_core_load_file
        doc = bejson_core_load_file(str(p))
        tasks = _tasks_from_doc(doc)
        pending = [t for t in tasks if not t["completed"]]
        if not pending:
            return jsonify({"error": "No pending tasks."}), 400
        task = pending[0]
        run_dir = _run_dir(base_dir, p.stem)
        prompt = assemble_prompt(doc, tasks, task, _last_output(run_dir, tasks, task["order"]))
        return jsonify({"task_order": task["order"], "task_name": task["name"],
                        "mandatory": task["mandatory"], "audit_enabled": task["audit_enabled"],
                        "prompt": prompt, "chars": len(prompt)})

    @app.route("/api/run/start", methods=["POST"])
    def api_run_start():
        body = request.get_json(silent=True) or {}
        meta, p, err = _resolve(body.get("entry_id"))
        if err:
            return err
        provider = str(body.get("provider") or DRYRUN_PROVIDER)
        mode = "next" if body.get("mode") == "next" else "all"
        try:
            retries = max(0, min(3, int(body.get("max_retries", 1))))
        except (TypeError, ValueError):
            retries = 1
        ok, msg = start_run(base_dir=base_dir, lib_dir=lib_dir, job_path=p,
                            entry_id=meta["entry_id"], job_name=meta["entry_name"],
                            provider=provider, model=str(body.get("model") or ""),
                            system=str(body.get("system") or DEFAULT_SYSTEM),
                            mode=mode, max_retries=retries)
        return (jsonify({"ok": True}), 200) if ok else (jsonify({"error": msg}), 409)

    @app.route("/api/run/status", methods=["GET"])
    def api_run_status():
        return jsonify(get_status())

    @app.route("/api/run/stop", methods=["POST"])
    def api_run_stop():
        request_stop()
        return jsonify({"ok": True})

    @app.route("/api/run/reset", methods=["POST"])
    def api_run_reset():
        body = request.get_json(silent=True) or {}
        meta, p, err = _resolve(body.get("entry_id"))
        if err:
            return err
        if get_status()["running"]:
            return jsonify({"error": "Cannot reset while a run is in progress."}), 409
        return jsonify({"ok": True, "tasks_reset": reset_job(p)})

    @app.route("/api/run/output", methods=["GET"])
    def api_run_output():
        meta, p, err = _resolve(request.args.get("entry_id"))
        if err:
            return err
        which = request.args.get("task_id", "")
        run_dir = _run_dir(base_dir, p.stem)
        target = run_dir / "final.md" if which == "final" else _out_path(run_dir, which)
        if not target.is_file():
            return jsonify({"error": "No saved output yet."}), 404
        return jsonify({"content": target.read_text(encoding="utf-8")})
