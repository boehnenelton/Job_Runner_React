# Change Log

## 2.8.0 (2026-10-11)
- Run tab + JobRunner.py: execute a Job Schema via the AI dispatch libs.
- Vendored AI libs into lib/ (unmodified).
- Mandatory flag now halts a run on failure; optional failed tasks are skipped.

## 2.7.1 (2026-08-25)
- Fixed Pydroid3 surrogate-pair crash on GET /.
