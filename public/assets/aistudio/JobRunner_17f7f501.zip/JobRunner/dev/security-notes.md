# Security Notes

- API keys: the vendored AI libs read keys from lib/config/<provider>_keys.104a.bejson (auto-created with a placeholder on first use) and genai from {HOME}/.env/gemini_keys.bejson. Policy keeps secrets in /storage/emulated/0/.env/secure/secureenv_file.json; the libs are frozen so they were not changed to read it. No keys are shipped in this package. Do not commit lib/config/.
- Run endpoints only accept registry entries of type schema, and the resolved job path must be inside the project dir.
- Task outputs are written to runs/<job_slug>/ only.
- Context/reference reads still go through the existing SAFE_ROOTS guard.
