# JobMaker 2.8.0 Technical Overview

Files: JobMaker.py (UI + authoring API), JobRunner.py (execution engine + /api/run/*), lib/ (frozen Core + AI dispatch libs).

Run flow: pick a saved Job Schema in the Hub, open Run, choose provider/model. Each pending task in task_order is assembled as Job_Goal, plan (Contextualize_Plan), previous output (Contextualize_Last), task, context chunks, reference paths. Optional audit (audit_enabled) runs a PASS/FAIL review with retry. Output goes to runs/<slug>/<task_id>.md; final.md is the ordered concatenation when the job completes.

Failure: mandatory task fails -> run halts. Optional task fails -> skipped, run continues. Job_Complete only when all tasks are done.

Providers: dryrun (no network), genai, groq, openrouter, grok, huggingface, ollama, tokenrouter work with the vendored libs. gemini needs lib_bejson_Core_bejson_schema.py; openai needs lib_bejson_AI_bejson_openai.py. Gemini models are reachable through genai.
