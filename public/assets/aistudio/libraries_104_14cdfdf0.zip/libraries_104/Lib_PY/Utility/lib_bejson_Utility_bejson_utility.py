"""
Library:         lib_bejson_Utility_bejson_utility.py
Family:          Utility
Module Purpose:  Implements runtime functionality and logic for lib_bejson_Utility_bejson_utility.py.
Architecture:    BEJSON 104db provides single-file multi-entity relational storage with positional null-padding, Record_Type_Parent discriminator headers, and plain-text LLM readability.
Version:         2.4.0
Release_Version: 300
Date:            2026-08-07
Author:          Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton
Format_Creator:  Elton Boehnen
RELATIONAL_ID:   374393bb-559d-4444-959f-a679b80d95f7
"""

import os
import sys
import json
import time
import base64
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

# Sibling Path Resolution
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_LIB_DIR = os.path.dirname(CURRENT_DIR)
CORE_DIR = os.path.join(PARENT_LIB_DIR, "Core")
if CORE_DIR not in sys.path:
    sys.path.append(CORE_DIR)

from lib_bejson_Core_bejson_path_guard import bejson_safe_join

try:
    import lib_bejson_Core_bejson_core as BEJSONCore
except ImportError:
    # Fallback for environments where it's not in the same folder structure
    print("Warning: lib_bejson_Core_bejson_core not found via standard import, attempting fallback...")
    try:
        import lib_bejson_Core_bejson_core as BEJSONCore
    except ImportError:
        print("CRITICAL: lib_bejson_Core_bejson_core still not found.")
        raise

try:
    # SCHEMA_MFDB_ENTITY was a byte-identical duplicate of Core's
    # SCHEMA_MFDB_ENTITY_v5 (verified 2026-07-22, see
    # BEJSON/Reports/FIX_SCHEMA_MFDB_ENTITY_DUPLICATE.md). Import the Core
    # definition under the local name instead of maintaining a second copy
    # that can silently drift from it.
    from lib_bejson_Core_bejson_schema import SCHEMA_MFDB_ENTITY_v5 as SCHEMA_MFDB_ENTITY
except ImportError:
    print("CRITICAL: lib_bejson_Core_bejson_schema (SCHEMA_MFDB_ENTITY_v5) not found.")
    raise

# ---------------------------------------------------------------------------
# Constants & Official Schemas
# ---------------------------------------------------------------------------

DEFAULT_EXTENSIONS = [".py", ".js", ".ts", ".html", ".css", ".md", ".json", ".sh", ".txt", ".bejson", ".tsx", ".jsx"]
DEFAULT_EXCLUDES = [".git", "__pycache__", "node_modules", "lib", "output", ".mfdb_lock", "dist", "build"]

# Text Chunk Separators (Standardized)
SEP_START = "--- FILE: "
SEP_END = " ---"

# Official CLI_CHUNKER Schema (BEJSON 104db)
SCHEMA_CLI_CHUNKER = [
    {"name": "Record_Type_Parent", "type": "string"},
    {"name": "project_name", "type": "string", "Record_Type_Parent": "ProjectMeta"},
    {"name": "version", "type": "string", "Record_Type_Parent": "ProjectMeta"},
    {"name": "root_path", "type": "string", "Record_Type_Parent": "ProjectMeta"},
    {"name": "file_path", "type": "string", "Record_Type_Parent": "FileContent"},
    {"name": "file_name", "type": "string", "Record_Type_Parent": "FileContent"},
    {"name": "content", "type": "string", "Record_Type_Parent": "FileContent"},
    {"name": "is_binary", "type": "boolean", "Record_Type_Parent": "FileContent"}
]

# Official MFDB_V5 Entity Schema (BEJSON 104)
# Imported from lib_bejson_Core_bejson_schema.SCHEMA_MFDB_ENTITY_v5 above —
# do not redefine locally; that was the duplicate this fix removed.

# ---------------------------------------------------------------------------
# Data Sanitization (Best Practices - No Regex)
# ---------------------------------------------------------------------------

def bejson_utility_sanitize_name(name: str) -> str:
    """Sanitizes names for filesystem safety without using regex."""
    invalid = '<>:"/\\|?*'
    sanitized = name
    for char in invalid:
        sanitized = sanitized.replace(char, '_')
    return sanitized

def bejson_utility_slugify(text: str) -> str:
    """Creates a simple lowercase alphanumeric slug without regex."""
    slug = ""
    for char in text.lower():
        if char.isalnum():
            slug += char
        elif char in " -_":
            slug += "_"
    return slug

# ---------------------------------------------------------------------------
# Core Detection & Encoding
# ---------------------------------------------------------------------------

def bejson_utility_is_binary(file_path: Union[str, Path]) -> bool:
    """Detection logic matching official chunker tools."""
    try:
        with open(file_path, 'tr', encoding='utf-8') as f:
            f.read(1024)
            return False
    except (UnicodeDecodeError, PermissionError):
        return True

def bejson_utility_encode_file(file_path: Union[str, Path], use_base64: bool = False) -> tuple:
    """
    Reads file content and returns (content, is_binary, is_base64).
    Matches MFDB v5 lossless binary logic.
    """
    is_bin = bejson_utility_is_binary(file_path)
    if not is_bin:
        try:
            return Path(file_path).read_text(encoding="utf-8"), False, False
        except Exception:
            return "", True, False
    
    if use_base64:
        try:
            raw = Path(file_path).read_bytes()
            return base64.b64encode(raw).decode('utf-8'), True, True
        except Exception:
            return "", True, True
    
    return "", True, False

# ---------------------------------------------------------------------------
# Cross-Format Generators
# ---------------------------------------------------------------------------

def bejson_utility_create_cli_chunk(target_dir: str, project_name: str, version: str) -> dict:
    """Generates a BEJSON 104db document compatible with Cli_Chunker."""
    target_path = Path(target_dir).resolve()
    values = []
    
    # Dynamic Field Mapping for Creation (Phase 7.3.4)
    fm = {f["name"]: i for i, f in enumerate(SCHEMA_CLI_CHUNKER)}
    f_count = len(SCHEMA_CLI_CHUNKER)

    # Meta record
    meta_row = [None] * f_count
    meta_row[fm["Record_Type_Parent"]] = "ProjectMeta"
    meta_row[fm["project_name"]]       = project_name
    meta_row[fm["version"]]            = version
    meta_row[fm["root_path"]]          = str(target_path)
    values.append(meta_row)
    
    for root, dirs, files in os.walk(target_path):
        dirs[:] = [d for d in dirs if d not in DEFAULT_EXCLUDES]
        for file in files:
            f_path = Path(root) / file
            if f_path.suffix.lower() in DEFAULT_EXTENSIONS:
                try:
                    rel_path = f_path.relative_to(target_path)
                    content, binary, _ = bejson_utility_encode_file(f_path, use_base64=False)
                    
                    file_row = [None] * f_count
                    file_row[fm["Record_Type_Parent"]] = "FileContent"
                    file_row[fm["file_path"]]          = str(rel_path)
                    file_row[fm["file_name"]]          = file
                    file_row[fm["content"]]            = content
                    file_row[fm["is_binary"]]          = binary
                    values.append(file_row)
                except Exception: continue
                
    return BEJSONCore.bejson_core_create_104db(["ProjectMeta", "FileContent"], SCHEMA_CLI_CHUNKER, values)

def bejson_utility_create_mfdb_version(target_dir: str, version: str, use_base64: bool = True) -> list:
    """
    Generates a list of values for an MFDB v5 Entity file (BEJSON 104).
    """
    target_path = Path(target_dir).resolve()
    rows = []
    
    fm = {f["name"]: i for i, f in enumerate(SCHEMA_MFDB_ENTITY)}
    f_count = len(SCHEMA_MFDB_ENTITY)
    
    for root, dirs, files in os.walk(target_path):
        dirs[:] = [d for d in dirs if d not in DEFAULT_EXCLUDES]
        for file in files:
            f_path = Path(root) / file
            if f_path.suffix.lower() in DEFAULT_EXTENSIONS:
                try:
                    rel_path = f_path.relative_to(target_path)
                    content, binary, b64 = bejson_utility_encode_file(f_path, use_base64=use_base64)
                    
                    row = [None] * f_count
                    row[fm["version"]]   = version
                    row[fm["file_path"]] = str(rel_path)
                    row[fm["file_name"]] = file
                    row[fm["content"]]   = content
                    row[fm["is_binary"]] = binary
                    row[fm["is_base64"]] = b64
                    rows.append(row)
                except Exception: continue
                
    return rows

# ---------------------------------------------------------------------------
# Text Chunking Logic (Non-Regex Implementation)
# ---------------------------------------------------------------------------

def bejson_utility_chunk_to_text(target_dir: str) -> str:
    """Concatenates files into a single text block with separators."""
    target_path = Path(target_dir).resolve()
    output = []
    
    for root, dirs, files in os.walk(target_path):
        dirs[:] = [d for d in dirs if d not in DEFAULT_EXCLUDES]
        for file in files:
            f_path = Path(root) / file
            if f_path.suffix.lower() in DEFAULT_EXTENSIONS and not bejson_utility_is_binary(f_path):
                try:
                    rel_path = f_path.relative_to(target_path)
                    content = f_path.read_text(encoding="utf-8")
                    output.append(f"{SEP_START}{rel_path}{SEP_END}")
                    output.append(content)
                    output.append("\n")
                except Exception: continue
                
    return "\n".join(output)

def bejson_utility_unchunk_from_text(text: str, output_dir: str) -> int:
    """Restores files from a text block using strictly string splitting."""
    count = 0
    out_root = Path(output_dir).resolve()

    # Split by the start separator
    parts = text.split(SEP_START)

    for part in parts:
        if not part.strip(): continue

        # Each part starts with: filename --- content
        if SEP_END in part:
            header, content = part.split(SEP_END, 1)
            rel_path = header.strip()

            if rel_path:
                # LIB-CH-M2 fix (2026-08-07):
                # (1) traversal -- same unguarded `out_root / rel_path`
                # class as LIB-C1, now routed through bejson_safe_join.
                # (2) content.lstrip("\n") stripped ALL leading newlines,
                # not just the single one the SEP_END split introduces --
                # a file that legitimately starts with blank lines lost
                # them. Now strips at most the one separator artifact.
                target_file = Path(bejson_safe_join(str(out_root), rel_path))
                target_file.parent.mkdir(parents=True, exist_ok=True)
                if content.startswith("\n"):
                    content = content[1:]
                target_file.write_text(content, encoding="utf-8")
                count += 1

    return count

# ---------------------------------------------------------------------------
# Lifecycle Utilities (Standard JSON Module)
# ---------------------------------------------------------------------------

def bejson_utility_parse_json(text: str) -> Any:
    """Robust JSON parsing using strictly the json module."""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Best practice: try to find the actual JSON object in a dirty string
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            return json.loads(text[start:end+1])
        raise

def bejson_utility_save_chunk(path: str, doc: dict) -> bool:
    """Standardized atomic write for all chunking operations."""
    return BEJSONCore.bejson_core_atomic_write(path, doc)

def bejson_utility_get_timestamp() -> str:
    """ISO 8601 UTC timestamp for manifest consistency."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())