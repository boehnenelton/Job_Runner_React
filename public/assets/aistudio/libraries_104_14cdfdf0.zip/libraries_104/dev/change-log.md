# libraries_104 Change Log

## 2026-11-01 - v5.5.2 PKG16: Core Family AI-Native Database Engine Documentation
- **README.md Expansion (+722 lines, total 1070 lines):**
  - Added comprehensive Section 13 detailing the Core Family as an AI-Native Database Engine.
  - Formulated token economics equations, context savings benchmarks (69%–74%), and cost reduction tables across Claude 3.5, GPT-4o, Gemini 1.5/2.0, and DeepSeek-V3/R1.
  - Documented autoregressive attention mechanisms, elimination of key hallucination via positional vectors, and prefix prompt caching optimization.
  - Outlined substrate invariants (immutable headers, two-phase POSIX atomic commits), Core primitive API specifications (PY, JS, TS, SH), O(1) field map caching, and boundary sanitization rules.
  - Cataloged error code registry (01–29 Core syntax, 30–60 MFDB federation, 130–159 recursive nesting).
  - Detailed specialized submodules (`bejson_list_validator`, `bejson_env`, `bejson_chunking`, `104db`, `path_guard`, `state_management`).
  - Added production implementation recipes: Python pipeline, Bash CLI pipeline, MFDB master-slave inner join, and AI agent streaming diff-patching protocol.
  - Added 10-vector comparative taxonomy contrasting BEJSON 104 Core against SQLite, DuckDB, MongoDB, and standard JSON.
---

## 2026-10-31 - v5.5.1 PKG15: junk strip (no library code changed)
- **Removed, because no code, test or registry outside them depends on them:** `Lib_PY/Core/cli/CLI_Doc_Chunker/` (standalone Flask app with its own nested `.bejson_project.json`), `Lib_PY/Core/cli/showcase/` and `gemini_showcase_intro.py`, `Lib_SH/Core/cli/showcase/`, `Lib_PY/bejson_tools.zip`, `Lib_PY/AI/cli/blogger_manager.py`, `Lib_PY/System/cli/book_builder.py`, `build_ebook.py`, `Lib_PY/AI/config/openai_{keys,model_registry,standard_profile}` (nothing reads them), `Lib_SH/Animation/example_schema.bejson`, `Lib_SH/Terminal_Menus/examples/`, and all `__pycache__/` folders (71 .pyc files).
- **Kept for review:** the removed files are in the sibling folder `libraries_104_removed/` with their original relative paths.
- **Left alone on purpose:** `Lib_PY/Core/cli/bejson_server.py` (listed in README), `Lib_PY/MD/demo.py`, `Lib_PY/lib_ai_model_registry.py` + `ai_model_registry.bejson`, `Lib_SH/AGENTS.MD`, `dev/` reports, all tests.
- **Registry/docs:** 8 `dependencies.bejson` rows for the removed files dropped (211), `library_changes` +1 row, manifest counts updated; README row for the non-existent `bejson_cli.py` and the `Doc_Chunker` line in `FORMAT_VS_ARCHITECTURE.md` removed.
---

## 2026-10-30 - v5.4.0 PKG12: Diagrams v3 merge & 3-language parity (PY/TS/JS) wired to Core
- **Merged `Diagrams` v3 (`mfdb-diagrammer-v3---react (1)`) into `Lib_PY/Diagrams`, `Lib_TS/Diagrams`, and `Lib_JS/Diagrams`:**
  - `lib_bejson_Diagrams_bejson_errors.{py,ts,js}` (`1.2.0`): Preserved codes `420`–`435` and added v3 codes `436`–`449` (`DIAGRAMS_ERROR_CODES`, `DiagramsError`, `AIBuildError`).
  - `lib_bejson_Diagrams_diagrams_core.{py,ts,js}` (`1.2.0`): Added `KNOWN_FLOW_VALUES`, `createMfdb132PackageFromModel`, and `extractDiagramModelFromMfdb132` adjusted to use Core's O(1) `bejson_core_get_field_map`, `bejson_core_chunking_hash_file_bytes`, `Parent_Hierarchy` normalization (`../104a.mfdb.bejson`), and `Diagram_Schema: "BEJSON-Diagram-1"`.
  - `lib_bejson_Diagrams_diagrams_validator.{py,ts,js}` (`1.2.0`): Added duplicate `shape_id` check, circular `shape_parent_fk` check (`E_DIAGRAMS_CIRCULAR_HIERARCHY = 427`), `Shape_<id>` `board_membership_fk` check, `diagrams_validator_validate_diagram_database`, `validateDiagramModel`, and `remediateDiagramModel`.
  - `lib_bejson_Diagrams_diagrams_ai.{py,ts,js}` (`1.3.0`): Added `existing_shape_ids` and `auto_remediate` support in `diagrams_ai_validate_plan_semantics`.
  - `lib_bejson_Diagrams_cli_tools.{py,ts,js}` (`1.2.0`): Added `occupied` coordinate collision avoidance and territory grid snapping in `apply_layout_scaffolding`.
- **Synced `BEJSON/` self-tracking MFDB:** Registered `Diagrams` (`JS`, `TS`) in `families.bejson` (35 families) and codes `420`–`449` (`PY`, `JS`, `TS`) in `errors.bejson` (490 rows); verified with `validate_mfdb_database`.
---

## 2026-10-29 - v5.3.0 PKG11: MFDB spec + 104 version parity patch v3 & data validation
- **Applied `bejson_mfdb_spec_js_ts_sh_patch_v3`:** `Lib_PY/Core/lib_bejson_Core_mfdb_validator.py` (2.2.4 -> 2.3.0), `Lib_TS/Core/lib_bejson_Core_mfdb_validators.ts` (2.1.5 -> 2.2.0), `Lib_SH/Core/lib_bejson_Core_bejson_validator.sh` (2.1.5 -> 2.2.0), `Lib_SH/Core/lib_bejson_Core_mfdb_validator.sh` (2.1.5 -> 2.2.0), plus spec-level test suites (PY 12, TS 12, SH 15).
- **Validated all 49 BEJSON files and `BEJSON/104a.mfdb.bejson`:** Removed non-MFDB standalone 104a entry `GeminiModelRegistry` from `BEJSON/104a.mfdb.bejson`; corrected `Format_Version` (`104` -> `104a`) in `Lib_PY/AI/config/litertlm_standard_profile.bejson` so custom key `Config_Version` validates cleanly.
- **Cleaned untracked clutter:** Purged all `*-from-root*` files, `dev/merge_staging/`, and nested duplicate `libraries_104/` directory.
---

## 2026-10-27 - v5.2.2 PKG10: package cleanup
- **Moved, not deleted: `dev/merge_staging/`** (+ `MANIFEST.bejson`, `README.md`): the 31 `*-from-root*` files (Lib_PY/AI 13: 4 modules + 9 configs; Lib_PY/Core 5; Core/cli 2; Core/cli/showcase 7; CLI_Doc_Chunker 4; each DIFFERS from the live file next to it, so none was a safe delete) and `Chunked_CLI_Doc_Chunker_v1.104db.bejson.txt` (holds Doc_Chunker.py, Doc_Chunker_Flask.py, static/app.js versions that match no live file). Original paths, sha256 and counterparts are in the manifest; restore by moving a file back to its `original_path`.
- **Deleted:** all `__pycache__/` folders; `Lib_PY/Core/BUGFIX_list_validator.md` (stale pre-relocation copy; `dev/BUGFIX_list_validator.md` is the relocation note plus identical text); `CLI_Doc_Chunker/update-libs.txt` (a stray chat request, content: "I compared that the local libs are not found, So I'm sending you the latest libraries with the tool separated into two folders I need you to put the correct dependency imports in the cracked folder with the doc chunker and send it back"); `CLI_Doc_Chunker/data/active_doc.txt` (runtime state file containing "Testing"; the app recreates it).
- **Not junk, left in place (untracked work in progress):** Lib_PY/Projects, Lib_JS/BEOS, new Lib_PY/AI modules and configs, BEHTML layer scaffolds, Core list validator, `stage/` banners.
- **Left alone, for your decision:** `Lib_PY/bejson_tools.zip` (6 tool files that exist nowhere else in the tree); `Lib_PY/ai_model_registry.bejson` + `Lib_PY/lib_ai_model_registry.py` sit at the Lib_PY root outside any family folder; nested tracker `Lib_PY/Core/cli/CLI_Doc_Chunker/.bejson_project.json` (the standard forbids trackers below a Tier 4 root); `Lib_SH/AGENTS.MD`.
---

## 2026-10-27 — v5.2.1 PKG9: reserve error block 250-269 (Standards logging)

- **Registry only.** `BEJSON/data/errors.bejson` +12 rows (250-261, family `Standards`, PY): the logging family lives in libraries_105 (`Lib_PY/Standards`) and its codes are reserved here so no 104 family claims the block. Manifest Errors count 416.
- **No library code changed.** Tracker `Project_Version` had lagged the change-log (5.0.0 vs 5.2.0) and is now 5.2.1.
- **Known, unchanged:** `validate_mfdb_database` on `104a.mfdb.bejson` reports `Lib_PY/AI/gemini_model_registry.104a.bejson` as not found. The file exists; the validator resolves entity paths relative to the manifest's own folder (`BEJSON/`), so the manifest entry would need to read `../Lib_PY/AI/...`. Pre-existing, not changed here.

---

## 2026-10-16 — v5.2.0 PKG8: nesting_query merged into core_nesting; nesting uses Core validator/field map; Bash + cache fixes

- **Merged** `lib_bejson_Core_bejson_nesting_query.{py,js,ts,sh}` into `lib_bejson_Core_bejson_core_nesting.*` (0.6.0). Query files removed, **no alias** (breaking; nothing in the bundle used them but the tests). Query API (`bejson_nesting_query`, `_get_path`, `_query_summary`, `QueryMatch`) is now in core_nesting; JS and TS export `E_NESTING_QUERY_*` from it too.
- **Core reuse (PY/JS/TS):** nested-cell validation calls the Core validator (PY `validate_bejson`, JS new `bejson_validator_validate_object`, TS `validate104`); field maps use the Core field-map cache (key `_bejson_field_map` replaces `_nesting_field_map` / `_nestingFieldMap`). Local `_build_field_map` / `_quick_validate_104` copies removed. **Bash** keeps its local validator: the Core Bash validator is file-based and cannot validate an in-memory cell.
- **Fixed — stale cache:** with no `RELATIONAL_ID` the fingerprint hashed only `Fields`, so two different documents with the same schema shared NestMap cache entries (the second scan returned the first one's results) and same-schema nesting could look circular. Now hashes Fields + Values (all four languages).
- **Fixed — Bash:** (1) the mandatory-key jq test ran against the key string, so every nested doc was rejected and scan found 0 cells; (2) `(( valid++ )) || (( invalid++ ))` also counted every first valid cell as invalid; (3) query skipped null/false cells and returned strings — now raw JSON, 2 matches in the smoke fixture like PY/JS/TS. Both former expected-failure checks are real passing checks.
- **Core JS:** validator `Format_Creator` must equal `Elton Boehnen` (was any string; PY/TS/SH already enforced it); new `bejson_validator_validate_object` (isolated, preserves the caller's validator state).
- **Error registries:** JS +4 codes (MFDB 57-60), Bash +7 (17-19, 57-60); PY, JS, Bash, TS now agree (66 codes).
- **Tests:** two new behavior tests per language (Core validator rules reach nested cells; no cache sharing). PY 7, JS 7, TS 7, Bash 6 nesting checks pass; all other suites pass; `tsc` 0 errors.
- Registries: dependencies (6 rows replaced), library_changes (+7), manifest counts. Not touched: `MFDB_Libraries.mfdb132.bejson` snapshot, `_nestingFieldMap` allowance in the PY/TS/JS validators (harmless, kept for compatibility), `Lib_TS/Lib_TS.zip` and `Lib_TS2.zip` (old snapshots from your copy, carried over as-is).

## 2026-10-16 — v5.1.0 PKG7: nesting errors folded into Core error files; Lib_PY/AI synced to CLI_AI V2.13.2 PKG33

### 1. Core nesting error codes now live in the standard Core error file
- Codes `E_NESTING_*` 130-139 (names and values unchanged) moved into `Lib_PY/Core/lib_bejson_Core_bejson_errors.py` (2.5.0), `Lib_JS/Core/lib_bejson_Core_bejson_errors.js` (2.4.0), `Lib_SH/Core/lib_bejson_Core_bejson_errors.sh` (1.6.0) and, for TS (which has no errors file; its Core codes live in `types.ts`), `Lib_TS/Core/lib_bejson_Core_bejson_types.ts` (2.5.0, `CORE_NESTING_ERRORS`).
- **Removed:** `lib_bejson_Core_bejson_nesting_errors.{py,js,ts,sh}`. **Breaking, no shims:** anything importing/sourcing those files must use the Core error file (TS: `CORE_NESTING_ERRORS` from `lib_bejson_Core_bejson_types`). Nothing inside this bundle still references them.
- Re-pointed: `core_nesting` 0.5.0 -> 0.5.1 and `nesting_query` 0.2.0 -> 0.2.1 in all four languages (in-code VERSION constants updated to match); smoke tests 1.0.0 -> 1.0.1. JS keeps its exported `NESTING_ERRORS` as the `E_NESTING_*` subset so that API is unchanged.
- Registries: 8 `dependencies` edges re-pointed, 4 Core `families` notes reworded, 12 `library_changes` rows added, manifest record counts updated. Error-registry rows for 130-139 unchanged (still family Core).
- Verified: nesting smoke tests PY 5/5, JS 5/5, TS 5/5, SH 3 ok + 2 expected-fail (identical to the pre-change baseline); full PY/JS/SH/TS test suites green; `tsc` 0 errors.

### 2. Lib_PY/AI updated from CLI_AI V2.13.2 PKG33 (verbatim copies)
- Updated: `ai_constants` 1.0.0 -> 1.2.1, `ai_dispatch` 1.7.0 (same version number, newer content: adds `geminirest`), `bejson_grok` 2.1.0, `bejson_groq` 3.1.0, `bejson_huggingface` 2.1.0, `bejson_ollama` 1.1.0, `bejson_openrouter` 3.2.0, `bejson_tokenrouter` 1.1.0, `gemini_standard_profiles` 3.1.0.
- New: `ai_context_files` 1.0.0, `ai_structured_instruction` 1.0.0, `ai_structured_reception` 1.0.0, `bejson_geminirest` 1.1.0; config defaults `ai_constants.bejson` (15 rows), `ai_keywords.bejson`, `ai_knowledge_pool.bejson` (both empty).
- All 13 files are byte-identical to CLI_AI; all 32 `lib_bejson_AI_*` modules import cleanly.
- **Not changed (left for your decision):** `bejson_provocative.py` (CLI_AI removed this provider on 2026-08-21), `ai_tool_system.py`, `bejson_gemini_tts.py` and root `gemini_model_registry.104a.bejson` exist only here, so they stay untouched. `ai_dispatch`, `gemini_standard_profiles` and `ai_context_files` headers have no `Release_Version: 300` line (CLI_AI's content copied as-is). The library's previous `ai_dispatch` carried the same 1.7.0 / RELATIONAL_ID but lacked the `geminirest` adapter.
- Not touched: `BEJSON/MFDB_Libraries.mfdb132.bejson` snapshot (already stale before this change), `Core/__pycache__`, tracker's second `Values` row.

## 2026-10-16 — v5.0.0 PKG6: field-map integrity follow-up (five open items)
- **`_`-key rule unified** (CLI 1.4.3, PY validator 2.2.7, JS 2.0.6, TS validators 2.0.6, Bash validator 2.1.5): persisted input rejects any top-level `_` key; in-memory objects accept only `_bejson_field_map` (verified against Fields), `_nesting_field_map` (PY), `_nestingFieldMap` (JS/TS). **Behaviour change:** 104a files carrying other `_` custom headers are now rejected by the library validators (they were accepted before; the CLI already rejected them).
- **JS validator exports** its API (UMD-like). mfdb_validator, parse and Lists were receiving `undefined` functions before. The appended-export workaround in the JS test is gone; the Lists test that asserted "exports nothing" now asserts the exports exist.
- **MFDB tests added** (PY, JS, TS, Bash). Bugs they exposed and fixed: JS `mfdb_core` threw ReferenceError on load under Node (`window.JSZip` unguarded, now 2.3.5); JS `_atomicWrite` was called 13 times and never defined, so federation and debug were dead (now defined, strips `_` keys); JS `create_connected_slave_entity` called `init_entity_file` with the wrong arguments (now takes an options argument); TS validator rejected every valid `../104a.mfdb.bejson` Parent_Hierarchy (depth now starts at the entity's directory, validators 2.1.5); Bash schema snapshot piped plain-text names through `jq '.[]'` and wrote nothing, and add/remove record were never debug-logged (now 2.2.5).
- **tsc: 0 errors** with `@types/node` (`Lib_TS/tsconfig.json` added). The 35 errors were `mfdb_core.ts` using `fs`/`path` it never imported (a real bug: the debug helpers threw and `catch {}` hid it) plus one bad cast. The remaining 15 without `@types/node` were only missing Node typings.
- README section 2.4 documents the field-map rules and test commands. Tracker bumped to 5.0.0 / PKG6, Project_GUID unchanged.
- Open: tracker's second `Values` row (user's PKG5 note, 3 cells) makes the 104a tracker fail validation (pre-existing; not touched). Not fixed, out of scope: `lib_bejson_Core_bejson_bejson.js` contains ESM `export` lines (parse error under require()); `lib_bejson_Core_bejson_parse.js` line 157 uses `__filename` unguarded; TS validator does not check manifest `file_path` escaping the DB root (PY does).

## 2026-10-14 — Merge + registry/doc drift remediation
- **Merged** `libraries_104-nesting-in-core.zip` (Lists split + nesting-in-Core) onto the newer `libraries_104.zip` (env-fill / AI work of 2026-10-13). Three-way, file by file: every upstream change (Core `env` 2.3.0, AI `registry_base` 2.1.0, `genai` 2.2.0, `dev/Testing/env_fill`, `dev/change-log.md`, `checklist-20261013-223000`) kept byte-identical; nothing in Core logic altered by the merge. (The three "both changed" docs were git-untracked baseline files; content = baseline + my edits only.)
- **Registry reconciled with code** (`BEJSON/data`): families +4 (Animation SH, Bookmaker PY, Core_Extension PY, Projects PY were in the tree but unregistered); errors +35 rows (AI 220-224 transcribe / 230-235 TTS, Bookmaker 450-459, Core_Extension 160-166, Diagrams 420-421 / 431-435); Terminal_Menus 7 rows renumbered 340-346 -> 360-366 to match `lib_bejson_TerminalMenus_bejson_errors.sh`; AI `registry_base` -> Core `core`/`env` dependency rows added; library_changes +4 (env 2.3.0, registry_base 2.1.0, genai 2.2.0, this reconcile); manifest counts/Modified_At. Totals: families 33, errors 404, dependencies 215, library_changes 95.
- **Version sync:** in-code `VERSION` constants of the 7 nesting modules (PY/JS/TS core_nesting + nesting_query, SH nesting_query) now match their header versions (0.5.0 / 0.2.0); they had still said 0.4.1 / 0.1.1 after the move.
- **Docs:** README `Core_bejson_env.py` section 2.0.1 -> 2.3.0 and documents `source_env_fill()`.
- **Intended state (confirmed):** list validator = its own **Lists** family (removed from Core); nested = part of **Core** (`Lib_*/Core/lib_bejson_Core_bejson_{core_nesting,nesting_query,nesting_errors}.*`).
- **Not changed / still open:** see `BEJSON/dev/change-log.md` (2026-10-14 entries) — MFDB-132 snapshot, `.bejson_project.json` version mismatch, SH nesting `jq` defect, Core JS validator exports, 4 stale comments in frozen Core error files, README sections still describing pre-audit numbering, dependency-registry coverage gaps.

## 2026-10-14 — Core_Nesting family dissolved into Core (see BEJSON/dev/change-log.md for full detail)
12 files moved into `Lib_*/Core/` as `lib_bejson_Core_bejson_{core_nesting,nesting_query,nesting_errors}.*` (0.5.0 / 0.2.0 / 1.1.0); codes 130-139 unchanged; tests `Lib_*/Core/tests/test_nesting_smoke.*`.

## 2026-10-13 — Lists family split out of Core (see BEJSON/dev/change-log.md for full detail)
New `Lib_PY|JS|TS|SH/Lists/` (`lib_bejson_Lists_list_validator.*` 2.0.0, own errors 480-499, array-field check ported to all four); old `lib_bejson_Core_bejson_list_validator.*` removed from Core. Breaking rename, no shims. Tests: PY 12, JS 11, TS 9, SH 25.

## 2026-10-13 — Environment fill (3 files, additive)
- `Lib_PY/Core/lib_bejson_Core_bejson_env.py` 2.2.4 -> 2.3.0: new `source_env_fill()`; existing functions byte-for-byte unchanged.
- `Lib_PY/AI/lib_bejson_AI_ai_registry_base.py` 2.0.1 -> 2.1.0: fixed numbered-slot env scan being nested under `if self.env_var:`; registries now call `source_env_fill()` so secureenv_file.json keys are found; env keys de-duplicated.
- `Lib_PY/AI/lib_bejson_AI_bejson_genai.py` 2.1.5 -> 2.2.0: `GenAIKeyManager` reads `GEMINI_KEY_1..21` + secure-store fill.
- Added `dev/Testing/env_fill/test_env_fill.py` (13 tests) and `dev/checklist-20261013-223000.md`.
- Verified: all 43 Lib_PY AI/Core modules import before and after. Downstream consumers (every subclass of RoundRobinKeyRegistry: groq, openrouter, grok, huggingface, tokenrouter, ollama, ollamalocal, gemini; interactions, provocative, brain_helper) use unchanged signatures.
- Not changed: JS/TS/SH families (no equivalent code there), your uncommitted edits to Core core.py / .gitignore etc. were left exactly as uploaded.
- Tracker note: `.bejson_project.json` was NOT bumped — its header (2.0.0 / PKG 5) and its row (4.0.0 / PKG 4) already disagree, so I left the tracker for your registration CLI to reconcile.
