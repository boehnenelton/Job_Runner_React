# Security Notes

## 2026-10-16 — Field map cache and reserved `_` prefix
- Threat: a persisted or crafted `_bejson_field_map` could redirect name-based lookups to the wrong column (read or write the wrong cell), be shared between documents, or collide on comma-containing field names.
- Mitigation: provenance-guarded in-memory cache (never trusted from disk), per-document map copy, JSON-encoded cache key, persisted `_` keys rejected by every validator, `atomic_write` strips `_` keys, duplicate field names rejected. O(1) lookup preserved (timing tests in PY and JS).
- Residual: TS validator does not check manifest `file_path` for escaping the DB root (PY does via path_guard).
- JS `_atomicWrite` (new in mfdb_core 2.3.5) writes a same-directory temp file then renames; it strips `_`-prefixed keys.

**Author**: Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton

## 2026-10-06 — Persisted `_bejson_field_map` poisoning (cross-column read)
- Severity: High (data integrity / confidentiality of column-addressed reads). Reachable by any crafted .bejson file or JSON string loaded through Core.
- Root cause: in-memory cache key trusted from untrusted input; no relation check between cache and `Fields`.
- Mitigation: cache stripped on load/parse, forbidden in persisted input by validators, O(1) freshness guard on reuse, per-document copy. Regression checks recorded in `PATCH_REPORT_field_map_integrity.md`.
- Hardening (same day): freshness guard alone was forgeable; engine-built provenance (Py `_FieldMap`, JS/TS WeakMap) is now required.
- Residual: a trusted caller editing its own engine-built map or `Fields` inner entries in place without clearing the cache is not detected (affects only that document).
- Stale embedded copies of the old TS code in the two `chunked5/*.104a.bejson.txt` archives were removed from the package (2026-10-06); regenerate with the chunker if wanted.
