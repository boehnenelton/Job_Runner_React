# libraries_104 Change Log

## 2026-10-16 — v5.2.0 PKG8: nesting_query merged into core_nesting; nesting uses Core validator/field map; Bash + cache fixes

- **Merged** `lib_bejson_Core_bejson_nesting_query.{py,js,ts,sh}` into `lib_bejson_Core_bejson_core_nesting.*` (0.6.0). Query files removed, **no alias** (breaking; nothing in the bundle used them but the tests). Query API (`bejson_nesting_query`, `_get_path`, `_query_summary`, `QueryMatch`) is now in core_nesting; JS and TS export `E_NESTING_QUERY_*` from it too.
- **Core reuse (PY/JS/TS):** nested-cell validation calls the Core validator (PY `validate_bejson`, JS new `bejson_validator_validate_object`, TS `validate104`); field maps use the Core field-map cache (key `_bejson_field_map` replaces `_nesting_field_map` / `_nestingFieldMap`). Local `_build_field_map` / `_quick_validate_104` copies removed. **Bash** keeps its local validator: the Core Bash validator is file-based and cannot validate an in-memory cell.
- **Fixed — stale cache:** with no `RELATIONAL_ID` the fingerprint hashed only `Fields`, so two different documents with the same schema shared NestMap cache entries (the second scan returned the first one's results) and same-schema nesting could look circular. Now hashes Fields + Values (all four languages).
- **Fixed — Bash:** (1) the mandatory-key jq test ran against the key string, so every nested doc was rejected and scan found 0 cells; (2) `(( valid++ )) || (( invalid++ ))` also counted every first valid cell as invalid; (3) query skipped null/false cells and returned strings — now raw JSON, 2 matches in the smoke fixture like PY/JS/TS. Both former expected-failure checks are real passing checks.
- **Core JS:** validator `Format_Creator` must equal `Elton Boehnen` (was any string; PY/TS/SH already enforced it); new `bejson_validator_validate_object` (isolated, preserves the caller's validator state).
- **Error registries:** JS +4 codes (MFDB 57-60), Bash +7 (17-19, 57-60); PY, JS, Bash, TS now agree (66 codes).
- **Tests:** two new behavior tests per language (Core validator rules reach nested cells; no cache sharing). PY 7, JS 7, TS 7, Bash 6 nesting checks pass; all other suites pass; `tsc` 0 errors.
- Registries: dependencies (6 rows replaced), library_changes (+7), manifest counts. Not touched: `MFDB_Libraries.mfdb132.bejson` snapshot, `_nestingFieldMap` allowance in the PY/TS/JS validators (harmless, kept for compatibility), `Lib_TS/Lib_TS.zip` and `Lib_TS2.zip` (old snapshots from your copy, carried over as-is).

## 2026-10-16 — v5.1.0 PKG7: nesting errors folded into Core error files; Lib_PY/AI synced to CLI_AI V2.13.2 PKG33

### 1. Core nesting error codes now live in the standard Core error file
- Codes `E_NESTING_*` 130-139 (names and values unchanged) moved into `Lib_PY/Core/lib_bejson_Core_bejson_errors.py` (2.5.0), `Lib_JS/Core/lib_bejson_Core_bejson_errors.js` (2.4.0), `Lib_SH/Core/lib_bejson_Core_bejson_errors.sh` (1.6.0) and, for TS (which has no errors file; its Core codes live in `types.ts`), `Lib_TS/Core/lib_bejson_Core_bejson_types.ts` (2.5.0, `CORE_NESTING_ERRORS`).
- **Removed:** `lib_bejson_Core_bejson_nesting_errors.{py,js,ts,sh}`. **Breaking, no shims:** anything importing/sourcing those files must use the Core error file (TS: `CORE_NESTING_ERRORS` from `lib_bejson_Core_bejson_types`). Nothing inside this bundle still references them.
- Re-pointed: `core_nesting` 0.5.0 -> 0.5.1 and `nesting_query` 0.2.0 -> 0.2.1 in all four languages (in-code VERSION constants updated to match); smoke tests 1.0.0 -> 1.0.1. JS keeps its exported `NESTING_ERRORS` as the `E_NESTING_*` subset so that API is unchanged.
- Registries: 8 `dependencies` edges re-pointed, 4 Core `families` notes reworded, 12 `library_changes` rows added, manifest record counts updated. Error-registry rows for 130-139 unchanged (still family Core).
- Verified: nesting smoke tests PY 5/5, JS 5/5, TS 5/5, SH 3 ok + 2 expected-fail (identical to the pre-change baseline); full PY/JS/SH/TS test suites green; `tsc` 0 errors.

### 2. Lib_PY/AI updated from CLI_AI V2.13.2 PKG33 (verbatim copies)
- Updated: `ai_constants` 1.0.0 -> 1.2.1, `ai_dispatch` 1.7.0 (same version number, newer content: adds `geminirest`), `bejson_grok` 2.1.0, `bejson_groq` 3.1.0, `bejson_huggingface` 2.1.0, `bejson_ollama` 1.1.0, `bejson_openrouter` 3.2.0, `bejson_tokenrouter` 1.1.0, `gemini_standard_profiles` 3.1.0.
- New: `ai_context_files` 1.0.0, `ai_structured_instruction` 1.0.0, `ai_structured_reception` 1.0.0, `bejson_geminirest` 1.1.0; config defaults `ai_constants.bejson` (15 rows), `ai_keywords.bejson`, `ai_knowledge_pool.bejson` (both empty).
- All 13 files are byte-identical to CLI_AI; all 32 `lib_bejson_AI_*` modules import cleanly.
- **Not changed (left for your decision):** `bejson_provocative.py` (CLI_AI removed this provider on 2026-08-21), `ai_tool_system.py`, `bejson_gemini_tts.py` and root `gemini_model_registry.104a.bejson` exist only here, so they stay untouched. `ai_dispatch`, `gemini_standard_profiles` and `ai_context_files` headers have no `Release_Version: 300` line (CLI_AI's content copied as-is). The library's previous `ai_dispatch` carried the same 1.7.0 / RELATIONAL_ID but lacked the `geminirest` adapter.
- Not touched: `BEJSON/MFDB_Libraries.mfdb132.bejson` snapshot (already stale before this change), `Core/__pycache__`, tracker's second `Values` row.

## 2026-10-16 — v5.0.0 PKG6: field-map integrity follow-up (five open items)
- **`_`-key rule unified** (CLI 1.4.3, PY validator 2.2.7, JS 2.0.6, TS validators 2.0.6, Bash validator 2.1.5): persisted input rejects any top-level `_` key; in-memory objects accept only `_bejson_field_map` (verified against Fields), `_nesting_field_map` (PY), `_nestingFieldMap` (JS/TS). **Behaviour change:** 104a files carrying other `_` custom headers are now rejected by the library validators (they were accepted before; the CLI already rejected them).
- **JS validator exports** its API (UMD-like). mfdb_validator, parse and Lists were receiving `undefined` functions before. The appended-export workaround in the JS test is gone; the Lists test that asserted "exports nothing" now asserts the exports exist.
- **MFDB tests added** (PY, JS, TS, Bash). Bugs they exposed and fixed: JS `mfdb_core` threw ReferenceError on load under Node (`window.JSZip` unguarded, now 2.3.5); JS `_atomicWrite` was called 13 times and never defined, so federation and debug were dead (now defined, strips `_` keys); JS `create_connected_slave_entity` called `init_entity_file` with the wrong arguments (now takes an options argument); TS validator rejected every valid `../104a.mfdb.bejson` Parent_Hierarchy (depth now starts at the entity's directory, validators 2.1.5); Bash schema snapshot piped plain-text names through `jq '.[]'` and wrote nothing, and add/remove record were never debug-logged (now 2.2.5).
- **tsc: 0 errors** with `@types/node` (`Lib_TS/tsconfig.json` added). The 35 errors were `mfdb_core.ts` using `fs`/`path` it never imported (a real bug: the debug helpers threw and `catch {}` hid it) plus one bad cast. The remaining 15 without `@types/node` were only missing Node typings.
- README section 2.4 documents the field-map rules and test commands. Tracker bumped to 5.0.0 / PKG6, Project_GUID unchanged.
- Open: tracker's second `Values` row (user's PKG5 note, 3 cells) makes the 104a tracker fail validation (pre-existing; not touched). Not fixed, out of scope: `lib_bejson_Core_bejson_bejson.js` contains ESM `export` lines (parse error under require()); `lib_bejson_Core_bejson_parse.js` line 157 uses `__filename` unguarded; TS validator does not check manifest `file_path` escaping the DB root (PY does).

## 2026-10-14 — Merge + registry/doc drift remediation
- **Merged** `libraries_104-nesting-in-core.zip` (Lists split + nesting-in-Core) onto the newer `libraries_104.zip` (env-fill / AI work of 2026-10-13). Three-way, file by file: every upstream change (Core `env` 2.3.0, AI `registry_base` 2.1.0, `genai` 2.2.0, `dev/Testing/env_fill`, `dev/change-log.md`, `checklist-20261013-223000`) kept byte-identical; nothing in Core logic altered by the merge. (The three "both changed" docs were git-untracked baseline files; content = baseline + my edits only.)
- **Registry reconciled with code** (`BEJSON/data`): families +4 (Animation SH, Bookmaker PY, Core_Extension PY, Projects PY were in the tree but unregistered); errors +35 rows (AI 220-224 transcribe / 230-235 TTS, Bookmaker 450-459, Core_Extension 160-166, Diagrams 420-421 / 431-435); Terminal_Menus 7 rows renumbered 340-346 -> 360-366 to match `lib_bejson_TerminalMenus_bejson_errors.sh`; AI `registry_base` -> Core `core`/`env` dependency rows added; library_changes +4 (env 2.3.0, registry_base 2.1.0, genai 2.2.0, this reconcile); manifest counts/Modified_At. Totals: families 33, errors 404, dependencies 215, library_changes 95.
- **Version sync:** in-code `VERSION` constants of the 7 nesting modules (PY/JS/TS core_nesting + nesting_query, SH nesting_query) now match their header versions (0.5.0 / 0.2.0); they had still said 0.4.1 / 0.1.1 after the move.
- **Docs:** README `Core_bejson_env.py` section 2.0.1 -> 2.3.0 and documents `source_env_fill()`.
- **Intended state (confirmed):** list validator = its own **Lists** family (removed from Core); nested = part of **Core** (`Lib_*/Core/lib_bejson_Core_bejson_{core_nesting,nesting_query,nesting_errors}.*`).
- **Not changed / still open:** see `BEJSON/dev/change-log.md` (2026-10-14 entries) — MFDB-132 snapshot, `.bejson_project.json` version mismatch, SH nesting `jq` defect, Core JS validator exports, 4 stale comments in frozen Core error files, README sections still describing pre-audit numbering, dependency-registry coverage gaps.

## 2026-10-14 — Core_Nesting family dissolved into Core (see BEJSON/dev/change-log.md for full detail)
12 files moved into `Lib_*/Core/` as `lib_bejson_Core_bejson_{core_nesting,nesting_query,nesting_errors}.*` (0.5.0 / 0.2.0 / 1.1.0); codes 130-139 unchanged; tests `Lib_*/Core/tests/test_nesting_smoke.*`.

## 2026-10-13 — Lists family split out of Core (see BEJSON/dev/change-log.md for full detail)
New `Lib_PY|JS|TS|SH/Lists/` (`lib_bejson_Lists_list_validator.*` 2.0.0, own errors 480-499, array-field check ported to all four); old `lib_bejson_Core_bejson_list_validator.*` removed from Core. Breaking rename, no shims. Tests: PY 12, JS 11, TS 9, SH 25.

## 2026-10-13 — Environment fill (3 files, additive)
- `Lib_PY/Core/lib_bejson_Core_bejson_env.py` 2.2.4 -> 2.3.0: new `source_env_fill()`; existing functions byte-for-byte unchanged.
- `Lib_PY/AI/lib_bejson_AI_ai_registry_base.py` 2.0.1 -> 2.1.0: fixed numbered-slot env scan being nested under `if self.env_var:`; registries now call `source_env_fill()` so secureenv_file.json keys are found; env keys de-duplicated.
- `Lib_PY/AI/lib_bejson_AI_bejson_genai.py` 2.1.5 -> 2.2.0: `GenAIKeyManager` reads `GEMINI_KEY_1..21` + secure-store fill.
- Added `dev/Testing/env_fill/test_env_fill.py` (13 tests) and `dev/checklist-20261013-223000.md`.
- Verified: all 43 Lib_PY AI/Core modules import before and after. Downstream consumers (every subclass of RoundRobinKeyRegistry: groq, openrouter, grok, huggingface, tokenrouter, ollama, ollamalocal, gemini; interactions, provocative, brain_helper) use unchanged signatures.
- Not changed: JS/TS/SH families (no equivalent code there), your uncommitted edits to Core core.py / .gitignore etc. were left exactly as uploaded.
- Tracker note: `.bejson_project.json` was NOT bumped — its header (2.0.0 / PKG 5) and its row (4.0.0 / PKG 4) already disagree, so I left the tracker for your registration CLI to reconcile.
