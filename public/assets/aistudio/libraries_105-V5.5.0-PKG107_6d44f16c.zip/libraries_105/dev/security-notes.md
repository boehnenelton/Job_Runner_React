# Security Notes: Adversarial review verdicts (2026-10-09)

| # | Finding | PY | JS | TS | SH | Status |
|---|---|---|---|---|---|---|
| 1 | 105db positional row-offset desync | confirmed | confirmed | confirmed | confirmed | fixed |
| 2 | Non-transactional cascade delete | confirmed | confirmed | n/a (in-memory) | confirmed | fixed |
| 3 | exec() in source_env | confirmed | n/a | n/a | n/a | fixed |
| 4 | ResilientPIDLock reclaim race | confirmed | n/a | n/a | n/a | fixed |
| 5 | Plaintext password in key cache | n/a | confirmed | confirmed | n/a | fixed |

Review inaccuracies: the single-chain Order->OrderItem->StockReservation example does not corrupt; a sibling-restrict variant does. The review's helper snippet is incomplete as written.

Residual risks:
- Lock reclaim (CORRECTED 2026-10-12): the earlier claim that the token check defeats the reclaim race was wrong -- the token only protected release(); the stress suite reproduced overlapping holders. Fixed with a reclaim guard + re-verification. Remaining window: an owner stalled >5s between mkdir() and writing its meta (grace period), or a guard holder dying and two reclaimers racing at the 5s guard-expiry.
- No flock (Android shared storage; guard-file clutter). JS/TS flock declined.
- Env-file ownership is not checked; env literals can still redirect module-level settings.
- `chunked5/Chunked_libraries_105.104a.bejson.txt` is a pre-existing generated artifact and was NOT regenerated; it reflects pre-remediation sources.

---

# Security Notes

## 2026-10-16 — Field map cache and reserved `_` prefix
- Threat: a persisted or crafted `_bejson_field_map` could redirect name-based lookups to the wrong column (read or write the wrong cell), be shared between documents, or collide on comma-containing field names.
- Mitigation: provenance-guarded in-memory cache (never trusted from disk), per-document map copy, JSON-encoded cache key, persisted `_` keys rejected by every validator, `atomic_write` strips `_` keys, duplicate field names rejected. O(1) lookup preserved (timing tests in PY and JS).
- Residual: TS validator does not check manifest `file_path` for escaping the DB root (PY does via path_guard).
- JS `_atomicWrite` (new in mfdb_core 2.3.5) writes a same-directory temp file then renames; it strips `_`-prefixed keys.

**Author**: Elton Boehnen · boehnenelton2024@gmail.com · boehnenelton2024.pages.dev · github.com/boehnenelton

## 2026-10-06 — Persisted `_bejson_field_map` poisoning (cross-column read)
- Severity: High (data integrity / confidentiality of column-addressed reads). Reachable by any crafted .bejson file or JSON string loaded through Core.
- Root cause: in-memory cache key trusted from untrusted input; no relation check between cache and `Fields`.
- Mitigation: cache stripped on load/parse, forbidden in persisted input by validators, O(1) freshness guard on reuse, per-document copy. Regression checks recorded in `PATCH_REPORT_field_map_integrity.md`.
- Hardening (same day): freshness guard alone was forgeable; engine-built provenance (Py `_FieldMap`, JS/TS WeakMap) is now required.
- Residual: a trusted caller editing its own engine-built map or `Fields` inner entries in place without clearing the cache is not detected (affects only that document).
- Stale embedded copies of the old TS code in the two `chunked5/*.104a.bejson.txt` archives were removed from the package (2026-10-06); regenerate with the chunker if wanted.

# Security Notes: Standards logging sink (2026-10-27)

- **Secrets in logs:** `**context` and `extra={"context": ...}` are serialised verbatim into `log_event_context_payload`. Never pass tokens, keys or credentials (secrets live only in `secureenv_file.json`); no redaction is performed. Use `secure=True` for sensitive entries.
- **Secure logging:** secure entries never reach the main log; the main log holds only a redacted placeholder (event timestamp/level/priority/key, sender subsystem, flag "redacted"). The placeholder reveals THAT a secure event happened (`secure_placeholder=False` removes it). 0600/0700 are not enforceable on shared Android storage or FAT: the library warns once and the flag then gives routing and audit separation only. Not encryption.
- **Foreign/corrupt files:** a parseable file with a non-Standards schema is refused (E251), never overwritten; an unparseable file is moved aside (`*.corrupt-<ts>-<pid>`), not deleted.
- **Lock scope:** writers use `ResilientPIDLock` on the log path; readers take no lock and rely on atomic replace. Do not log to a path from code already holding its lock.
- **Crash window:** rows buffered in a killed process are lost; ERROR/FATAL entries are written immediately.
